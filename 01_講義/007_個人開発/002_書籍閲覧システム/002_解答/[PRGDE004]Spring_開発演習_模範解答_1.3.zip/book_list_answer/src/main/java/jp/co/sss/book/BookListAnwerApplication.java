package jp.co.sss.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookListAnwerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookListAnwerApplication.class, args);
	}

}
