package review_obj.list;

public class Animal extends Creature{
	/**
	 * コンストラクタ
	 * @param name
	 * @param species
	 * @param runSpeed
	 */
	public Animal(String name ,String species,Integer runSpeed) {
		super(name,species,runSpeed);
	}	
}
