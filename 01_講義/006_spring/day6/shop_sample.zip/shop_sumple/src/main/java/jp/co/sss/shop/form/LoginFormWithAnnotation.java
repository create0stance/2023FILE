package jp.co.sss.shop.form;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import jp.co.sss.shop.util.Login;

/**
 * 入力チェック付きLoginFormクラス
 *
 */
@Login
public class LoginFormWithAnnotation {
	
	// Integer型のフィールドの場合、未入力で送信された際に「Null」で送信される。
	// そのため未入力チェックは@NotNullで行う。
	@NotNull
	@Max(value = 999)
	private Integer userId;
	
	// String型のフィールドの場合、未入力で送信された際に「空文字(Blank）」で送信される。
	// そのため未入力チェックは、@NotBlankで行う。
	@NotBlank
	@Size(max = 16)
	// ^：行の先頭
	// [a-zA-Z0-9]：英数字
	// +：直前の文字の1回以上の繰り返し
	// *：直前の文字の0回以上の繰り返し
	@Pattern(regexp = "^[a-zA-Z0-9]+$")
	private String password;

	/**
	 * @return userId
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param userId セットする userId
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * @param password セットする password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}
