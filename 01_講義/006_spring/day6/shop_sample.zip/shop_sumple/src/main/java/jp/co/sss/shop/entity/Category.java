package jp.co.sss.shop.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
/**
 * カテゴリEntity
 *
 */
@Entity
@Table(name = "categories")
public class Category {
	
	/** カテゴリID */
    @Id
    private Integer id;

    /** カテゴリ名 */
    @Column
    private String name;
    
    /** カテゴリに属する商品の平均価格 */
    @Transient // 列に対応しないフィールドへ付与するアノテーション
	private Double catAvgPrice ;
   
    /** カテゴリに属する商品一覧  */
	@OneToMany(mappedBy="category")
	// 一対多の場合、OneToManyを使用
	// mappedBy="関連Entityの対象フィールド名"
	// 戻り値：List<関連Entityの型>
    private List<ItemWithCategory> items;
	
	/**
	 * カテゴリIDを取得
	 * @return カテゴリID
	 */
	public Integer getId() {
        return id;
    }
	
	/**
	 * カテゴリIDをセット
	 * @param id カテゴリID
	 */
    public void setId(Integer id) {
        this.id = id;
    }
    
    /**
     * カテゴリ名を取得
     * @return カテゴリ名
     */
    public String getName() {
        return name;
    }
    
    /**
     * カテゴリ名をセット
     * @param name カテゴリ名
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
	 * 商品一覧を取得
	 * @return items 商品Entity一覧
	 */
	public List<ItemWithCategory> getItems() {
		return items;
	}
	
	/**
	 * 商品一覧をセット
	 * @param items セットする商品一覧
	 */
	public void setItems(List<ItemWithCategory> categories) {
		this.items = categories;
	}
	
	/**
	 * 平均価格を整数で取得
	 * @return catAvgPrice
	 */
	public Integer getCatAvgPrice() {
		return (int)Math.round(catAvgPrice);
	}

	/**
	 * 平均価格をセット
	 * @param catAvgPrice セットする平均価格
	 */
	public void setCatAvgPrice(Double catAvgPrice) {
		this.catAvgPrice = catAvgPrice;
	}
}

