package jp.co.sss.shop.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.shop.entity.Category;//7章 外部キーによる条件検索 2．コントローラの編集 追記
import jp.co.sss.shop.entity.ItemWithCategory;//7章 外部キーによる条件検索 2．コントローラの編集 追記
import jp.co.sss.shop.repository.CategoryRepository;
import jp.co.sss.shop.repository.ItemWithCategoryRepository;

@Controller
public class ItemWithCategoryController {

	/** レポジトリ */
	@Autowired
	private ItemWithCategoryRepository repository;

	/** カテゴリテーブル用レポジトリ */
	@Autowired
	private CategoryRepository catReppository;

	/**
	 * 商品一覧表示
	 * @param model Model
	 * @return 商品一覧表示ビュー
	 */
	@RequestMapping("/items/findItemAndCategory")
	public String showItemAndCategoryList(Model model) {

		// 一覧を取得しリクエストスコープに保存
		model.addAttribute("items", repository.findAll());

		return "items/item_category_list";
	}

	/**
	 * 商品情報をカテゴリIDで絞り込み表示
	 * @param categoryId 絞り込むカテゴリID
	 * @param model リクエストスコープに保存
	 * @return 商品一覧表示ビュー
	 */
	@RequestMapping("/items/searchByCategoryId/{categoryId}")
	public String searchByCategoryId(
			// パスからカテゴリIDを取得
			@PathVariable Integer categoryId, Model model) {

		//パスで指定されたカテゴリIDを持つEntityを作成
		Category category = new Category();
		// 主キーをセット
		category.setId(categoryId);

		//カテゴリで絞り込み検索
		List<ItemWithCategory> items = repository.findByCategory(category);

		//検索結果をリクエストスコープに保存
		model.addAttribute("items", items);

		//商品一覧画面をリターン
		return "items/item_category_list";
	}

	/**
	 * カテゴリ一覧を商品情報と合わせて取得
	 * [補足]OneToMany
	 * @param model
	 * @return
	 */
	@RequestMapping("/items/findAllCategory")
	public String findAllCategory(Model model) {
		// カテゴリ一覧を所属する商品と合わせて一覧取得
		List<Category> cats = catReppository.findAll();
		// リクエストスコープに保存
		model.addAttribute("cats", cats);
		// カテゴリ一覧ページをリターン
		return "items/categories";
	}

	// EntityManager：EntityのDB登録などを管理する：
	@Autowired
	EntityManager entityManager;

	/**
	 * パスで指定されたIDの商品情報を表示
	 * ★NamedQuery使用
	 * @param id 商品ID
	 * @param model Model
	 * @return 商品一覧ページビュー
	 */
	@RequestMapping("/items/searchWithNamedQuery/{id}")
	public String searchWithNamedQuery(@PathVariable Integer id, Model model) {

		// java.persistence.Queryの作成：クエリ文を作成したり、実行したり出来る。
		// EntityManager.createNamedQueryメソッドにクエリ名を渡し取得。
		Query query = entityManager.createNamedQuery("findByIdNamedQuery");

		// パラメータ値をプレースホルダに埋め込む
		// setParameter("プレースホルダ名",値)
		query.setParameter("id", id);

		//クエリの実行結果をListで取得
		@SuppressWarnings("unchecked") // 未検査キャストの警告をチェックしない
		List<ItemWithCategory> itemList = query.getResultList();

		// リクエストスコープに変数名「items」で、Listを保存
		model.addAttribute("items", itemList);

		// 商品一覧ページビューをリターン
		return "items/item_category_list";
	}

	/**
	 * getSingleResultで1件取得する際の例
	 * ★NamedQuery使用：getSingleResultで1件取得
	 * @param id 商品ID
	 * @param model Model
	 * @return 商品詳細ページビュー
	 */
	@RequestMapping("/items/searchWithNamedSingleQuery/{id}")
	public String searchWithNamedSingleQuery(@PathVariable Integer id, Model model) {

		// java.persistence.Queryの作成：クエリ文を作成したり、実行したり出来る。
		// EntityManager.createNamedQueryメソッドにクエリ名を渡し取得。
		Query query = entityManager.createNamedQuery("findByIdNamedQuery");

		// パラメータ値をプレースホルダに埋め込む
		// setParameter("プレースホルダ名",値)
		query.setParameter("id", id);

		// getSingleResultで1件取得
		ItemWithCategory item;
		try {
			// Object型でリターンされるためキャスト
			item = (ItemWithCategory) query.getSingleResult();

		} catch (NoResultException e) {
			// レコードが存在しない場合、nullをセット
			item = null;
		}
		// コンソール出力し内容を確認
		System.out.println(item);

		// リクエストスコープに保存
		model.addAttribute("item", item);

		// 商品詳細ページビューをリターン
		return "items/item_category";
	}

	/**
	 * パスで指定されたIDの商品情報を表示
	 * ★Queryアノテーション使用
	 * @param id 商品ID
	 * @param model Model
	 * @return 商品一覧ページビュー
	 */
	@RequestMapping("/items/searchWithQuery/{id}")
	public String searchWithQuery(@PathVariable Integer id, Model model) {

		// Queryアノテーションを使用し、作ったJPQLを利用し、指定IDの商品を取得
		List<ItemWithCategory> items = repository.findByIdQuery(id);
		// リクエストスコープに保存
		model.addAttribute("items", items);

		// 商品一覧ページビューをリターン
		return "items/item_category_list";
	}

	/**
	 * パスで指定されたIDの商品情報を表示
	 * ★Queryアノテーションで1件取得する際の例
	 * @param id 商品ID
	 * @param model Model
	 * @return 商品一覧ページビュー
	 */
	@RequestMapping("/items/findByIdSingleQuery/{id}")
	public String findByIdSingleQuery(@PathVariable Integer id, Model model) {

		// Queryアノテーションを使用し作成したJPQLを利用し、指定IDの商品を取得
		ItemWithCategory item = repository.findByIdSingleQuery(id);
		// リクエストスコープに保存
		model.addAttribute("item", item);

		// 商品詳細ページビューをリターン
		return "items/item_category";
	}

	/**
	 *  平均価格より高額な商品一覧を表示
	 * @param model Model
	 * @return 商品一覧ページビュー
	 */
	@RequestMapping("/items/searchWithQuery")
	public String searchWithQuery(Model model) {
		
		// 平均価格より高額な商品Listを取得し、スコープに保存
		model.addAttribute("items", repository.findByPriceGreaterThanEqualAVGPriceQuery());
		
		// 補足：平均価格を取得し、スコープに保存
		model.addAttribute("priceAverage",repository.getAverege());
		
		// 商品詳細ページをリターン
		return "items/item_category_list";
	}

	/**
	 * [補足]カテゴリごとの平均価格を取得し降順ソート
	 * @param model Model
	 * @return 商品一覧ページビュー
	 */
	@RequestMapping("/items/catAvgSorted")
	public String catAvgSorted(Model model) {
		
		// 平均価格より高額な商品Listを取得し、スコープに保存
		model.addAttribute("catAvgSorted", repository.catAvgSorted());
		
		// 全件取得
		model.addAttribute("items", repository.findAll());

		// 商品詳細ページをリターン
		return "items/item_category_list";
	}
	
}
