package jp.co.sss.shop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jp.co.sss.shop.entity.Category;
import jp.co.sss.shop.entity.ItemWithCategory;

public interface ItemWithCategoryRepository
		extends JpaRepository<ItemWithCategory, Integer> {

	/**
	 * カテゴリで商品を絞り込む
	 * @param category カテゴリEntity
	 * @return 商品Entityリスト
	 */
	List<ItemWithCategory> findByCategory(Category category);

	/**
	 * 主キー検索し、Listで取得
	 * @param id 主キー
	 * @return List
	 */
	@Query("SELECT i FROM ItemWithCategory i WHERE i.id = :id")
	// メソッド名・・・任意のメソッド名
	// 引数・・・（@Param("プレースホルダ名") 引数（プレースホルダに埋め込む値）)
	public List<ItemWithCategory> findByIdQuery(@Param("id") Integer id);

	/**
	 * 主キー検索し1つのEntityを取得
	 * @param id 主キー
	 * @return 商品Entity
	 */
	@Query("SELECT i FROM ItemWithCategory i WHERE i.id = :id")
	public ItemWithCategory findByIdSingleQuery(@Param("id") Integer id);

	/**
	 * 平均価格より高額な商品一覧を取得
	 * @return 平均価格より高額な商品List
	 */
	@Query("SELECT i FROM ItemWithCategory i WHERE i.price >= " +
			"(SELECT AVG(i2.price) FROM ItemWithCategory i2) ORDER BY i.price")
	// SELECT * FROM items_with_categories WHERE price >= (SELECT AVG(price) from items_with_categories);
	public List<ItemWithCategory> findByPriceGreaterThanEqualAVGPriceQuery();

	/**
	 * 【補足】平均価格を取得
	 * @return 平均価格
	 */
	@Query("SELECT AVG(i.price) FROM ItemWithCategory i")
	Integer getAverege();
	
	/**
	 * カテゴリごとの平均価格を取得し降順ソート
	 * @return 取得結果List
	 */
	@Query("SELECT new ItemWithCategory(c.id,c.name,AVG(i.price)) FROM ItemWithCategory "
			+ "i INNER JOIN i.category c GROUP BY c.id,c.name "
			+ "ORDER BY AVG(i.price) DESC")
	// SELECT c.id,c.name,AVG(i.price) FROM items_with_categories i INNER JOIN categories c 
	//			ON i.category_id = c.id GROUP BY c.id,c.name ORDER BY AVG(i.price) DESC 
	List<ItemWithCategory> catAvgSorted();
}
