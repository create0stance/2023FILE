package jp.co.sss.shop.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import jp.co.sss.shop.entity.Item;

/**
 * 商品テーブルリポジトリ
 * 
 */
public interface ItemRepository extends JpaRepository<Item, Integer> {
	
	/*
	 * ★リポジトリ：
	 * ①指定したテーブルに対するCRUD処理を行う。
	 * ②JpaRepositoryを継承したインターフェイス
	 * ③JpaRepositoryのジェネリクス指定
	 * <関連Entityの型,関連Entityに定義した主キーフィールドの型>
	 */
	/*
	 * WHEREでの絞り込みやOrderでのソートなどは、
	 * 抽象メソッドをリポジトリにし、レコードを取得する。
	 * 
	 * ■メソッドの戻り値について
	 * ↓複数件レコードを取得するメソッド
	 * List<Entity> 等
	 * ↓1件取得するメソッド
	 * Entity 等
	 */

	/**
	 * 商品テーブルから全レコードを取得し、価格降順でソート
	 * @return 商品エンティティリスト
	 */
	// SELECT * FROM item order by price desc;
	List<Item> findAllByOrderByPriceDesc();
	
	/**
	 * 商品テーブルから価格でレコードを絞り込みエンティティリストで取得
	 * @param price 検索する価格
	 * @return 商品エンティティリスト
	 */
	// SELECT * FROM item WHERE price = 引数priceの値;
	List<Item> findByPrice(Integer price);
	
	/**
	 * 商品テーブルから商品名と価格でレコードを絞り込みエンティティリストで取得
	 * @param name 検索する名前
	 * @param price 検索する価格
	 * @return 商品エンティティリスト
	 */
	// SELECT * FROM item WHERE name=引数nameの値 AND price = 引数priceの値
	List<Item> findByNameAndPrice(String name, Integer price);
	 
	 /**
	  * 商品名に検索文字列が含まれる商品一覧を取得
	  * @param name 検索文字列
	  * @return 商品エンティティリスト
	  */
	 // SELECT * FROM item WHERE name LIKE "%name%"
	 List<Item> findByNameLike(String name);
	 
	 /**
	  * 商品名に検索文字列1または検索文字列2が含まれる商品一覧を取得
	  * @param n1 検索文字列1
	  * @param n2 検索文字列2
	  * @return 商品エンティティリスト
	  */
	 // SELECT * FROM item WHERE name LIKE "%n1%" OR name LIKE "%n2%"
	 List<Item> findByNameContainingOrNameContaining(String n1,String n2);
}
