package jp.co.sss.shop.util;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * ログインアノテーション
 *
 */
// ★@target：アノテーションをつける対象
// TYPE : クラス・インタフェース・アノテーション
// FIELD、METHOD、CONSTRUCTORなどがはある
// 今回はクラスに付与するためTYPEを指定
@Target({java.lang.annotation.ElementType.TYPE})

// ★@Retention：アノテーションの影響範囲
// SOURCE : アノテーションが、コンパイル時に破棄される
// CLASS(デフォルト) : classファイルに記録される。実行時は読み込まれない。
// RUNTIME : class ファイルに記録る。また、実行時JVMにアノテーションの情報が読み込まれる。
@Retention(RetentionPolicy.RUNTIME)

// ★@Documented：javadoc問うに記載される
@Documented

// ★@Constraint(validatedBy = {クラス指定})
// 制約内容の具体的なロジックを記述したクラスを指定する。
// @NotNull等の様に制約に追加される。
@Constraint(validatedBy = { LoginValidator.class })
public @interface Login {
	/*
	 * アノテーション型:クラスやフィールド、メソッドなどに付けられる注釈。
	 * コンパイラやツールに付加情報を伝える事が出来る。
	 * メンバの記述：型 メンバ名() 
	 * 変数のようなもの。デフォルト値を指定でき、@Login(massege = "上書きしたい文")等で、値をセットできる
	 */
	// 入力エラー時のメッセージ設定
	String message() default "{ ユーザID、もしくはパスワードが間違っています。}";
	
	// 作成したアノテーションの処理順を指定するグループ化ための宣言：必ず空の配列を指定。
	Class<?>[] groups() default {};
	
	//	チェック対象のオブジェクトになんらかのメタ情報を与えるための宣言：必ず空の配列を指定。
	Class<? extends Payload>[] payload() default {};
	
	// LoginFormWithValidationクラスのuserIdフィールド名
	// ※LoginFormWithValidationの初期化で使用する
	String fieldUserId() default "userId";
	
	// LoginFormWithValidationクラスのpasswordフィールド名
	String fieldPassword() default "password";

}
