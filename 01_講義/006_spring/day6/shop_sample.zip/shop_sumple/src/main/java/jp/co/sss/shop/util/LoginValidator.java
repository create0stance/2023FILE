package jp.co.sss.shop.util;

import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

/**
 * ログインバリデーター
 *  *
 */
public class LoginValidator implements ConstraintValidator<Login, Object> {

	/** LoginFormWithValidationクラスのusetIdフィールド名を保持 */
	private String userId;
	
	/** LoginFormWithValidationクラスのpasswordフィールド名を保持 */
	private String password;

	/**
	 * バリデーターの初期化
	 * アノテーション型クラスから値を取得し設定を行う
	 */
	@Override
	public void initialize(Login annotation) {
		// Loginアノテーションで指定した入力チェック対象のフィールド名をフィールドにセット
		this.userId = annotation.fieldUserId();
		this.password = annotation.fieldPassword();
	}

	/**
	 * 入力チェック処理メソッド
	 * @param form 入力チェック対象のクラス(LoginFormWithValidation)
	 * @param context ConstraintValidatorContext:バリデーション設定を操作するクラス
	 * @see ConstraintValidator
	 * @return エラーなし：true
	 */
	@Override
	public boolean isValid(Object form, ConstraintValidatorContext context) {
		// デフォルトのエラーメッセージを使わない設定
		context.getDefaultConstraintMessageTemplate();
		
		// Setter,Getterを直接使わずに、プロパティの値を設定したり取得したりするクラス
		BeanWrapper beanWrapper = new BeanWrapperImpl(form);
		
		// LoginFormWithValidationにセットされている値の取得
		// ※Object型で取得するため、キャストが必要
		Integer userId = (Integer) beanWrapper.getPropertyValue(this.userId);
		String password = (String) beanWrapper.getPropertyValue(this.password);
		
		// LoginFormWithValidationにセットされている値でバリデーションを行う
		if (!Objects.isNull(userId) && userId.equals(123) && "test123".equals(password)) {
			return true;
		} else {
			return false;
		}
	}

}
