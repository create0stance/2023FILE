package jp.co.sss.shop.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.form.LoginForm;
import jp.co.sss.shop.form.LoginFormWithAnnotation;
import jp.co.sss.shop.form.LoginFormWithValidation;
import jp.co.sss.shop.service.SessionService;
import jp.co.sss.shop.util.Util;

@Controller
public class SessionController {

	public SessionController() {
		System.out.println("SessionControllerが作成されました。");
	}

	/**
	 * ログインページの表示
	 * @return ログインページビュー
	 */
	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public String login() {
		return "session/login";
	}

	/**
	 * ログインフォームで入力された
	 * ユーザーIDを取得しコンソールに出力
	 * @param userId ユーザーID
	 * @return ログインページ
	 */
	@RequestMapping(path = "/doLogin", method = RequestMethod.GET)
	// パラメータ名と同名の変数を引数に置いとくと
	// パラメータ値が代入(バインド)される
	public String doLoginGet(Integer userId, String password) {
		System.out.println(password);
		System.out.println(userId);
		return "session/login";
	}

	/**
	 * POSTされたuserIdの値をコンソール出力
	 * @param userId
	 * @return ログインページビュー
	 */
	@RequestMapping(path = "/doLogin", method = RequestMethod.POST)
	public String doLoginPost(Integer userId) {

		System.out.println(userId);

		// ビューのパス指定
		//		return "session/login";
		return "redirect:/login";
	}

	/**
	 * ログインフォーム表示
	 * @return ログインフォームビューパス
	 */
	@GetMapping("loginUsingForm")
	public String loginUsingForm() {
		return "session/loginUsingForm";
	}

	/**
	 * コントローラーの引数にフォームクラスを使う
	 * @param form 
	 * Loginフォームから送信されたデータを保持するクラス
	 * @return ログインフォームビュー
	 */
	@PostMapping("doLoginUsingForm")
	public String doLoginUsingForm(LoginForm form) {
		System.out.println(form.getUserId());
		System.out.println(form.getPassword());

		return "session/loginUsingForm";
	}

	/**
	 * リクエストスコープに保存されたデータを使う
	 * @return
	 */
	@RequestMapping(path = "/loginOnRequest", method = RequestMethod.GET)
	public String loginOnRequest() {
		return "session/loginOnRequest";
	}

	/**
	 * ログインフォームから送信されたデータをビューに渡す
	 * @param model BindingAwareModelMap リクエストされたデータを管理するHashMap
	 * @param form ログインフォームから送信されたデータ
	 * @return ログインフォームビュー
	 */
	@RequestMapping(path = "/doLoginOnRequest", method = RequestMethod.POST)
	public String doLoginOnRequest(Model model, LoginForm form) {

		// 【この場合のModel実装クラス】BindingAwareModelMap
		// バインドされているオブジェクトをHashMapに保管し管理する
		// クラス名をキーとして値を保存する。

		// リクエストスコープにuserIdを保存
		model.addAttribute("userId", form.getUserId());

		// ビューへ処理を移行
		return "session/loginOnRequest";
	}

	/**
	 * sessionにフォームデータを保存する
	 * @return ログインフォームビューパス
	 */
	@RequestMapping(path = "loginOnSession", method = RequestMethod.GET)
	public String loginOnSession() {
		return "session/loginOnSession";
	}

	/**
	 * ログインフォームの送信データを受け取り
	 * ログイン可能ならSessionにuserIdを保存し
	 * TOPページへリダイレクト。
	 * ログイン不可なら、再度ログインページを表示
	 * @param form LoginFormクラス
	 * @param session HttpSession
	 * @return ビューパス
	 */
	@Autowired
	SessionService service;

	@RequestMapping(path = "doLoginOnSession", method = RequestMethod.POST)
	public String doLoginOnSession(LoginForm form, HttpSession session) {

		// ログインOKならsessionにuserIdを保存し、
		// TOPページへリダイレクト
		if (service.checkLogin(form.getUserId())) {
			// sessionに変数名(キー)userIdで入力されたIDを保存
			session.setAttribute("userId", form.getUserId());

			return "redirect:/";
		}

		return "session/loginOnSession";

	}

	/**
	 * sessionを破棄
	 * @param session
	 * @return
	 */
	@RequestMapping("logout")
	public String logout(HttpSession session) {
		// sessionを破棄
		session.invalidate();
		return "session/logout";
	}

	/**
	 * 入力チェック付きログインフォームを表示
	 * @param form ログインフォーム
	 * @return ログインフォーム
	 */
	@RequestMapping(path = "/loginWithValidation", method = RequestMethod.GET)
	public String loginWithValidation(
			// @ModelAttribute
			// ハンドラメソッドの処理前に、Modelに対象のオブジェクトが登録されているか検索する。
			// 無ければそのタイミングでオブジェクトをnewし、Modelに保存する
			// ※【重要】登録するキーについて
			// @ModelAttributeに属性名を指定しない場合、クラス名の頭文字が小文字のキーで検索・登録する
			@ModelAttribute LoginFormWithValidation form

	// 【補足】変数名(キー)を指定する場合の記載方法。上記は以下と同じ意味
	//			@ModelAttribute("loginFormWithValidation") LoginFormWithValidation form
	) {

		// ログインフォームビューをリターン
		return "session/loginWithValidation";
	}

	/**
	 * ログインフォームPOST処理
	 * @param form ログインフォーム
	 * @param result バリデーション結果保持クラス
	 * @param session セッション
	 * @param model Model
	 * @return  userId：123ならTOPページへリダイレクト、それ以外または入力エラーの場合、ログイン画面をリターン
	 */
	@RequestMapping(path = "/loginWithValidation", method = RequestMethod.POST)
	public String doLoginWithValidation(
			// バリデーション処理を行う場合、@Validを付与する
			@Valid @ModelAttribute LoginFormWithValidation form,
			// バリデーション結果を処理するため、BindingResult(バリデーション結果を保持するオブジェクト)を取得。
			// ※Formクラスより後に記載する！
			BindingResult result,
			// Sessionを利用するためHttpSessionを取得
			HttpSession session,
			// Modelに保存されている値を確認するためModelを取得
			Model model) {

		// リクエストスコープに保存されているデータをコンソールに出力
		Util.showModelInfoAndReturnMap(model);

		// BindingResultクラスのhasErrorsメソッドを利用し、入力エラーがあるか確認
		if (result.hasErrors()) {
			System.out.println("エラーがあります。");
			// エラーがあれば、ログインフォームを再度表示
			return "session/loginWithValidation";
		}

		// 入力されたuserIdが123の場合、sessionにキーuserIdで入力値を保存
		if (form.getUserId() == 123) {
			session.setAttribute("userId", form.getUserId());
			// TOPページへリダイレクト
			return "redirect:/";

		} else {
			// 123以外の入力であれば、ログインフォームを再度表示
			System.out.println("123以外が入力されました。");
			return "session/loginWithValidation";
		}
	}

	/**
	 * 独自例外処理：ログインフォームを表示
	 * @param form ログインフォーム
	 * @return ログインページ：ビュー
	 */
	@RequestMapping(path = "/loginWithAnnotation", method = RequestMethod.GET)
	public String loginWithAnnotation(
			// ビューにFormクラスを渡すためModelにFormクラスを追加
			@ModelAttribute LoginFormWithAnnotation form) {
		return "session/loginWithAnnotation";
	}


	/**
	 * 独自例外：ログインフォームPOST処理
	 * @param form ログインフォーム
	 * @param result バリデーション結果保持クラス
	 * @param session セッション
	 * @return  userId：123ならTOPページへリダイレクト、それ以外または入力エラーの場合、ログイン画面をリターン
	 */
	@RequestMapping(path = "/loginWithAnnotation", method = RequestMethod.POST)
	public String doLoginWithAnnotation(@Valid @ModelAttribute LoginFormWithAnnotation form, BindingResult result,
			HttpSession session) {
		
		// 入力エラーが無ければ、sessionにユーザーIDをセットし、TOPページへリダイレクト
		if (!result.hasErrors()) {
			session.setAttribute("userId", form.getUserId());
			return "redirect:/";
		}else {
			// 入力エラーがあれば、ログインページを表示
			return "session/loginWithAnnotation";
		}
	}

}
