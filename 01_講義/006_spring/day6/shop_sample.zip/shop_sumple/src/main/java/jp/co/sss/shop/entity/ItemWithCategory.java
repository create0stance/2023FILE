package jp.co.sss.shop.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "items_with_categories")
// ★NamedQuery：
// ①Entityに記載する
// ②name="任意のクエリ名"
// ③JPQL:
//		From句：「Entityの型 別名」で指定
//		SELECT句：「別名」=「*と同意」
//		WHERE句での条件指定「別名.フィールド名 = プレースホルダ」
@NamedQuery(name="findByIdNamedQuery",query="SELECT i FROM ItemWithCategory i WHERE i.id = :id")
public class ItemWithCategory {
	
	
	/**
	 * コンストラクタ
	 * ※引数ありのコンストラクタ作成時は引数なしコンストラクタの生成が必須！
	 */
	public ItemWithCategory() {}
	
	/**
	 * コンストラクタ
	 * @param categoryId カテゴリID
	 * @param categoryName カテゴリ名
	 * @param catAvgPrice カテゴリに属する商品の平均価格
	 */
	public ItemWithCategory(Integer categoryId,String categoryName,Double catAvgPrice) {
		// カテゴリEntityオブジェクトを生成し、値をセット
		Category category = new Category();
		category.setId(categoryId);
		category.setName(categoryName);
		category.setCatAvgPrice(catAvgPrice);
		// categoryフィールドにセット
		setCategory(category);
	}
	
	/** 商品ID */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_items_with_categories_gen")
	@SequenceGenerator(name = "seq_items_with_categories_gen", sequenceName = "seq_items_with_categories", allocationSize = 1)
	private Integer id;

	/** 商品名 */
	@Column
	private String name;

	/** 商品価格 */
	@Column
	private Integer price;
	
	/** カテゴリEntity */
	// ★多対一の関係性を示すアノテーション
	@ManyToOne
	// ★結合条件の指定
	// name="自テーブルの列名"
	// referencedColumnName="参照先Entityのフィールド名"
	@JoinColumn(name = "category_id",
				referencedColumnName = "id")
	private Category category;
	
	

	@Override
	public String toString() {
		String str = super.toString();
		str += "\nID：" + this.getId();
		str += "\n商品名：" + this.getName();
		str += "\n商品価格：" + this.getPrice();
		str += "\nカテゴリID：" +  this.getCategory().getId();
		str += "\nカテゴリ名：" +  this.getCategory().getName();
		return str;
	}
	/**
	 * 商品IDを取得
	 * @return 商品ID
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 商品IDをセット
	 * @param id 商品ID
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 商品名を取得
	 * @return 商品名
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * 商品名をセット
	 * @param name 商品名
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 商品価格を取得
	 * @return 商品価格
	 */
	public Integer getPrice() {
		return price;
	}
	/**
	 * 商品価格をセット
	 * @param price 商品価格
	 */
	public void setPrice(Integer price) {
		this.price = price;
	}

	/**
	 * 商品カテゴリを取得
	 * @return 商品カテゴリ
	 */
	public Category getCategory() {
		return category;
	}
	
	/**
	 * 商品カテゴリをセット
	 * @param category 商品カテゴリ
	 */
	public void setCategory(Category category) {
		this.category = category;
	}

	
}

