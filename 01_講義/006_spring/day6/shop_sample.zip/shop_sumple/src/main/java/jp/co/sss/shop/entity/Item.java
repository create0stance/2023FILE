package jp.co.sss.shop.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *商品テーブルEntity
 */
@Entity
// oracleで作成したテーブル名を指定
@Table(name="items")
public class Item {
	
	/** 商品ID */
	// 主キーフィールドに付与
	@Id
	// 値の作成方法の指定
	@GeneratedValue(
			// 戦略
			strategy = GenerationType.SEQUENCE,
			// 値ジェネレーター：ジェネレーター名で指定
			generator = "seq_items_gen")
	
	// シーケンスジェネレーターの設定
	@SequenceGenerator(
			// ジェネレーター名
			name = "seq_items_gen", 
			// シーケンス名(データベースで作成したシーケンス名）
			sequenceName = "seq_items",
			//増減値 (データベースのシーケンス 増減値に合わせる)
			allocationSize = 1
			)
	private Integer id;
	
	/** 商品名 */
	@Column
	private String name;
	
	/** 商品価格 */
	@Column
	private Integer price;
	
	/** Entity生成日時 */
	@Transient //テーブル列に存在しないフィールドには@Transientを付与する
	private Date date;
	
	/** コンストラクタ */
	public Item(){
		// Entity生成時に日時をセット
		this.date = new Date();
	}
	
	/**
	 * Entity生成日時を取得
	 * @return date Entity生成日時
	 */
	public Date getDate() {
		return date;
	}
	
	/**
	 * Entity生成日時をセット
	 * @param date Entity生成日時
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	
	/**
	 * 商品IDを取得
	 * @return id 商品ID
	 */
	public Integer getId() {
		return id;
	}
	
	/**
	 * 商品IDをセットする
	 * @param id セットする商品ID
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * 商品名を取得
	 * @return name 商品名
	 */
	public String getName() {
		return name;
	}
	/**
	 * 商品名をセット
	 * @param name セットする 商品名
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * 商品価格を取得する
	 * @return price 商品価格
	 */
	public Integer getPrice() {
		return price;
	}
	
	/**
	 * 商品価格をセットする
	 * @param price セットする商品価格
	 */
	public void setPrice(Integer price) {
		this.price = price;
	}
}
