package jp.co.sss.shop.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.entity.Category;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.form.ItemForm;
import jp.co.sss.shop.repository.CategoryRepository;
import jp.co.sss.shop.repository.ItemRepository;

@Controller
public class ItemRegistController {

	@Autowired
	ItemRepository itemRepo;

	@Autowired
	CategoryRepository cateRepo;

	//登録画面表示
	@RequestMapping("/regist/input")
	public String inputItem(@ModelAttribute ItemForm form) {
		System.out.println("input:" + form);
		return "items/regist_input";

	}

	//確認画面表示
	@RequestMapping("/regist/confirm")
	public String confirmItem(@Valid @ModelAttribute ItemForm form, BindingResult result) {
		if (result.hasErrors()) {
			System.out.println("back:" + form);
			return inputItem(form);//入力エラー時
		} else {
			System.out.println("check:" + form);
			return "items/regist_confirm";//確認画面遷移
		}

	}

	//登録処理
	//二重登録防止のためPRGパターンでの処理
	@RequestMapping(path = "/regist/create-item", method = RequestMethod.POST)
	public String exeRegistItem(ItemForm form) {

		//エンティティ生成
		Item item = new Item();
		item.setName(form.getName());
		item.setPrice(form.getPrice());
		Category category = cateRepo.getReferenceById(form.getCategoryId());
		item.setCategory(category);
		//コンソール表示
		System.out.println("regist:" + item);

		//登録
		itemRepo.save(item);

		return "redirect:/regist/complete";

	}

	//登録完了画面表示
	@RequestMapping("/regist/complete")
	public String completeRegistItem() {
		return "items/regist_complete";

	}

}
