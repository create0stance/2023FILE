package jp.co.sss.shop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.form.ItemForm;
import jp.co.sss.shop.repository.CategoryRepository;
import jp.co.sss.shop.repository.ItemRepository;

@Controller
public class ItemDeleteController {

	@Autowired
	ItemRepository itemRepo;

	@Autowired
	CategoryRepository cateRepo;

	//削除確認画面表示
	@RequestMapping("/delete/confirm/{id}")
	public String confirmItem(@PathVariable Integer id, @ModelAttribute ItemForm form) {

		/**ここに記述*/
		/**主キー検索してitemエンティティを取得*/

		/**itemエンティティからitemformへ値を移し替える*/

		return "items/delete_confirm";//確認画面遷移
	}

	//削除処理
	//二重送信防止のためPRGパターンでの処理
	@RequestMapping(path = "/delete/delete-item", method = RequestMethod.POST)
	public String exeDeleteItem(ItemForm form) {

		/**ここに記述*/
		/**itemエンティティを生成*/

		/**itemFormからitemエンティティへ値を移し替える*/

		/**削除処理*/

		return "";/**完了画面へリダイレクト*/

	}

	//削除完了画面表示
	@RequestMapping("/delete/complete")
	public String completeUpdateItem() {
		return "items/delete_complete";

	}

}
