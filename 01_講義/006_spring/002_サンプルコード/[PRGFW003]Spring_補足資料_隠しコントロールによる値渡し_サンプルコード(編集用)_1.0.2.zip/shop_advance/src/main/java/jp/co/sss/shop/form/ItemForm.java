package jp.co.sss.shop.form;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class ItemForm {

	@Max(value = 999)
	private Integer id;

	@NotBlank
	@Size(max = 25)
	private String name;

	@Digits(integer = 5, fraction = 0)
	@Min(1)
	@Max(99999)
	private Integer price;
	private Integer categoryId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	//ログ出力
	@Override
	public String toString() {
		return "フォーム：ItemForm [id=" + id + ", name=" + name + ", price=" + price + ", categoryId=" + categoryId + "]";
	}

}