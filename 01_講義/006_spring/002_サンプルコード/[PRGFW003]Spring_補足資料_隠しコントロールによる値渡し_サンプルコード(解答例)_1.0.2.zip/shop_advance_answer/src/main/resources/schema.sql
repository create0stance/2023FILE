CREATE TABLE categories (
  id NUMBER(3) PRIMARY KEY,
  name VARCHAR(100 CHARACTERS)
);
CREATE TABLE items (
  id NUMBER(3) PRIMARY KEY,
  name VARCHAR(100 CHARACTERS),
  price NUMBER(5) ,
  category_id NUMBER(3) NOT NULL REFERENCES categories(id)
  );

--コミットする。
COMMIT;
