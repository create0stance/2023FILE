-- seq_categories シーケンスを作成する。
CREATE SEQUENCE seq_categories NOCACHE;
CREATE SEQUENCE seq_items NOCACHE;

-- categories テーブルにレコードを追加する。
INSERT INTO categories VALUES (NEXT VALUE FOR seq_categories, '食料品');
INSERT INTO categories VALUES (NEXT VALUE FOR seq_categories, '文房具');
INSERT INTO categories VALUES (NEXT VALUE FOR seq_categories, '書籍');

-- items テーブルにレコードを追加する。
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'みかん', 100, 1);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '鉛筆', 200, 2);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'Java 参考書', 300, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'りんご', 250, 1);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'バナナ', 300, 1);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'いちご', 450, 1);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'ボールペン', 170, 2);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '消しゴム', 120, 2);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'ノート ', 150, 2);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'ペンケース', 800, 2);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '定規', 200, 2);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'Java プログラミング問題集', 2500, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, 'SQL 入門', 1500, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '明解 Spring Framework', 3500, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 1 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 2 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 3 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 4 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 5 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 6 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '長編歴史小説 第 7 巻', 1000, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '観光ガイドマップ東京編', 1300, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '観光ガイドマップ大阪編', 1300, 3);
INSERT INTO items VALUES (NEXT VALUE FOR seq_items, '観光ガイドマップ京都編', 1300, 3);

-- コミット
COMMIT;
