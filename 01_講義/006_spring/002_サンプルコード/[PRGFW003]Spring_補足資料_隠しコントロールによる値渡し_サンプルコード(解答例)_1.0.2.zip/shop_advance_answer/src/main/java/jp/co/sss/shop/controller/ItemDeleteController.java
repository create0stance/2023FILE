package jp.co.sss.shop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.entity.Category;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.form.ItemForm;
import jp.co.sss.shop.repository.CategoryRepository;
import jp.co.sss.shop.repository.ItemRepository;

@Controller
public class ItemDeleteController {

	@Autowired
	ItemRepository itemRepo;

	@Autowired
	CategoryRepository cateRepo;

	//削除確認画面表示
	@RequestMapping("/delete/confirm/{id}")
	public String confirmItem(@PathVariable Integer id, @ModelAttribute ItemForm form) {

		Item item = itemRepo.getReferenceById(id);
		form.setId(item.getId());
		form.setName(item.getName());
		form.setPrice(item.getPrice());
		form.setCategoryId(item.getCategory().getId());
		System.out.println("check:" + form);
		return "items/delete_confirm";//確認画面遷移
	}

	//削除処理
	//二重送信防止のためPRGパターンでの処理
	@RequestMapping(path = "/delete/delete-item", method = RequestMethod.POST)
	public String exeDeleteItem(ItemForm form) {

		//エンティティ生成
		Item item = new Item();
		item.setId(form.getId());
		item.setName(form.getName());
		item.setPrice(form.getPrice());
		Category category = cateRepo.getReferenceById(form.getCategoryId());
		item.setCategory(category);
		//ログ
		System.out.println("delete:" + item);
		//削除
		itemRepo.delete(item);

		return "redirect:/delete/complete";

	}

	//削除完了画面表示
	@RequestMapping("/delete/complete")
	public String completeUpdateItem() {
		return "items/delete_complete";

	}

}
