package jp.co.sss.shop.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.entity.Category;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.form.ItemForm;
import jp.co.sss.shop.repository.CategoryRepository;
import jp.co.sss.shop.repository.ItemRepository;

@Controller
public class ItemUpdateController {

	@Autowired
	ItemRepository itemRepo;

	@Autowired
	CategoryRepository cateRepo;

	//更新入力画面表示
	@RequestMapping("/update/input/{id}")
	public String inputItem(boolean backflg, @PathVariable Integer id, @ModelAttribute ItemForm form) {

		//一覧画面から遷移してきた場合
		if (!backflg) {
			Item item = itemRepo.getReferenceById(id);
			form.setId(item.getId());
			form.setName(item.getName());
			form.setPrice(item.getPrice());
			form.setCategoryId(item.getCategory().getId());
		}
		System.out.println("input:" + form);
		return "items/update_input";

	}

	//更新確認画面表示
	@RequestMapping("/update/confirm")
	public String confirmItem(@Valid @ModelAttribute ItemForm form, BindingResult result) {
		if (result.hasErrors()) {
			System.out.println("back:" + form);
			return inputItem(true, null, form);//入力エラー時
		} else {
			System.out.println("check:" + form);
			return "items/update_confirm";//確認画面遷移
		}
	}

	//更新処理
	//二重登録防止のためPRGパターンでの処理
	@RequestMapping(path = "/update/update-item", method = RequestMethod.POST)
	public String exeUpdateItem(ItemForm form) {

		//エンティティ生成
		Item item = new Item();
		item.setId(form.getId());
		item.setName(form.getName());
		item.setPrice(form.getPrice());
		Category category = cateRepo.getReferenceById(form.getCategoryId());
		item.setCategory(category);
		//ログ
		System.out.println("update:" + item);
		//更新
		itemRepo.save(item);

		return "redirect:/update/complete";

	}

	//更新完了画面表示
	@RequestMapping("/update/complete")
	public String completeUpdateItem() {
		return "items/update_complete";

	}

}
