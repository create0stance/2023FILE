
package jp.co.sss.training.lesson02_01;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0201Controller {

	@Autowired
	private TrainingUserRepository userRepository;

	@RequestMapping(path = "/lesson02_01/index")
	public String index(Model model) {
		model.addAttribute("users", userRepository.findAll());
		return "lesson02_01/index";
	}

}
