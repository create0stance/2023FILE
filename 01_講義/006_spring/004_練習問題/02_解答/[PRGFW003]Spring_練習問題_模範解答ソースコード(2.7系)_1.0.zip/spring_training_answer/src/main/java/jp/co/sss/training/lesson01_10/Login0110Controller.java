package jp.co.sss.training.lesson01_10;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.training.form.UserForm;

@Controller
public class Login0110Controller {

	@RequestMapping(path = "/lesson01_10/login")
	public String login() {
		return "lesson01_10/login";
	}

	@RequestMapping(path = "/lesson01_10/login", method = RequestMethod.POST)
	public String doLogin(UserForm loginForm, HttpSession session) {
		String userId = loginForm.getUserId();
		String password = loginForm.getPassword();
		if (userId != null && userId.length() > 0 && userId.equals(password)) {
			session.setAttribute("userId", userId);
			return "redirect:/lesson01_10/top";
		} else {
			return "lesson01_10/login";
		}
	}
	
	@RequestMapping(path = "/lesson01_10/top")
	public String top(HttpSession session) {
		return "lesson01_10/top";
	}

	@RequestMapping(path = "/lesson01_10/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "lesson01_10/login";
	}

}
