package jp.co.sss.training.lesson02_09;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.training.bean.UserBean;
import jp.co.sss.training.entity.TrainingUser;
import jp.co.sss.training.form.UserForm;
import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0209Controller {

	@Autowired
	private TrainingUserRepository userRepository;

	@RequestMapping(path = "/lesson02_09/edit")
	public String edit() {
		// 更新用のリンク画面を表示
		return "lesson02_09/index";
	}

	@RequestMapping(path = "/lesson02_09/update/input/{id}", method = RequestMethod.GET)
	public String update(@PathVariable Long id, Model model) {

		// 更新対象のユーザ情報を取得
		TrainingUser user = userRepository.getReferenceById(id);
		UserBean bean = new UserBean();
		// エンティティの値をBeanにコピー
		BeanUtils.copyProperties(user, bean);
		// リクエストスコープに情報を登録
		model.addAttribute("user", bean);
		
		// 編集用画面に遷移
		return "lesson02_09/edit";
	}

	@RequestMapping(path = "/lesson02_09/update/complete/{id}", method = RequestMethod.POST)
	public String updateComplete(@PathVariable Long id, UserForm form, Model model) {
		
		// 更新対象のユーザ情報を取得
		TrainingUser user = userRepository.getReferenceById(id);
		// フォームで受け取った値をエンティティにコピー
		BeanUtils.copyProperties(form, user, "id");
		// ユーザ情報を更新
		user = userRepository.save(user);
		
		UserBean userBean = new UserBean();
		// エンティティの値をBeanにコピー
		BeanUtils.copyProperties(user, userBean);
		// リクエストスコープに情報を登録
		model.addAttribute("user", userBean);
		
		// 詳細画面に遷移
		return "lesson02_09/show";
	}

}
