package jp.co.sss.training.lesson08_01;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.entity.TrainingUser;
import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0801Controller {

	@Autowired
	private TrainingUserRepository userRepository;

	@RequestMapping(path = "/lesson08_01/indexPaging")
	public String index(Model model,Pageable pageable) {
		//ユーザー情報を検索
		Page<TrainingUser> pageList = userRepository.findAll(pageable);
		//検索結果を保存するためのJavaBeans(リスト)	を用意
		List<TrainingUser> user0801List = pageList.getContent();

		//ユーザー情報をリクエストスコープに保存
		model.addAttribute("pages",pageList);
		model.addAttribute("users",user0801List);
		
		model.addAttribute("url","/lesson08_01/indexPaging");

		return "lesson08_01/index";
	}

}