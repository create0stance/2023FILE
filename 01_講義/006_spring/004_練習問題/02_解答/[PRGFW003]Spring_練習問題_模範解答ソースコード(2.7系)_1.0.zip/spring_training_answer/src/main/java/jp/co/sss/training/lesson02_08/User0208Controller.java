package jp.co.sss.training.lesson02_08;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.training.bean.UserBean;
import jp.co.sss.training.entity.TrainingUser;
import jp.co.sss.training.form.UserForm;
import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0208Controller {

	@Autowired
	private TrainingUserRepository trainingUserRepository;

	@RequestMapping(path = "/lesson02_08/new")
	public String newForm() {
		return "lesson02_08/new";
	}

	@RequestMapping(path = "/lesson02_08/create", method = RequestMethod.POST)
	public String create(UserForm userForm, Model model) {

		// フォームの値をエンティティにコピー
		TrainingUser trainingUser = new TrainingUser();
		BeanUtils.copyProperties(userForm, trainingUser);
		// 登録処理を実行
		trainingUser = trainingUserRepository.save(trainingUser);
		// エンティティの値をBeanにコピー
		UserBean bean = new UserBean();
		BeanUtils.copyProperties(trainingUser, bean);
		model.addAttribute("user", bean);

		// 詳細画面へ遷移
		return "lesson02_08/show";
	}

}
