package jp.co.sss.training.lesson06_02;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jp.co.sss.training.lesson06_01.Message0601Filter;

@Configuration
public class Filter0602Config implements WebMvcConfigurer {
	@Bean
	public FilterRegistrationBean<Message0601Filter> configMessage0601Filter() {
		FilterRegistrationBean<Message0601Filter> bean = new FilterRegistrationBean<Message0601Filter>();

		bean.setFilter(new Message0601Filter());
		bean.setOrder(1);
		return bean;
	}

	@Bean
	public FilterRegistrationBean<Message0602Filter> configMessage0602Filter() {
		FilterRegistrationBean<Message0602Filter> bean = new FilterRegistrationBean<Message0602Filter>();

		bean.setFilter(new Message0602Filter());
		bean.setOrder(2);
		return bean;
	}
}