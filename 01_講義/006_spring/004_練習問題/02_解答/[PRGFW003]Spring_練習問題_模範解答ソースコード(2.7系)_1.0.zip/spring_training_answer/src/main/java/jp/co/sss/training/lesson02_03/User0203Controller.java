package jp.co.sss.training.lesson02_03;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.bean.UserBean;
import jp.co.sss.training.entity.TrainingUser;
import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0203Controller {

	@Autowired
	private TrainingUserRepository userRepository;

	@RequestMapping(path = "/lesson02_03/index")
	public String index(Model model) {
		model.addAttribute("users", userRepository.findAll());
		return "lesson02_03/index";
	}

	@RequestMapping(path = "/lesson02_03/show/{id}")
	public String show(@PathVariable long id, Model model) {
		
		UserBean userBean = new UserBean();
		TrainingUser user = userRepository.getReferenceById(id);
		// データベースから取得した情報をBeanにコピー
		BeanUtils.copyProperties(user,userBean);
		model.addAttribute("user", userBean);
		
		return "lesson02_03/show";
	}

}
