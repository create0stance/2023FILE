package jp.co.sss.training.lesson04_03;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0403Controller {

	@Autowired
	private TrainingUserRepository userRepository;
	
    @RequestMapping(path = "/lesson04_03/index")
    public String index(Model model) {
        model.addAttribute("users", userRepository.findAll());
        return "lesson04_03/index";
    }

	@RequestMapping(path = "/lesson04_03/searchName")
	public String index(String keyword, Model model) {
		model.addAttribute("keyword", keyword);
		if (keyword != null && keyword.length() > 0) {
			keyword = "%" + keyword + "%";
		} else {
			keyword = "%";
		}

		// ユーザ名に基づいてユーザ一覧情報を検索
		model.addAttribute("users", userRepository.findByName(keyword));
		// ユーザ名に基づいてユーザの取得件数を検索
		model.addAttribute("count", userRepository.countByName(keyword));
		return "lesson04_03/index";
	}

}
