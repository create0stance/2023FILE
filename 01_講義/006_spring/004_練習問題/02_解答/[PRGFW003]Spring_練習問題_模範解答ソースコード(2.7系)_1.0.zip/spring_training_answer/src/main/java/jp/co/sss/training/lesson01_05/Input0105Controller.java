package jp.co.sss.training.lesson01_05;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Input0105Controller {

    @RequestMapping(path = "/lesson01_05/getForm")
    public String getForm() {
        return "lesson01_05/getForm";
    }

    @RequestMapping(path = "/lesson01_05/input", method = RequestMethod.GET)
    public String getInput(String inputText) {
    	System.out.println(inputText);
        return "lesson01_05/getForm";
    }


}
