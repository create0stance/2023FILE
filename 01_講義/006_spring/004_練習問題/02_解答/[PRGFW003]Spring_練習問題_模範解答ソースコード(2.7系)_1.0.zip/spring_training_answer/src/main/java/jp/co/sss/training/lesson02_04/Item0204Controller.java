package jp.co.sss.training.lesson02_04;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.ItemRepository;

@Controller
public class Item0204Controller {
    @Autowired
    private ItemRepository itemRepository;

    @RequestMapping(path = "/lesson02_04/index")
    public String hello(Model model) {
        model.addAttribute("items", itemRepository.findByPriceAndGenreId(200, 1));
        return "lesson02_04/index";
    }

}
