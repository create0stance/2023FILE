package jp.co.sss.training.lesson04_02;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class User0402Controller {

	@Autowired
	private TrainingUserRepository userRepository;

    @RequestMapping(path = "/lesson04_02/index")
    public String index(Model model) {
        model.addAttribute("users", userRepository.findAll());
        return "lesson04_02/index";
    }
    
    @RequestMapping(path = "/lesson04_02/searchName")
    public String searchName(String keyword, Model model) {
        model.addAttribute("keyword", keyword);
        if (keyword != null && keyword.length() > 0) {
            keyword = "%" + keyword + "%";
        } else {
            keyword = "%";
        }

        model.addAttribute("users", userRepository.findByName(keyword));
        return "lesson04_02/index";
    }

}
