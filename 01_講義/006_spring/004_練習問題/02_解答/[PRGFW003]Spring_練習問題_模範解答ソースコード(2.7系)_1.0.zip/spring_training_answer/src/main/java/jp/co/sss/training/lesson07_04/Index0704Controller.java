package jp.co.sss.training.lesson07_04;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Index0704Controller {

	@RequestMapping(path = "/lesson07_04/index")
	public String index(String keyword, Model model) {
		return "lesson07_04/index";
	}
}
