package jp.co.sss.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import jp.co.sss.training.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

	List<Item> findByPriceAndGenreId(int price, int genreId);	//	lesson03_03
	List<Item> findByPriceOrGenreId(int price, int genreId);	//	lesson03_04
	List<Item> findByOrderByPriceAsc();	//lesson03_05
	List<Item> findTop5ByOrderByPriceDesc();	//lesson03_06
	List<Item> findByNameStartingWith(String keyword);	//lesson03_07
}
