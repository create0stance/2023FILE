package jp.co.sss.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTrainingAnswerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTrainingAnswerApplication.class, args);
	}

}
