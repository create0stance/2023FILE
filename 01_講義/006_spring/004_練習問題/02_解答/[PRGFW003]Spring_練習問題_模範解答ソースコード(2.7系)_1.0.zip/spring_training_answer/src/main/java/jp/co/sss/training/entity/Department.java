package jp.co.sss.training.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "department")
public class Department {

	@Id
	@GeneratedValue
	private long id;

	@Column
	private String name;


	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
        return id;
    }

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
