package jp.co.sss.training.lesson02_06;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.training.entity.TrainingUser;
import jp.co.sss.training.form.LoginForm;
import jp.co.sss.training.repository.TrainingUserRepository;

@Controller
public class Login0206Controller {

	@Autowired
	private TrainingUserRepository userRepository;

	@RequestMapping(path = "/lesson02_06/login")
	public String login() {
		return "lesson02_06/login";
	}

	@RequestMapping(path = "/lesson02_06/login", method = RequestMethod.POST)
	public String doLogin(LoginForm loginForm, HttpSession session) {

		String userId = loginForm.getUserId();
		String password = loginForm.getPassword();
		TrainingUser user = userRepository.findByUserIdAndPassword(userId, password);

		if (user != null) {
			session.setAttribute("userId", userId);
			return "redirect:/lesson02_06/top";
		} else {
			return "lesson02_06/login";
		}

	}

	@RequestMapping(path = "/lesson02_06/top")
	public String top() {
		return "lesson02_06/top";
	}

	@RequestMapping(path = "/lesson02_06/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "lesson02_06/top";
	}

}
