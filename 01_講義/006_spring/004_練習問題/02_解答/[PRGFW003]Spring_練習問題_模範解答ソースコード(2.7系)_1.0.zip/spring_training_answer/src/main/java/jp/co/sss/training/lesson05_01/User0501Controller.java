package jp.co.sss.training.lesson05_01;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class User0501Controller {

	@RequestMapping(path = "/lesson05_01/new")
	public String newForm(@ModelAttribute User0501Form userForm) {
		return "lesson05_01/new";
	}

	@RequestMapping(path = "/lesson05_01/create", method = RequestMethod.POST)
	public String create(@Valid @ModelAttribute User0501Form userForm, BindingResult result, Model model) {
		if (result.hasErrors()) {
			for (ObjectError err : result.getAllErrors()) {
				model.addAttribute("formError", err.getDefaultMessage());
			}
			return "lesson05_01/new";
		} else {
			return "lesson05_01/result";
		}
	}

}
