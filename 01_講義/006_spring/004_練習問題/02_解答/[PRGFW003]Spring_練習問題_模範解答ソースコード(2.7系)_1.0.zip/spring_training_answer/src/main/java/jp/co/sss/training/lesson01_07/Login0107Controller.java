package jp.co.sss.training.lesson01_07;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Login0107Controller {

	@RequestMapping(path = "/lesson01_07/login")
	public String login() {
		return "lesson01_07/login";
	}

	@RequestMapping(path = "/lesson01_07/login", method = RequestMethod.POST)
	public String doLogin(String userId, String password) {
		if (userId != null  && userId.length() > 0 && userId.equals(password)) {
			return "redirect:/lesson01_07/top";
		} else {
			return "lesson01_07/login";
		}
	}

	@RequestMapping(path = "/lesson01_07/top")
	public String top() {
		return "lesson01_07/top";
	}

}
