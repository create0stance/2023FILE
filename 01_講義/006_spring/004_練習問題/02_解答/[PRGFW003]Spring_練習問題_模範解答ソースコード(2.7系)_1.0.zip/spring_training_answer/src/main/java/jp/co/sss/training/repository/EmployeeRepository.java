package jp.co.sss.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import jp.co.sss.training.entity.Department;
import jp.co.sss.training.entity.Employee;

@Component
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	List<Employee> findByDepartment(Department department);
	
	@Query("SELECT e FROM Employee e WHERE e.userId LIKE :keyword")
	List<Employee> findByName(@Param("keyword") String keyword);

}
