package jp.co.sss.training.lesson01_09;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Request0109Controller {
	@RequestMapping(path = "/lesson01_09/input")
	public String input() {
		return "lesson01_09/input";
	}

	@RequestMapping(path = "/lesson01_09/result")
	public String result(String keyword, Model model) {
		model.addAttribute("keyword", keyword);
		return "lesson01_09/result";
	}
}
