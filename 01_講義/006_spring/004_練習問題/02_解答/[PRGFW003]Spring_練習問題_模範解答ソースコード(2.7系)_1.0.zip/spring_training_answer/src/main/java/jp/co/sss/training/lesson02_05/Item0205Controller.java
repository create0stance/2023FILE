package jp.co.sss.training.lesson02_05;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.ItemRepository;

@Controller
public class Item0205Controller {
    @Autowired
    private ItemRepository itemRepository;

    @RequestMapping(path = "/lesson02_05/index")
    public String hello(Model model) {
        model.addAttribute("items", itemRepository.findByPriceOrGenreId(200, 2));
        return "lesson02_05/index";
    }

}
