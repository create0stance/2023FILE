package jp.co.sss.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jp.co.sss.training.entity.TrainingUser;

public interface TrainingUserRepository extends JpaRepository<TrainingUser, Long> {
	TrainingUser findByUserIdAndPassword(String userId, String password);

	@Query("SELECT u FROM TrainingUser u WHERE u.userId LIKE :keyword")
	List<TrainingUser> findByName(@Param("keyword") String keyword);

	@Query("SELECT COUNT(u) FROM TrainingUser u WHERE u.userId LIKE :keyword")
	int countByName(@Param("keyword") String keyword);

}
