package jp.co.sss.training.lesson03_02;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.entity.Department;
import jp.co.sss.training.entity.Employee;
import jp.co.sss.training.repository.EmployeeRepository;

@Controller
public class Employee0302Controller {

	@Autowired
	private EmployeeRepository employeeRepository;

	@RequestMapping(path = "/lesson03_02/index/{departmentId}")
	public String index(@PathVariable Long departmentId, Model model) {

		// 外部参照先テーブルのエンティティとなるDepartmentのオブジェクトを生成
		Department department = new Department();

		// Departmentオブジェクト内のIDフィールドにパラメータの値を設定
		department.setId(departmentId);

		// Departmentオブジェクト内のIDフィールドを使用した条件検索を実行
		List<Employee> employee = employeeRepository.findByDepartment(department);

		// 検索結果をリクエストスコープに保存
		model.addAttribute("employee", employee);
		return "lesson03_02/index";
	}

}
