package jp.co.sss.training.lesson02_02;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.ItemRepository;

@Controller
public class Item0202Controller {
    @Autowired
    private ItemRepository itemRepository;

    @RequestMapping(path = "/lesson02_02/index")
    public String hello(Model model) {
        model.addAttribute("items", itemRepository.findByOrderByPriceAsc());
        return "lesson02_02/index";
    }

}
