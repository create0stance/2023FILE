package jp.co.sss.training.lesson08_02;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class HelloInterceptor {
	
	@Before("execution(* jp.co.sss.training.lesson06_03.*.*(..))")
    public void before(JoinPoint jp) {
        System.out.println("リクエストを処理します");
    }

}
