package jp.co.sss.training.lesson02_10;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.bean.FoodBean;
import jp.co.sss.training.entity.Food;
import jp.co.sss.training.form.FoodForm;
import jp.co.sss.training.repository.FoodRepository;

@Controller
public class Food0210Controller {

	@Autowired
	private FoodRepository foodRepository;

	@RequestMapping(path = "/lesson02_10/index")
	public String list(Model model) {
		// 全件検索を実行
		model.addAttribute("foods", foodRepository.findAll());
		// 一覧画面へ遷移
		return "lesson02_10/index";
	}

	@RequestMapping(path = "/lesson02_10/search")
	public String search(Model model, String name) {
		// あいまい検索を実行
		model.addAttribute("foods", foodRepository.findByNameContaining(name));
		// 一覧画面へ遷移
		return "lesson02_10/index";
	}

	@RequestMapping(path = "/lesson02_10/create/input")
	public String createInput() {
		// 登録画面へ遷移
		return "lesson02_10/create_input";
	}

	@RequestMapping(path = "/lesson02_10/create/complete")
	public String createComplete(FoodForm foodForm) {

		// フォームの値をエンティティにコピー
		Food food = new Food();
		BeanUtils.copyProperties(foodForm, food, "id");
		// 登録処理を実行
		foodRepository.save(food);

		// 登録処理完了画面に遷移
		return "lesson02_10/complete";

	}

	@RequestMapping(path = "/lesson02_10/update/input/{id}")
	public String updateInput(@PathVariable Long id, Model model) {

		// 更新対象の情報を検索
		Food food = foodRepository.getReferenceById(id);

		// 取得した情報をBeanにコピー
		FoodBean bean = new FoodBean();
		BeanUtils.copyProperties(food, bean);

		// Beanの情報をリクエストスコープに登録
		model.addAttribute("food", bean);

		// 更新画面へ遷移
		return "lesson02_10/update_input";
	}

	@RequestMapping(path = "/lesson02_10/update/complete/{id}")
	public String updateComplete(@PathVariable Long id, FoodForm foodForm) {

		// 更新対象の情報を取得
		Food food = foodRepository.getReferenceById(id);

		// フォームの値をエンティティにコピー
		BeanUtils.copyProperties(foodForm, food, "id");
		// 更新処理を実行
		foodRepository.save(food);

		// 登録処理完了画面に遷移
		return "lesson02_10/complete";
	}

	@RequestMapping(path = "/lesson02_10/delete/complete/{id}")
	public String deleteComplete(@PathVariable Long id) {

		// IDを基に削除処理を実行
		foodRepository.deleteById(id);

		// 削除処理完了画面へ遷移
		return "lesson02_10/complete";
	}

}
