package jp.co.sss.training.lesson02_11;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.training.repository.ItemRepository;

@Controller
public class Item0211Controller {
    @Autowired
    private ItemRepository itemRepository;

    @RequestMapping(path = "/lesson02_11/index")
    public String hello(Model model) {
        model.addAttribute("items", itemRepository.findTop5ByOrderByPriceDesc());
        return "lesson02_11/index";
    }

}
