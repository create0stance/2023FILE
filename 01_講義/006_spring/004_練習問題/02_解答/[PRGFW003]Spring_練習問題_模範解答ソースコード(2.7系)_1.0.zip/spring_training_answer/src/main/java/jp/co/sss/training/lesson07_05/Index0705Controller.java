package jp.co.sss.training.lesson07_05;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Index0705Controller {

	@RequestMapping(path = "/lesson07_05/index")
	public String index() {
		return "lesson07_05/index";

	}

	@RequestMapping(path = "/lesson07_05/new")
	public String newForm() {
		return "lesson07_05/new";

	}
}
