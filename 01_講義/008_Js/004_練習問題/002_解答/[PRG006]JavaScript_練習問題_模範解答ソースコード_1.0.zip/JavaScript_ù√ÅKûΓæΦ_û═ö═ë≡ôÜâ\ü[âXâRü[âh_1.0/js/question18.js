function showDetail() {
  var detail = document.getElementById("detail");
  detail.innerHTML = '産地:青森県<br>糖度:13度';
}

function hideDetail() {
  var detail = document.getElementById("detail");
  detail.innerHTML = '';
}