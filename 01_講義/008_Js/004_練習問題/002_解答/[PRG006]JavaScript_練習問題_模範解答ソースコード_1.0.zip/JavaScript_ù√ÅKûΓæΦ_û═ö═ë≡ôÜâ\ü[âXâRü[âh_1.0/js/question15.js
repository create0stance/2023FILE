function getText() {
  var message = document.getElementById('message');
  alert(message.textContent);
}