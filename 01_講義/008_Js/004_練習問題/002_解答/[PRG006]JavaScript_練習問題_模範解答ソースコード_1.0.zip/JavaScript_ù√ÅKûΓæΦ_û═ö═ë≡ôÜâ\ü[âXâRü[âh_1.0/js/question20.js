function changeClassValue() {
  var message = document.getElementById('block');
  message.setAttribute('class', 'change');
}