function tax(price){
  return price * 1.08;
}
