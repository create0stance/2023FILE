function showMessage() {
  var message = document.messageForm.message.value;
  alert(message);
}