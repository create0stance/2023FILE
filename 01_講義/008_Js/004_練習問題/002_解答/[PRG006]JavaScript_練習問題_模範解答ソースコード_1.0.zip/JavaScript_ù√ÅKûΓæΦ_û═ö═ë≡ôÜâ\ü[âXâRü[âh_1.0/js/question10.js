function stringCheck(str) {
  if(str.match(/^[0-9]+$/)){
    return true;
  }else{
    return false;
  }
}
