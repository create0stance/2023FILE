function controlForm() {
  var message = document.messageForm.message.disabled = true;
}