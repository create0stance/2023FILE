function getClassValue() {
  var message = document.getElementById('block');
  alert('class属性の値は「' + message.getAttribute('class') + '」です。');
}