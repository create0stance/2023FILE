function replaceText(newMessage) {
  var message = document.getElementById('message');
  message.innerHTML = '<a href=\'http://www.3sss.co.jp/tis/\'>' + newMessage + '</a>';
}