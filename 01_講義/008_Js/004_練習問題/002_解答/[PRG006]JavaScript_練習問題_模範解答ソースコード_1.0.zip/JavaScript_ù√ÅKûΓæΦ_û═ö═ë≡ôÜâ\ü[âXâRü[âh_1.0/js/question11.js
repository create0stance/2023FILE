function showCalc() {
  alert(100 * 50);
}
