document.write('<h1>');
document.write('Hello world!');
document.write('</h1>');