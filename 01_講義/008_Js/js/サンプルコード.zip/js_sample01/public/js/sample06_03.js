var num = 10;
if (num > 0) {
  alert(num + 'は正の数です。');
} else if (num < 0) {
  alert(num + 'は負の数です。');
} else {
  alert('0です。');
}
