var age = 30;
if (age >= 20) {
  alert(age + '歳は成人です。');
}
