var season = ['Spring', 'Summer', 'Fall', 'Winter'];
//alert(season[1]);
console.log("seasonの要素数は、"+season.length);
season.forEach((element, index) => {
	console.log(index);
	console.log(element);
 });
 
 for (let i = 0; i < season.length; i++) {
  	console.log(i);
	console.log(season[i]);
}

