function convertCtoF(c) {
  var f = 9 / 5 * c + 32;
  return f;
}

alert('摂氏20度は、華氏' + convertCtoF(20) + '度に該当します。');
alert('摂氏30度は、華氏' + convertCtoF(30) + '度に該当します。');
