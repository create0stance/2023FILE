var result1 = 'Hello' + 'World';
var result2 = '1' + '2';
var result3 = '1' + 2;
var result4 = 1 + 2;
alert(result1 + '\n' + result2 + '\n' + result3 + '\n' + result4);

let n = 1;
let d = 1.0;
let strOne = '1';
let nullVal = null;
let zero = 0;
let blank = "";
let undefinedVal ;
console.log("1と'1'を比較");
console.log(n == strOne);
console.log(n === strOne);
// 1と1.0は同じ数値型のため比較した場合、trueとなる。
console.log(n == d);
console.log(n === d);
// 空文字とゼロは等価比較の場合、true
console.log(blank == zero);
console.log(blank === zero);
// nullとゼロは等価比較の場合、true
console.log(nullVal == undefinedVal);
console.log(nullVal === undefinedVal);
