var age = 10;
if (age >= 20) {
  alert(age + '歳は成人です。');
} else {
  alert(age + '歳は未成年です。');
}
