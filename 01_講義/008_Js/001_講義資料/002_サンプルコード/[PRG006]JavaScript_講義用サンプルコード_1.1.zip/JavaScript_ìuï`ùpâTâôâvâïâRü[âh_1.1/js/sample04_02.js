var season = ['Spring', 'Summer', 'Fall', 'Winter'];
alert(season[1]);
