function showDialog() {
  alert(document.form.name.value + 'さん、こんにちは！');
}
