package lesson04;

public class Practice0402 {
    public static void main(String[] args) {

        // コメント下に1行処理を追記してください。

//        System.out.println("変数numの値は" + num + "です。");
    }
}
