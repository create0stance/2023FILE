package lesson03;

public class Practice0305 {
    public static void main(String[] args) {
    }
}
