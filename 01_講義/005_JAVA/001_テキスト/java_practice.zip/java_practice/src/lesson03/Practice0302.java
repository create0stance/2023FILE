package lesson03;

public class Practice0302 {
    public static void main(String[] args) {
        System.out.println("Javaは楽しいです。");
        System.out.println(123);
    }
}
