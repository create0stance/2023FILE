package lesson03;

public class Practice0304 {
    public static void main(String[] args) {
    }
}
