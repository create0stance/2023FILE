package review_obj;

/**
 * キャラクタークラス
 *
 */
public class Character {



}
