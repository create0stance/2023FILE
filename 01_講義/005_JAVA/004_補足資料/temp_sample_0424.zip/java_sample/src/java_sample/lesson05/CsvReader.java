package java_sample.lesson05;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class CsvReader {
	private static long startTime;

	private static long endTime;

	public static void main(String[] args) throws IOException {

		// 計測開始
		startTime = System.nanoTime();
		loadFileScanner("student.csv");
		// loadFileBufferedReader("student.csv");

		// 計測終了
		endTime = System.nanoTime();

		// 実行時間をミリ秒で表示
		System.out.println((double) (endTime - startTime) / 1000000);

	}

	/**
	 * CSVをBufferedReaderで処理する
	 * @throws IOException
	 */
	static void loadFileBufferedReader(String csvPath) throws IOException {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(csvPath)))) {
			// 1行の文字列を代入する変数
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
		}
	}

	/**
	 * CSVをScannerで処理する
	 * @throws FileNotFoundException
	 */
	static void loadFileScanner(String csvPath) throws FileNotFoundException {
		Scanner scanner = new Scanner(new File(csvPath));
		while (scanner.hasNext()) {
			String line = scanner.nextLine();
			System.out.println(line);
		}
	}

}
