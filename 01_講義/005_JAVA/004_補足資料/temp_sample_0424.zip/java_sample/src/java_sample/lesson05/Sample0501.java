// パッケージ名の指定
package java_sample.lesson05;

// クラスファイルを読み込み使えるようにする
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Sample0501 {
	public static void main(String[] args) throws IOException {
		// ★クラス：
		//		・機能で分類し書き分けられたプログラム。
		//		・様々な機能(メソッド)などが書かれている。
		
		// ★オブジェクト：
		//		・書かれたプログラム(機能=メソッドなど)を使える状態にしたもの。
		//		・new クラス名()でオブジェクトが作られ、プログラムが使えるようになる。（メモリ上にロードされる。インスタンスともいう。）
		
		// ★変数へオブジェクトを代入する 
		//		・オブジェクトは変数に代入し、その機能を利用する。(例外もある）
		//		・生成されたオブジェクトを変数に代入する際にも、型の指定が必要。
		// 		・型指定はクラス名となる。

		System.out.println("文字列を入力してください。");

		// BufferedReaderオブジェクトを生成し、変数readerに代入
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		// BufferedReaderのreadlineメソッドを利用し、入力された文字列を読み込み変数strに代入
		// ※改行コードが入力されるまで、処理がストップする
		String str = reader.readLine();
		
		System.out.println(str + "が入力されました。");

		knowMechanism();
	}

	private static void knowMechanism() throws IOException {
		boolean doLoop = true;
		while (doLoop) {
			// InputStreamを使う
			//			useInputStream();
			// InputStreamReader
			useStreamReader();
		}
	}

	private static void useBufferedReader() throws IOException {
	
		// InputStreamオブジェクトを取得：バイトストリームで文字列を1バイトずつ読み込む。
		InputStream in = System.in;
		
		// InputStreamReaderオブジェクトを生成：文字ストリームへ変換し1文字ずつ。
		InputStreamReader streamReader = new InputStreamReader(in);
		
		// BufferedReaderオブジェクトを生成：文字ストリームから、効率的に文字をまとめて読み込む
		BufferedReader reader = new BufferedReader(streamReader);
		
		// BufferedReaderのreadlineメソッドを利用し、入力された文字列を読み込み変数strに代入
		// ※改行コードが入力されるまで、処理がストップする
		// ※例外IOExceptionが発生する可能性のあるメソッドのため例外処理が必要
		String str = reader.readLine();
		
		System.out.println("入力された文字列：" + str);
		
	}

	/**
	 * InputStreamクラスで文字列を取得
	 * @throws IOException
	 */
	private static void useInputStream() throws IOException {
		/*
		 * InputStream:
		 *	・入力された文字列を1バイトの連続したバイトコードとして読み込む
		 */
		// InputStreamをSystemクラスから取得
		InputStream in = System.in;
		// 入力文字列を1バイトずつ取得し10進数で取得
		int byteCode = in.read();
		// バイトコードを出力
		System.out.println("バイトコード：" + byteCode);
		// バイトコードをcharに変換すると、アスキーコードに対応した1文字に変換される。
		System.out.println("文字へ変換：" + (char) byteCode);
		// ※日本語等は、1文字2バイトなので正しく取得できない
	}

	/**
	 * InputStreamReaderで文字列データを取得
	 * @throws IOException
	 */
	private static void useStreamReader() throws IOException {
		/*
		 * InputStreamReader：
		 * バイトストリームを読み込み文字ストリームへ変換する。
		 * バイトストリーム：1バイトごとの連続したデータ
		 * 文字ストリーム：1文字ごとの連続したデータ
		 */
		// InputStreamReaderオブジェクトを生成
		InputStreamReader streamReader = new InputStreamReader(System.in);
		// 文字列データを1文字ずつ文字コードで取得
		int aschiiCode = streamReader.read();
		System.out.println("文字コード：" + aschiiCode);
		// 文字コードをcharに変換すると、アスキーコードに対応した1文字に変換される。
		System.out.println("文字へ変換：" + (char) aschiiCode);

		// 文字列をまとめて処理する場合の記載例
		//		int aschiiCode2;
		//		while((aschiiCode2 = streamReader.read()) != 13 ) {
		//			System.out.println("文字コード：" + aschiiCode2);
		//			// 文字コードをcharに変換すると、アスキーコードに対応した1文字に変換される。
		//			System.out.println("文字へ変換：" + (char) aschiiCode2);
		//		}

	}

}
