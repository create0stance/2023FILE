// クラスが所属されるパッケージ指定
package java_sample.lesson03;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

/**
 * 
 * クラス定義
 *
 */
public class Sample0303 {

	/**
	 * メインメソッド
	 * プログラム実行時の最初に実行される
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// 記載したプログラムが実行される
		
		// コンソールに文字列を出力する
		System.out.println("ようこそ！Javaへ！！");
		
		/*
		 * 現在の標準出力先を保持する
		 */
		PrintStream sysOut = System.out;
		
		/*
         * 標準出力の出力先をファイルに切り変える
         */
        FileOutputStream fos = new FileOutputStream("out.txt");
        PrintStream ps = new PrintStream(fos);
        System.setOut(ps); 

        // 出力する
        System.out.println("ファイルへ書き込む！");

        // ファイルをクローズ
        ps.close();
        fos.close();

        /*
         * 標準出力をデフォルトに戻す
         */
        System.setOut(sysOut);
	}

}
