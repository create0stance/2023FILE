package review;

import java.io.BufferedReader;
import java.util.Scanner;

public class Day2 {
	public static void main(String[] args) {
		System.out.println((byte)911100);
		byte b = -128;
		System.out.println((byte)0);
		Scanner scanner = new Scanner(System.in); 
		scanner.nextLine();
		BufferedReader br;
	}
}
