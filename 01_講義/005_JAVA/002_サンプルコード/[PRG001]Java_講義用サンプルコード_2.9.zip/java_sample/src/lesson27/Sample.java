package lesson27;

public class Sample {
    public static void main(String[] args) {
        Integer.parseInt("abc");
    }
}
