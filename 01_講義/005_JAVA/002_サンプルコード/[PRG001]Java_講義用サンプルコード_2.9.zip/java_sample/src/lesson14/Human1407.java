package lesson14;

/**
 * 人間クラス
 */
public class Human1407 {
    /**
     * 趣味を伝える
     *
     * @return 趣味
     */
    String[] tellHobbies() {
        String[] hobbies = {"ランニング","映画鑑賞","読書"};
        return hobbies;
    }
}

