package lesson14;

/**
 * 携帯電話クラス
 */
public class Phone1405 {
        /** 機種名 */
        String phoneName;
}

