package lesson14;

/**
 * 人間クラス
 */
public class Human1405 {
    /**
     * 携帯電話を購入
     *
     * @param p 携帯電話
     */
    void buyPhone(Phone1405 p) {
        System.out.println(p.phoneName + "を購入しました。");
    }
}
