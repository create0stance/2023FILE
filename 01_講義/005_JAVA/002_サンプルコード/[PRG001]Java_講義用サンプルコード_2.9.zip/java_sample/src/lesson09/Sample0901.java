package lesson09;

public class Sample0901 {
    public static void main(String[] args) {
        // iが5未満の場合、繰り返す
        for (int i = 0; i < 5; i++) {
            System.out.println("こんにちは");
        }
        System.out.println("繰り返しが終了しました。");
    }
}
