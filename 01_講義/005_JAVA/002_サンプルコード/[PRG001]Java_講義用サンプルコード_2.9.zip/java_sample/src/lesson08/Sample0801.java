package lesson08;

public class Sample0801 {
    public static void main(String[] args) {
        int a = 20;
        int b = 40;

        System.out.println("a:" + a + " b:" + b);
        System.out.println("a == b:" + (a == b));
        System.out.println("a != b:" + (a != b));
        System.out.println("a < b:" + (a < b));
        System.out.println("b < a:" + (b < a));
        System.out.println("a >= 10:" + (a >= 10));
        System.out.println("a >= 20:" + (a >= 20));
    }
}
