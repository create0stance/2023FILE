package lesson04;

public class Sample0402 {

    public static void main(String[] args) {
    	int num = 2;

        System.out.println("変数numの値は" + num + "です。");

        // 新しい変数の値を代入
        num = 4;

        // 変更した値を出力
        System.out.println("変更後の変数numの値は" + num + "です。");

    }
}
