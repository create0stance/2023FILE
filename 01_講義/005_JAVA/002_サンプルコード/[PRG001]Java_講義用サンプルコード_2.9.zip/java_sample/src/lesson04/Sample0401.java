package lesson04;

public class Sample0401 {
    public static void main(String[] args) {
        // int型の変数numを宣言
        int num;
        // numに2を代入
        num = 2;
        // numの値を出力
        System.out.println("変数numの値は" + num + "です。");
    }
}
