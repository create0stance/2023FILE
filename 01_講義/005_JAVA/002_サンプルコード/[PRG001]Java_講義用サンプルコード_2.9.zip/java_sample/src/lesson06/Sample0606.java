package lesson06;

public class Sample0606 {
    public static void main(String[] args) {
        double dnum1 = 170.5;
        double dnum2 = 65.3;

        System.out.println("身長は" + dnum1 + "cmです。");
        System.out.println("体重は" + dnum2 + "kgです。");

        int inum1 = (int) dnum1;
        int inum2 = (int) dnum2;

        System.out.println("身長は" + inum1 + "cm です。");
        System.out.println("体重は" + inum2 + "kg です。");
    }
}
