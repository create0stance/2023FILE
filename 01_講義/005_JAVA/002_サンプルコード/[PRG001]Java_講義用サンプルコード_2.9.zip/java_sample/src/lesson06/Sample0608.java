package lesson06;

public class Sample0608 {
    public static void main(String[] args) {
        int inum1 = 6;
        int inum2 = 4;

        double dnum = inum1 / inum2;

        System.out.println("6÷4 は" + dnum + "です。");

    }
}
