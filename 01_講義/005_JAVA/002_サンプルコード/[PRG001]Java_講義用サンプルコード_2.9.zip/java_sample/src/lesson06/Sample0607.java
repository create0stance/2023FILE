package lesson06;

public class Sample0607 {
    public static void main(String[] args) {
        int width = 5;
        double height = 2.5;

        // int型とdouble型の数値の演算
        System.out.println("四角形の面積は" + (width * height) + "cm2です。");
    }
}
