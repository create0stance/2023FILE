package lesson06;

public class Sample0605 {
    public static void main(String[] args) {
        int inum1 = 170;
        int inum2 = 65;

        System.out.println("身長は" + inum1 + "cmです。");
        System.out.println("体重は" + inum2 + "kgです。");

        // サイズが大きい型に代入
        double dnum1 = inum1;
        double dnum2 = inum2;

        System.out.println("身長は" + dnum1 + "cmです。");
        System.out.println("体重は" + dnum2 + "kgです。");
    }
}
