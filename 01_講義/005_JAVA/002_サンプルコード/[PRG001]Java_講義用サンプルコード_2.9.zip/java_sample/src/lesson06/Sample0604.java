package lesson06;

public class Sample0604 {
    public static void main(String[] args) {
        System.out.println("2*10は" + 2 * 10 + "です。");
        System.out.println("2+10は" + 2 + 10 + "です。");
    }
}
