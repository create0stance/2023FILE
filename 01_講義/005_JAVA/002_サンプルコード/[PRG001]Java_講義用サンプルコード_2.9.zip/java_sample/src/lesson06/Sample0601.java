package lesson06;

public class Sample0601 {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 3;

        // 算術演算子を使った演算
        System.out.println("num1+num2は" + (num1 + num2) + "です。");
        System.out.println("num1-num2は" + (num1 - num2) + "です。");
        System.out.println("num1*num2は" + (num1 * num2) + "です。");
        System.out.println("num1/num2は" + (num1 / num2) + "です。");
        System.out.println("num1%num2は" + (num1 % num2) + "です。");
    }
}
