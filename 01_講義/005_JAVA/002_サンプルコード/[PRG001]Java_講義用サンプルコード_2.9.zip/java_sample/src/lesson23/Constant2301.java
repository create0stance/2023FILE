package lesson23;

/**
 * 定数クラス
 */
public class Constant2301 {
    public static final String POLICE = "警察官";
    public static final String TEACHER = "教師";
    public static final String CHEF = "料理人";
}
