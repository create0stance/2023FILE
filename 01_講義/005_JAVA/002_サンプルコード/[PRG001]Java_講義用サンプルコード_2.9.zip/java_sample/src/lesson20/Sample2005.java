package lesson20;

public class Sample2005 {
    public static void main(String[] args) {
    	// 携帯電話クラスのオブジェクトを生成
        Phone2005 p = new Phone2005();
        // Phoneクラスのshow()を呼び出す。
        p.show();

        // スマートフォンクラスのオブジェクトを生成
        SmartPhone2005 sp = new SmartPhone2005();
        // SmartPhoneクラスのshow()を呼び出す。
        sp.show();
    }
}
