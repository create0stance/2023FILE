package lesson20;

/**
 * スマートフォンクラス
 */
public class SmartPhone2004 extends Phone2004 {
    /**
     * 通信量を2倍に設定
     */
    public void doubleData() {
        data *= 2;
    }
}
