package lesson20;

/**
 * スマートフォンクラス
 */
public class SmartPhone2002 extends Phone2002 {
	/**
     * コンストラクタ
     */
	public SmartPhone2002() {
        System.out.println("SmartPhoneクラスのコンストラクタが呼ばれました。");
    }
	public void method() {
		System.out.println("I do nothing, but I can make your project looks better");
	}

}
