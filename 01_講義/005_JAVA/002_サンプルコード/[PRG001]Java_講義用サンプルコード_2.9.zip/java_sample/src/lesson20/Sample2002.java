package lesson20;

public class Sample2002 {
    public static void main(String[] args) {
    	// スマートフォンクラスのオブジェクトを生成
        SmartPhone2002 sp = new SmartPhone2002();
        sp.method();
    }
}
