package lesson20;

/**
 * スマートフォンクラス
 */
public class SmartPhone2001 extends Phone2001 {

    public void smartPhoneFunction() {
        System.out.println("スマートフォンの機能を利用しました。");
    }

}
