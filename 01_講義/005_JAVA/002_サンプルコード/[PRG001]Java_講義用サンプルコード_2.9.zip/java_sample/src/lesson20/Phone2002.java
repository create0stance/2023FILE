package lesson20;

/**
 * 携帯電話クラス
 */
public class Phone2002 {
	/**
     * コンストラクタ
     */
    public Phone2002() {
        System.out.println("Phoneクラスのコンストラクタが呼ばれました。");
    }
}
