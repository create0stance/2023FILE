package lesson20;

public class Sample2003 {
    public static void main(String[] args) {
        // スマートフォンクラスのオブジェクトを生成
        SmartPhone2003 sp = new SmartPhone2003();
        sp.method();
    }
}
