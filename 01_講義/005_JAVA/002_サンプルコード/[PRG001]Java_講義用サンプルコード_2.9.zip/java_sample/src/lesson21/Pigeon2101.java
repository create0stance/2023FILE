package lesson21;

/**
 * 鳩クラス（具象クラス）
 */
public class Pigeon2101 extends Animal2101 {
    /**
     * 鳴くメソッド（具象メソッド）
     */
    @Override
    public void bark() {
        System.out.println("ポッポー");
    }
}
