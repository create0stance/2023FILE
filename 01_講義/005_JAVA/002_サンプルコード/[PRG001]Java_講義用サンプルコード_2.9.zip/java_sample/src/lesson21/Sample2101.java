package lesson21;

public class Sample2101 {
    public static void main(String[] args) {
    	// Pigeon2101クラスのオブジェクトを生成
        Pigeon2101 pigeon = new Pigeon2101();
        // 鳴き声を表示
        pigeon.bark();
        // 挨拶を表示
        pigeon.greet();

        // Lion2101クラスのオブジェクトを生成
        Lion2101 lion = new Lion2101();
        // 鳴き声を表示
        lion.bark();
        // 挨拶を表示
        lion.greet();
    }
}
