package lesson07;

public class Sample0704 {
    public static void main(String[] args) {
        // 配列を初期化
        int[] height = { 162, 177, 154, 185 };

        // 配列要素の長さを調べる
        System.out.println("身体測定をした人数は" + height.length + "人です。");
    }
}
