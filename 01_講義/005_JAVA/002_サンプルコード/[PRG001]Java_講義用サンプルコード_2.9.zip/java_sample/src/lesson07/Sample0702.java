package lesson07;

public class Sample0702 {
    public static void main(String[] args) {
        // 配列を初期化
        int[] height = { 162, 177, 154, 185 };

        System.out.println("3人目の身長は" + height[2] + "cmです。");
    }
}
