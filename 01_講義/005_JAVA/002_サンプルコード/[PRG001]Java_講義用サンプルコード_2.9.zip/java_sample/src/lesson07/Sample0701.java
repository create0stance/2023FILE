package lesson07;

public class Sample0701 {
    public static void main(String[] args) {
        // 配列を準備
        int[] height = new int[4];

        // 要素に値を代入
        height[0] = 162;
        height[1] = 177;
        height[2] = 154;
        height[3] = 185;

        System.out.println("1人目の身長は" + height[0] + "cmです。");
    }
}
