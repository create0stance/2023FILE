package lesson03;

public class Sample0305 {
    public static void main(String[] args) {
        System.out.print("こんにちは！");
        System.out.print("よろしくお願いします。");
    }
}