package lesson03;

public class Sample0304 {
    public static void main(String[] args) {
        System.out.println("こんにちは！");
        System.out.println("よろしくお願いします。");
    }
}
