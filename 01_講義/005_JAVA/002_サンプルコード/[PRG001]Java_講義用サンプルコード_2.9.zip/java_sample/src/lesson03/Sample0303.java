package lesson03;

public class Sample0303 {
    public static void main(String[] args) {
        System.out.println("ようこそJavaへ！");
    }
}
