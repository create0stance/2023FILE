package lesson03;

public class Sample0302 {
    public static void main(String[] args) {
        System.out.println("ようこそJavaへ！"); // 修正箇所①：「"」を追記
    }
} // 修正箇所②：クラスブロックの綴じ括弧「}」を追記

