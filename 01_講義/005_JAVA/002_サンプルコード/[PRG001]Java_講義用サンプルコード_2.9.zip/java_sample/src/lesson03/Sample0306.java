package lesson03;

public class Sample0306 {
    public static void main(String[] args) {
        System.out.println('J');
        System.out.println("Javaを学ぼう！");
        System.out.println(123);
    }
}
