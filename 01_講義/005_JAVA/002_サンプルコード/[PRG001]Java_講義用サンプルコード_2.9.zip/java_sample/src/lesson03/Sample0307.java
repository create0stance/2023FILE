package lesson03;

public class Sample0307 {
	public static void main(String[] args) {
		System.out.println("円マーク：¥¥");
		System.out.println("ダブルクォーテーション：\"");
	}
}
