package lesson03;

public class Sample0308 {
    public static void main(String[] args) {
        // 各アルファベットを8進数形式で指定
        System.out.println("文字コードでAという文字を出力：\101");
        System.out.println("文字コードでaという文字を出力：\141");
    }
}
