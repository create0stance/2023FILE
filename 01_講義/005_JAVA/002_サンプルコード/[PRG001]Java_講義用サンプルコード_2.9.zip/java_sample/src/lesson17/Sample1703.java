package lesson17;

public class Sample1703 {
    public static void main(String[] args) {
        // 犬クラスのオブジェクトを生成してコンストラクタ（引数あり）を呼び出す
        Dog1703 dog = new Dog1703(2,"秋田犬");

        // 性別と犬種の値を出力
        dog.show();
    }
}

