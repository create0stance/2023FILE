package lesson13;

/**
 * 携帯電話クラス
 */
public class Phone1302 {
    /** 携帯電話の料金 */
    int fee;
}
