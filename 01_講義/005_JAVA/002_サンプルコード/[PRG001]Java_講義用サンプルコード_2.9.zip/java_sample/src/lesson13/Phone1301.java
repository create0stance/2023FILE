package lesson13;

/**
 * 携帯電話クラス
 */
public class Phone1301 {
    /** 携帯電話の料金 */
    int fee;

    /** 携帯電話のデータ通信量 */
    double data;
}
