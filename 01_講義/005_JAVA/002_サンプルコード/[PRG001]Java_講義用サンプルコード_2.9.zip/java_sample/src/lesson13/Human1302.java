package lesson13;

/**
 * 人間クラス
 */
public class Human1302 {
    /** 名前 */
    String name;

    /** 所持している携帯電話 */
    Phone1302 phone;
}
