package lesson24.a;

/**
 * 携帯電話クラス
 */
public class Phone2401 {
    /** 料金 */
    private int fee;
    /** データ通信量 */
    private double data;

    public void method() {
    	System.out.println(fee + data);
    }
}
