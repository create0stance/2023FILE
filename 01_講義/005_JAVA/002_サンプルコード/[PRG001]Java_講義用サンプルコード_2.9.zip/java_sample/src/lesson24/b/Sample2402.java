package lesson24.b;

import lesson24.a.Phone2401;

public class Sample2402 {
    public static void main(String[] args) {
    	// 携帯電話クラスのオブジェクトを生成
        Phone2401 phone = new Phone2401();
        lesson24.c.Phone2401 phone1 = new lesson24.c.Phone2401();

        phone.method();
        phone1.method();
    }
}
