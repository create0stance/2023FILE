package lesson24.b;

public class Sample2401 {
    public static void main(String[] args) {
    	// 携帯電話クラスのオブジェクトを生成
        lesson24.a.Phone2401 phone = new lesson24.a.Phone2401();
        phone.method();
    }
}
