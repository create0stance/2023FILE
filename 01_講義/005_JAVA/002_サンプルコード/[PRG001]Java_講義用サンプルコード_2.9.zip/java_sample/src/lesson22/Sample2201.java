package lesson22;

public class Sample2201 {
    public static void main(String[] args) {
        // 犬クラスに対する操作
        Dog2201 dog = new Dog2201();
        dog.bark();
        dog.walk();

        // 猫クラスに対する操作
        Cat2201 cat = new Cat2201();
        cat.bark();
        cat.walk();
    }
}
