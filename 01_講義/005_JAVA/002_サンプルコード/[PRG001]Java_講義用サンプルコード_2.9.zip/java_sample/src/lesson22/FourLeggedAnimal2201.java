package lesson22;

/**
 * 四足歩行の動物インターフェイス
 */
public interface FourLeggedAnimal2201 {
    /**
     * 歩く
     */
    void walk();
}
