package lesson22;

/**
 * 鳴く動物インターフェイス
 */
public interface BarkingAnimal2201 {
    /**
     * 鳴き声を表示
     */
    void bark();
}
