package Chap14_06;

/**
 * 第14章<br>
 * 問題14-6<br>
 * <br>
 * 設問内容は同パッケージ内のDVDPlayerTester.javaに記載
 *
 * @author System Shared
 */

// プレイヤー インタフェースPlayer
public interface Player {
	void play(); // ○再生
	void stop(); // ○停止
}
