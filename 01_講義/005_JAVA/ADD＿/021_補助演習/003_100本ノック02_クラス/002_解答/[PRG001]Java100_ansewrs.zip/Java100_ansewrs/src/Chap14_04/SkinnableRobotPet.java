package Chap14_04;

import Chap14_02.Skinnable;

/**
 * 第14章<br>
 * 問題14-4<br>
 * <br>
 * 設問内容は同パッケージ内のSkinnableRobotPetTester.javaに記載
 *
 * @author System Shared
 */

// 着せかえ可能なロボット型ペットクラスSkinnableRobotPet
public class SkinnableRobotPet extends RobotPet implements Skinnable {
	private int skin; //スキン

	//コンストラクタ
	public SkinnableRobotPet(String name, String masterName, int skin) {
		super(name, masterName); //スーパークラスのコンストラクタ
		this.skin = skin;
	}

	//スキン変更
	public void changeSkin(int skin) {
		this.skin = skin;
	}

	//現在のスキンを表示
	public void printSkin() {
		switch (skin) {
		case BLACK:
			System.out.print("黒");
			break;
		case RED:
			System.out.print("赤");
			break;
		case GREEN:
			System.out.print("緑");
			break;
		case BLUE:
			System.out.print("青");
			break;
		case LEOPARD:
			System.out.print("豹柄");
			break;
		}
	}
}