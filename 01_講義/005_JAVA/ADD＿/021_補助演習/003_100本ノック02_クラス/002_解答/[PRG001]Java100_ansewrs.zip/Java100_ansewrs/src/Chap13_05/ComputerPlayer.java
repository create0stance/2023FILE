package Chap13_05;

import java.util.Random;

/**
 * 第13章<br>
 * 問題13-5<br>
 * <br>
 * 設問内容は同パッケージ内のPlayer.javaに記載
 *
 * @author System Shared
 */

// ジャンケン・コンピュータプレイヤークラス
public class ComputerPlayer extends Player {
	private static Random rand;

	static {
		rand = new Random();
	}

	// --- 手を決定（乱数として生成する） ---//
	public int nextHand() {
		return rand.nextInt(3);
	}
}
