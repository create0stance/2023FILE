package
Chap10_07;
import java.util.Scanner;
/**
 *問題10-7のメインメソッド
 *
 * <実行例>xの値～a[3]まではすべて入力した値。<br>
 * xの値：1<br>
 * yの値：2<br>
 * zの値：3<br>
 * 配列aの要素数：4<br>
 * a[0]5<br>
 * a[1]6<br>
 * a[2]7<br>
 * a[3]8<br>
 * x, yの最小値は1です。<br>
 * x, yの最大値は2です。<br>
 * x, y, zの最小値は1です。<br>
 * x, y, zの最大値は3です。<br>
 * 配列aの最小値は5です。<br>
 * そのインデックスは｛0 ｝です。<br>
 * 配列aの最大値は8です。<br>
 * そのインデックスは｛3 ｝です。<br>
 * <br>
 * @author System Shared
 */

public class MinMaxTester {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("xの値：");
		int x = stdIn.nextInt();
		System.out.print("yの値：");
		int y = stdIn.nextInt();
		System.out.print("zの値：");
		int z= stdIn.nextInt();

		System.out.print("配列aの要素数：");
		int num = stdIn.nextInt();
		int[] a = new int[num];			// 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("a[" + i + "]");
			a[i] = stdIn.nextInt();
		}

		System.out.printf("x, yの最小値は%dです。 \n", MinMax.min(x, y));
		System.out.printf("x, yの最大値は%dです。 \n", MinMax.max(x, y));

		System.out.printf("x, y, zの最小値は%dです。 \n", MinMax.min(x, y, z));
		System.out.printf("x, y, zの最大値は%dです。 \n", MinMax.max(x, y, z));

		System.out.printf("配列aの最小値は%dです。 \n", MinMax.min(a));

		int xmin[] = MinMax.minIndexArray(a);
		System.out.print("そのインデックスは｛");
		for (int i = 0; i < xmin.length; i++){
			System.out.print(xmin[i] + " ");
		}
		System.out.println("｝です。");

		System.out.printf("配列aの最大値は%dです。 \n", MinMax.max(a));

		int xmax[] = MinMax.maxIndexArray(a);
		System.out.print("そのインデックスは｛");
		for (int i = 0; i < xmax.length; i++) {
			System.out.print(xmax[i] + " ");
		}
		System.out.println("｝です。");
		
		stdIn.close();
	}
}
