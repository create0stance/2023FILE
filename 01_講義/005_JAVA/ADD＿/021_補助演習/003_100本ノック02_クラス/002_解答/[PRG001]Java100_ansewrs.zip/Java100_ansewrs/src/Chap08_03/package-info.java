/**
 * JavaPracticeChap08_04<br>
 * 第8章 クラスの基本<br>
 * @author SystemShared
 */
package 
Chap08_03;
