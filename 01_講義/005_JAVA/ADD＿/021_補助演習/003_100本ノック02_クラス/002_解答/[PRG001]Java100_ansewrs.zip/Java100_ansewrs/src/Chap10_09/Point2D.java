package
Chap10_09;
import java.util.GregorianCalendar;
import static java.util.GregorianCalendar.*;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-9<br>
 * int型のX座標とY座標とで表される2次元座標クラスを作成せよ。<br>
 * 座標の一方の値もしくは両方の値を指定しなくてもインスタンスを生成できるものとする（指定されなかった値は0にすること）。<br>
 * なお、インスタンス生成の累計回数が、プログラム実行開始日と等しいとき（たとえば2010年10月3日に実行している場合は、<br>
 * 3個目のインスタンスの生成時）に、『当たり！！今日3個目の座標が生成されました。』と表示すること（改行文字も出力する。<br>
 * <br>
 * 『当たり！！今日（現在の日付）個目の座標が生成されました。』となる<br>
 * 2009年8月6日に実行した結果<br>
 * <実行例><br>
 * 0 (0,0)<br>
 * 1 (0,0)<br>
 * 2 (0,0)<br>
 * 3 (0,0)<br>
 * 4 (0,0)<br>
 * 当たり！！今日6個目の座標が生成されました。<br>
 * 5 (0,0)<br>
 * 6 (0,0)<br>
 * 7 (0,0)<br>
 * 8 (0,0)<br>
 * 9 (0,0)<br>
 * 10 (0,0)<br>
 * 11 (0,0)<br>
 * 12 (0,0)<br>
 * 13 (0,0)<br>
 * 14 (0,0)<br>
 * 15 (0,0)<br>
 * 16 (0,0)<br>
 * 17 (0,0)<br>
 * 18 (0,0)<br>
 * 19 (0,0)<br>
 * 20 (0,0)<br>
 * 21 (0,0)<br>
 * 22 (0,0)<br>
 * 23 (0,0)<br>
 * 24 (0,0)<br>
 * 25 (0,0)<br>
 * 26 (0,0)<br>
 * 27 (0,0)<br>
 * 28 (0,0)<br>
 * 29 (0,0)<br>
 * 30 (0,0)<br>
 * 31 (0,0)<br>
 * 32 (0,0)<br>
 * 33 (0,0)<br>
 * 34 (0,0)<br>
 * 35 (0,0)<br>
 * 36 (0,0)<br>
 * 37 (0,0)<br>
 * 38 (0,0)<br>
 * 39 (0,0)<br>
 * <br>
 * @author System Shared
 */

// 『当たり』付き2次元座標クラスPoint2D
public class Point2D {
	private static int counter = 0;			// 何番までの識別番号を与えたか
	private static int day;					// 今日の日

	private int x = 0;						// X座標
	private int y = 0;						// Y座標

	//--- クラス初期化子 ---//
	static {
		GregorianCalendar today = new GregorianCalendar();		// 現在の日時
		day = today.get(DATE);									// todayの日
	}

	//--- インスタンス初期化子 ---//
	{
		if (++counter == day) {
			System.out.print("当たり！！");
			System.out.printf("今日%d個目の座標が生成されました。 \n", counter);
		}
	}

	//--- コンストラクタ ---//
	public Point2D() {
	}
	public Point2D(int x) {
		this.x = x;
	}
	public Point2D(int x, int y) {
		this.x = x;
		this.y = y;
	}

	//--- X座標のゲッタ ---//
	public int getX() {
		return x;
	}
	//--- Y座標のゲッタ ---//
	public int getY() {
		return y;
	}

	//--- 最後に与えた識別番号を取得する ---//
	public static int getCounter() {
		return counter;
	}

	//--- 文字列表現"(x, y)"を返す ---//
	@Override
	public String toString() {
		return "(" + x + "," + y + ")";
	}
}
