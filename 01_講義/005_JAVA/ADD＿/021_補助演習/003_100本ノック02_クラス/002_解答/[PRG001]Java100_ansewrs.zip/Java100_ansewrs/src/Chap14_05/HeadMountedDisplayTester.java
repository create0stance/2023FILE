package Chap14_05;

import Chap14_01.Wearable;
import Chap14_02.Skinnable;

/**
 * 第14章<br>
 * 問題14-5<br>
 * 着せかえ可能で装着可能なヘッドマウントディスプレイクラスHeadMountedDisplayを作成せよ。<br>
 * インターフェースWearableとSkinnableを実装すること。<br>
 * <br>
 * <実行例><br>
 * ディスプレイを付けました。<br>
 * ディスプレイを外しました。<br>
 * LEOPARD DISPLAY<br>
 * ディスプレイを付けました。<br>
 * ディスプレイを外しました。<br>
 * BLACK DISPLAY<br>
 * <br>
 *
 * @author System Shared
 */

// ヘッドマウントディスプレイクラス HeadMountedDisplayの利用例
public class HeadMountedDisplayTester {
	public static void main(String[] args) {
		HeadMountedDisplay hmd = new HeadMountedDisplay();
		hmd.putOn(); // 装着
		hmd.putOff(); // 解除
		hmd.changeSkin(Skinnable.LEOPARD); // スキンを変更
		hmd.putSkin(); // スキンを表示

		Wearable w = (Wearable) hmd;

		w.putOn(); // 装着
		w.putOff(); // 解除

		Skinnable s = (Skinnable) hmd;
		s.changeSkin(Skinnable.BLACK); // スキンを変更

		hmd.putSkin(); // スキンを表示
	}
}
