package
Chap09_05;
import java.util.Scanner;
/**
 * 銀行口座クラス[Ver.2]の利用例（その他）
 *
 * <実行例(AccountTester2)><br>
 * 口座情報を入力せよ。<br>
 * 名    義 ： 佐藤一郎<br>
 * 番    号 ： 111111<br>
 * 残    高 ： 99999<br>
 * 開設年 ： 2009<br>
 * 開設月 ： 1<br>
 * 開設日 ： 1<br>
 * 口座基本情報 ： {佐藤一郎, 111111, 99999}<br>
 * 開設日 ： 2009年01月01日(木)<br>
 * <br>
 * @author SystemShared
 */

public class AccountTester2 {
	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.println("口座情報を入力せよ。");
			System.out.print("名    義 ： ");
			String name = stdIn.next();
			System.out.print("番    号 ： ");
			String no = stdIn.next();
			System.out.print("残    高 ： ");
			long balance = stdIn.nextLong();
			System.out.print("開設年 ： ");
			int y = stdIn.nextInt();
			System.out.print("開設月 ： ");
			int m = stdIn.nextInt();
			System.out.print("開設日 ： ");
			int d = stdIn.nextInt();

			Account2 a = new Account2(name, no, balance, new Day(y, m, d));

			System.out.println("口座基本情報 ： " + a);
			System.out.println("開設日 ： " + a.getOpenDay().toString());

			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能文字は半角数字のみです。");
			System.exit(0);
		}
	}
}