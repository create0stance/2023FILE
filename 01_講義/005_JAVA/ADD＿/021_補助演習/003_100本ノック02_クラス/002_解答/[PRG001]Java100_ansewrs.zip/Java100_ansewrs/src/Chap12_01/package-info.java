/**
 * JavaPracticeChap12_01<br>
 * 第12章 クラスの派生と多相性<br>
 * @author SystemShared
 */
package
Chap12_01;
