package
Chap09_02;
import java.util.Scanner;
/**
 * ２次元座標クラスCoordinate [Ver.2] の利用例
 *
 * <実行例(CoordinateTester)>
 * 座標pを入力せよ。
 * X座標 ： 2
 * Y座標 ： 3
 * p = (2.0, 3.0)
 * qをpと同じ座標として作りました。
 * q = (2.0, 3.0)
 * pとqは等しいです。
 * c1   = (0.0, 0.0)
 * c2   = (0.0, 0.0)
 * a[0] = (0.0, 0.0)
 * a[1] = (0.0, 0.0)
 * a[2] = (0.0, 0.0)
 *
 */

public class CoordinateTester {
	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.println("座標pを入力せよ。");
			System.out.print("X座標 ： ");
			double x = stdIn.nextDouble();
			System.out.print("Y座標 ： ");
			double y = stdIn.nextDouble();

			Coordinate p = new Coordinate(x, y);
			System.out.println("p = " + p);

			Coordinate q = new Coordinate(p);
			System.out.println("qをpと同じ座標として作りました。");
			System.out.println("q = " + q);

			if (p.equalto(q)) {
				System.out.println("pとqは等しいです。");
			} else {
				System.out.println("pとqは等しくありません。");
			}
			Coordinate c1 = new Coordinate();
			Coordinate c2 = new Coordinate();

			System.out.println("c1   = " + c1);
			System.out.println("c2   = " + c2);

			Coordinate[] a = new Coordinate[3];
			for (int i = 0; i < a.length; i++) {
				a[i] = new Coordinate();
			}
			for (int i = 0; i < a.length; i++) {
				System.out.println("a[" + i + "] = " + a[i]);
			}
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能文字は半角数字のみです。");
		}
	}
}