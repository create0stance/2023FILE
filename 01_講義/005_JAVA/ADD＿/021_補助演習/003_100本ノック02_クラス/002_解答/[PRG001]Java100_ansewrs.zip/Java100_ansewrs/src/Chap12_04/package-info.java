/**
 * JavaPracticeChap12_04<br>
 * 第12章 クラスの派生と多相性<br>
 * @author SystemShared
 */
package
Chap12_04;
