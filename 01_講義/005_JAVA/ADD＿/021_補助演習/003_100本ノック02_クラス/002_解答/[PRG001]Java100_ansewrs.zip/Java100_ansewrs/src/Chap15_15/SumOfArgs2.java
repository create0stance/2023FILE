package Chap15_15;

/**
 * 第15章<br>
 * 問題15-15<br>
 * コマンドライン引数で与えられた実数値をすべて合計した値を表示するプログラムを作成せよ。<br>
 * 拡張for文を用いて実現すること。<br>
 * なお、実行する際はツールバーの[実行]⇒[実行構成]を選択し、Javaアプリケーションで<br>
 * SumOfArgs2が選択されているのを確認し、[(x)=引数]⇒[プログラムの引数]に<br>
 * 5.5 3.75 2.25<br>
 * を引数として設定し実行します。<br>
 * <br>
 * <実行例><br>
 * 合計は11.5です。<br>
 * <br>
 *
 * @author System Shared
 */

// コマンドライン引数で与えられたすべての数値を加算して表示
public class SumOfArgs2 {
	public static void main(String[] args) {
		double sum = 0.0;
		//--- 配列argsを変数sに代入していく。(for-each文)---//
		for (String s : args) {
			sum += Double.parseDouble(s);
		}
		System.out.println("合計は" + sum + "です。");
	}
}
