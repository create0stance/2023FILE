package Chap14_03;

/**
 * 第14章<br>
 * 問題14-3<br>
 * <br>
 * 設問内容は同パッケージ内のShapeTester.javaに記載
 *
 * @author System Shared
 */

// =====2次元インターフェース====//
public interface Plane2D {
	int getArea(); // ○面積を求める
}
