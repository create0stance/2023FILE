package
Chap09_01;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-1<br>
 * X座標とY座標とで構成される２次元座標クラスCoordinateを作成せよ。X座標とY座標の値<br>
 * を取得するメソッドと設定するメソッドを定義すること。<br>
 * <br>
 * <実行例(CoordinateTester1)><br>
 * 座標pを入力せよ。<br>
 * X座標 ： 1<br>
 * Y座標 ： 2<br>
 * p = (1.0, 2.0)<br>
 * p = (9.9, 9.9)<br>
 * q = (9.9, 9.9)<br>
 * <br>
 * <実行例(CoordinateTester2)><br>
 * 座標pを入力せよ。<br>
 * X座標 ： 3<br>
 * Y座標 ： 6<br>
 * 座標qを入力せよ。<br>
 * X座標 ： 4<br>
 * Y座標 ： 1<br>
 * p != qです。<br>
 * pとqは等しくありません。<br>
 * pとqは等しくありません。<br>
 * <br>
 * <実行例(CoordinateTester3)><br>
 * 座標は何個 ： 3<br>
 * a[0] = (5.5, 7.7)<br>
 * a[1] = (5.5, 7.7)<br>
 * a[2] = (5.5, 7.7)<br>
 * <br>
 * @author SystemShared
 */

// ２次元座標クラスCoordinate [Ver.1]
public class Coordinate {
	private double x;	// X座標
	private double y;	// Y座標

	//--- コンストラクタ ---//
	Coordinate(double x,double y) {
		this.x = x;
		this.y = y;
	}
	public double getX() {		// X座標を取得
		return x;
	}
	public double getY() {		// Y座標を取得
		return y;
	}
	public void setX(double x) {	// X座標を設定
		this.x = x;
	}
	public void setY(double y) {	// Y座標を設定
		this.y = y;
	}
	public void set(double x,double y) {	// 座標を設定
		this.x = x;
		this.y = y;
	}
}
