package
Chap09_03;
import java.util.Scanner;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-3<br>
 * 《人間クラス》の配列を生成するプログラムを作成せよ。生成時に要素を初期化するものを、<br>
 * 作成後の要素に値を代入するものなど、複数のパターンを作ること。<br>
 * <br>
 * <実行例><br>
 * 配列qの要素数 ： 1<br>
 * q[0]<br>
 * 名前 ： 植木<br>
 * 身長 ： 170<br>
 * 体重 ： 60<br>
 * 配列yの行数 ： 1<br>
 * y[0]の列数 ： 1<br>
 * y[0][0]<br>
 * 名前 ： 佐藤<br>
 * 身長 ： 175<br>
 * 体重 ： 55<br>
 * ■配列p<br>
 * No.0 佐藤太郎 170cm  60kg<br>
 * No.1 佐藤次郎 160cm  59kg<br>
 * ■配列q<br>
 * No.0 植木 170cm  60kg<br>
 * ■配列x<br>
 * 第0行<br>
 * No.0 斉藤一郎 175cm  52kg<br>
 * No.1 斉藤二郎 169cm  60kg<br>
 * 第1行<br>
 * No.0 鈴木太郎 178cm  70kg<br>
 * No.1 鈴木次郎 172cm  61kg<br>
 * 第2行<br>
 * No.0 田中一郎 168cm  59kg<br>
 * No.1 田中二郎 165cm  59kg<br>
 * ■配列y<br>
 * 第0行<br>
 * <br>
 * @author SystemShared
 */

// 人間クラスのインスタンスの配列
public class HumanArrayTester {
	// Human型１次元配列の全要素を表示
	static void printHumanArray(Human[] a) {
		for (int i = 0; i < a.length; i++) {
			System.out.printf("No.%d %s %3dcm %3dkg\n", i, a[i].getName(), a[i].getHeight(), a[i].getWeight());
		}
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		int n;

		// ---------- １次元配列 ----------//
		// 生成と同時に初期化
		Human[] p = { new Human("佐藤太郎", 170, 60), new Human("佐藤次郎", 160, 59), };

		// 配列と個々のインスタンスを個別に生成
		System.out.print("配列qの要素数 ： ");
		n = stdIn.nextInt();

		Human[] q = new Human[n];

		for (int i = 0; i < q.length; i++) {
			System.out.println("q[" + i + "]");
			System.out.print("名前 ： ");
			String name = stdIn.next();
			try {
				System.out.print("身長 ： ");
				int height = stdIn.nextInt();
				System.out.print("体重 ： ");
				int weight = stdIn.nextInt();
				q[i] = new Human(name, height, weight);
			} catch (Exception e) {
				System.out.println("入力可能文字は半角数字のみです");
				System.exit(0);
			}
		}

		// ---------- ２次元配列 ----------//
		// 生成と同時に初期化（３行２列）
		Human[][] x = {
				{ new Human("斉藤一郎", 175, 52), new Human("斉藤二郎", 169, 60) },
				{ new Human("鈴木太郎", 178, 70), new Human("鈴木次郎", 172, 61) },
				{ new Human("田中一郎", 168, 59), new Human("田中二郎", 165, 59) }, };

		// 配列と個々のインスタンスを個別に生成（凸凹配列）
		System.out.print("配列yの行数 ： ");
		n = stdIn.nextInt();

		Human[][] y = new Human[n][];
		for (int i = 0; i < y.length; i++) {
			System.out.print("y[" + i + "]の列数 ： ");
			n = stdIn.nextInt();
			y[i] = new Human[n];
			for (int j = 0; j < y[i].length; j++) {
				try {
					System.out.println("y[" + i + "][" + j + "]");
					System.out.print("名前 ： ");
					String name = stdIn.next();
					System.out.print("身長 ： ");
					int height = stdIn.nextInt();
					System.out.print("体重 ： ");
					int weight = stdIn.nextInt();
					y[i][j] = new Human(name, height, weight);
				} catch (Exception e) {
					System.out.println("入力可能文字は半角数字のみです。");
					System.exit(0);
				}
			}
		}

		// ---------- 表示 ----------//
		// １次元配列
		System.out.println("■配列p");
		printHumanArray(p);

		System.out.println("■配列q");
		printHumanArray(q);

		// ２次元配列
		System.out.println("■配列x");
		for (int i = 0; i < x.length; i++) {
			System.out.printf("第%d行\n", i);
			printHumanArray(x[i]);
		}
		System.out.println("■配列y");
		for (int i = 0; i < y.length; i++) {
			System.out.printf("第%d行\n", i);
		}
		
		stdIn.close();
	}
}