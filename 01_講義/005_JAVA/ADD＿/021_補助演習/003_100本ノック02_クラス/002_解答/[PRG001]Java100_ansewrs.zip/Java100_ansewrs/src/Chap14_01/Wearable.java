package Chap14_01;

/**
 * 第14章<br>
 * 問題14-1<br>
 * <br>
 * 設問内容は同パッケージ内のWearableTester.javaに記載
 *
 * @author System Shared
 */

// ウェアラブル インターフェースWearable
public interface Wearable {
	void putOn();	//着る
	void putOff();	//脱ぐ
}

