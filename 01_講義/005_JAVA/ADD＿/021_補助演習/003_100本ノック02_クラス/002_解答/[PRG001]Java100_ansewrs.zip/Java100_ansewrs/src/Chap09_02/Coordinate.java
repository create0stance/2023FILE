package
Chap09_02;
/**
 * 第9章 単純なクラスの作成
 * 問題9-2
 * 前問で作成したクラスには以下の問題点がある。
 * ・コンストラクタは2つのdouble型引数を要求するため、インスタンスの生成に柔軟性が欠ける。
 * ・ある座標と同じ座標をもつインスタンスの構築が容易でない。
 * ・二つの座標が等しいかどうかの判定が容易でない。
 * ・座標の表示のたびに、二つのゲッタgetXとgetYを呼び出して座標を調べなければならない。
 * 上記の問題点を解決するように、２次元座標クラスCoordinateを改良せよ。
 *
 * <実行例(CoordinateTester)>
 * 座標pを入力せよ。
 * X座標 ： 2
 * Y座標 ： 3
 * p = (2.0, 3.0)
 * qをpと同じ座標として作りました。
 * q = (2.0, 3.0)
 * pとqは等しいです。
 * c1   = (0.0, 0.0)
 * c2   = (0.0, 0.0)
 * a[0] = (0.0, 0.0)
 * a[1] = (0.0, 0.0)
 * a[2] = (0.0, 0.0)
 *
 * @author SystemShared
 */

// ２次元座標クラスCoordinate [Ver.2]
public class Coordinate {
	private double x = 0.0;
	private double y = 0.0;

	//--- コンストラクタ ---//
	public Coordinate() {}
	public Coordinate(double x, double y) {
		set(x, y);
	}
	public Coordinate(Coordinate c) {
		this(c.x, c.y);
	}
	public double getX() {		// x座標を取得
		return x;
	}
	public double getY() {		// y座標を取得
		return y;
	}
	public void setX(double x) {	// x座標を設定
		this.x = x;
	}
	public void setY(double y) {	// y座標を設定
		this.y = y;
	}
	public void set(double x, double y) {	// 座標を設定
		this.x = x;
		this.y = y;
	}
	public boolean equalto(Coordinate c) {
		return (x == c.x) && (y == c.y);
	}
	@Override
	public String toString() {
		return "("+ x +", "+ y +")";
	}
}
