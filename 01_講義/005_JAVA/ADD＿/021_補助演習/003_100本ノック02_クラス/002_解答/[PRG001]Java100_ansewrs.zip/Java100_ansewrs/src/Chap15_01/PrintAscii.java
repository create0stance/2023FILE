package Chap15_01;

/**
 * 第15章<br>
 * 問題15-1<br>
 * 文字と文字コード（Unicodde）の両方で英数字と記号の一覧を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * ! 0021<br>
 * " 0022<br>
 * # 0023<br>
 * ･･･中略･･･<br>
 * | 007c<br>
 * } 007d<br>
 * ~ 007e<br>
 * <br>
 *
 * @author Systm Shared
 */

// 英数字と記号を文字と文字コードで表示
public class PrintAscii {
	public static void main(String[] args) {
		for (char i = 0x21; i <= 0x7E; i++) {
			System.out.printf("%c %04x\n", i, (int) i);
		}
	}
}