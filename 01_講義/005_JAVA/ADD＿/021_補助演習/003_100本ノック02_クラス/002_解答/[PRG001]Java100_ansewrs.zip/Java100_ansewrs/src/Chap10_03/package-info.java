/**
 * JavaPracticeChap10_03<br>
 * 第10章 クラス変数とクラスメソッド<br>
 * @author SystemShared
 */
package 
Chap10_03;
