package Chap13_01;

/**
 * 第13章<br>
 * 問題13-1<br>
 * 犬のクラスDogと猫クラスCatを作成せよ。これらのクラスは、動物クラスAnimalから派生するものとする。<br>
 * 動物クラスは抽象クラスとし、名前のフィールド(コンストラクタで設定する)、名前のゲッタ、吠える(鳴く)メソッドをもたせること。<br>
 * また、犬種を表す文字列フィールドをDogに、年齢を表す整数型フィールドをCatに追加すること(いずれもコンストラクタで設定する)。<br>
 * <br>
 * <実行例><br>
 * ハチ公 ワンワン！！<br>
 * <br>
 * マイケル ニャ～ン！！<br>
 * <br>
 *
 * @author System Shared
 */

// --- 犬クラス [Ver.1] ---//
class Dog extends Animal {
	private String type; // 犬種

	public Dog(String name, String type) {
		super(name); // コンストラクタ
		this.type = type;
	}

	public void bark() {
		System.out.println("ワンワン！！"); // 吠える
	}

}
