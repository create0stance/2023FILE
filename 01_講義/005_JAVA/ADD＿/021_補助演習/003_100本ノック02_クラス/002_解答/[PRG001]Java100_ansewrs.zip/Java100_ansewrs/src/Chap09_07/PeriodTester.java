package
Chap09_07;
/**
 * 期間クラスの利用例
 *
 * <実行例(PeriodTester)><br>
 * 明治 ＝ {1868年09月08日(火)～1912年07月30日(火)}<br>
 * 大正 ＝ {1912年07月30日(火)～1926年12月25日(土)}<br>
 * 昭和 ＝ {1926年12月25日(土)～1989年01月18日(水)}<br>
 * <br>
 */

public class PeriodTester {
	public static void main(String[] args) {
		Period meiji = new Period(
				new Day(1868, 9, 8),
				new Day(1912, 7, 30));
		Period taisho = new Period(
				new Day(1912, 7, 30),
				new Day(1926, 12, 25));
		Period shouwa = new Period(
				new Day(1926, 12, 25),
				new Day(1989, 1, 18));

		System.out.println("明治 ＝ "+ meiji);
		System.out.println("大正 ＝ "+ taisho);
		System.out.println("昭和 ＝ "+ shouwa);
	}
}