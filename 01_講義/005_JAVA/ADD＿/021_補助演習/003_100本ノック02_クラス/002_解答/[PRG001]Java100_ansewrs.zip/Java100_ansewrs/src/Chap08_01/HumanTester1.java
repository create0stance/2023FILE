package
Chap08_01;

/**
 * 第8章 クラスの基本<br>
 * 問題8-1<br>
 * 名前・身長・体重などをメンバとしてもつ<<人間クラス>>を作成せよ(フィールドは自分で自由に設計すること)。<br>
 * <br>
 * ＜実行例＞<br>
 * 名前：芹川隆<br>
 * 身長：172cm<br>
 * 体重：78kg<br>
 * <br>
 * 名前：植木学<br>
 * 身長：170cm<br>
 * 体重：58kg<br>
 * <br>
 * @author SystemShared
 */

//人間クラス[Ver.1]の利用例
class HumanTester1 {
	public static void main(String[] args) {
		Human1 suzuki = new Human1();
		Human1 takada = new Human1();

		suzuki.name = "鈴木二郎";
		suzuki.height = 170;
		suzuki.weight = 60;

		takada.name = "高田龍一";
		takada.height = 166;
		takada.weight = 72;

		System.out.println("名前：" + suzuki.name); //suzukiのデータを表示
		System.out.println("身長：" + suzuki.height + "cm");
		System.out.println("体重：" + suzuki.weight + "kg");
		System.out.println();

		System.out.println("名前：" + takada.name); //takadaのデータを表示
		System.out.println("身長：" + takada.height + "cm");
		System.out.println("体重：" + takada.weight + "kg");
	}
}