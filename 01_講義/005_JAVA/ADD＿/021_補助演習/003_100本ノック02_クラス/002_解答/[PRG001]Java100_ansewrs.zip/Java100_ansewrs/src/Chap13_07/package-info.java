/**
 * JavaPracticeChap13_07<br>
 * 第13章 抽象クラス<br>
 * @author SystemShared
 */
package
Chap13_07;
