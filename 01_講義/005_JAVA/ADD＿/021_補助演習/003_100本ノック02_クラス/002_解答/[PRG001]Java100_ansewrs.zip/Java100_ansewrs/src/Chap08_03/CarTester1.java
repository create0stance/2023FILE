package
Chap08_03;

/**
 * 第8章 クラスの基本<br>
 * 問題8-3<br>
 * 自動車クラスCarを利用するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 名　　前：ビッツ<br>
 * ナンバー：福岡999ん99-99<br>
 * 車　　幅：1660mm<br>
 * 車　　高：1500mm<br>
 * 車　　長：3640mm<br>
 * タ ン ク：40.0リットル<br>
 * 燃　　費：12.0km/リットル<br>
 * <br>
 * 名　　前：マーチ<br>
 * ナンバー：福岡999ん99-98<br>
 * 車　　幅：1660mm<br>
 * 車　　高：1525mm<br>
 * 車　　長：3695mm<br>
 * タ ン ク：41.0リットル<br>
 * 燃　　費：12.0km/リットル<br>
 * <br>
 * @author SystemShared
 */

//自動車クラス[Ver.1]の利用例(その1)
public class CarTester1 {
	public static void main(String[] args) {
		Car vitz = new Car("ビッツ", "福岡999ん99-99", 1660, 1500, 3640, 40.0, 35.0, 12.0);
		Car march = new Car("マーチ", "福岡999ん99-98", 1660, 1525, 3695, 41.0, 35.0, 12.0);

		vitz.putSpec(); //vitzのスペックを表示
		System.out.println();
		march.putSpec(); //marchのスペックを表示
	}
}
