package
Chap09_05;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-5<br>
 * 以下に示す銀行口座クラスに対して、口座開設日のフィールドをtoStringメソッドを追加せよ。<br>
 * ※コンストラクタを変更したり、口座開設日のゲッタ（口座開設日フィールドが参照する日付インスタンスのコピーを返す）などのメソッドを追加したりすること。<br>
 * <br>
 * <実行例(AccountTester1)><br>
 * 口座開設日 ： 2010年10月15日(金)<br>
 * 口座開設日 ： 2010年10月15日(金)<br>
 * <br>
 * <実行例(AccountTester2)><br>
 * 口座情報を入力せよ。<br>
 * 名    義 ： 佐藤一郎<br>
 * 番    号 ： 111111<br>
 * 残    高 ： 99999<br>
 * 開設年 ： 2009<br>
 * 開設月 ： 1<br>
 * 開設日 ： 1<br>
 * 口座基本情報 ： {佐藤一郎, 111111, 99999}<br>
 * 開設日 ： 2009年01月01日(木)<br>
 * <br>
 * @author SystemShared
 */

// 銀行口座クラス[Ver.1]
public class Account {
	private String name;		// 口座名義
	private String no; 			// 口座番号
	private long balance; 		// 預金残高

	// --- コンストラクタ ---//
	Account(String n, String num, long z) {
		name = n; 				// 口座名義
		no = num; 				// 口座番号
		balance = z; 			// 預金残高

	}

	// --- 口座名義を調べる ---//
	String getName() {
		return name;
	}

	// --- 口座番号を調べる ---//
	String getNo() {
		return no;
	}

	// --- 預金残高を調べる ---//
	long getBalance() {
		return balance;
	}

	// --- k円を預ける ---//
	void deposit(long k) {
		this.balance += k;
	}

	// --- k円おろす ---//
	void withdraw(long k) {
		this.balance -= k;
	}

}