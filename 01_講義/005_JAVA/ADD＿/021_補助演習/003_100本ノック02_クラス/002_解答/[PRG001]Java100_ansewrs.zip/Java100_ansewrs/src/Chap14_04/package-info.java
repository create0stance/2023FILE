/**
 * JavaPracticeChap14_04<br>
 * 第14章 インターフェース<br>
 * @author SystemShared
 */
package
Chap14_04;
