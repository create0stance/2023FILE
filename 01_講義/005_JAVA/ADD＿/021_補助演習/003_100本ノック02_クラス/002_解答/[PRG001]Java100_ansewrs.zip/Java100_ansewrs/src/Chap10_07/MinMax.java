package
Chap10_07;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-7<br>
 * 二値／三値／配列の最小値を求めるメソッドや最大値を求めるメソッドを集めたユーティリティクラスMinMaxを改良せよ。<br>
 * <br>
 * <実行例>xの値～a[3]まではすべて入力した値。<br>
 * xの値：1<br>
 * yの値：2<br>
 * zの値：3<br>
 * 配列aの要素数：4<br>
 * a[0]5<br>
 * a[1]6<br>
 * a[2]7<br>
 * a[3]8<br>
 * x, yの最小値は1です。<br>
 * x, yの最大値は2です。<br>
 * x, y, zの最小値は1です。<br>
 * x, y, zの最大値は3です。<br>
 * 配列aの最小値は5です。<br>
 * そのインデックスは｛0 ｝です。<br>
 * 配列aの最大値は8です。<br>
 * そのインデックスは｛3 ｝です。<br>
 * <br>
 * @author System Shared
 */

// 最小値・最大値を求めるユーティリティクラス
public class MinMax {
	//--- a, bの最小値を返却 ---//
	public static int min(int a, int b) {
		return a < b ? a : b;
	}

	//--- a, b, cの最小値を返却 ---//
	public static int min (int a, int b, int c) {
		int min = a;

		if (b < min) {
			min = b;
		}
		if (c < min) {
			min = c;
		}

		return min;
	}

	//--- 配列aの最小値を返却 ---//
	public static int min(int[] a) {
		int min = a[0];

		for (int i = 1; i < a.length; i++) {
			if (a[i] < min){
				min = a[i];
			}
		}

		return min;
	}

	//--- 配列aの最小値をもつ全要素のインデックスを格納した配列を返却 ---//
	public static int[] minIndexArray(int[] a) {
		int min = min(a);		// 最小値
		int count = 0;			// 最小値をもつ要素の数

		for (int i = 0; i < a.length; i++){
			if (a[i] == min) {
				count++;
			}
		}

		int[] c = new int[count--];

		for (int i = a.length - 1; count >= 0; i--){
			if (a[i] == min){
				c[count--] = i;
			}
		}

		return c;
	}

	//--- a, bの最大値を返却 ---//
	public static int max(int a, int b) {
		return a > b ? a : b;
	}

	//--- a, b, cの最大値を返却 ---//
	public static int max(int a, int b, int c) {
		int max = a;

		if (b > max) {
			max = b;
		}
		if (c > max) {
			max = c;
		}

		return max;
	}

	//--- 配列aの最大値を返却 ---//
	public static int max(int[] a) {
		int max = a[0];

		for (int i = 1; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
			}
		}

		return max;
	}

	//--- 配列aの最大値をもつ全要素のインデックスを格納した配列を返却 ---//
	public static int[] maxIndexArray(int[] a) {
		int max = max(a);		// 最大値
		int count = 0;			// 最大値をもつ要素の個数

		for (int i = 0; i < a.length; i++) {
			if (a[i] == max) {
				count++;
			}
		}

		int[] c = new int[count--];

		for (int i = a.length - 1; count >= 0; i--) {
			if (a[i] == max) {
				c[count--] = i;
			}
		}

		return c;
	}
}
