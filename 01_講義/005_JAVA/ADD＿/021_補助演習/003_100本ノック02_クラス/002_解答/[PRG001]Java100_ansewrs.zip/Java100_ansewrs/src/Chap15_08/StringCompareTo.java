package Chap15_08;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-8<br>
 * 二つの文字列の大小関係を判定するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 文字列s1 ： ABC<br>
 * 文字列s2 ： XYZ<br>
 * s1のほうが小さい。<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列の比較（大小関係）
public class StringCompareTo {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("文字列s1 ： ");
		String s1 = stdIn.next();
		System.out.print("文字列s2 ： ");
		String s2 = stdIn.next();

		int balance = s1.compareTo(s2);
		if (balance < 0) {
			System.out.println("s1のほうが小さい。");
		} else if (balance > 0) {
			System.out.println("s2のほうが小さい。");
		} else {
			System.out.println("s1とs2は等しい。");
		}
		
		stdIn.close();
	}
}