package Chap11_03;

import Chap11_03.id.DateId;

/**
 * 第11章 パッケージ<br>
 * 問題11-3<br>
 * yyyy年mm月dd日にプログラムを実行すると、『今日はyyyy年mm月dd日です。』と一度だけ表示して、<br>
 * インスタンスを生成するたびに各インスタンスにyyymmdd01,yyyymmdd02,･･･という識別番号を与える<br>
 * 連番クラスDateIdを作成せよ。（問題10-3のクラスを改変して作成するとよい）<br>
 * なお、クラスの所属するパッケージ名はChap11_03.idとし、クラスDateidをテストするためのプログラムDateIdTester<br>
 * は、Chap11_03パッケージに所属するクラスとすること。<br>
 * <br>
 * <実行例><br>
 * 今日は2009年08月21日です。<br>
 * aの識別番号：2009082101<br>
 * bの識別番号：2009082102<br>
 * cの識別番号：2009082103<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 識別番号クラスの利用例
public class DateIdTester {

	public static void main(String[] args) {
		DateId a = new DateId();
		DateId b = new DateId();
		DateId c = new DateId();

		System.out.println("aの識別番号：" + a.getId());
		System.out.println("bの識別番号：" + b.getId());
		System.out.println("cの識別番号：" + c.getId());
	}
}
