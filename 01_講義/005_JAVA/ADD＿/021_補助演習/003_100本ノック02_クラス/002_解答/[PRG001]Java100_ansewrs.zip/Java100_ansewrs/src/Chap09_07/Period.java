package 
Chap09_07;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-7<br>
 * 開始日と終了日とから構成される《期間》を表すクラス Period を作成せよ。<br>
 * フィールドは以下のようになる。<br>
 * class Period {<br>
 * 		private Day from;	// 開始日<br>
 * 		private Day to;		// 終了日<br>
 * }<br>
 * コンストラクタやメソッドを自由に定義すること。<br>
 * <br>
 * <実行例(PeriodTester)><br>
 * 明治 ＝ {1868年09月08日(火)～1912年07月30日(火)}<br>
 * 大正 ＝ {1912年07月30日(火)～1926年12月25日(土)}<br>
 * 昭和 ＝ {1926年12月25日(土)～1989年01月18日(水)}<br>
 * <br>
 * @author SystemShared
 */

// 期間クラス
public class Period {
	private Day from;	// 開始日
	private Day to;		// 終了日

	//--- コンストラクタ ---//
	public Period(Day from, Day to){
		this.from = new Day(from);
		this.to = new Day(to);
	}
	public Day getFrom() {	// 開始日を取得
		return new Day(from);
	}
	public Day getTo() {	// 終了日を取得
		return new Day(to);
	}
	@Override
	public String toString() {
		return "{"+ from +"～"+ to +"}";
	}
}
