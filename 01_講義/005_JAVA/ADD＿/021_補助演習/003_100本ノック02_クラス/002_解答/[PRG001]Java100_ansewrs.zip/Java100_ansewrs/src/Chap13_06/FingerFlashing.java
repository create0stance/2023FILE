package Chap13_06;

import java.util.Scanner;

import Chap13_05.ComputerPlayer;
import Chap13_05.HumanPlayer;

/**
 * 第13章<br>
 * 問題13-6<br>
 * 前問で作成したプレーヤクラスを用いて、ジャンケンを行うプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * じゃんけんポン!! 0…グー／1…チョキ／2…パー ： 2<br>
 * 私はグーで、あなたはパーです。<br>
 * あなたの勝ちです。<br>
 * もう一度？ (0)いいえ (1)はい ：1<br>
 * じゃんけんポン!! 0…グー／1…チョキ／2…パー ： 0<br>
 * 私はパーで、あなたはグーです。<br>
 * あなたの負けです。<br>
 * もう一度？ (0)いいえ (1)はい ：0<br>
 * <br>
 *
 * @author System Shared
 */

// ジャンケン・プレイヤー群のテストプログラム
class FingerFlashing {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		HumanPlayer hp = new HumanPlayer();
		ComputerPlayer cp = new ComputerPlayer();
		String[] hands = { "グー", "チョキ", "パー" };

		int retry; // もう一度行うか？

		do {
			// コンピュータの手を生成
			int comp = cp.nextHand();

			// 人間の手を生成（読み込む）
			int user = hp.nextHand();

			// 両者の手を表示
			System.out.println("私は" + hands[comp] + "で、あなたは" + hands[user]
					+ "です。");

			// 判定
			int judge = (user - comp + 3) % 3;
			switch (judge) {
			case 0:
				System.out.println("引き分けです。");
				break;
			case 1:
				System.out.println("あなたの負けです。");
				break;
			case 2:
				System.out.println("あなたの勝ちです。");
				break;
			}

			// もう一度行うかどうかを確認
			do {
				System.out.print("もう一度？ (0)いいえ (1)はい ：");
				retry = stdIn.nextInt();
			} while (retry != 0 && retry != 1);
		} while (retry == 1);
		
		stdIn.close();
	}
}
