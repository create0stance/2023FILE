package
Chap08_02;

/**
 * 第8章 クラスの基本<br>
 * 問題8-2<br>
 * 他のクラスから値を自由に書き換えられないように、クラスHuman1を改良せよ。クラスにはフィールドだけでなく、コンストラクタとメソッドを定義すること。<br>
 * <br>
 * ＜実行例＞<br>
 * 名前：電子太郎<br>
 * 身長：170cm<br>
 * 体重：68kg<br>
 * <br>
 * 名前：電子花子<br>
 * 身長：166cm<br>
 * 体重：45kg<br>
 * <br>
 * @author SystemShared
 */

class HumanTester2 {
	public static void main(String[] args) {
		Human2 suzuki = new Human2("鈴木二郎", 170, 60);
		Human2 takada = new Human2("高田龍一", 166, 72);

		suzuki.gainWeight(3); //鈴木君が3kg太る
		takada.gainWeight(5); //高田君が5kg痩せる

		System.out.println("名前：" + suzuki.getName());
		System.out.println("身長：" + suzuki.getHeight() + "cm");
		System.out.println("体重：" + suzuki.getWeight() + "kg");
		System.out.println();

		System.out.println("名前：" + takada.getName());
		System.out.println("身長：" + takada.getHeight() + "cm");
		System.out.println("体重：" + takada.getWeight() + "kg");
	}
}