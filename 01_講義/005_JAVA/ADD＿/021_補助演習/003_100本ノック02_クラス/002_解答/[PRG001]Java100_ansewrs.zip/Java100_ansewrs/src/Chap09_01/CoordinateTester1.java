package
Chap09_01;
import java.util.Scanner;
/**
 * ２次元座標クラスCoordinate [Ver.1]の利用例（その１）
 *
 * <実行例(CoordinateTester1)><br>
 * 座標pを入力せよ。<br>
 * X座標 ： 1<br>
 * Y座標 ： 2<br>
 * p = (1.0, 2.0)<br>
 * p = (9.9, 9.9)<br>
 * q = (9.9, 9.9)<br>
 */

public class CoordinateTester1 {

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);		// ストリームスキャン
			System.out.println("座標pを入力せよ。");

			System.out.print("X座標 ： ");
			double x = stdIn.nextDouble();

			System.out.print("Y座標 ： ");
			double y = stdIn.nextDouble();

			Coordinate p = new Coordinate(x, y);
			System.out.println("p = (" + p.getX() + ", " + p.getY() + ")");

			Coordinate q = p;
			q.set(9.9, 9.9);

			System.out.println("p = (" + p.getX() + ", " + p.getY() + ")");
			System.out.println("q = (" + q.getX() + ", " + q.getY() + ")");
			
			stdIn.close();

		} catch (Exception e) {
			System.out.println("入力可能文字は半角数字のみです。");
		}
	}

}
