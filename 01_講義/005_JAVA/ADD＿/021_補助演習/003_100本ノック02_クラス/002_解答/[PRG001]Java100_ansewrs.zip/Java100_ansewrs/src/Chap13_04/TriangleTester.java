package Chap13_04;

import java.util.Scanner;

/**
 * 第13章<br>
 * 問題13-4<br>
 * 図形クラス群に対して、直角二等辺三角形を表すクラス群を追加せよ。左下が直角のもの、<br>
 * 左上が直角のもの、右下が直角のもの、右上が直角のものを追加すること。<br>
 * 直角二等辺三角形を現す抽象クラスを作り、そこから個々のクラスを派生して作ること。<br>
 * <br>
 * <実行例><br>
 * 三角形は何個 ： 4<br>
 * 1番の三角形の種類（1…左下直角／2…左上直角／3…右下直角／4…右上直角） ： 1<br>
 * 長さ ： 2<br>
 * 2番の三角形の種類（1…左下直角／2…左上直角／3…右下直角／4…右上直角） ： 2<br>
 * 長さ ： 3<br>
 * 3番の三角形の種類（1…左下直角／2…左上直角／3…右下直角／4…右上直角） ： 3<br>
 * 長さ ： 4<br>
 * 4番の三角形の種類（1…左下直角／2…左上直角／3…右下直角／4…右上直角） ： 4<br>
 * 長さ ： 3<br>
 * TriangleLB(length:2)<br>
 * *<br>
 * **<br>
 *<br>
 * TriangleLU(length;3)<br>
 * ***<br>
 * **<br>
 * *<br>
 *<br>
 * TriangleRB(length:4)<br>
 *    *<br>
 *   **<br>
 *  ***<br>
 * ****<br>
 *<br>
 * TriangleRU(length:3)<br>
 * ***<br>
 *  **<br>
 *   *<br>
 * <br>
 *
 * @author System Shared
 */

// 直角二等辺三角形クラス群のテストプログラム
class TriangleTester {
	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("三角形は何個 ： ");
			int no = stdIn.nextInt();
			AbstTriangle[] p = new AbstTriangle[no];

			for (int i = 0; i < no; i++) {
				int type;
				do {
					System.out.print((i + 1) + "番の三角形の種類（1…左下直角／2…左上直角"
							+ "／3…右下直角／4…右上直角） ： ");
					type = stdIn.nextInt();

				} while (type < 1 || type > 4);

				System.out.print("長さ ： ");
				int len = stdIn.nextInt();
				p[i] = (type == 1) ? new TriangleLB(len)
						: (type == 2) ? new TriangleLU(len)
								: (type == 3) ? new TriangleRB(len)
										: new TriangleRU(len);
			}

			for (AbstTriangle s : p) {
				s.print();
				System.out.println();
			}
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
