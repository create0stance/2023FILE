package Chap14_03;

import Chap13_03.Shape;

/**
 * 第14章<br>
 * 問題14-3<br>
 * <br>
 * 設問内容は同パッケージ内のShapeTester.javaに記載
 *
 * @author System Shared
 */

// Plane2Dインターフェースを実装した平行四辺形クラス
// ===平行四辺形===//
public class Parallelogram extends Shape implements Plane2D {
	private int width; // 底辺の幅
	private int height; // 高さ

	public Parallelogram(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public String toString() { // 文字列表現
		return "Parallelogram(width:" + width + ", height:" + height + ")";
	}

	public void draw() { // 描画
		for (int i = 1; i <= height; i++) {
			for (int j = 1; j <= height - i; j++) {
				System.out.print(' ');
			}
			for (int j = 1; j <= width; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}

	public int getArea() {
		return width * height; // ○面積を求める
	}
}
