package Chap15_06;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-6<br>
 * <br>
 * 設問内容は同パッケージ内のWearableTester.javaに記載
 *
 * <実行例><br>
 * 文字列s1 ： ABC漢字abc日本語123<br>
 * 文字列s2 ： 日本語<br>
 * 9文字目にマッチします。<br>
 * ABC漢字abc日本語123<br>
 *         日本語<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列探索（全角文字列対応版）
public class SearchString2 {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("文字列s1 ： ");
		String s1 = stdIn.next();

		System.out.print("文字列s2 ： ");
		String s2 = stdIn.next();

		int idx = s1.indexOf(s2);
		if(idx == -1) {
			System.out.println("s1中にs2は含まれません。");
		} else {
			// マッチ文字の直前までの《半角》での文字を求める
			int len = 0;
			for (int i=0; i < idx; i++) {
				len += s1.substring(i, i + 1).getBytes().length;
			}
			len += s2.length();
			System.out.println((idx + 1) +"文字目にマッチします。");
			System.out.println(s1);
			System.out.printf(String.format("%%%ds\n", len), s2);
		}
		
		stdIn.close();
	}
}