package
Chap09_01;
import java.util.Scanner;
/**
 * ２次元座標クラスCoordinate [Ver.1]の利用例（その３ ： 配列）
 *
 * <実行例(CoordinateTester3)><br>
 * 座標は何個 ： 3<br>
 * a[0] = (5.5, 7.7)<br>
 * a[1] = (5.5, 7.7)<br>
 * a[2] = (5.5, 7.7)<br>
 * <br>
 */

public class CoordinateTester3 {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("座標は何個 ： ");
		int n = stdIn.nextInt();
		Coordinate[] a = new Coordinate[n];		 // 要素数nのCoordinate型配列

		for (int i = 0; i < a.length; i++) {
			a[i] = new Coordinate(5.5, 7.7);
		}// 全要素を（5.5, 7.7）で生成
		for (int i = 0; i < a.length; i++) {
			System.out.printf("a[%d] = (%.1f, %.1f)\n", i, a[i].getX(), a[i].getY());
		}
		
		stdIn.close();
	}
}
