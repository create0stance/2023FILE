package Chap14_02;

/**
 * 第14章<br>
 * 問題14-2<br>
 * <br>
 * 設問内容は同パッケージ内のSkinnableSoftwareTester.javaに記載
 *
 * @author System Shared
 */

// 着せかえ可能なソフトウェアクラスSkinnableSoftware
public class SkinnableSoftware implements Skinnable {
	int skin; // スキン

	// コンストラクタ
	public SkinnableSoftware() {
		this.skin = BLACK;
	}

	public SkinnableSoftware(int skin) {
		this.skin = skin;
	}

	public void changeSkin(int skin) { // ★スキン変更
		this.skin = skin;
	}

	public int getSkin() { // スキン取得
		return skin;
	}

	public String getSkinString() { // スキンの文字列を返却
		switch (skin) {
		case BLACK:
			return "BLACK";
		case RED:
			return "RED";
		case GREEN:
			return "GREEN";
		case BLUE:
			return "BLUE";
		case LEOPARD:
			return "LEOPARD";
		}
		return "";
	}

}
