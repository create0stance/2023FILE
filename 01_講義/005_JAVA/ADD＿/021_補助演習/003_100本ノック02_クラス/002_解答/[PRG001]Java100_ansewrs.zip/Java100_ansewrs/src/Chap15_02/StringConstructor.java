package Chap15_02;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-1<br>
 * String型の文字列を生成するプログラムを作成せよ。生成は複数の方法で行うこと。<br>
 * <br>
 * <実行例><br>
 * 文字列 ： NAL<br>
 * s1 = ABC<br>
 * s2 = <br>
 * s3 = ABCDEFGHIJ<br>
 * s4 = FGH<br>
 * s5 = XYZ<br>
 * s6 = NAL<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列を生成
public class StringConstructor {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in, "Windows-31j");
		char[] c = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J' };
		String s1 = "ABC"; // 文字列リテラルで初期化
		String s2 = new String(); // String()
		String s3 = new String(c); // String(char[])
		String s4 = new String(c, 5, 3); // String(char[], int, int)
		String s5 = new String("XYZ"); // String(String)

		System.out.print("文字列 ： ");
		String s6 = stdIn.next();

		System.out.println("s1 = " + s1);
		System.out.println("s2 = " + s2);
		System.out.println("s3 = " + s3);
		System.out.println("s4 = " + s4);
		System.out.println("s5 = " + s5);
		System.out.println("s6 = " + s6);
		
		stdIn.close();
	}
}