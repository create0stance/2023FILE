package Chap15_12;

/**
 * 第15章<br>
 * 問題15-12<br>
 * プログラム起動時にコマンドラインで与えられた文字列（コマンドライン引数）をすべて<br>
 * 表示するプログラムを作成せよ。<br>
 * なお、実行する際はツールバーの[実行]⇒[実行構成]を選択し、Javaアプリケーションで<br>
 * PrintArgsが選択されているのを確認し、[(x)=引数]⇒[プログラムの引数]に<br>
 * Turbo NA DOHC<br>
 * を引数として設定し実行します。<br>
 * <br>
 * <実行例><br>
 * args[0] = Turbo<br>
 * args[1] = NA<br>
 * args[2] = DOHC<br>
 * <br>
 *
 * @author System Shared
 */

// コマンドライン引数を表示する
public class PrintArgs {
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.println("args[" + i + "] = " + args[i]);
		}
	}
}
