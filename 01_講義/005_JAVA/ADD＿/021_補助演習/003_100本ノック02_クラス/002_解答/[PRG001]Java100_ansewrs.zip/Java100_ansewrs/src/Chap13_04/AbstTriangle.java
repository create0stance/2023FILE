package Chap13_04;

import Chap13_03.Shape;
/**
 * 第13章<br>
 * 問題13-4<br>
 * <br>
 * 設問内容は同パッケージ内のTriangleTester.javaに記載
 *
 * @author System Shared
 */

/**
 * クラスAbstTriangleは直角二等辺三角形を表す抽象クラスです。<br>
 * このクラスは、図形を表す抽象クラスShapeから派生したクラスです。<br>
 * 抽象クラスですから、本クラスのインスタンスを派生することはできません。<br>
 * 具体的な直角二等辺三角形クラスは、このクラスから派生します。<br>
 * @see Shap
 * @see TriangleLB TriangleLU TriangleRB TriangleRU
 */

public abstract class AbstTriangle extends Shape {

	/**
	 * 一辺の長さを表すint型のフィールドです。<br>
	 */
	private int length;

	/**
	 * 直角二等辺三角形を生成するコンストラクタです。<br>
	 * 一辺の長さを引数として受け取ります。<br>
	 * @param length 生成する直角二等辺三角形の一辺の長さ。
	 */
	public AbstTriangle(int length) {
		setLength(length);
	}

	/**
	 * 一辺の長さを取得します。<br>
	 * @return 一辺の長さ。
	 */
	public int getLength() {
		return length;
	}

	/**
	 * 一辺の長さを設定します。<br>
	 * @param length 設定する一辺の長さ。
	 */
	public void setLength(int length) {
		this.length = length;
	}

	/**
	 * メソッドtoStringは、二等辺三角形に関する図形情報を表す文字列を返却します。<br>
	 * @return 文字列"AdstTriangle(length:3)"を返却します。<br>
	 *         3の部分は一辺の長さに応じた値です。
	 */
	public String toString() {
			return "AbstTriangle(length:" + length + ")";
	}
}
