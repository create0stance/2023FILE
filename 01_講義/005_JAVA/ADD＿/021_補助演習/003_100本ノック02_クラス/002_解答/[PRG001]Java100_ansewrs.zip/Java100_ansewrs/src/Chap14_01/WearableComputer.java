package Chap14_01;

/**
 * 第14章<br>
 * 問題14-1<br>
 * <br>
 * 設問内容は同パッケージ内のWearableTester.javaに記載
 *
 * @author System Shared
 */

// ウェアラブルコンピュータ クラスWearableComputer
public class WearableComputer implements Wearable {

	public void putOn() {
		System.out.println("コンピュータを起動しました。");
	}

	public void putOff() {
		System.out.println("コンピュータをシャットダウンしました。");
	}

	public void reset() {
		System.out.println("コンピュータを再起動しました。");
	}
}
