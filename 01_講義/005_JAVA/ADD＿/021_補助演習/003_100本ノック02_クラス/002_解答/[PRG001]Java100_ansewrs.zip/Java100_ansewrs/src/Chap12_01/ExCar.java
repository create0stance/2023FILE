package Chap12_01;
/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-1<br>
 * 以下に示す自動車クラスCarに対して、総走行距離を表すフィールドと、その値を調べるメソッドを<br>
 * 追加した自動車クラスExCarを作成せよ。クラスCarから派生すること。<br>
 * 派生とは、既存クラスを継承して新しいクラスを作り出すこと。<br>
 * なお、このクラスは問題12-2以降で利用する。<br>
 * <br>
 *
 * @author SystemShared
 */

// 自動車クラス(走行距離付き)
public class ExCar extends Car{
	private double totalMileage;	// 総走行距離

	//--- コンストラクタ ---//
	public ExCar(String name, int width, int height, int length, double fuel,
			Day purchaseDay){
	super(name, width, height, length, fuel, purchaseDay);
		totalMileage = 0.0;
	}

	//--- 総倉庫距離を調べる ---//
	public double getTotalMileage(){
		return totalMileage;
	}

	//--- スペックの表示 ---//
	public void putSpec(){
		super.putSpec();
		System.out.printf("総走行距離 : %.2fkm\n", totalMileage);
	}

	//--- X方向にdx・Y方向にdy移動 ---//
	public boolean move(double dx, double dy){
		double dist = Math.sqrt(dx * dx + dy * dy);	// 移動距離

		if(!super.move(dx, dy))
			return false;			// 移動できない   ･･･ 燃料不足
		else {
			totalMileage += dist;	// 総走行距離
			return true;			// 移動完了
		}
	}
}
