package Chap15_05;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-5<br>
 * 文字列を読み込んで、その全文字の文字コードを表示するプログラムお作成せよ。<br>
 * <br>
 * <実行例><br>
 * 文字列s ： AB漢字<br>
 * s[0] = A 0041<br>
 * s[1] = B 0042<br>
 * s[2] = 漢 6F22<br>
 * s[3] = 字 5B57<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列を１文字ずつ走査して文字コードを表示
public class StringCode {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("文字列s ： ");
		String s = stdIn.next();

		for(int i = 0; i < s.length(); i++) {
			System.out.printf("s[%d] = %c %04X\n", i, s.charAt(i), (int)s.charAt(i));
		}
		
		stdIn.close();
	}
}