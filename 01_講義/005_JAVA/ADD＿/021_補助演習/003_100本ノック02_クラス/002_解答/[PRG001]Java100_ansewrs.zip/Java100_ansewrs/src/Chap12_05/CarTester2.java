package Chap12_05;

import Chap12_01.Car;
import Chap12_01.ExCar;
import Chap12_01.Day;

/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-5<br>
 * サブクラスである自動車クラスのExCar型のインスタンスを参照しているCar型のクラス型変数に対して、<br>
 * メソッドputSpecを呼び出した場合の挙動をプログラムを作成して確認せよ。<br>
 * Carクラス,ExCarクラスは問題12-1で作成したクラスをインポートすること。<br>
 * <br>
 * <実行例><br>
 * 名前 : W140<br>
 * 車幅 : 1885mm<br>
 * 車高 : 1490mm<br>
 * 車長 : 5220mm<br>
 * 総走行距離 : 0.00km<br>
 * <br>
 *
 * @author SystemShared
 */

// 自動車クラスの利用例（多相性）
public class CarTester2 {

	public static void main(String[] args) {
		Car car1 = new ExCar("W140", 1885, 1490, 5220, 95.0, new Day(2005, 10,
				13));

		car1.putSpec(); // スペックの表示
	}
}
