package
Chap10_10;
/**
 * 第10章 クラス変数とクラスメソッド
 * 問題10-10
 * インスタンスが生成されるたびに『明解銀行での口座開設ありがとうございます。』と表示するように、
 * クラスAccountを変更せよ。表示はインスタンス初期化子で行うこと。
 * @author System Shared
 */

// 銀行口座クラス Ver.3
public class Account {
	private  static int counter = 0;		// 何番までの識別番号を与えたか

	private String name;					// 口座名義
	private String no;						// 口座番号
	private long balance;					// 預金残高
	private Day openDay;					// 口座開設日
	private int id;							// 識別番号

	//--- インスタンス初期化子 ---//
	{
		id = ++counter;
		System.out.println("明解銀行での口座開設ありがとうございます。");
	}

	//--- コンストラクタ（預金額は0で口座開設日は今日） ---//
	public Account (String name, String no) {
		this(name, no, 0, new Day());
	}

	//--- コンストラクタ ---//
	public Account(String name, String no, long balance, Day opneDay) {
		this.name = name;					// 口座名義
		this.no = no;						// 口座番号
		this.balance = balance;				// 預金残高
		this.openDay = new Day(openDay);				// 口座開設日
	}

	//--- 口座名義を調べる ---//
	public String getName() {
		return name;
	}

	//--- 口座番号を調べる ---//
	public String getNo() {
		return no;
	}

	//--- 預金残高を調べる ---//
	public long getBalance() {
		return balance;
	}

	//--- 識別番号を取得 ---//
	public int getId() {
		return id;
	}

	//--- 口座開設日を調べる ---//
	public Day getOpenDay() {
		return new Day(openDay);
	}

	//--- k円預ける ---//
	public void deposit(long k) {
		balance += k;
	}

	//--- k円おろす ---//
	public void withdraw(long k) {
		balance -= k;
	}

	//--- 文字列表現による口座基本情報を返却する ---//
	@Override
	public String toString() {
		return "{" + name + ", " + no + ", " + balance + "}";
	}
}
