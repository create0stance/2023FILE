package Chap13_04;

/**
 * 第13章<br>
 * 問題13-4<br>
 * <br>
 * 設問内容は同パッケージ内のTriangleTester.javaに記載
 *
 * @author System Shared
 */

/**
 * クラスTriangleRUは右上が直角の二等辺三角形を表すクラスです。<br>
 * このクラスは、直角二等辺三角形を表す抽象クラスAbstTriangleから派生したクラスです。<br>
 *
 * @see Shape
 * @see AbstTriangle
 */
public class TriangleRU extends AbstTriangle {

	/**
	 * 右上が直角の二等辺三角形を生成するコンストラクタです。<br>
	 * 一辺の長さを引数として受け取ります。<br>
	 *
	 * @param length
	 *            生成する直角二等辺三角形の一辺の長さ。
	 */
	public TriangleRU(int length) {
		super(length);
	}

	/**
	 * メソッドtoStringは、右下が直角の二等辺三角形に関する図形情報を表す文字列を返却します。<br>
	 *
	 * @return 文字列"TriangleRU(length:3)"を返却します。 3の部分は長さに応じた値です。
	 */
	public String toString() {
		return "TriangleRU(length:" + getLength() + ")";
	}

	/**
	 * メソッドdrawは、右上が直角の二等辺三角形を描画します。<br>
	 * 描画は、アステリスク記号'*'を並べることによって行います。<br>
	 */
	public void draw() {
		for (int i = getLength(); i >= 1; i--) {
			for (int j = 1; j <= getLength() - i; j++)
				System.out.print(' ');
			for (int j = 1; j <= i; j++)
				System.out.print("*");
			System.out.println();
		}
	}
}
