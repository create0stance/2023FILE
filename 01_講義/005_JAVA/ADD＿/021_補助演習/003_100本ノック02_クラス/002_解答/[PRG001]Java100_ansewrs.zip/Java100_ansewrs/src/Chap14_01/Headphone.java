package Chap14_01;

/**
 * 第14章<br>
 * 問題14-1<br>
 * <br>
 * 設問内容は同パッケージ内のWearableTester.javaに記載
 *
 * @author System Shared
 */

// ヘッドフォン クラスHeadphone
public class Headphone implements Wearable {

	int volume = 0; // ボリューム

	public void putOn() {
		System.out.println("ヘッドフォンを付けました。");
	}

	public void putOff() {
		System.out.println("ヘッドフォンを外しました。");
	}

	public void setVolume(int volume) {
		this.volume = volume;
		System.out.println("ボリュームを" + volume + "に変更しました。");
	}
}
