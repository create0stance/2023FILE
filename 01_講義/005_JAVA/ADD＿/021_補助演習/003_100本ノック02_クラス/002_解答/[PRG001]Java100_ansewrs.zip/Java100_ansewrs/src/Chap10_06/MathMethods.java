package
Chap10_06;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-6<br>
 * 実数値を読み込んで、その値の絶対値、平方根、その値を半径としてもつ円の面積を求めて表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例>実数に1と入力した場合<br>
 * 実数：<br>
 * 1
 * 絶対値：1.0<br>
 * 平方根：1.0<br>
 * 面　積：3.141592653589793<br>
 * <br>
 * @author System Shared
 */

import java.util.Scanner;

// 絶対値・平方根・円の面積を求める
public class MathMethods {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("実数：");
		double x = stdIn.nextDouble();

		System.out.println("絶対値：" + Math.abs(x));
		System.out.println("平方根：" + Math.sqrt(x));
		System.out.println("面　積：" + Math.PI * x * x);
		
		stdIn.close();
	}
}
