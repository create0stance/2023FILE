package
Chap08_03;

/**
 * 第8章 クラスの基本
 * 問題8-3
 * 自動車クラスCarを定義する。
 *
 * この自動車クラスを利用してCarTester1.javaとCarTester2.javaの問題に答えよ。
 *
 * @author SystemShared
 */

//自動車クラス[Ver.1]
public class Car {
	private String name; //名前
	private String number; //ナンバー
	private int width; //幅
	private int height; //高さ
	private int length; //長さ
	private double x; //現在位置X座標
	private double y; //現在位置Y座標
	private double tankage; //タンク容量
	private double fuel; //残り燃料
	private double sfc; //燃料

	//コンストラクタ
	Car(String name, String number, int width, int height, int length, double tankage, double fuel, double sfc) {
		this.name = name;
		this.number = number;
		this.width = width;
		this.height = height;
		this.length = length;
		this.tankage = tankage;
		this.fuel = (fuel <= tankage) ? fuel : tankage; //最大でもタンク容量と同じ
		this.sfc = sfc;
		x = y = 0.0;
	}

	double getX() {
		return x; //現在位置X座標を取得
	}
	double getY() {
		return y; //現在位置Y座標を取得
	}
	double getFuel() {
		return fuel; //残り燃料を取得
	}

	//スペック表示
	void putSpec() {
		System.out.println("名　　前：" + name);
		System.out.println("ナンバー：" + number);
		System.out.println("車　　幅：" + width + "mm");
		System.out.println("車　　高：" + height + "mm");
		System.out.println("車　　長：" + length + "mm");
		System.out.println("タ ン ク：" + tankage + "リットル");
		System.out.println("燃　　費：" + sfc + "km/リットル");
	}

	//X方向にdx・Y方向にdy移動
	boolean move(double dx, double dy) {
		double dist = Math.sqrt(dx * dx + dy * dy); //移動距離
		double f = dist / sfc; //移動に必要な燃料

		if (f > fuel)
			return false; //移動できない…燃料不足
		else {
			fuel -= f; //移動距離の分だけ燃料が減る
			x += dx;
			y += dy;
			return true; //移動完了
		}
	}

	//dfリットル供給
	void refuel(double df) {
		if (df > 0) {
			fuel += df;
			if (fuel > tankage)
				fuel = tankage;
		}
	}
}