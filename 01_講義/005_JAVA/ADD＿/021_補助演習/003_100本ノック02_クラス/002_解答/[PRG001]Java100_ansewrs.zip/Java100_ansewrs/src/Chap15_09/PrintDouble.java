package Chap15_09;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-9<br>
 * 浮動小数点xを、小数点以下の部分をp桁で、全体を少なくともw桁で表示するメソッド<br>
 * printDouble を作成せよ。<br>
 * printDouble(double x, int p, int w)<br>
 * <br>
 * <実行例><br>
 * 実数値 ： 3.1415926535<br>
 * 表示全桁数 ： 9<br>
 * 小数部桁数 ： 4<br>
 * 3.1416<br>
 * <br>
 *
 * @author System Shared
 *
 */

// 浮動小数点数値を任意の桁数で表示
public class PrintDouble {
	// 浮動小数点数値xを小数点以下の部分をp桁で全体を少なくともw桁で表示
	static void printDouble(double x, int p, int w) {
		System.out.printf(String.format("%%%d.%df", w, p), x);
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("実数値 ： ");
			double x = stdIn.nextDouble();

			System.out.print("表示全桁数 ： ");
			int w = stdIn.nextInt();

			System.out.print("小数部桁数 ： ");
			int p = stdIn.nextInt();

			printDouble(x, p, w);
			System.out.println();
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能文字は半角数字のみです。");
			System.exit(0);
		}
	}
}
