package Chap14_03;

/**
 * 第14章<br>
 * 問題14-3<br>
 * このパッケージには、面積を求めるためのメソッドgetAreaをもつ2次元インターフェースPlane2Dと、<br>
 * そのインターフェースを実装した長方形クラスRectangle(問題13-3)と、平行四辺形クラスParallelogramがある。<br>
 * これらの図形クラス郡を完成させ、それぞれの面積を求めるプログラム例を作成せよ。<br>
 * <br>
 * <実行例><br>
 * a[0]の面積=10<br>
 * a[1]の面積=10<br>
 * <br>
 *
 * @author System Shared
 */

// 図形クラス郡の利用例
class ShapeTester {

	public static void main(String[] args) {
		Plane2D[] a = {
				new Rectangle(2, 5), //長方形
				new Parallelogram(2, 5), //平行四辺形
		};

		for (int i = 0; i < a.length; i++)
			System.out.println("a[" + i + "]の面積=" + a[i].getArea());
	}
}