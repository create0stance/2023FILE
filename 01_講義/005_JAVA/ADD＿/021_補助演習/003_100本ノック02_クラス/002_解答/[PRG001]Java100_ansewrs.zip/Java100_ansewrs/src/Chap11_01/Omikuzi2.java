package Chap11_01;

import java.util.GregorianCalendar;
import java.util.Random;
import static java.util.GregorianCalendar.*;

/**
 * 第11章 パッケージ<br>
 * 問題11-1<br>
 * おみくじプログラムを作成せよ。今日の日付と、大吉・吉・中吉・小吉・凶のいずれかの<br>
 * 運勢を表示すること。<br>
 * なお、パッケージのインポートに静的インポート宣言を利用すること。<br>
 * <br>
 * <実行例><br>
 * 今日は2009年08月21日です。
 * 今日の運勢は吉です。
 * <br>
 *
 * @author System Shared
 *
 */
// 今日の日付と運勢（その２）
class Omikuzi2 {

	public static void main(String[] args) {
		GregorianCalendar today = new GregorianCalendar();
		int y = today.get(YEAR);			// 年
		int m = today.get(MONTH) + 1;		// 月
		int d = today.get(DATE);			// 日
		System.out.printf("今日は%04d年%02d月%02d日です。\n", y, m, d);

		Random rand = new Random(10);
		int k = rand.nextInt(10);			// 運勢：0～9の乱数
		System.out.print("今日の運勢は");
		switch (k) {
		 case 0 :
			 System.out.print("大吉");
			 break;
		 case 1 : case 2 : case 3:
			 System.out.print("吉");
			 break;
		 case 4 : case 5 : case 6:
			 System.out.print("中吉");
			 break;
		 case 7 : case 8 :
			 System.out.print("小吉");
			 break;
		 case 9 :
			 System.out.print("凶");
			 break;
		}
		System.out.println("です。");
	}
}
