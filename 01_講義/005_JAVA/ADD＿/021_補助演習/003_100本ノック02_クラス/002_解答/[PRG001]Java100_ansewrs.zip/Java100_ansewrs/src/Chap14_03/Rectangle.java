package Chap14_03;

import Chap13_03.Shape;

/**
 * 第14章<br>
 * 問題14-3<br>
 * <br>
 * 設問内容は同パッケージ内のShapeTester.javaに記載
 *
 * @author System Shared
 */

// Plane2Dインターフェースを実装した長方形クラス
// ===長方形===/
public class Rectangle extends Shape implements Plane2D {

	private int width; // 幅
	private int height; // 高さ

	public Rectangle(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public String toString() { // 文字列表現
		return "Rectangle(width:" + width + ", height:" + height + ")";
	}

	public void draw() { // 描画
		for (int i = 1; i <= height; i++) {
			for (int j = 1; j <= width; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}

	public int getArea() {
		return width * height; // ○面積を求める
	}
}
