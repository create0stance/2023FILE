package Chap15_14;

/**
 * 第15章<br>
 * 問題15-14<br>
 * コマンドライン引数で与えられた半径をもつ円の円周の長さと面積を求めて<br>
 * 表示するプログラムを表示せよ。<br>
 * なお、実行する際はツールバーの[実行]⇒[実行構成]を選択し、Javaアプリケーションで<br>
 * Circleが選択されているのを確認し、[(x)=引数]⇒[プログラムの引数]に<br>
 * 5.5<br>
 * を引数として設定し実行します。<br>
 * <br>
 * <実行例><br>
 * 半径5.50の円周は34.56で面積は95.03です。<br>
 * <br>
 *
 * @author System Shared
 */

// コマンドライン引数で与えられた半径を持つ円の円周の長さと面談を求めて表示
public class Circle {
	public static void main(String[] args) {
		double r = Double.parseDouble(args[0]);
		System.out.printf("半径%.2fの円周は%.2fで面積は%.2fです。\n"
						, r, 2 * Math.PI * r, Math.PI * r * r);
	}
}
