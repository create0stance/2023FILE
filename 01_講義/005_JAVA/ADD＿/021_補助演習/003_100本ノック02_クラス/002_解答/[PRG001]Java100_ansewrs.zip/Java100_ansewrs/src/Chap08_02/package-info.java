/**
 * JavaPracticeChap08_02<br>
 * 第8章 クラスの基本<br>
 * @author SystemShared
 */
package 
Chap08_02;
