package
Chap09_05;
/**
 * 銀行口座クラス [Ver.2] の利用例（その他）
 *
 * <実行例(AccountTester1)><br>
 * 口座開設日 ： 2010年10月15日(金)<br>
 * 口座開設日 ： 2010年10月15日(金)<br>
 * <br>
 * @author SystemShared
 */

public class AccountTester1 {
	public static void main(String[] args) {
		Day d = new Day(2010, 10, 15);
		Account2 suzuki = new Account2("鈴木一郎", "125768", 100, d);

		Day p = suzuki.getOpenDay();
		System.out.println("口座開設日 ： "+ p);

		p.set(1999, 12, 31);		// 開設日を書き換える（？）

		Day q = suzuki.getOpenDay();
		System.out.println("口座開設日 ： "+ q);
	}
}
