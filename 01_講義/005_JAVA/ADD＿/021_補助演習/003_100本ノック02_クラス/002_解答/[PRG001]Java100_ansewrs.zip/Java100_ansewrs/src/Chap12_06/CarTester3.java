package Chap12_06;

import Chap12_01.Car;
import Chap12_01.ExCar;
import Chap12_01.Day;

/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-6<br>
 * サブクラスである自動車クラスExCar型のインスタンスを参照しているCar型のクラス型変数に対して<br>
 * メソッドmoveとgetTotalMileageを呼び出した場合の挙動をプログラムを作成して確認せよ。<br>
 * Carクラス,ExCarクラスは問題12-1で作成したクラスをインポートすること。<br>
 * <br>
 * <実行例><br>
 * 総走行距離 : 14.142135623730951<br>
 * <br>
 *
 * @author SystemShared
 */

// 参照型の拡大変化と縮小変換
public class CarTester3 {
	public static void main(String[] args) {
		Car car1 = new ExCar("W140", 1885, 1490, 5220, 95.0, new Day(2005, 10,
				13));
		car1.move(10, 10); // 移動

		// System.out.println("総走行距離 : " + car1.getTotalMileage()); //エラー
		System.out.println("総走行距離 : " + ((ExCar) car1).getTotalMileage());
	}
}
