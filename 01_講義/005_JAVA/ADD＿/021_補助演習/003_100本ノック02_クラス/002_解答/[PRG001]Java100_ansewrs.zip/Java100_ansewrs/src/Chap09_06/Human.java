package
Chap09_06;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-6<br>
 * 《人間クラス》に、誕生日のフィールドとtoStringメソッドを追加せよ。<br>
 * ※コンストラクタを変更したり、誕生日のゲッタなどのメソッドを追加したりすること。<br>
 * <br>
 * <実行例(HumanTester1)><br>
 * suzuki = {鈴木二郎: 170cm 60kg<br>
 * 1975年03月12日(水)生まれ}<br>
 * takada = {高田龍一: 166cm 72kg<br>
 * 1987年10月07日(水)生まれ}<br>
 * <br>
 * @author SystemShared
 */

// 人間クラス [Ver.3]
public class Human {
	private String name;		// 名前
	private int height;			// 身長
	private int weight;			// 体重
	private Day birthday;		// 誕生日

	//--- コンストラクタ ---//
	public Human(String name, int height, int weight, Day birthday){
		this.name = name;
		this.weight = weight;
		this.height = height;
		this.birthday = new Day(birthday);
	}
	public String getName() {	// 名前を取得
		return name;
	}
	public int getHeight() {	// 身長を取得
		return height;
	}
	public int getWeight() {	// 体重を取得
		return weight;
	}
	public Day getBirthday() {
		return new Day(birthday);
	}

	public void gainWeight(int w) {		// 太る
		weight += w;
	}
	public void reduceWeight(int w) {	// 痩せる
		weight -= w;
	}

	//--- データ表示 ---//
	public void putData() {
		System.out.println("名前 ： "+ name);
		System.out.println("身長 ： "+ height +"cm");
		System.out.println("体重 ： "+ weight +"kg");
	}

	//--- 文字列化 ---//
	@Override
	public String toString(){
		return "{"+ name + ": "+ height +"cm "+ weight +"kg \n"+ birthday +"生まれ}";
	}
}
