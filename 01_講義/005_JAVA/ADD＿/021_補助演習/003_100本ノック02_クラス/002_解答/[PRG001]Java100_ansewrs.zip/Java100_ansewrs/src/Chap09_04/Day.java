package
Chap09_04;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-4<br>
 * 以下に示す日付クラスを利用するプログラムを作成せよ。すべてのコンストラクタの働きを確認できるようにすること。<br>
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。<br>
 * <br>
 * <実行例(DayTester)><br>
 * Day1を入力せよ。<br>
 * 年 ： 2009<br>
 * 月 ： 1<br>
 * 日 ： 1<br>
 * day1 = 2009年01月01日(木)<br>
 * day2をday1と同じ日付として作りました。<br>
 * day2 = 2009年01月01日(木)<br>
 * day1とday2は等しいです。<br>
 * d1    = 0001年01月01日(月)<br>
 * d2    = 2010年01月01日(金)<br>
 * d3    = 2010年10月01日(金)<br>
 * d4    = 2010年10月15日(金)<br>
 * a[0] = 0001年01月01日(月)<br>
 * a[1] = 0001年01月01日(月)<br>
 * a[2] = 0001年01月01日(月)<br>
 * <br>
 * @author SystemShared
 */

// 日付クラスDay [Ver.1]
public class Day {
	private int year = 1;		// 年
	private int month = 1;		// 月
	private int date = 1;		// 日

	//-- コンストラクタ  --//
	public Day(){}
	public Day(int year) {
		this.year = year;
	}
	public Day(int year, int month) {
		this(year);
		this.month = month;
	}
	public Day(int year, int month, int date){
		this(year, month);
		this.date = date;
	}
	public Day(Day d){
		this(d.year, d.month, d.date);
	}

	// 年・月・日の取得と設定
	public int getYear() {				// 年を取得
		return year;
	}
	public void setYear(int year) {		// 年を設定
		this.year = year;
	}
	public int getMonth() {				// 月を取得
		return month;
	}
	public void setMonth(int month) {	// 月を設定
		this.month = month;
	}
	public int getDate() {				// 日を取得
		return date;
	}
	public void setDate(int date) {		// 日を設定
		this.date = date;
	};

	public void set(int year, int month, int date){
		this.year = year;				// 年
		this.month = month;				// 月
		this.date = date;				// 日
	}

	//--- 曜日を求める ---//
	public int dayOfWeek() {
		int y = year;					// 0 ・・・日曜日
		int m = month;					// 1 ・・・月曜日
		if(m == 1 || m == 2) {			//   :
			y--;						// 5 ・・・金曜日
			m += 12;					// 6 ・・・土曜日
		}
		return (y + y / 4 - y / 100 + y / 400 + (13 * m + 8) / 5 + date) % 7;
	}

	// --- 日付dと等しいか ---//
	public boolean equalto(Day d){
		return year == d.year && month == d.month && date == d.date;
	}

	// --- 文字列表現を返却 ---//
	@Override
	public String toString() {
		String[] wd = {"日", "月", "火", "水", "木", "金", "土"};
		return String.format("%04d年%02d月%02d日(%s)",year, month, date, wd[dayOfWeek()]);
	}
}