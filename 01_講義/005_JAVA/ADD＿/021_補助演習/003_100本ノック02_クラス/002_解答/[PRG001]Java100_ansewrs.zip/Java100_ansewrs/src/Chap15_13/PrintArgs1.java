package Chap15_13;

/**
 * 第15章<br>
 * 問題15-13<br>
 * 問題15-12のプログラムと同様に、コマンドラインで与えられた文字列<br>
 * （コマンドライン引数）をすべて表示するプログラムを作成せよ。<br>
 * 文字列内の文字を1文字ずつ走査しながら表示すること。<br>
 * なお、実行する際はツールバーの[実行]⇒[実行構成]を選択し、Javaアプリケーションで<br>
 * PrintArgs1が選択されているのを確認し、[(x)=引数]⇒[プログラムの引数]に
 * Turbo NA DOHC<br>
 * を引数として設定し実行します。<br>
 * <br>
 * <実行例><br>
 * args[0] = Turbo<br>
 * args[1] = NA<br>
 * args[2] = DOHC<br>
 * <br>
 *
 * @author System Shared
 */

// コマンドライン引数を表示する（1文字ずつ走査）
public class PrintArgs1 {
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.print("args[" + i + "] = ");
			for (int j = 0; j < args[i].length(); j++) {
				System.out.print(args[i].charAt(j));
			}
			System.out.println();
		}
	}
}
