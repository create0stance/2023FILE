package Chap14_06;

/**
 * 第14章<br>
 * 問題14-6<br>
 * クラスDVDPlayerを利用するプログラム例を作成せよ。<br>
 * <br>
 * <実行例><br>
 * DVDPlayer型変数a<br>
 * ■DVD再生開始！<br>
 * ■DVD再生終了！<br>
 * ■DVDスロー再生開始！<br>
 * DVDPlayer型変数b<br>
 * ■DVD再生開始！<br>
 * ■DVD再生終了！<br>
 * DVDPlayer型変数c<br>
 * ■DVD再生開始！<br>
 * ■DVD再生終了！<br>
 * ■DVDスロー再生開始！<br>
 * <br>
 *
 * @author System Shared
 */

// DVDプレーヤクラスDVDPlayerの利用例
public class DVDPlayerTester {
	public static void main(String[] args) {
		DVDPlayer a = new DVDPlayer();
		Player b = new DVDPlayer();
		ExPlayer c = new DVDPlayer();

		System.out.println("DVDPlayer型変数a");
		a.play(); // 再生
		a.stop(); // 停止
		a.slow(); // スロー再生

		System.out.println("DVDPlayer型変数b");
		b.play(); // 再生
		b.stop(); // 停止

		System.out.println("DVDPlayer型変数c");
		c.play(); // 再生
		c.stop(); // 停止
		c.slow(); // スロー再生
	}
}
