/**
 * JavaPracticeChap12_05<br>
 * 第12章 クラスの派生と多相性<br>
 * @author SystemShared
 */
package
Chap12_05;
