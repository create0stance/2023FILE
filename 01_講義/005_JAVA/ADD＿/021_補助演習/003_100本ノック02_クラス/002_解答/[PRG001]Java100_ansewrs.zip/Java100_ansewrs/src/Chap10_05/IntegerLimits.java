package 
Chap10_05;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-5<br>
 * 四つの整数型byte, short, int, longの各型で表現できる数値の最小値と最大値を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数型の表現範囲<br>
 * byte 型：-128～127<br>
 * short型：-32768～32767<br>
 * int  型：-2147483648～2147483647<br>
 * long 型：-9223372036854775808～9223372036854775807<br>
 * <br>
 * @author System Shared
 */

// 整数型の各型で表現できる数値の範囲を表示
public class IntegerLimits {

	public static void main(String[] args) {

		System.out.println("整数型の表現範囲");

		System.out.println("byte 型：" + Byte.MIN_VALUE + "～" + Byte.MAX_VALUE);
		System.out.println("short型：" + Short.MIN_VALUE + "～" + Short.MAX_VALUE);
		System.out.println("int  型：" + Integer.MIN_VALUE + "～" + Integer.MAX_VALUE);
		System.out.println("long 型：" + Long.MIN_VALUE + "～" + Long.MAX_VALUE);
	}
}
