package Chap14_06;

/**
 * 第14章<br>
 * 問題14-6<br>
 * <br>
 * 設問内容は同パッケージ内のDVDPlayerTester.javaに記載
 *
 * @author System Shared
 */

// 拡張プレーヤ インタフェース（スロー再生付き） ExPlayer
public interface ExPlayer extends Player {
	void slow(); // ●スロー再生
}
