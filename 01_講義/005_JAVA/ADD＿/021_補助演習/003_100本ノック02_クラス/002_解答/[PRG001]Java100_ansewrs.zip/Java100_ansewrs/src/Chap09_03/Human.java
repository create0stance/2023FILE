package 
Chap09_03;

public class Human {
	private String name;		// 名前
	private int height;			// 身長
	private int weight;			// 体重

	//--- コンストラクタ ---//
	public Human(String name, int height, int weight){
		this.name = name;
		this.weight = weight;
		this.height = height;
	}
	public String getName() {	// 名前を取得
		return name;
	}
	public int getHeight() {	// 身長を取得
		return height;
	}
	public int getWeight() {	// 体重を取得
		return weight;
	}

	public void gainWeight(int w) {		// 太る
		weight += w;
	}
	public void reduceWeight(int w) {	// 痩せる
		weight -= w;
	}

	//--- データ表示 ---//
	public void putData() {
		System.out.println("名前 ： "+ name);
		System.out.println("身長 ： "+ height +"cm");
		System.out.println("体重 ： "+ weight +"kg");
	}

	//--- 文字列化 ---//
	@Override
	public String toString(){
		return "{"+ name + ": "+ height +"cm "+ weight +"kg}";
	}
}