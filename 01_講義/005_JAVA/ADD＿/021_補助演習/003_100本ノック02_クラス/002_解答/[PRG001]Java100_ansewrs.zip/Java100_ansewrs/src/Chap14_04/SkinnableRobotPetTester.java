package Chap14_04;

import Chap14_02.Skinnable;

/**
 * 第14章<br>
 * 問題14-4<br>
 * 以下に示すように、ペットクラスPetからロボット型ペットクラスRobotPetが派生している。<br>
 * クラスRobotPetを拡張した、着せ替え可能なロボット型ペットクラスを作成せよ。<br>
 * 問題14-2で作成したインターフェースSkinnableを実装すること。<br>
 * <br>
 * <実行例><br>
 * ■僕の名前はKurtです！<br>
 * ■ご主人様はアイです！<br>
 * <br>
 * ◇私はロボット。名前はR2D2。<br>
 * ◇ご主人様はルーク。<br>
 * <br>
 * ◇私はロボット。名前はOSX5。<br>
 * ◇ご主人様はApple。<br>
 * スキンは豹柄です。<br>
 * <br>
 * ■僕の名前はマイケルです！<br>
 * ■ご主人様は英男です！<br>
 * <br>
 *
 * @author System Shared
 */

// 着せかえ可能なロボット型ペットクラスSkinnableRobotPetの利用例
public class SkinnableRobotPetTester {

	// pが参照するインスタンスに自己紹介される
	static void intro(Pet p) {
		p.introduce();
	}

	public static void main(String[] args) {
		Pet[] a = {
				new Pet("Kurt", "アイ"),
				new RobotPet("R2D2", "ルーク"),
				new SkinnableRobotPet("OSX5", "Apple", Skinnable.LEOPARD),
				new Pet("マイケル", "英男"),
		};
		for (Pet p : a){
			intro(p); // pが参照するインスタンスい自己紹介させる

			// pの参照先がSkinnableRobotPetであれば･･･
			if(p instanceof SkinnableRobotPet){
				System.out.print("スキンは");
				((SkinnableRobotPet)p).printSkin();
				System.out.println("です。");
			}
			System.out.println();
		}
	}
}
