package Chap13_05;

import java.util.Scanner;

/**
 * 第13章<br>
 * 問題13-5<br>
 * <br>
 * 設問内容は同パッケージ内のPlayer.javaに記載
 *
 * @author System Shared
 */

// ジャンケン・人間プレイヤークラス
public class HumanPlayer extends Player {
	private static Scanner stdIn;

	static {
		stdIn = new Scanner(System.in);
	}

	// --- 手を決定（キーボードから読み込む） ---//
	public int nextHand() {
		do {
			System.out.print("じゃんけんポン!!  0…グー／1…チョキ／2…パー ： ");
			hand = stdIn.nextInt();
		} while (hand < 0 || hand > 2);
		return hand;
	}
}