package
Chap10_01;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-1<br>
 * 個々のインスタンスに識別番号を与えるように、人間クラスHumanを改良せよ。<br>
 * インスタンス生成のたびに、1, 2, ･･･という連続した値を与えること。<br>
 * <br>
 * <実行例><br>
 * 名前：鈴木さん<br>
 * 身長：167cm<br>
 * 体重：52kg<br>
 * 番号：1<br>
 * <br>
 * 名前：高田さん<br>
 * 身長：176cm<br>
 * 体重：58kg<br>
 * 番号：2<br>
 * <br>
 * @author System Shared
 */

class HumanTester {

	public static void main(String[] args) {
		Human suzuki = new Human("鈴木さん", 167, 52);
		Human takada = new Human("高田さん", 176, 58);

		suzuki.putData();		// suzukiのデータを表示
		System.out.println("番号：" + suzuki.getId());

		System.out.println();

		takada.putData();		// takadaのデータを表示
		System.out.println("番号：" + takada.getId());
	}
}


// 人間クラス Ver.4
public class Human {
	private static int counter = 0;	//何番までの識別番号を与えたか
	private String name;		// 名前
	private int height;			// 身長
	private int weight;			// 体重
	private int id;				// 識別番号

	//--- コンストラクタ ---//
	public Human(String name, int height, int weight){
		this.name = name;
		this.height = height;
		this.weight = weight;
		id = ++counter;

	}

	//--- 名前を取得 ---//
	public String getName() {
		return name;
	}
	//--- 身長を取得 ---//
	public int getHeight() {
		return height;
	}
	//--- 体重を取得 ---//
	public int getWeight() {
		return weight;
	}

	//--- 太る ---//
	public void gainWeight(int w) {
		weight += w;
	}
	//--- 痩せる ---//
	public void reduceWeight(int w) {
		weight -= w;
	}

	//--- 識別番号を取得 ---//
	public int getId() {
		return id;
	}

	//--- データ表示 ---//
	public void putData() {
		System.out.println("名前：" + name);
		System.out.println("身長：" + height + "cm");
		System.out.println("体重：" + weight + "kg");
	}
}