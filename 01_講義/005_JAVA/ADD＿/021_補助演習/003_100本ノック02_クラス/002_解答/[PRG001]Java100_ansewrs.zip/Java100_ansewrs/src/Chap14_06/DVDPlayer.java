package Chap14_06;

/**
 * 第14章<br>
 * 問題14-6<br>
 * <br>
 * 設問内容は同パッケージ内のDVDPlayerTester.javaに記載
 *
 * @author System Shared
 */

// ====DVDプレイヤー DVDPlayer ===//
public class DVDPlayer implements ExPlayer {

	public void play() { // ○再生
		System.out.println("■DVD再生開始！");
	}

	public void stop() { // ○停止
		System.out.println("■DVD再生終了！");
	}

	public void slow() { // ●スロー再生
		System.out.println("■DVDスロー再生開始！");
	}
}
