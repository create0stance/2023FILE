package Chap12_04;

import Chap12_01.Car;
import Chap12_01.ExCar;
import Chap12_01.Day;

/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-4<br>
 * スーパークラスであるCar型のクラス型変数が、サブクラスである自動車クラスExCar型の<br>
 * インスタンスを参照できることをプログラムを作成して確認せよ。<br>
 * Carクラス,ExCarクラスは問題12-1で作成したクラスをインポートすること。<br>
 * <br>
 * <実行例><br>
 * xの購入日 : 2010年12月24日(金)<br>
 * yの購入日 : 2010年12月24日(金)<br>
 * yの総走行距離 : 0.0<br>
 * <br>
 *
 * @author SystemShared
 */

// is-Aの関係とインスタンスへの参照
public class CarTester1 {

	public static void main(String[] args) {
		Car car1 = new Car("W140", 1885, 1490, 5220, 95.0,
				new Day(2005, 10, 13));
		ExCar car2 = new ExCar("W221", 1845, 1490, 5205, 90.0, new Day(2010,
				12, 24));

		Car x; // クラス型変数は･･･
		x = car1; // 自分自身の型のインスタンスは参照できる（当たり前）
		x = car2; // 下位クラス型のインスタンスも参照できる！

		System.out.println("xの購入日 : " + x.getPurchaseDay());

		ExCar y; // クラス型変数は･･･
		// y = car1; //上位クラス型のインスタンスは参照できない！
		y = car2; // 自分自身の型のインスタンスは参照できる（当たり前）

		System.out.println("yの購入日 : " + y.getPurchaseDay());
		System.out.println("yの総走行距離 : " + y.getTotalMileage());
	}
}
