package
Chap10_04;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-4<br>
 * 問題10-3で作成したクラスIdを、以下のように変更したクラスExIdを改良せよ。<br>
 *
 * インスタンスを生成するたびに識別番号をnずつ増やして与える（nは正の数）。<br>
 * nの値は、指定されない限り1とするが、メソッドを通じて取得・変更できるようにする。<br>
 * たとえばインスタンスを3個生成した後に、nを4に変更した場合、<br>
 * インスタンスに与える識別番号は生成順に1, 2, 3, 7, 11, 15 ･･･となる。<br>
 * <br>
 * <実行例><br>
 * aの識別番号：1<br>
 * bの識別番号：2<br>
 * cの識別番号：3<br>
 * dの識別番号：7<br>
 * eの識別番号：11<br>
 * fの識別番号：15<br>
 * 最後に与えた識別番号 = 15<br>
 * 次回に与える識別番号 = 19<br>
 * <br>
 * @author System Shared
 */

// 連番クラス（増分が変更できる）
public class ExIdTester {

	public static void main(String[] args) {
		ExId a = new ExId();		// 識別番号1番
		ExId b = new ExId();		// 識別番号2番
		ExId c = new ExId();		// 識別番号3番
		ExId.setStep(4);
		ExId d = new ExId();		// 識別番号7番
		ExId e = new ExId();		// 識別番号11番
		ExId f = new ExId();		// 識別番号15番

		System.out.println("aの識別番号：" + a.getId());
		System.out.println("bの識別番号：" + b.getId());
		System.out.println("cの識別番号：" + c.getId());
		System.out.println("dの識別番号：" + d.getId());
		System.out.println("eの識別番号：" + e.getId());
		System.out.println("fの識別番号：" + f.getId());

		int max = ExId.getMaxId();
		System.out.println("最後に与えた識別番号 = " + max);
		System.out.println("次回に与える識別番号 = " + (max + ExId.getStep()));

	}
}

class ExId {
	private static int counter = 0;			// 何番までの識別番号を与えたか
	private static int step = 1;			// 増分
	private int id;							// 識別番号

	//--- コンストラクタ ---//
	public ExId() {
		id = counter += step;				// 識別番号
	}

	//--- 識別番号を取得 ---//
	public int getId() {
		return id;
	}

	//--- 増分を取得 ---//
	public static int getStep() {
		return step;
	}

	//--- 増分を設定 ---//
	public static int setStep(int s) {
		step = (s >= 1) ? s : 1;
		return step;
	}

	//--- 最後に与えた識別番号を取得 ---//
	public static int getMaxId() {
		return counter;
	}
}
