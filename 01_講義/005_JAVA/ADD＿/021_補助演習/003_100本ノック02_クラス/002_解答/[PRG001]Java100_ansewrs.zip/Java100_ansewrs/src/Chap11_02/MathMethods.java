package Chap11_02;

import static java.lang.Math.*;
import static java.lang.System.*;

import java.util.Scanner;

/**
 * 第11章 パッケージ<br>
 * 問題11-2<br>
 * 実数値を読み込んで、その値の絶対値、平方根、その値を半径としてもつ円の面積を求めて表示<br>
 * するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 実数 ： 5.5<br>
 * 絶対値 ： 5.5<br>
 * 平方根 ： 2.345207879911715<br>
 * 面  積 ： 95.03317777109123<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 絶対値・平方根・円の面積を求める
class MathMethods {

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(in);
			out.print("実数 ： ");
			double x = stdIn.nextDouble();
			out.println("絶対値 ： " + abs(x));
			out.println("平方根 ： " + sqrt(x));
			out.println("面     積 ： " + PI * x * x);
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
