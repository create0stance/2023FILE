package
Chap10_03;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-3<br>
 * 問題10-2のクラスIdに、最後に与えた識別番号を返すクラスメソッドgetMaxIdを追加せよ。<br>
 * 	static int getMaxId()<br>
 * なお、このメソッドは、インスタンスをn個生成した時点で呼び出すとnを返すことになる。<br>
 * <br>
 * <実行例><br>
 * aの識別番号：1<br>
 * bの識別番号：2<br>
 * Id.counter	= 2<br>
 * a.counter	= 2<br>
 * b.counter	= 2<br>
 * <br>
 * @author System Shared
 */

public class IdTester {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		Id a = new Id();		// 識別番号1番
		Id b = new Id();		// 識別番号2番

		System.out.println("aの識別番号：" + a.getId());
		System.out.println("bの識別番号：" + b.getId());

		System.out.println("Id.counter	= " + Id.getMaxId());
		System.out.println("a.counter	= " + a.getMaxId());
		System.out.println("b.counter	= " + b.getMaxId());
	}
}


// 連番クラス ver.2
class Id {
	private static int counter = 0;		// 何番までの識別番号を与えたか
	private int id;						// 識別番号

	//--- コンストラクタ ---//
	public Id() {
		id = ++counter;					// 識別番号
	}

	//--- 識別番号を取得 ---//
	public int getId() {
		return id;
	}

	//--- 最後に与えた識別番号を取得 ---//
	public static int getMaxId() {
		return counter;
	}
}