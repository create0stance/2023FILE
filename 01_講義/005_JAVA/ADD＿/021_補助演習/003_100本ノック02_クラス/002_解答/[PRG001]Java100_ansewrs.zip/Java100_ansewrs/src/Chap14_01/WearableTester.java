package Chap14_01;

/**
 * 第14章<br>
 * 問題14-1<br>
 * 『着る』メソッドと『脱ぐ』メソッドを持つインターフェースWearableを作成せよ。<br>
 * さらに、そのインターフェースを実装した以下の2つのクラスを作成せよ。<br>
 * ・ヘッドフォンクラスHeadphone（ボリューム調整メソッドをもつ）<br>
 * ・ウェアラブルコンピュータクラスWearableComputer（再起動メソッドをもつ）<br>
 * <br>
 * <実行例><br>
 * ヘッドフォンを付けました。<br>
 * コンピュータを起動しました。<br>
 * ヘッドフォンを外しました。<br>
 * コンピュータをシャットダウンしました。<br>
 * <br>
 *
 * @author System Shared
 */

// インタフェースWearableを実装したクラス利用例
public class WearableTester {
	public static void main(String[] args) {
		Wearable[] a = new Wearable[2];
		a[0] = new Headphone(); // ヘッドフォン
		a[1] = new WearableComputer(); // ウェアラブルコンピュータ

		for(int i = 0; i < a.length; i++){
			a[i].putOn();
		}

		for(int i = 0; i < a.length; i++){
			a[i].putOff();
		}
	}
}
