/**
 * JavaPracticeChap09_04<br>
 * 第9章 単純なクラスの作成<br>
 * @author SystemShared
 */
package 
Chap09_04;
