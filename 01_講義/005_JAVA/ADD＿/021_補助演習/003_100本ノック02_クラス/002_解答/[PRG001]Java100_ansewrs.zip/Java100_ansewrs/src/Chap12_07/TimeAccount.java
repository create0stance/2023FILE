package Chap12_07;

/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-7<br>
 * 以下に示すTimeAccontは、銀行口座クラス[Ver1]から派生した<br>
 * 定期預金付き銀行口座クラスである。銀行口座クラス型変数a, bの普通預金と<br>
 * 定期預金残高の合計額を比較した結果を返却するメソッドcompBalanceを作成せよ。<br>
 *
 * static int compBalance(Account a, Account B)<br>
 * 合計額を比較して、aの方が多ければ1、等しければ0、bの方が大きければ-1を返却すること。<br>
 * もしaやbの参照先が、定期預金を持たないAccount方のインスタンスであれば、普通預金の<br>
 * 金額を比較対照とすること。<br>
 * <br>
 * <実行例><br>
 * 足立君と仲田君の預金残高の比較結果です。<br>
 * 仲田君のほうが預金残高が多い。<br>
 * <br>
 *
 * @author SystemShared
 */

// 定期預金付き銀行口座クラス
public class TimeAccount extends Account {
	private long timeBalance;

	// コンストラクタ
	TimeAccount(String name, String no, long balance, long timeBalance) {
		super(name, no, balance); //
		this.timeBalance = timeBalance;
	}

	// 定期預金残高を調べる
	long getTimeBalance() {
		return timeBalance;
	}

	// 定期預金を解約して全額を普通預金に移す
	void cancel(long k) {
		deposit(timeBalance);
		timeBalance = 0;
	}

}
