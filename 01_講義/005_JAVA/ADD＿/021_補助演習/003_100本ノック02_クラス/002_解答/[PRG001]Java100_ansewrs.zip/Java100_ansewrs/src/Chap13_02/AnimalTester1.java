package Chap13_02;

/**
 * 第13章<br>
 * 問題13-2<br>
 * 前問の動物クラス群に対して、以下に示すメソッド toString と introduce を追加せよ。<br>
 * <br>
 * ・toString … 犬クラスDog では "type の name" という文字列 (例："柴犬のハチ公") を、<br>
 *             猫クラスCat では "age 歳の name" という文字列 (例："7歳のマイケル") を返却。<br>
 * <br>
 * ・introduce … 全動物クラスに共通。toString の返却文字列に "だ" を加えたものを表示し、<br>
 *              メソッド bark によって吠える (例；『柴犬のハチ公だワンワン!!』と表示する)。<br>
 * <br>
 * <実行例1(toString)><br>
 * a[0] = 柴犬のハチ公<br>
 * a[1] = 7歳のマイケル<br>
 * <br>
 *
 * @author System Shared
 */

// 動物クラス群 [Ver.2]のテストプログラム(toStringメソッドのテスト)
public class AnimalTester1 {
	public static void main(String[] args) {
		Animal[] a = new Animal[2];
		a[0] = new Dog("ハチ公", "柴犬"); // 犬
		a[1] = new Cat("マイケル", 7); // 猫
		for (int i = 0; i < a.length; i++)
			System.out.println("a[" + i + "] = " + a[i]);
	}
}
