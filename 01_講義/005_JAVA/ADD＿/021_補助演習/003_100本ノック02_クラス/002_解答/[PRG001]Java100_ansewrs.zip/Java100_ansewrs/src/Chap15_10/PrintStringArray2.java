package Chap15_10;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-10<br>
 * <br>
 * <実行例><br>
 * 文字列の個数 ： 3<br>
 * sx[0] = Turbo<br>
 * sx[1] = NA<br>
 * sx[2] = DOHC<br>
 * Turbo<br>
 * NA<br>
 * DOHC<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列の配列を表示するメソッド
public class PrintStringArray2 {
	static void printString(String s) {
		for (int i = 0; i < s.length(); i++) {
			System.out.print(s.charAt(i));
		}
	}

	static void printStringArray(String[] a) {
		for (int i = 0; i < a.length; i++) {
			printString(a[i]);
			System.out.println();
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("文字列の個数 ： ");
			int n = stdIn.nextInt();
			String[] sx = new String[n];

			for (int i = 0; i < sx.length; i++) {
				System.out.print("sx[" + i + "] = ");
				sx[i] = stdIn.next();
			}
			printStringArray(sx);
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
