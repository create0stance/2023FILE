/**
 * JavaPracticeChap15_01<br>
 * 第15章 文字と文字列<br>
 * @author SystemShared
 */
package
Chap15_01;
