/**
 * JavaPracticeChap13_04<br>
 * 第13章 抽象クラス<br>
 * @author SystemShared
 */
package
Chap13_04;
