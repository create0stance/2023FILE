package Chap13_05;

/**
 * 第13章<br>
 * 問題13-5<br>
 * ジャンケンの《プレーヤ》を表す抽象クラスを定義せよ。そのクラスから、以下のクラスを派生すること。<br>
 * ・人間プレーヤクラス（出す手をキーボードから読み込む）<br>
 * ・コンピュータプレーヤクラス（出す手を乱数で生成する）<br>
 * なお、この作成したPlayer,HumanPlayer,ComputerPlayerクラスは以降の問題で利用する。<br>
 * <br>
 *
 * @author System Shared
 */

// ジャンケンのプレイヤーを表す抽象クラス
public abstract class Player {
	int hand; // 手(0…グー/1…チョキ/2…パー )

	public abstract int nextHand(); // 手を決定
}
