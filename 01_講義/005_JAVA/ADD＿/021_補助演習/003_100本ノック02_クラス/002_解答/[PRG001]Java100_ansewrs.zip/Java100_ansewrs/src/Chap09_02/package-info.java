/**
 * JavaPracticeChap09_02<br>
 * 第9章 単純なクラスの作成<br>
 * @author SystemShared
 */
package 
Chap09_02;
