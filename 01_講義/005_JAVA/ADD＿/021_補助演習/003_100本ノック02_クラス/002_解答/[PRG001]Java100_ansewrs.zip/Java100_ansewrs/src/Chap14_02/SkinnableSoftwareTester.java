package Chap14_02;

/**
 * 第14章<br>
 * 問題14-2<br>
 * <br>
 * 同パッケージ内の着せかえインターフェースSkinnableを実装するクラスを作成せよ。<br>
 * 黒/赤/緑/青/豹柄を選択するためのメソッドchangeSkinを実装すること。<br>
 * 着せかえ可能なソフトウェアクラス SkinnableSoftwareを利用し<br>
 * 実行するSkinnableSoftwareTesterクラスを完成させよ。<br>
 * <br>
 * ＜実行例＞<br>
 * xのスキンはLEOPARDです。<br>
 * yのスキンはGREENです。<br>
 * <br>
 *
 * @author System Shared
 */

public class SkinnableSoftwareTester {

	public static void main(String[] args) {

		SkinnableSoftware x = new SkinnableSoftware(); // 黒
		SkinnableSoftware y = new SkinnableSoftware(Skinnable.GREEN); // 緑

		x.changeSkin(Skinnable.LEOPARD); // xのスキンを豹柄に変更

		System.out.println("xのスキンは" + x.getSkinString() + "です。");
		System.out.println("yのスキンは" + y.getSkinString() + "です。");

	}
}
