package Chap11_03.id;

import java.util.GregorianCalendar;
import static java.util.GregorianCalendar.*;

/**
 * 第11章 パッケージ<br>
 * 問題11-3<br>
 * yyyy年mm月dd日にプログラムを実行すると、『今日はyyyy年mm月dd日です。』と一度だけ表示して、<br>
 * インスタンスを生成するたびに各インスタンスにyyymmdd01,yyyymmdd02,･･･という識別番号を与える<br>
 * 連番クラスDateIdを作成せよ。（問題10-3のクラスを改変して作成するとよい）<br>
 * なお、クラスの所属するパッケージ名はChap11_03.idとし、クラスDateidをテストするためのプログラムDateIdTester<br>
 * は、Chap11_03パッケージに所属するクラスとすること。<br>
 * <br>
 * <実行例><br>
 * 今日は2009年08月21日です。<br>
 * aの識別番号：2009082101<br>
 * bの識別番号：2009082102<br>
 * cの識別番号：2009082103<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 識別番号クラス（開始番号を今日の日付から決定）
public class DateId {
	private static int counter; // 何番までの識別番号を与えたか

	private int id; // 識別番号

	static {
		GregorianCalendar today = new GregorianCalendar();
		int y = today.get(YEAR); // 年
		int m = today.get(MONTH) + 1; // 月
		int d = today.get(DATE); // 日

		System.out.printf("今日は%04d年%02d月%02d日です。\n", y, m, d);
		counter = y * 1000000 + m * 10000 + d * 100;
	}

	// -- コンストラクタ --//
	public DateId() {
		id = ++counter; // 識別番号
	}

	// --- 識別番号を取得 ---//
	public int getId() {
		return id;
	}
}