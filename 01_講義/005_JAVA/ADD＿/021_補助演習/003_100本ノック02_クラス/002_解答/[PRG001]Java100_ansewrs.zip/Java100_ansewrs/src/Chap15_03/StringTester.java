package Chap15_03;

/**
 * 第15章<br>
 * 問題15-3<br>
 * 空参照・空文字列・他のString型変数が参照しているものと同じ綴りの文字列リテラルで、<br>
 * String型の変数を初期化あるいは代入するとどうなるか。プログラムを作成して確認せよ。<br>
 * <br>
 * <実行例><br>
 * 文字列s1 = null<br>
 * 文字列s1 = <br>
 * 文字列s1 = ABC<br>
 * 文字列s1 = ABC<br>
 * 文字列s1 = XYZ<br>
 * s3とs4は同じ文字リテラルを参照している。<br>
 * <br>
 *
 * @author System Shared
 */

// お文字列と空参照・空文字列・他のString型変数が参照いている文字列へ参照
public class StringTester {
	public static void main(String[] args) {
		String s1 = null; // 空参照（参照していない）
		String s2 = ""; // ""を参照
		String s3 = "ABC"; // "ABC"を参照
		String s4 = "ABC"; // "ABC"を参照
		String s5 = "ABC"; // "ABC"を参照
		s5 = "XYZ";

		System.out.println("文字列s1 = " + s1);
		System.out.println("文字列s1 = " + s2);
		System.out.println("文字列s1 = " + s3);
		System.out.println("文字列s1 = " + s4);
		System.out.println("文字列s1 = " + s5);
		System.out.println("s3とs4は同じ文字リテラルを参照"
				+ ((s3 == s4) ? "している。" : "していない。"));
		/*
		 * 以下、IF文を省略化しない場合
		 * System.out.print("s3とs4は同じ文字リテラルを参照");
		 *  if(s3 == s4){
		 *   System.out.println("している。");
		 *  } else {
		 *   System.out.println("していない。");
		 *  }
		 */
	}
}