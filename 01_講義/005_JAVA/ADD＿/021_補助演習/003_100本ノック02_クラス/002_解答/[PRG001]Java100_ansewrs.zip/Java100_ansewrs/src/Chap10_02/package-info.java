/**
 * JavaPracticeChap10_02<br>
 * 第10章 クラス変数とクラスメソッド<br>
 * @author SystemShared
 */
package 
Chap10_02;
