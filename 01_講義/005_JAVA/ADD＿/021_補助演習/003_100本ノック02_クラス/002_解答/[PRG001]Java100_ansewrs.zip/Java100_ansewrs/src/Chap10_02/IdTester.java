package
Chap10_02;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-2<br>
 * 問題10-1のクラスHumanの識別番号に関連する部分のみを抽出した連番クラスIdを改良せよ。<br>
 * <br>
 * <実行例><br>
 * aの識別番号：1<br>
 * bの識別番号：2<br>
 * Id.counter	= 2<br>
 * a.counter	= 2<br>
 * b.counter	= 2<br>
 * <br>
 * @author System Shared
 */

public class IdTester {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		Id a = new Id();		// 識別番号1番
		Id b = new Id();		// 識別番号2番

		System.out.println("aの識別番号：" + a.getId());
		System.out.println("bの識別番号：" + b.getId());

		System.out.println("Id.counter	= " + Id.counter);
		System.out.println("a.counter	= " + a.counter);
		System.out.println("b.counter	= " + b.counter);
	}
}


// 連番クラス Ver.1

class Id {
	static int counter = 0;		// 何番までの識別番号を与えたか
	private int id;				// 識別番号

	//--- コンストラクタ ---//
	public Id() {
		id  = ++counter;		// 識別番号
	}

	//--- 識別番号を取得 ---//
	public int getId() {
		return id;
	}
}