package Chap15_11;

import java.util.Scanner;

import Chap13_05.ComputerPlayer;
import Chap13_05.HumanPlayer;

/**
 * 第15章<br>
 * 問題15-11<br>
 * 3人で行うジャンケンプログラムを作成せよ。プレイヤー3人のうち、コンピュータを2人として、<br>
 * 人間を1人とすること。また、問題13-5で作成した、プレイヤークラスを利用すること。<br>
 * <br>
 * <実行例><br>
 * じゃんけんポン!!  0…グー／1…チョキ／2…パー ： 0<br>
 * コンピュータ1はパーで、コンピュータ2はチョキで、あなたはグーです。<br>
 * 引き分けです。<br>
 * もう一度？ (0)いいえ (1)はい：1<br>
 * じゃんけんポン!!  0…グー／1…チョキ／2…パー ： 1<br>
 * コンピュータ1はチョキで、コンピュータ2はグーで、あなたはチョキです。<br>
 * コンピュータ2の勝ちです。<br>
 * もう一度？ (0)いいえ (1)はい：0<br>
 * <br>
 *
 * @author System Shared
 */

// 3人ジャンケン
public class FingerFlashing3 {
	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			HumanPlayer hp = new HumanPlayer();
			ComputerPlayer cp1 = new ComputerPlayer();
			ComputerPlayer cp2 = new ComputerPlayer();

			String[] hands = { "グー", "チョキ", "パー" };
			// --- もう一度行うか？ ---//
			int retry;

			do {
				// --- コンピュータの手を生成 ---//
				int comp1 = cp1.nextHand();
				int comp2 = cp2.nextHand();

				// --- 人間の手を生成（読み込む） ---//
				int user = hp.nextHand();

				// --- 両者の手を表示 ---//
				System.out.println("コンピュータ1は" + hands[comp1] + "で、"
						+ "コンピュータ2は" + hands[comp2] + "で、" + "あなたは"
						+ hands[user] + "です。");

				// --- 判定 ---//
				// user 対 comp1
				int r1 = (user - comp1 + 3) % 3;
				// user 対 comp2
				int r2 = (user - comp2 + 3) % 3;

				// --- userの勝ち ---//
				if (r1 == 2 && r2 == 2) {
					System.out.println("あなたの勝ちです。");

					// --- comp1の勝ち ---//
				} else if (r1 == 1 && r2 == 0) {
					System.out.println("コンピュータ1の勝ちです。");

					// --- comp2の勝ち ---//
				} else if (r1 == 0 && r2 == 1) {
					System.out.println("コンピュータ2の勝ちです。");

					// --- userとcomp1の勝ち ---//
				} else if (r1 == 0 && r2 == 2) {
					System.out.println("あなたとコンピュータ1の勝ちです。");

					// --- userとcomp2の勝ち ---//
				} else if (r1 == 2 && r2 == 0) {
					System.out.println("あなたとコンピュータ2の勝ちです。");

					// --- comp1とcomp2の勝ち ---//
				} else if (r1 == 1 && r2 == 1) {
					System.out.println("コンピュータ1とコンピュータ2の勝ちです。");

					// --- 引き分け ---//
				} else {
					System.out.println("引き分けです。");
				}

				// --- もう一度行うかどうかを確認 ---//
				do {
					System.out.print("もう一度？ (0)いいえ (1)はい：");
					retry = stdIn.nextInt();
				} while (retry != 0 && retry != 1);
			} while (retry == 1);
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
