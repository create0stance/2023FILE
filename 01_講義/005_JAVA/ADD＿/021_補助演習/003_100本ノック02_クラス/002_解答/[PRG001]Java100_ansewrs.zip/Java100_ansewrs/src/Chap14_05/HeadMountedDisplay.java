package Chap14_05;

import Chap14_01.Wearable;
import Chap14_02.Skinnable;

/**
 * 第14章<br>
 * 問題14-5<br>
 * <br>
 * 設問内容は同パッケージ内のHeadMountedDisplayTester.javaに記載
 *
 * @author System Shared
 */

// ヘッドマウントディスプレイクラスHeadMountedDisplay
public class HeadMountedDisplay implements Wearable, Skinnable {
	private int skin; // スキン

	// 装着
	public void putOn() {
		System.out.println("ディスプレイを付けました。");
	}

	// 解除
	public void putOff() {
		System.out.println("ディスプレイを外しました。");
	}

	// スキン変更
	public void changeSkin(int skin) {
		this.skin = skin;
	}

	// 現在のスキンを表示
	public void putSkin() {
		switch (skin) {
		case BLACK:
			System.out.println("BLACK DISPLAY");
			break;
		case RED:
			System.out.println("RED DISPLAY");
			break;
		case GREEN:
			System.out.println("GREEN DISPLAY");
			break;
		case BLUE:
			System.out.println("BLUE DISPLAY");
			break;
		case LEOPARD:
			System.out.println("LEOPARD DISPLAY");
			break;
		}
	}
}
