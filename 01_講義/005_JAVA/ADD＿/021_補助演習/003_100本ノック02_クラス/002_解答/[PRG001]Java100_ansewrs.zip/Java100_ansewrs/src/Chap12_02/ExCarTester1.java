package Chap12_02;

import Chap12_01.ExCar;
import Chap12_01.Day;

/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-2<br>
 * 自動車クラスExCar型のインスタンスを作り、現在位置を残り燃料と購入日を表示するプログラムを作成せよ。<br>
 * ExCarクラスは問題12-1で作成したクラスをインポートすること。<br>
 * <br>
 * <実行例><br>
 * 現在位置 : (0.00, 0.00)<br>
 * 残り燃料 : 95.00リットル<br>
 * 購入日 : 2005年10月13日(木)<br>
 * <br>
 *
 * @author SystemShared
 */

// 自動車クラス(総走行距離付き)の利用例(現在位置・残り燃料・購入日の表示)
public class ExCarTester1 {
	public static void main(String[] args) {
		ExCar myCar = new ExCar("W140", 1885, 1490, 5220, 95.0, (new Day(2005,
				10, 13)));
		System.out.printf("現在位置 : (%.2f, %.2f)\n", myCar.getX(), myCar.getY());
		System.out.printf("残り燃料 : %.2fリットル\n", myCar.getFuel());
		System.out.printf("購入日 : %s\n", myCar.getPurchaseDay());
	}

}
