package
Chap09_06;
/**
 * 人間クラス [Ver.3]の利用例
 *
 * <実行例(HumanTester1)><br>
 * suzuki = {鈴木二郎: 170cm 60kg<br>
 * 1975年03月12日(水)生まれ}<br>
 * takada = {高田龍一: 166cm 72kg<br>
 * 1987年10月07日(水)生まれ}<br>
 * <br>
 * @author SystemShared
 */

public class HumanTester1 {
	public static void main(String[] args) {
		Human suzuki = new Human("鈴木太郎", 170, 60, new Day(1975, 3, 12));
		Human sato = new Human("佐藤二郎", 166, 72, new Day(1987, 10, 7));

		System.out.println("suzuki = "+ suzuki);
		System.out.println("sato = "+ sato);
	}

}