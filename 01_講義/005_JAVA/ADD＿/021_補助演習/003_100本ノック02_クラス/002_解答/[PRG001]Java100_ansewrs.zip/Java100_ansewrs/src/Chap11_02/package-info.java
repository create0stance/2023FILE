/**
 * JavaPracticeChap11_02<br>
 * 第11章 パッケージ<br>
 * @author SystemShared
 */
package
Chap11_02;
