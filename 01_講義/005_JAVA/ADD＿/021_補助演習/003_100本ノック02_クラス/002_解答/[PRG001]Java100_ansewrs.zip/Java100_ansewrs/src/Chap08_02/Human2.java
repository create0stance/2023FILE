package
Chap08_02;

/**
 * 第8章 クラスの基本<br>
 * 問題8-2<br>
 * 他のクラスから値を自由に書き換えられないように、クラスHuman1を改良せよ。クラスにはフィールドだけでなく、コンストラクタとメソッドを定義すること。<br>
 * <br>
 * ＜実行例＞<br>
 * 名前：電子太郎<br>
 * 身長：170cm<br>
 * 体重：68kg<br>
 * <br>
 * 名前：電子花子<br>
 * 身長：166cm<br>
 * 体重：45kg<br>
 * <br>
 * @author SystemShared
 */

//人間クラス[Ver.2]
public class Human2 {
	String name; //名前
	int height; //身長
	int weight; //体重

	//コンストラクタ
	Human2(String n, int h, int w) {
		name = n;
		height = h;
		weight = w;
	}

	//名前を取得するメソッド
	String getName() {
		return name; //名前を取得
	}


	//身長を取得するメソッド
	int getHeight() {
		return height; //身長を取得
	}


	//体重を取得するメソッド
	int getWeight() {
		return weight; //体重を取得
	}


	//太るメソッド
	void gainWeight(int w) {
		weight += w; //太る
	}


	//痩せるメソッド
	void reduceWeight(int w) {
		weight -= w; //痩せる
	}


}
