package
Chap08_01;

/**
 * 第8章 クラスの基本<br>
 * 問題8-1<br>
 * 名前・身長・体重などをメンバとしてもつ<<人間クラス>>を作成せよ(フィールドは自分で自由に設計すること)。<br>
 * <br>
 * ＜実行例＞<br>
 * 名前：芹川隆<br>
 * 身長：172cm<br>
 * 体重：78kg<br>
 * <br>
 * 名前：植木学<br>
 * 身長：170cm<br>
 * 体重：58kg<br>
 * <br>
 * @author SystemShared
 */

//人間クラス[Ver.1]
class Human1 {
	String name; //名前
	int height; //身長
	int weight; //体重
}
