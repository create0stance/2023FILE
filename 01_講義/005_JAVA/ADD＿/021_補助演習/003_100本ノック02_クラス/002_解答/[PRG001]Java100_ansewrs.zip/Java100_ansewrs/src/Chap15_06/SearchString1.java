package Chap15_06;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-6<br>
 * 文字列s1の中に文字列s2が含まれているかどうかを調べるプログラムを作成せよ。含まれていない場合は<br>
 * 『s1中にs2は含まれません。』と表示すること。含まれている場合は、一致する部分が上下で揃うように二つ<br>
 * の文字列を縦に並べて表示すること。<br>
 * <br>
 * <実行例><br>
 * 文字列s1 ： ABCDEFGHI<br>
 * 文字列s2 ： EFG<br>
 * ABCDEFGHI<br>
 *     EFG<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列探索
public class SearchString1 {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("文字列s1 ： ");
		String s1 = stdIn.next();

		System.out.print("文字列s2 ： ");
		String s2 = stdIn.next();

		int idx = s1.indexOf(s2);
		if(idx == -1) {
			System.out.println("s1中にs2は含まれません。");
		} else {
			System.out.println(s1);
			for (int i=0; i<idx; i++){
				System.out.print(' ');
			}
			System.out.println(s2);
		}
		
		stdIn.close();
	}
}