package
Chap10_08;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-8<br>
 * クラスDayを以下のように改良せよ。<br>
 * <br>
 * ・引数を受け取らないコンストラクタによるインスタンスの生成時は、<br>
 *  西暦1年1月1日で初期化するのではなく、プログラム実行時の日付で初期化する。<br>
 * ・引数を受け取るコンストラクタに不正な値が指定された場合は、適当な値に調整する<br>
 *  （たとえば13月がしてされた場合は12月とする／9月31日と指定された場合は9月30日とする。<br>
 * <br>
 * さらに、以下に示すメソッドを追加すること：<br>
 * ある年が閏年であるかどうかを判定するクラスメソッド<br>
 * 日付が属する年が閏年であるかどうかを判定するメソッド<br>
 * 年内での経過日数（その年の元旦から数えて何日目であるか）を求めるメソッド<br>
 * 年内の残り日数を求めるメソッド<br>
 * 他の日付との前後関係（より前の日付か／同じ日付か／より後ろの日付か）を判定するインスタンスメソッド<br>
 * 二つの日付の前後関係を判定するクラスメソッド<br>
 * 日付を一つ後ろに進めるメソッド（日付が2012年12月31日であれば、2013年1月1日に更新する）<br>
 * 次の日の日付を返却するメソッド<br>
 * 日付を1つ前に戻すメソッド<br>
 * 前の日の日付を返却するメソッド<br>
 * 日付をn日後ろに進めるメソッド<br>
 * n日後の日付を返却するメソッド<br>
 * 日付をn日前に戻すメソッド<br>
 * n日前の日付を返却するメソッド<br>
 * <br>
 * <実行例><br>
 * 日付を入力せよ。<br>
 * 年：2009<br>
 * 月：8<br>
 * 日：7<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了1<br>
 * 2009年08月07日(金)に関する情報<br>
 * 閏年ではない。<br>
 * 年内経過日数：219<br>
 * 年内残り日数：146<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了2<br>
 * [1]年月日を変更　[2]年を変更<br>
 * [3]月を変更　　　[4]日を変更<br>
 * [5]1日進める　　 [6]1日戻す<br>
 * [7]n日進める　　 [8]n日戻す：7<br>
 * 何日：50<br>
 * 2009年09月26日(土)に更新されました。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了3<br>
 * 比較対象の日付を入力せよ。<br>
 * 年：2001<br>
 * 月：1<br>
 * 日：1<br>
 * 2009年09月26日(土)のほうが後。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了4<br>
 * [1]翌日　[2]前日　[3]n日後　[4]n日前：1<br>
 * それは2009年09月27日(日)です。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了4<br>
 * [1]翌日　[2]前日　[3]n日後　[4]n日前：4<br>
 * 何日：100<br>
 * それは2009年06月18日(木)です。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了5<br>
 * <br>
 * @author System Shared
 */
import java.util.Scanner;

public class DayTester {
	static Scanner stdIn = new Scanner(System.in);

	//--- 日付に関する情報を表示 ---//
	static void display(Day day) {
		System.out.println(day + "に関する情報");
		System.out.println("閏年" + (day.isLeap() ? "である。" : "ではない。"));
		System.out.println("年内経過日数：" + day.dayOfYear());
		System.out.println("年内残り日数：" + day.leftDayOfYear());
	}

	//--- 日付を変更 ---//
	static void change(Day day) {
		System.out.println("[1]年月日を変更　[2]年を変更");
		System.out.println("[3]月を変更　　　[4]日を変更");
		System.out.println("[5]1日進める　　 [6]1日戻す");
		System.out.print(  "[7]n日進める　　 [8]n日戻す：");

		int change = stdIn.nextInt();
		int y = 0, m = 0, d = 0, n = 0;

		if (change == 1 || change == 2) {
			System.out.print("年：");
			y = stdIn.nextInt();
		}
		if (change == 1 || change == 3) {
			System.out.print("月：");
			m = stdIn.nextInt();
		}
		if (change == 1 || change == 4) {
			System.out.print("日：");
			d = stdIn.nextInt();
		}
		if (change == 7 || change == 8) {
			System.out.print("何日：");
			n = stdIn.nextInt();
		}

		switch (change) {
			case 1: day.set(y, m, d);	break;		// y年m月d日に設定
			case 2: day.setYear(y);		break;		// y年に設定
			case 3: day.setMonth(m);	break;		// m月に設定
			case 4: day.setDate(d);		break;		// d日に設定
			case 5: day.succeed();		break;		// 1日進める
			case 6: day.preceed();		break;		// 1日戻す
			case 7: day.succeedDays(n);	break;		// n日進める
			case 8: day.preceedDays(n); break;		// n日戻す
		}
		System.out.println(day + "に更新されました。");
	}

	//--- 他の日付との比較 ---//
	static void compare(Day day) {
		System.out.println("比較対象の日付を入力せよ。");
		System.out.print("年：");
		int y = stdIn.nextInt();
		System.out.print("月：");
		int m = stdIn.nextInt();
		System.out.print("日：");
		int d = stdIn.nextInt();

		Day d2 = new Day(y, m, d);		// 比較対象の日付

		int comp = day.compareTo(d2);	// int comp = compare(day, d2);でも可
		System.out.print(day);

		switch (comp) {
			case -1: System.out.println("のほうが前。");	break;
			case  1: System.out.println("のほうが後。");	break;
			case  0: System.out.println("と同じ。");		break;
		}
	}

	//--- 前後の日付を求める ---//
	static void beforeAfter(Day day) {
		System.out.print("[1]翌日　[2]前日　[3]n日後　[4]n日前：");
		int type = stdIn.nextInt();
		int n = 0;
		if (type == 3 || type == 4) {
			System.out.print("何日：");
			n = stdIn.nextInt();
		}

		System.out.print("それは");
		switch (type) {
			case 1: System.out.print(day.succeedingDay());	break;		// 翌日
			case 2: System.out.print(day.preceedingDay());	break;		// 前日
			case 3: System.out.print(day.after(n));			break;		// n日後
			case 4: System.out.print(day.before(n));		break;		// n日前
		}
		System.out.println("です。");
	}

	public static void main(String[] args) {
		System.out.println("日付を入力せよ。");
		System.out.print("年：");
		int y = stdIn.nextInt();
		System.out.print("月：");
		int m = stdIn.nextInt();
		System.out.print("日：");
		int d = stdIn.nextInt();

		Day day = new Day(y, m, d);

		while (true) {
			System.out.print(
					"[1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較\n" +
					"[4]前後の日付を求める　　　[5]終了");

			int menu = stdIn.nextInt();
			if (menu == 5) {
				break;
			}

			switch (menu) {
			case 1: display(day);		break;	// 日付に関する情報を表示
			case 2: change(day);		break;	// 日付を変更
			case 3: compare(day);		break;	// 他の日付との比較
			case 4: beforeAfter(day);	break;	// 前後の日付を求める
			}
		}
	}
}
