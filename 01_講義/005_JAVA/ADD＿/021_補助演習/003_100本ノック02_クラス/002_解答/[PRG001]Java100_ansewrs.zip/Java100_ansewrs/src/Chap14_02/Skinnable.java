package Chap14_02;

/**
 * 第14章<br>
 * 問題14-2<br>
 * <br>
 * 設問内容は同パッケージ内のSkinnableSoftwareTester.javaに記載
 *
 * @author System Shared
 */

//着せかえインターフェースSkinnable
public interface Skinnable {
	int BLACK = 0;		// 黒
	int RED = 1;		// 赤
	int GREEN = 2;		// 緑
	int BLUE = 3;		// 青
	int LEOPARD = 4;	// 豹柄
	void changeSkin(int skin);	// ★スキン変更
}
