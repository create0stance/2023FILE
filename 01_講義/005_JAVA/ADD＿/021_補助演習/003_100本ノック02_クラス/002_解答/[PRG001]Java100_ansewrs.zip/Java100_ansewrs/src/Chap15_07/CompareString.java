package Chap15_07;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-7<br>
 * キーボードから読み込んだ二つの文字列が等しいかどうかを判定するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 文字列s1 ： ABC<br>
 * 文字列s2 ： ABC<br>
 * s1 != s2 です。<br>
 * s1とs2の中身は等しい。<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列の比較
public class CompareString {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("文字列s1 ： ");
		String s1 = stdIn.next();
		System.out.print("文字列s2 ： ");
		String s2 = stdIn.next();

		if (s1 == s2) {
			System.out.println("s1 == s2 です。"); // 実行されない
		} else {
			System.out.println("s1 != s2 です。"); // 必ず実行される
		}
		if (s1.equals(s2)) {
			System.out.println("s1とs2の中身は等しい。");
		} else {
			System.out.println("s1とs2の中身は等しくない。");
		}
		
		stdIn.close();
	}
}