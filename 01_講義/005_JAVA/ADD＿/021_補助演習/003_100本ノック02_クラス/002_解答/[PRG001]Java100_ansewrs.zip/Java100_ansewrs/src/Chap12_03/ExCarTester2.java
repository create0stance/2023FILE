package Chap12_03;

import Chap12_01.ExCar;
import Chap12_01.Day;

/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-3<br>
 * 自動車クラスExCar型のインスタンスを作り、メソッドputSpecを呼び出して<br>
 * スペックを表示するプログラムを作成せよ。<br>
 * ExCarクラスは問題12-1で作成したクラスをインポートすること。<br>
 * <br>
 * <実行例><br>
 * 名前 : W140<br>
 * 車幅 : 1885mm<br>
 * 車高 : 1490mm<br>
 * 車長 : 5220mm<br>
 * 総走行距離 : 0.00km<br>
 * <br>
 *
 * @author SystemShared
 */

// 自動車クラス(総走行距離付き)の利用例(スペックの表示)
public class ExCarTester2 {

	public static void main(String[] args) {
		ExCar myCar = new ExCar("W140", 1885, 1490, 5220, 95.0, new Day(2005,
				10, 13));
		myCar.putSpec(); // スペックの表示
	}
}
