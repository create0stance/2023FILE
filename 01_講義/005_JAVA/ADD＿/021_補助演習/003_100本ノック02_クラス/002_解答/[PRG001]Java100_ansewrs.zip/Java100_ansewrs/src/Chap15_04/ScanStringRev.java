package Chap15_04;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-4<br>
 * 文字列を読み込んで、その文字列を逆順に表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 文字列 ： AB漢字<br>
 * 逆から読むと字漢BAです。<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列を１文字ずつ逆順に走査して表示
public class ScanStringRev {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("文字列 ： ");

		String s = stdIn.next();

		System.out.print("逆から読むと");
		for (int i = s.length()-1; i >= 0; i--) {
			System.out.print(s.charAt(i));
		}
		System.out.print("です。");
		
		stdIn.close();
	}
}
