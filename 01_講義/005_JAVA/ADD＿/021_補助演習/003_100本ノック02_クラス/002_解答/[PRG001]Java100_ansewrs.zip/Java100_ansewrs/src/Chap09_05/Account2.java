package
Chap09_05;
/**
 * 第9章 単純なクラスの作成<br>
 * 問題9-5<br>
 * 以下に示す銀行口座クラスに対して、口座開設日のフィールドとtoStringメソッドを追加せよ。<br>
 * ※コンストラクタを変更したり、口座開設日のゲッタ（口座開設日フィールドが参照する日付インスタンスのコピーを返す）などのメソッドを追加したりすること。<br>
 * <br>
 * <実行例(AccountTester2)><br>
 * 口座情報を入力せよ。<br>
 * 名    義 ： 佐藤一郎<br>
 * 番    号 ： 111111<br>
 * 残    高 ： 99999<br>
 * 開設年 ： 2009<br>
 * 開設月 ： 1<br>
 * 開設日 ： 1<br>
 * 口座基本情報 ： {佐藤一郎, 111111, 99999}<br>
 * 開設日 ： 2009年01月01日(木)<br>
 * <br>
 * @author SystemShared
 */

// 銀行口座クラス[Ver.2]
public class Account2 {
	private String name;			// 口座名義
	private String no;				// 口座番号
	private long balance;			// 預金残高
	private Day openDay;			// 口座開設日

	//--- コンストラクタ ---//
	Account2(String n, String num, long z, Day d){
		name = n;					// 口座名義
		no = num;					// 口座番号
		balance = z;				// 預金残高
		openDay = new Day(d);		// 口座開設日
	}

	//--- 口座名義を調べる ---//
	public String getName() {
		return name;
	}

	//--- 口座番号を調べる ---//
	public String getNo() {
		return no;
	}

	//--- 預金残高を調べる ---//
	public long getBalance() {
		return balance;
	}

	//--- 口座開設日を調べる ---//
	public Day getOpenDay(){
		return new Day(openDay);
	}

	//--- k円を預ける ---//
	public void deposit(long k) {
		this.balance += k;
	}

	//--- k円おろす ---//
	public void withdraw(long k) {
		this.balance -= k;
	}

	//--- 文字列表現による口座基本情報を返却する ---//
	@Override
	public String toString() {
		return "{"+ name +", "+ no +", "+ balance +"}";
	}
}