/**
 * JavaPracticeChap13_01<br>
 * 第13章 抽象クラス<br>
 * @author SystemShared
 */
package
Chap13_01;
