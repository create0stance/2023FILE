/**
 * JavaPracticeChap13_06<br>
 * 第13章 抽象クラス<br>
 * @author SystemShared
 */
package
Chap13_06;
