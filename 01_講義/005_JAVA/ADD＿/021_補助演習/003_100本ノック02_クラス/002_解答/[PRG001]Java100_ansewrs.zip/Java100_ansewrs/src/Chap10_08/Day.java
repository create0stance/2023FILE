package
Chap10_08;
/**
 * 第10章 クラス変数とクラスメソッド<br>
 * 問題10-8<br>
 * クラスDayを以下のように改良せよ。<br>
 * <br>
 * ・引数を受け取らないコンストラクタによるインスタンスの生成時は、<br>
 *  西暦1年1月1日で初期化するのではなく、プログラム実行時の日付で初期化する。<br>
 * ・引数を受け取るコンストラクタに不正な値が指定された場合は、適当な値に調整する<br>
 *  （たとえば13月がしてされた場合は12月とする／9月31日と指定された場合は9月30日とする。<br>
 * <br>
 * さらに、以下に示すメソッドを追加すること：<br>
 * ある年が閏年であるかどうかを判定するクラスメソッド<br>
 * 日付が属する年が閏年であるかどうかを判定するメソッド<br>
 * 年内での経過日数（その年の元旦から数えて何日目であるか）を求めるメソッド<br>
 * 年内の残り日数を求めるメソッド<br>
 * 他の日付との前後関係（より前の日付か／同じ日付か／より後ろの日付か）を判定するインスタンスメソッド<br>
 * 二つの日付の前後関係を判定するクラスメソッド<br>
 * 日付を一つ後ろに進めるメソッド（日付が2012年12月31日であれば、2013年1月1日に更新する）<br>
 * 次の日の日付を返却するメソッド<br>
 * 日付を1つ前に戻すメソッド<br>
 * 前の日の日付を返却するメソッド<br>
 * 日付をn日後ろに進めるメソッド<br>
 * n日後の日付を返却するメソッド<br>
 * 日付をn日前に戻すメソッド<br>
 * n日前の日付を返却するメソッド<br>
 * <br>
 * <実行例><br>
 * 日付を入力せよ。<br>
 * 年：2009<br>
 * 月：8<br>
 * 日：7<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了1<br>
 * 2009年08月07日(金)に関する情報<br>
 * 閏年ではない。<br>
 * 年内経過日数：219<br>
 * 年内残り日数：146<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了2<br>
 * [1]年月日を変更　[2]年を変更<br>
 * [3]月を変更　　　[4]日を変更<br>
 * [5]1日進める　　 [6]1日戻す<br>
 * [7]n日進める　　 [8]n日戻す：7<br>
 * 何日：50<br>
 * 2009年09月26日(土)に更新されました。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了3<br>
 * 比較対象の日付を入力せよ。<br>
 * 年：2001<br>
 * 月：1<br>
 * 日：1<br>
 * 2009年09月26日(土)のほうが後。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了4<br>
 * [1]翌日　[2]前日　[3]n日後　[4]n日前：1<br>
 * それは2009年09月27日(日)です。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了4<br>
 * [1]翌日　[2]前日　[3]n日後　[4]n日前：4<br>
 * 何日：100<br>
 * それは2009年06月18日(木)です。<br>
 * [1]日付に関する情報を表示　[2]日付を変更　[3]他の日付との比較<br>
 * [4]前後の日付を求める　　　[5]終了5<br>
 * <br>
 * @author System Shared
 */

import java.util.GregorianCalendar;
import static java.util.GregorianCalendar.*;
// 日付クラスDay Ver.2
class Today {
	public static void main(String[] args) {
		Day today = new Day();		// 今日
		System.out.println("今日は" + today + "です。");
	}
}

class Day {
	private int year	= 1;
	private int month	= 1;
	private int date	= 1;
	//--- 各月の日数 ---//
	private static int[][] mdays = {
		// 平成
		{
			31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
		},
		// 閏年
		{
			31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
		},
	};

	//--- y年は閏年か？ ---//
	public static boolean isLeap(int y) {
		return y % 4 == 0 && y % 100 != 0 || y % 400 == 0;
	}

	//--- y年m月の日数（28/29/30/31） ---//
	public static int dayOfMonth(int y, int m) {
		return mdays[isLeap(y) ? 1 : 0][m - 1];
	}

	//--- 調整されたm月（1～12の範囲外の値を調整） ---//
	private static int adjustedMonth(int m) {
		return m < 1 ? 1 : m > 12 ? 12 : m;
	}

	//--- 調整されたy年m月のd日（1～28/29/30/31の範囲外の値を調整）---//
	private static int adjustedDay(int y, int m, int d) {
		if (d < 1) {
			return 1;
		}
		int dMax = dayOfMonth(y, m);		// y年m月の日数
		return d > dMax ? dMax : d;
	}

	//--- コンストラクタ（今日の日付） ---//
	public Day() {
		GregorianCalendar today = new GregorianCalendar();		// 現在の日付
		this.year	= today.get(YEAR);							// 年
		this.month	= today.get(MONTH) + 1;						// 月
		this.date	= today.get(DATE);							// 日
	}

	//--- コンストラクタ（year年1月1日） ---//
	public Day(int year) {
		this.year = year;
	}

	//--- コンストラクタ（year年month月1日）---//
	public Day(int year, int month) {
		this(year);
		this.month = adjustedMonth(month);
	}

	//--- コンストラクタ（year年month月day日） ---//
	public Day(int year, int month, int date) {
		this(year, month);
		this.date = adjustedDay(year, this.month, date);
	}

	//--- コピーコンストラクタ（dと同じ日付） ---//
	public Day(Day d) {
		this(d.year, d.month, d.date);
	}

	//--- 年を取得 ---//
	public int getYear() {
		return year;
	}

	//--- 月を取得 ---//
	public int getMonth() {
		return month;
	}

	//--- 日を取得 ---//
	public int getDate() {
		return date;
	}

	//--- 年を設定 ---//
	public void setYear(int year) {
		this.year	= year;									// 年
		this.month	= adjustedDay(year, month, date);		// 日を調整
	}

	//--- 月を設定 ---//
	public void setMonth(int month) {
		this.month	= adjustedMonth(month);					// 月を調整
		this.date	= adjustedDay(year, this.month, date);	// 日を調整
	}

	//--- 日を設定 ---//
	public void setDate(int date) {
		this.date	= adjustedDay(year, month, date);		// 日を調整
	}

	//--- 年・月・日を設定 ---//
	public void set(int year, int month, int date) {
		this.year	= year;									// 年
		this.month	= adjustedMonth(month);					// 月を調整
		this.date	= adjustedDay(year, this.month, date);	// 日を調整
	}

	//--- 閏年か ---//
	public boolean isLeap() {
		return isLeap(year);								// クラスメソッド版isLeapを呼び出す
	}

	//--- 曜日を求める ---//
	public int dayOfWeek() {
		int y = year;			// 0 ･･･ 日曜日
		int m = month;			// 1 ･･･ 月曜日
		if (m == 1 || m == 2) {	//    :
			y--;				// 5 ･･･ 金曜日
			m += 12;			// 6 ･･･ 土曜日
		}
		return (y + y / 4 - y / 100 + y / 400 + (13 * m + 8) / 5 + date) % 7;
	}

	//--- 日付dと等しいか ---//
	public boolean equalTo(Day d) {
		return year == d.year && month == d.month && date == d.date;
	}

	//--- 文字列表現を返却 ---//
	@Override
	public String toString() {
		String[] wd = {"日", "月", "火", "水", "木", "金", "土"};
		return String.format("%04d年%02d月%02d日(%s)", year, month, date, wd[dayOfWeek()]);
	}

	//--- 年内の経過日数 ---//
	public int dayOfYear() {
		int days = date;		// 年内の経過日数

		for (int i = 1; i < month; i++)			// 1月～(m-1)月の日数を加える
			days += dayOfMonth(year, i);
		return days;
	}

	//--- 年内の残り日数 ---//
	public int leftDayOfYear() {
		return 365 + (isLeap(year) ? 1 : 0) - dayOfYear();
	}

	//--- 日付dとの前後関係を判定 ---//
	public int compareTo(Day d) {
		return compare(this, d);
	}

	//--- 二つの日付の前後関係を判定 ---//
	public static int compare(Day d1, Day d2) {
		if (d1.year		> d2.year) return  1;			// 年が異なる
		if (d1.year		< d2.year) return -1;			//		〃
														// 年は等しい
		if (d1.month	> d2.month) return  1;			// 月が異なる
		if (d1.month	< d2.month) return -1;			//		〃

		return d1.date > d2.date ? 1 : d1.date < d2.date ? -1 : 0;		// 月も等しい
	}

	//--- 日付を一つ後ろに進める ---//
	public void succeed() {
		if (date < dayOfMonth(year, month)) {
			date++;
		}else {
			if (++month > 12) {
				year++;
				month = 1;
			}
			date = 1;
		}
	}

	//--- 翌日の日付を返す ---//
	public Day succeedingDay() {
		Day temp = new Day(this);
		temp.succeed();
		return temp;
	}

	//--- 日付を一つ前に戻す ---//
	public void preceed() {
		if (date > 1) {
			date--;
		}else {
			if (--month < 1) {
				year--;
				month = 12;
			}
			date = dayOfMonth(year, month);
		}
	}

	//--- 前日の日付を返す ---//
	public Day preceedingDay() {
		Day temp = new Day(this);
		temp.preceed();
		return temp;
	}

	//--- 日付をn日後ろに進める ---//
	public void succeedDays(int n) {
		if (n < 0) {
			preceedDays(-n);
		}else if(n > 0){
			date += n;
			while (date > dayOfMonth(year, month)) {
				date -= dayOfMonth(year, month);
				if (++month > 12) {
					year++;
					month = 1;
				}
			}
		}
	}

	//--- n日後の日付を返す ---//
	public Day after(int n) {
		Day temp = new Day(this);
		temp.succeedDays(n);
		return temp;
	}

	//--- 日付をn日前に戻す ---//
	public void preceedDays(int n) {
		if (n < 0) {
			succeedDays(-n);
		}else if(n > 0) {
			date -= n;
			while (date < 1) {
				if (--month < 1) {
					year--;
					month = 12;
				}
				date += dayOfMonth(year, month);
			}
		}
	}

	//--- n日前の日付を返す ---//
	public Day before(int n) {
		Day temp = new Day(this);
		temp.preceedDays(n);
		return temp;
	}
}
