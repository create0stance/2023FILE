/**
 * JavaPracticeChap09_06<br>
 * 第9章 単純なクラスの作成<br>
 * @author SystemShared
 */
package 
Chap09_06;
