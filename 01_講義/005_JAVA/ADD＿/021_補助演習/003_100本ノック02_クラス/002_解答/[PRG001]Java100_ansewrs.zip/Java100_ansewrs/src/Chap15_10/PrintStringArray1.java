package Chap15_10;

import java.util.Scanner;

/**
 * 第15章<br>
 * 問題15-10<br>
 * String型の配列に格納されている全体文字列を表示するメソッドを作成せよ。文字列の表示は、<br>
 * charAtメソッドによって１文字ずつ走査しながら行うこと。また、各文字列を表示するたびに改行<br>
 * 文字を出力すること。<br>
 * <br>
 * <実行例><br>
 * 文字列の個数 ： ３<br>
 * sx[0] = Turbo<br>
 * sx[1] = NA<br>
 * sx[2] = DOHC<br>
 * Turbo<br>
 * NA<br>
 * DOHC<br>
 * <br>
 *
 * @author System Shared
 */

// 文字列の配列を表示するメソッド [Ver.1]
public class PrintStringArray1 {

	// 文字列の配列を表示
	static void printStringArray(String[] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length(); j++) {
				System.out.print(a[i].charAt(j));
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("文字列の個数 ： ");
			int n = stdIn.nextInt();
			String[] sx = new String[n];

			for (int i = 0; i < sx.length; i++) {
				System.out.print("sx[" + i + "] = ");
				sx[i] = stdIn.next();
			}
			printStringArray(sx);
			
			stdIn.close();
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}