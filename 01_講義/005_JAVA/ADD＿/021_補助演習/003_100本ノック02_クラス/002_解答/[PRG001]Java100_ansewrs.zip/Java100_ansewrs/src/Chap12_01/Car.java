package Chap12_01;
/**
 * 第12章 クラスの派生と多相性<br>
 * 問題12-1<br>
 * 以下に示す自動車クラスCarに対して、総走行距離を表すフィールドと、その値を調べるメソッドを<br>
 * 追加した自動車クラスExCarを作成せよ。クラスCarから派生すること。<br>
 * なお、Carクラス,ExCarクラスは問題12-2以降で利用する為mainメソッドを持たない。<br>
 * また、Carクラスは問題8-3で作成したクラスを流用。今回使用しないフィールドは既に削除してある。<br>
 * <br>
 *
 * @author SystemShared
 */

// 自動車クラス[Ver.2]
public class Car {

	private String name;		// 名前
	private int width; 			// 幅
	private int height; 		// 高さ
	private int length; 		// 長さ
	private double x; 			// 現在位置X座標
	private double y; 			// 現在位置Y座標
	private double fuel; 		// 残り燃料
	private Day purchaseDay;	// 購入日


	//--- コンストラクタ ---//
	public Car(String name, int width, int height, int length, double fuel,
			Day purchaseDay){
		this.name = name;	this.width = width;	this.height = height;
		this.length = length;	this.fuel =fuel;	x = y = 0.0;
		this.purchaseDay = new Day(purchaseDay);
	}

	public double getX(){ return x; }
	public double getY(){ return y; }
	public double getFuel(){ return fuel; }
	public Day getPurchaseDay(){return new Day(purchaseDay);}

	//--- スペックの表示 ---//
	public void putSpec(){
		System.out.println("名前 : " + name);
		System.out.println("車幅 : " + width + "mm");
		System.out.println("車高 : " + height + "mm");
		System.out.println("車長 : " + length + "mm");
	}

	//--- X方向にdx・Y方向にdy移動 ---//
	public boolean move(double dx, double dy){
		double dist = Math.sqrt(dx * dx + dy * dy);	// 移動距離

		if(dist > fuel)
			return false;	// 移動できない   ･･･ 燃料不足
		else {
			fuel -= dist;	// 移動距離の分だけ燃料が減る
			x += dx;
			y += dy;
			return true;	// 移動完了
		}
	}
}
