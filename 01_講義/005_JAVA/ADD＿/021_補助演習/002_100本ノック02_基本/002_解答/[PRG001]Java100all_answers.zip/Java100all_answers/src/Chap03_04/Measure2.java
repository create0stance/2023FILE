package
Chap03_04;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-4<br>
 * 前問のプログラムを論理補数演算子！を用いて置きかえよ。<br>
 * <br>
 * <実行例><br>
 * 変数Ａ：8<br>
 * 変数Ｂ：4<br>
 * ＢはＡの約数です。<br>
 * <br>
 * @author SystemShared
 */

class Measure2 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("変数Ａ：");
		int a = stdIn.nextInt();
		System.out.print("変数Ｂ：");
		int b = stdIn.nextInt();

		if (!(a % b == 0)){
			System.out.println("ＢはＡの約数ではありません。");
		}else{
			System.out.println("ＢはＡの約数です。");
		}

	}
}
