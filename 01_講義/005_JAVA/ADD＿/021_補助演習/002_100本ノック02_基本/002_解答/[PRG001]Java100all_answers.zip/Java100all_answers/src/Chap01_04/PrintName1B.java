package Chap01_04;
/**
 * 第1章 画面に文字を表示しよう<br>
 * 問題1-4<br>
 * 各行に1文字ずつ自分の名前を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 電<br>
 * 子<br>
 * 太<br>
 * 郎<br>
 *<br>
 * @author SystemShared
 */

public class PrintName1B {
   public static void main(String[] args) {
	   System.out.println("電\n子\n太\n郎");

   }
}