package Chap07_22;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-22<br>
 * 配列aの要素a[idx]にxを挿入し配列を返却するメソッドarrayInsOfを作成せよ。<br>
 * int[] arrayInsOf(int[] a, int idx, int x)<br>
 * 挿入い伴ってa[idx]以降の全要素を一つ後方にずらすこと。<br>
 * 【例】たとえば配列aの要素が{1, 3, 4, 7, 9, 11}のときにarrayInsOf{a, 2, 99}と呼び出され<br>
 * た場合、返却する配列の要素は{1, 3, 99, 4, 7, 9, 11}となる。<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 6<br>
 * x[0] : 1<br>
 * x[1] : 3<br>
 * x[2] : 4<br>
 * x[3] : 7<br>
 * x[4] : 9<br>
 * x[5] : 11<br>
 * 挿入するインデックス ： 2<br>
 * 挿入する値 ： 99<br>
 * y[0] = 1<br>
 * y[1] = 3<br>
 * y[2] = 99<br>
 * y[3] = 4<br>
 * y[4] = 7<br>
 * y[5] = 9<br>
 * y[6] = 11<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 配列に要素を挿入した配列を返却
public class ArrayInsOf {
	// --- 配列aのa[idx]にxを挿入した配列を返却 ---//
	static int[] arrayInsOf(int[] a, int idx, int x) {
		if (idx < 0 || idx > a.length) {
			return a.clone();
		} else {
			int[] c = new int[a.length + 1];
			int i = 0;
			for ( ; i < idx; i++) {
				c[i] = a[i];
			}
			for( ; i< a.length; i++){
				c[i + 1] =a[i];
			}
			c[idx] = x;
			return c;
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();
			int[] x = new int[num]; // 要素数numの配列

			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			System.out.print("挿入するインデックス ： ");
			int idx = stdIn.nextInt();

			System.out.print("挿入する値 ： ");
			int n = stdIn.nextInt();

			// 配列xのx[idx]にを挿入した配列を生成
			int[] y = arrayInsOf(x, idx, n);

			for (int i = 0; i < y.length; i++) { // 配列yを表示
				System.out.println("y[" + i + "] = " + y[i]);
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
