package Chap07_23;

/**
 * 第7章 メソッド<br>
 * 問題7-23<br>
 * 行列xとyの和を求めてzに格納するメソッドaddMatrixを作成せよ。<br>
 * boolen addMatrix(int[][] x, int[][] y, int[][] z)<br>
 * 三つの配列の要素数が等しければ加算を行ってtrueを返し、等しくなければ加算を行わずに<br>
 * falseを返すこと。<br>
 * <br>
 * <実行例><br>
 * 行列a<br>
 * 1 2 3 <br>
 * 4 5 6 <br>
 * <br>
 * 行列b<br>
 * 6 3 4 <br>
 * 5 1 2 <br>
 * <br>
 * 行列c<br>
 * 7 5 7 <br>
 * 9 6 8 <br>
 * <br>
 * @author System Shared
 *
 */
// 二つ行列の和を求める
public class AddMatrixX {

	//--- 行列xとyの和をzに代入 ---//
	static boolean addMatrix(int[][] x, int[][] y, int[][] z){
		if(x.length != y.length || y.length != z.length){
			return false;
		}
		for(int i = 0; i < x.length; i++){
			if(x[i].length != y[i].length || y[i].length != z[i].length){
				return false;
			}
		}
		for(int i = 0; i < x.length; i++){
			for(int j = 0; j < x[i].length; j++){
				z[i][j] = x[i][j] + y[i][j];
			}
		}
		return true;
	}
	//--- 行列mの全要素を表示 ---//
	static void printMatrix(int[][] m){
		for(int i = 0; i < m.length; i++){
			for(int j = 0; j < m[i].length; j++){
				System.out.print(m[i][j] +" ");
			}
		System.out.println();
		}
	}
	public static void main(String[] args) {
			int[][] a = {{1, 2, 3},{4, 5, 6}};
			int[][] b = {{6, 3, 4},{5, 1, 2}};
			int[][] c = new int[2][3];

			if(addMatrix(a, b, c)){ // aとbの和をに代入
				System.out.println("行列a");
				printMatrix(a);
				System.out.println("\n行列b");
				printMatrix(b);
				System.out.println("\n行列c");
				printMatrix(c);
			}
	}
}