package 
Chap04_09;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-9<br>
 * 正の整数値を読み込んで、その桁数を出力するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 正の整数値の桁数を求めます。<br>
 * 正の整数値：1254<br>
 * その数は4桁です。<br>
 * <br>
 * @author SystemShared
 */

//正の整数値の桁数を求める
class DigitNo {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("正の整数値の桁数を求めます。");
		int x;
		do {
			System.out.print("正の整数値：");
			x = Integer.parseInt(br.readLine());
		} while (x <= 0);

		int digits = 0; //桁数
		while (x > 0) {
			digits++; //桁数をインクリメント
			x /= 10; //xを10で割る
		}
		System.out.println("その数は" + digits + "桁です。");
	}
}