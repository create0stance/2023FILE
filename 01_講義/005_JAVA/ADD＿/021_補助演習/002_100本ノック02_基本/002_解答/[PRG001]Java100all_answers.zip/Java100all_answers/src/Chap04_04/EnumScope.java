package 
Chap04_04;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-4<br>
 * 二つの整数値を読み込んで、小さいほうの数以上で大きいほうの数以下の全整数の小さいほうから順に表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数A：33<br>
 * 整数B：28<br>
 * 28 29 30 31 32 33<br>
 * <br>
 * @author SystemShared
 */

class EnumScope {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));;
		String input = "";

		System.out.print("整数A：");
		input = br.readLine();
		int a = Integer.parseInt(input);
		System.out.print("整数B：");
		input = br.readLine();
		int b = Integer.parseInt(input);

		if (a > b) { //aがbより大きければ
			int t = a;
			a = b;
			b = t;
		}

		do {
			System.out.print(a + " ");
			a = a + 1;
		} while (a <= b);
		System.out.println();
	}
}
