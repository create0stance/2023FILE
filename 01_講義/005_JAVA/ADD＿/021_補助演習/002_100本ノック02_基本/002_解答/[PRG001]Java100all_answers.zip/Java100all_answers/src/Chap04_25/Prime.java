package Chap04_25;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-25<br>
 * 正の整数を読み込み、それが素数であるかどうかを判定するプログラムを作成せよ。素数とは、<br>
 * 2以上n未満のいずれの数でも割り切ることの出来ない整数nのことである。<br>
 * <br>
 * <実行例1><br>
 * 2以上の整数値 ： 13<br>
 * それは素数です。<br>
 * <br>
 * <実行例2><br>
 * 2以上の整数値 ： 14<br>
 * それは素数ではありません。<br>
 * <br>
 *
 * @author System Shared
 */
// 素数の判定
public class Prime {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		int n;
		do {
			System.out.print("2以上の整数値 ： ");
			n = stdIn.nextInt();
		} while (n < 2);

		int i;
		for (i = 2; i < n; i++) {
			if (n % i == 0) { // 割り切れた（素数ではない）
				break;
			}
		}
		if (i == n) {
			System.out.println("それは素数です。");
		} else {
			System.out.println("それは素数ではありません。");
		}
	}
}
