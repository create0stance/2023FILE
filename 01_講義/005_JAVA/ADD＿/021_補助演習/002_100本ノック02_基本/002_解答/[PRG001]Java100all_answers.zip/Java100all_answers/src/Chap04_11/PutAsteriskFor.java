package Chap04_11;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-11<br>
 * 記号文字を任意の個数だけ出力する問題4-7をfor文で実現せよ。<br>
 * <br>
 * <実行例><br>
 * 何個*を表示しますか ： 12<br>
 * ************<br>
 * <br>
 *
 * @author System Shared
 */
// 読み込んだ個数だけ*を表示
public class PutAsteriskFor {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("何個*を表示しますか ： ");
		int n = stdIn.nextInt();

		if (n > 0) {
			for (int i = 0; i < n; i++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
