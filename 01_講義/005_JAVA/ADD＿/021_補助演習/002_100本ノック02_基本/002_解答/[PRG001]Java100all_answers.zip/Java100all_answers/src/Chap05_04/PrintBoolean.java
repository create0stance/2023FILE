package 
Chap05_04;
/**
 * 第5章 基本型と演算
 * 問題5-4
 * 論理型の変数にtrueやfalseを代入して、その値を表示するプログラムを作成せよ。
 * @author System Shared
 */

class PrintBoolean {

	public static void main(String[] args) {
		boolean b1 = true;
		boolean b2 = false;

		System.out.println("b1 = " + b1);
		System.out.println("b2 = " + b2);
	}
}
