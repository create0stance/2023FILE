package 
Chap03_07;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-7<br>
 * 二つの変数ａ，ｂに値を読み込んで、その大小関係を以下のいずれかで表示するプログラムを作成せよ。<br>
 * 『ａのほうが大きいです。』『ｂのほうが大きいです。』『ａとｂは同じ値です。』<br>
 * <br>
 * <実行例><br>
 * 変数ａ：1<br>
 * 変数ｂ：2<br>
 * ｂのほうが大きいです。<br>
 * <br>
 * @author SystemShared
 */

class Balance {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("変数ａ：");	int a = stdIn.nextInt();
		System.out.print("変数ｂ：");	int b = stdIn.nextInt();

		if (a > b)
			System.out.println("ａのほうが大きいです。");
		else if (a < b)
			System.out.println("ｂのほうが大きいです。");
		else
			System.out.println("ａとｂは同じ値です。");
	}
}
