package Chap01_02;
/**
 * 第1章 画面に文字を表示しよう<br>
 * 問題1-2<br>
 * プログラム中の文の終端を示すセミコロン;が欠如しているとどうなるか。プログラムをコンパイルして検証せよ。<br>
 *<br>
 * <実行例><br>
 * Exception in thread "main" java.lang.Error: コンパイル問題が未解決です:<br>
 *<br>
 * @author SystemShared
 */

public class HelloError {
   public static void main(String[] args) {
	   System.out.println("初めてのJavaプログラム。");
	   System.out.println("画面に出力しています。");
   }
}
