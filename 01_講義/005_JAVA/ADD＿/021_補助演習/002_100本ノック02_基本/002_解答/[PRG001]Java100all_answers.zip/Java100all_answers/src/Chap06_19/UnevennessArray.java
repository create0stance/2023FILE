package
Chap06_19;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-19<br>
 * 行によって列数の異なる2次元配列を生成するプログラムを作成せよ。<br>
 * 行数・列数・各要素の値はキーボードから読み込むこと。<br>
 * <br>
 * <実行例><br>
 * 凸凹な2次元配列を作ります。<br>
 * 行数：2<br>
 * 0行目の行数：1<br>
 * 1行目の行数：3<br>
 * 各要素の値を入力せよ。<br>
 * c[0][0]：2<br>
 * c[1][0]：4<br>
 * c[1][1]：6<br>
 * c[1][2]：5<br>
 * 配列cの各要素の値は次のようになっています。<br>
 *   2<br>
 *   4  6  5<br>
 * <br>
 * @author SystemShared
 */

//凸凹な2次元配列
class UnevennessArray {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("凸凹な2次元配列を作ります。");
		System.out.print("行数：");
		int height = stdIn.nextInt();

		int[][] c = new int[height][];

		for (int i = 0; i < c.length; i++) {
			System.out.print(i + "行目の行数：");
			int width = stdIn.nextInt();
			c[i] = new int[width];
		}

		System.out.println("各要素の値を入力せよ。");
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				System.out.printf("c[%d][%d]：", i, j);
				c[i][j] = stdIn.nextInt();
			}
		}

		System.out.println("配列cの各要素の値は次のようになっています。");
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++){
				System.out.printf("%3d", c[i][j]);
			}
			System.out.println();
		}
	}
}