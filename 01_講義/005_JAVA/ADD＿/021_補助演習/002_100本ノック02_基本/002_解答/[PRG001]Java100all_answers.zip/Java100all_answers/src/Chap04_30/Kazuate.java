package Chap04_30;

import java.util.Random;
import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-30<br>
 * 問題4-3の数当てゲームを、当てるべき数を0～99に変更するとともに、プレーヤが入力できる回数に制限を<br>
 * 設けたプログラムを作成せよ。制限回数内にあてられなかった場合は、正解を表示してゲームを終了すること。<br>
 * <br>
 * <実行例><br>
 * 数当てゲーム開始!!<br>
 * 0～99の数を当てて下さい。<br>
 * 残り6回。いくつかな ： 50<br>
 * もっと大きな数だよ。<br>
 * 残り5回。いくつかな ： 75<br>
 * もっと小さな数だよ。<br>
 * 残り4回。いくつかな ： 62<br>
 * もっと小さな数だよ。<br>
 * 残り3回。いくつかな ： 57<br>
 * もっと小さな数だよ。<br>
 * 残り2回。いくつかな ： 53<br>
 * もっと大きな数だよ。<br>
 * 残り1回。いくつかな ： 55<br>
 * もっと大きな数だよ。<br>
 * 残念。正解は56でした。<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 数当てゲーム（0～99を当てさせる）
public class Kazuate {
	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		int MAX_NO = 6; // 最大入力回数
		int leftNo = MAX_NO; // 残り回数
		int no = rand.nextInt(100); // 当てるべき数：0~99の乱数として生成

		System.out.println("数当てゲーム開始!!");
		System.out.println("0～99の数を当てて下さい。");

		int x;
		do {
			System.out.print("残り" + (leftNo--) + "回。いくつかな ： ");
			x = stdIn.nextInt();

			if (x > no) {
				System.out.println("もっと小さな数だよ。");
			} else if (x < no) {
				System.out.println("もっと大きな数だよ。");
			}
		} while (x != no && leftNo > 0);
		if (x == no) {
			System.out.println((MAX_NO - leftNo) + "回で当たりましたね。");
		} else {
			System.out.println("残念。正解は" + no + "でした。");
		}
	}
}