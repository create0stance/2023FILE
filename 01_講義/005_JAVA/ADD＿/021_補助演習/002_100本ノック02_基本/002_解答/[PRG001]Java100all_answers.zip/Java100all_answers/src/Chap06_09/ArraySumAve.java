package
Chap06_09;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-9<br>
 * double型の配列の全要素の合計値と平均値を求めるプログラムを作成せよ。<br>
 * 要素数と全要素の値はキーボードから読み込むこと。<br>
 * <br>
 * <実行例><br>
 * 要素数：3<br>
 * a[0] = 4<br>
 * a[1] = 5<br>
 * a[2] = 6<br>
 * 全要素の合計は15.0です。<br>
 * 全要素の平均は5.0です。<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素の合計と平均を求めて表示(拡張for文)
class ArraySumAve {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("要素数：");

		int n = stdIn.nextInt(); //要素数を読み込む
		double[] a = new double[n]; //配列を生成

		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "] = ");
			a[i] = stdIn.nextDouble();
		}

		double sum = 0; //合計
		for (double i : a){
			sum += i;
		}

		System.out.println("全要素の合計は" + sum + "です。");
		System.out.println("全要素の平均は" + sum / n + "です。");
	}
}
