package Chap02_01;
/**
 * 二つの整数値82と17の和と差を求めて表示（演算結果のみを表示）<br>
 * <br>
 * <実行例><br>
 * 82 + 17 = 99<br>
 * 82 - 17 = 65<br>
 * <br>
 * @author SystemShared
 */


class SumDiff2 {

	public static void main(String[] args) {
		System.out.println("82 + 17 = " + (82 + 17));
		System.out.println("82 - 17 = " + (82 - 17));
	}
}