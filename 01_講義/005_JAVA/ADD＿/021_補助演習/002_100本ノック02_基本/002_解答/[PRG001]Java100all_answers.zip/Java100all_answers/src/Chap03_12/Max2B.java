package 
Chap03_12;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-12<br>
 * 二つの実数値を読み込んで、大きいほうの値を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 実数ａ:1<br>
 * 実数ｂ:3<br>
 * 大きいほうの値は3.0です。<br>
 * <br>
 * @author SystemShared
 */

class Max2B {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("実数ａ:");	double a = stdIn.nextDouble();
		System.out.print("実数ｂ:");	double b = stdIn.nextDouble();

		double max = a > b ? a : b;		//大きいほうの値

		System.out.println("大きいほうの値は" + max + "です。");
	}
}
