package 
Chap02_05;
import java.util.Scanner;
/**
 * 第2章 変数を使おう<br>
 * 問題2-5<br>
 * キーボードから読み込んだ整数値をそのまま反復して表示するプログラムを作成せよ。<br>
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。<br>
 * <br>
 * <実行例><br>
 * 整数値：100<br>
 * 100と入力しましたね。<br>
 * <br>
 * @author SystemShared
 */

public class ScanInteger {
	public static void main(String[] args){
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int x = stdIn.nextInt();

		System.out.println(x + "と入力しましたね。");
	}

}