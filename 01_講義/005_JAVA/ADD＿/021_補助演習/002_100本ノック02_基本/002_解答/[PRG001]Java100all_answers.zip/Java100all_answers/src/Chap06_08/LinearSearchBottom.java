package
Chap06_08;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-8<br>
 * 配列から任意の値をもつ要素を探索するプログラムを作成せよ。<br>
 * 同一の値をもつ要素が複数個存在する場合、最も先頭に位置する要素を見つけるプログラムと、最も末尾側に位置する要素を見つけるプログラムの両方を作成せよ。<br>
 * <br>
 * <実行例><br>
 * 要素数：2<br>
 * a[0] = 1<br>
 * a[1] = 2<br>
 * 探す数値：1<br>
 * それはa[0]にあります。<br>
 * <br>
 * @author SystemShared
 */

//線形探索(その2：最も先頭側の要素を探索)
class LinearSearchBottom {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を読み込む
		int[] a = new int[n]; //配列を生成

		for (int j = 0; j < n; j++) {
			System.out.print("a[" + j + "] = ");
			a[j] = stdIn.nextInt();
		}

		System.out.print("探す数値：");
		int key = stdIn.nextInt();

		int i;
		for (i = n - 1; i >= 0; i--){
			if (a[i] ==key){
				break;
			}
		}

		if (i >= 0){ //探索成功
			System.out.print("それはa[" + i + "]にあります。");
		}else{ //探索失敗
			System.out.print("それはありません。");
		}
	}
}