package 
Chap03_19;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-19<br>
 * 三つの整数値を読み込んで昇順（小さい順）にソートするプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 変数ａ：11<br>
 * 変数ｂ：13<br>
 * 変数ｃ：7<br>
 * ａ≦ｂ≦ｃとなるようにソートしました。<br>
 * 変数ａは7です。<br>
 * 変数ｂは11です。<br>
 * 変数ｃは13です。<br>
 * <br>
 * @author SystemShared
 */

class Sort3 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("変数ａ：");		int a = stdIn.nextInt();
		System.out.print("変数ｂ：");		int b = stdIn.nextInt();
		System.out.print("変数ｃ：");		int c = stdIn.nextInt();

		if (a > b) {		//ａがｂより大きければａとｂを交換
			int t = a; 	a = b; 	b = t;
		}
		if (b > c) {		//ｂがｃより大きければｂとｃを交換
			int t = b;	b = c;	c = t;
		}
		if (a > b) {		//ａがｂより大きければａとｂを交換
			int t = a; 	a = b; 	b = t;
		}

		System.out.println("ａ≦ｂ≦ｃとなるようにソートしました。");
		System.out.println("変数ａは" + a + "です。");
		System.out.println("変数ｂは" + b + "です。");
		System.out.println("変数ｃは" + c + "です。");
	}

}
