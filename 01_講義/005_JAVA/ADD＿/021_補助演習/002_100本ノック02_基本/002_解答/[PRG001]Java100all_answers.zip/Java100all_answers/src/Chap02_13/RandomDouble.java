package 
Chap02_13;

import java.util.Random;
/**
 * 第2章 変数を使おう<br>
 * 問題2-13<br>
 * 以下に示すプログラムを作成せよ<br>
 * ・0.0以上1.0未満の実数値をランダムに生成して表示。<br>
 * ・0.0以上10.0未満の実数値をランダムに生成して表示。<br>
 * ・-1.0以上1.0未満の実数値をランダムに生成して表示。<br>
 * <br>
 * <実行例><br>
 * ３個の乱数を生成しました。<br>
 * 0.0以上1.0未満0.6975438282635715<br>
 * 0.0以上10.0未満1.2170632094531197<br>
 * -1.0以上1.0未満-0.22874809960998532<br>
 * <br>
 * @author System Shared
 */
public class RandomDouble {
	public static void main(String[] args) {
		Random rand = new Random();

		double x1 = rand.nextDouble();		// 0.0以上1.0未満の乱数
		double x2 = rand.nextDouble() * 10.0;	// 0.0以上10.0未満の乱数
		double x3 = -1 + 2 * rand.nextDouble();	// -1.0以上1.0未満の乱数

		System.out.println("３個の乱数を生成しました。");
		System.out.println("0.0以上1.0未満"+ x1);
		System.out.println("0.0以上10.0未満"+ x2);
		System.out.println("-1.0以上1.0未満"+ x3);

	}

}
