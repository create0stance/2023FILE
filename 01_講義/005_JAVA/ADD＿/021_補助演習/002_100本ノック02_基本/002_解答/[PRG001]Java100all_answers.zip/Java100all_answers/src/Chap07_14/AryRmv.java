package Chap07_14;

import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-14<br>
 * 配列aから要素a[idx]を削除するメソッドaryRmvを作成せよ。<br>
 * void aryRmv(int[] a, int idx)<br>
 * 削除はa[idx]より後ろの全要素を一つ前方にずらすことによって行うこと。なお、移動されず<br>
 * にあまってしまう末尾要素a[a.length - 1]の値は変更しなくてよい。<br>
 *  【例】配列aの要素が{1, 3, 4, 7, 9, 11}のときにaryRmvN{a, 2}と呼び出した後の配列aの要素<br>
 *     は{1, 3, 7, 9, 11, 11}となる。<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 6<br>
 * a[0] : 1<br>
 * a[1] : 3<br>
 * a[2] : 4<br>
 * a[3] : 7<br>
 * a[4] : 9<br>
 * a[5] : 11<br>
 * 削除する要素のインデックス : 2<br>
 * a[0] = 1<br>
 * a[1] = 3<br>
 * a[2] = 7<br>
 * a[3] = 9<br>
 * a[4] = 11<br>
 * a[5] = 11<br>
 * <br>
 * @author System Shared
 *
 */
// 配列からの要素の削除
public class AryRmv {
	//--- 配列aからa[idx]を削除（以降の要素を前方へずらす） ---//
	static void aryRmv(int[] a, int idx){
		if(idx >= 0 && idx < a.length){
			for (int i = idx; i < a.length - 1; i++){
				a[i] = a[i + 1];
			}
		}
	}

	public static void main(String[] args) {
		try{
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();
			int[] a = new int[num]; // 要素数numの配列

			for (int i = 0; i < num; i++){
				System.out.print("a["+ i +"] : ");
				a[i] = stdIn.nextInt();
			}
			System.out.print("削除する要素のインデックス : ");
			int idx = stdIn.nextInt();

			aryRmv(a, idx); // 配列aからa[idx]を削除

			for(int i = 0; i < num; i++){ // 配列aを表示
				System.out.println("a["+ i +"] = "+ a[i]);
			}
		}catch(Exception e){
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}