package 
Chap05_10;
/**
 * 第5章 基本型と演算<br>
 * 問題5-10<br>
 * "ABC\n"と表示するプログラムを作成せよ。（二重引用符などの記号文字も表示すること）。<br>
 * <br>
 * <実行例><br>
 * "ABC\n"<br>
 * <br>
 * @author System Shared
 */

class PrintABC {

	public static void main(String[] args) {
		System.out.println("\"ABC\\n\"");
	}
}
