package 
Chap02_14;

import java.util.Scanner;

/**
 * 第2章 変数を使おう<br>
 * 問題2-14<br>
 * 名前の姓と名とを個別のキーボードから読み込んで、挨拶を行うプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 姓 ： 柴田<br>
 * 名 ： 望洋<br>
 * こんにちは柴田望洋さん。<br>
 * <br>
 * @author System Shared
 */
public class Greeting {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("姓 ： ");
		String firstName = stdIn.next(); // 姓
		System.out.print("名 ： ");
		String lastName = stdIn.next(); // 名

		System.out.println("こんにちは"+ firstName + lastName +"さん。");

	}

}
