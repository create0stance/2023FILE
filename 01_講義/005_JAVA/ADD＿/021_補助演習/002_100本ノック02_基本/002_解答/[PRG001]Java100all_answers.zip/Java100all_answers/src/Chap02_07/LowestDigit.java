package 
Chap02_07;
import java.util.Scanner;
/**
 * 第2章 変数を使おう<br>
 * 問題2-7<br>
 * キーボードから読み込んだ整数値の最下位桁を除いた値と、最下位桁を表示するプログラムを作成せよ。<br>
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。<br>
 * <br>
 * <実行例><br>
 * 整数値：123<br>
 * 最下位桁を除いた値は12です。<br>
 * 最下位桁は3です。<br>
 * <br>
 * @author SystemShared
 */

public class LowestDigit {
	public static void main(String[] args){
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int x = stdIn.nextInt();

		System.out.println("最下位桁を除いた値は" + (x / 10) + "です。");
		System.out.println("最下位桁は" + (x % 10) + "です。");

	}

}