package 
Chap02_03;
/**
 * 第2章 変数を使おう<br>
 * 問題2-3<br>
 * 小数点をもつ実数値をxとyに代入するように変更してその結果を考察せよ。<br>
 * <br>
 * <実行例><br>
 * xの値は63.4です。<br>
 * yの値は18.3です。<br>
 * 合計は81.7です。<br>
 * 平均は40.85です。<br>
 * <br>
 * @author SystemShared
 */

public class SumAveError {
   public static void main(String[] args){
	   double x;
	   double y;

	   x = 63.4;
	   y = 18.3;

	   System.out.println("xの値は" + x + "です。");
	   System.out.println("yの値は" + y + "です。");
	   System.out.println("合計は" + (x + y) + "です。" );
	   System.out.println("平均は" + (x + y) / 2 + "です。");
   }
}