package Chap04_18;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-18<br>
 * 読み込み整数値のすべての約数と、その個数お表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数値 ： 12<br>
 * 1 2 3 4 6 12<br>
 * 約数は6個です。<br>
 * <br>
 *
 * @author System Shared
 */
// 読み込んだ整数値のすべての約数を表示
public class Neasure {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値 ： ");
		int n = stdIn.nextInt();

		int count = 0; // 約数の個数
		for (int i = 1; i <= n; i++) {
			if (n % i == 0) { // 割り切れたら
				System.out.print(i + " "); // 表示
				count++;
			}
		}
		System.out.println("\n約数は" + count + "個です。"); // 個数を表示
	}
}
