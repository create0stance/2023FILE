package 
Chap06_01;
/**
 * 第6章 配列br>
 * 問題6-1<br>
 * 要素型がdouble型で要素数が5の配列を生成して、その全要素の値を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * a[0] = 0.0<br>
 * a[1] = 0.0<br>
 * a[2] = 0.0<br>
 * a[3] = 0.0<br>
 * a[4] = 0.0<br>
 * <br>
 * @author SystemShared
 */

//構成要素型がdouble型で構成要素数が5の配列
class DoubleArray {

	public static void main(String[] args) {
		double[] a = new double[5]; //配列の宣言

		//全構成要素の値を表示
		System.out.println("a[" + 0 + "] = " + a[0]);
		System.out.println("a[" + 1 + "] = " + a[1]);
		System.out.println("a[" + 2 + "] = " + a[2]);
		System.out.println("a[" + 3 + "] = " + a[3]);
		System.out.println("a[" + 4 + "] = " + a[4]);
	}
}
