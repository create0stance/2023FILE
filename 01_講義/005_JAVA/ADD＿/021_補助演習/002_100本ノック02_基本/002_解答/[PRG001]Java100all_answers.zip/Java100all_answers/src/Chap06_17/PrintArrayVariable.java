package 
Chap06_17;
/**
 * 第6章 配列<br>
 * 問題6-17<br>
 * 配列変数の値を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * a = [I@e53108<br>
 * a = null<br>
 * <br>
 * @author SystemShared
 */

//配列変数の値を表示
class PrintArrayVariable {

	public static void main(String[] args) {
		int[] a = new int[5];
		System.out.println("a = " + a);

		a = null;
		System.out.println("a = " + a);
	}
}