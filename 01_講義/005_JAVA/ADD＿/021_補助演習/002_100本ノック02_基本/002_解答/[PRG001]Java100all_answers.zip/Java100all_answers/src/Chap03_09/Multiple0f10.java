package
Chap03_09;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-9<br>
 * 正の整数値を読み込んで、それが10の倍数であれば『その値は１０の倍数です。』と表示し、<br>
 * そうでなければ『その値は10の倍数ではありません。』と表示するプログラムを作成せよ。<br>
 * ※正でない値を読み込んだ場合は、『正でない値が入力されました。』と表示すること。<br>
 * <br>
 * <実行例><br>
 * 整数値：100<br>
 * その値は10の倍数です。<br>
 * <br>
 * @author SystemShared
 */

class Multiple0f10 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int n = stdIn.nextInt();

		if (n > 0){
			if (n % 10 == 0){
				System.out.println("その値は10の倍数です。");
			}else{
				System.out.println("その値は10の倍数ではありません。");
			}
		}else{
			System.out.println("正ではない値が入力されました。");
		}

	}
}
