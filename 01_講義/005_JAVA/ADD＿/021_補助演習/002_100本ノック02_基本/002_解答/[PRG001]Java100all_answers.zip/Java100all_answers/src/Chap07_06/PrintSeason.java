package 
Chap07_06;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-6<br>
 * 引数mで指定された月の季節を表示するメソッドprintSeasonを表示せよ。<br>
 * mが3,4,5であれば『春』、6,7,8であれば『夏』、9,10,11であれば『秋』、12,1,2であれば『冬』と表示し、それ以外の値であれば何も表示しないこと。<br>
 * void printSeason(int m)<br>
 * <br>
 * ＜実行例1＞<br>
 * 何月ですか(1～12)：8<br>
 * その月の季節は夏です。<br>
 * <br>
 * ＜実行例2＞<br>
 * 何月ですか(1～12)：12<br>
 * その月の季節は冬です。<br>
 * <br>
 * @author SystemShared
 */

//指定された月の季節を表示するメソッド
class PrintSeason {

	//月の季節を表示
	static void printSeason(int m) {
		switch (m) {
		case 3:
		case 4:
		case 5:
			System.out.print("春");
			break;
		case 6:
		case 7:
		case 8:
			System.out.print("夏");
			break;
		case 9:
		case 10:
		case 11:
			System.out.print("秋");
			break;
		case 12:
		case 1:
		case 2:
			System.out.print("冬");
			break;
		}
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		int month;
		do {
			System.out.print("何月ですか(1～12)：");
			month = stdIn.nextInt();
		} while (month < 1 || month > 12);

		System.out.print("その月の季節は");
		printSeason(month);
		System.out.print("です。");
	}
}