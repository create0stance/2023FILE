package Chap07_19;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-19<br>
 * 配列aの要素の中で値がxである全要素のインデックスを先頭から順に格納した配列を返却する<br>
 * メソッドarraySrchIdxを作成せよ。<br>
 * int[] arraySrchIdx(int[] a, int x)<br>
 * 【例】配列aの要素が{1, 5, 4, 8, 5, 5, 7}でarraySrchIdx(a, 5)と呼び出された場合、<br>
 * 返却する配列は{1, 4, 5}となる（値が5である要素のインデックスを並べｔものとなる）。<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 7<br>
 * x[0] : 1<br>
 * x[1] : 5<br>
 * x[2] : 4<br>
 * x[3] : 8<br>
 * x[4] : 5<br>
 * x[5] : 5<br>
 * x[6] : 7<br>
 * 探索する値 ： 5<br>
 * 一致する要素のインデックス<br>
 * 1<br>
 * 4<br>
 * 5<br>
 * <br>
 *
 * @author System Shared
 *
 */
// ある値と一致する全要素のインデックスを抽出
public class ArraySearchIndex {

	// --- 配列aｋらxと一致する全要素のインデックスを抽出した配列を返却 ---//
	static int[] arraySrchIdx(int[] a, int x) {
		int count = 0; // xと一致する要素の個数
		for (int i = 0; i < a.length; i++) {
			if (a[i] == x) {
				count++;
			}
		}
		int[] c = new int[count--];
		for (int i = a.length - 1; count >= 0; i--) {
			if (a[i] == x) {
				c[count--] = i;
			}
		}
		return c;
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();
			int[] x = new int[num]; // 要素数numの配列
			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			System.out.print("探索する値 ： ");
			int n = stdIn.nextInt();
			int[] b = arraySrchIdx(x, n);
			if (b.length == 0) {
				System.out.println("一致する要素はありません。");
			} else {
				System.out.println("一致する要素のインデックス");
				for (int i = 0; i < b.length; i++) { // 配列bを表示
					System.out.println(b[i]);
				}
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
