package 
Chap02_06;
import java.util.Scanner;
/**
 * 第2章 変数を使おう<br>
 * 問題2-6<br>
 * キーボードから読み込んだ整数値に10を加えた値と10を減じた値を出力するプログラムを作成せよ。<br>
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。<br>
 * <br>
 * <実行例><br>
 * 整数値：100<br>
 * 10を加えた値は110です。<br>
 * 10を減じた値は90です。<br>
 * <br>
 * @author SystemShared
 */

public class PlusMinus10 {
	public static void main(String[] args){
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int x = stdIn.nextInt();

		System.out.println("10を加えた値は" + (x + 10) + "です。");
		System.out.println("10を減じた値は" + (x - 10) + "です。");
	}

}