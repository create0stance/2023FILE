package
Chap04_10;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-10<br>
 * 正の整数値nを読み込んで、1からnまでの積を求めるプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 正の整数値：5<br>
 * 1から5までの積は120です。<br>
 * <br>
 * @author SystemShared
 */

//nの階乗を求める
class Factorial {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int n;
		do {
			System.out.print("正の整数値：");
			n = Integer.parseInt(br.readLine());
		} while (n <= 0);

		long factorial = 1;
		int i = 1;

		while (i <= n) {
			factorial *= i; //factorialに1を掛ける
			i++;
		}
		System.out.println("1から" + n + "までの積は" + factorial + "です。");
	}
}