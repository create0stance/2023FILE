package Chap04_20;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-20<br>
 * 月を整数値として読み込んで、それに対応する季節を表示するプログラムを作成せよ。好きなだけ何度でも<br>
 * 繰り返して入力・表示出来るようにし、月お読み込みにおいて1～12以外の値が入力されたああ異は、再<br>
 * 入力させるようにすること。（do文の中にdo文が入る二重ループとなる）<br>
 * <br>
 * <実行例><br>
 * 季節を求めます。<br>
 * 何月ですか ： 13<br>
 * 何月ですか ： 6<br>
 * それは夏です。<br>
 * もう一度？ 1･･･Yes / 0･･･No ： 1<br>
 * 何月ですか ： 11<br>
 * それは秋です。<br>
 * もう一度？ 1･･･Yes / 0･･･No ： 0<br>
 * <br>
 *
 * @author System Shared
 */
// 入力された月の季節を表示
public class SeasonRepeat {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		int retry; // もう一度？

		System.out.println("季節を求めます。");

		do {
			int month; // 季節を求める月
			do {
				System.out.print("何月ですか ： ");
				month = stdIn.nextInt();
			} while (month < 1 || month > 12);
			if (month >= 3 && month <= 5) {
				System.out.println("それは春です。");
			} else if (month >= 6 && month <= 8) {
				System.out.println("それは夏です。");
			} else if (month >= 9 && month <= 11) {
				System.out.println("それは秋です。");
			} else if (month == 12 || month == 1 || month == 2) {
				System.out.println("それは冬です。");
			}
			System.out.print("もう一度？ 1･･･Yes / 0･･･No ： ");
			retry = stdIn.nextInt();
		} while (retry == 1);
	}
}
