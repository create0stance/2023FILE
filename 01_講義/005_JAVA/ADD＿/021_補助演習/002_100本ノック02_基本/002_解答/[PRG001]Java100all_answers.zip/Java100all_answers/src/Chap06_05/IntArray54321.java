package
Chap06_05;
/**
 * 第6章 配列<br>
 * 問題6-5<br>
 * 要素数5のint型配列の各要素を先頭から順に5、4、3、2、1で初期化して表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * a[0] = 5<br>
 * a[1] = 4<br>
 * a[2] = 3<br>
 * a[3] = 2<br>
 * a[4] = 1<br>
 * <br>
 * @author SystemShared
 */

//配列の各要素を5、4、3、2、1で初期化して表示
class IntArray54321 {

	public static void main(String[] args) {
		int[] a = {5, 4, 3, 2, 1}; //配列の宣言

		for (int i = 0; i < a.length; i++){
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}
