package
Chap05_08;
/**
 * 第5章 基本型と演算<br>
 * 問題5-8<br>
 * float型の変数を0.0から1.0まで0.001ずつ増やしていく様子と、int型の変数を0から1000<br>
 * までインクリメントした値を1000で割った値を求める様子を、横に並べて表示するプログ<br>
 * ラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 *   float        int<br>
 * --------------------<br>
 * 0.0000000   0.0000000<br>
 * 0.0010000   0.0010000<br>
 * 0.0020000   0.0020000<br>
 * 0.0030000   0.0030000<br>
 * 0.0040000   0.0040000<br>
 * 		・・中略・・<br>
 * 0.9959908   0.9960000<br>
 * 0.9969907   0.9970000<br>
 * 0.9979907   0.9980000<br>
 * 0.9989907   0.9990000<br>
 * 0.9999907   1.0000000<br>
 * <br>
 * @author System Shared
 */

class LoopFloatInt {

	public static void main(String[] args) {
		System.out.println("  float        int");
		System.out.println("--------------------");

		float x = 0.0f;
		for (int i = 0; i <= 1000; i++, x += 0.001f)
			System.out.printf("%9.7f   %9.7f\n", x, (float)i / 1000);
	}
}
