package 
Chap05_09;
/**
 * 第5章 基本型と演算<br>
 * 問題5-9<br>
 * 0.0から1.0まで0.001おきに、その値と、その値の２乗を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 *   x     xの２乗<br>
 * ----------------<br>
 * 0.000  0.0000000<br>
 * 0.001  0.0000010<br>
 * 0.002  0.0000040<br>
 * 0.003  0.0000090<br>
 * 	・・中略・・<br>
 * 0.996  0.9919976<br>
 * 0.997  0.9939905<br>
 * 0.998  0.9959855<br>
 * 0.999  0.9979824<br>
 * 1.000  0.9999814<br>
 * <br>
 * @author System Shared
 */

class SquareInt {

	public static void main(String[] args) {
		System.out.println("  x     xの２乗");
		System.out.println("----------------");

		for (int i = 0; i <= 1000; i++) {
			float x= (float)i / 1000;
			System.out.printf("%5.3f %10.7f\n", x, x * x);
//			Mathクラスを使った場合のxの2条
//			System.out.printf("%5.3f %10.7f\n", x, Math.pow(x, 2));
	    }
	}
}
