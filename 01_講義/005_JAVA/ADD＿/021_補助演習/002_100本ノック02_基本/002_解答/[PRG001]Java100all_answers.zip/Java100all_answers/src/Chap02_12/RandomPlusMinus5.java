package Chap02_12;

import java.util.Random;
import java.util.Scanner;

/**
 * 第2章 変数を使おう<br>
 * 問題2-12<br>
 * キーボードから読み込んだ値プラスマイナス５の範囲の整数値をランダムに生成して表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数値 ： 7<br>
 * その値±5の乱数を生成しました。<br>
 * 値は12です。<br>
 * <br>
 * <実行例><br>
 * 整数値 ： 7<br>
 * その値±5の乱数を生成しました。<br>
 * 値は3です。<br>
 * <br>
 *
 * @author System Shared
 */
// キーボードから読み込んだ整数値±5の値を乱数で生成して表示
public class RandomPlusMinus5 {
	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値 ： ");
		int x = stdIn.nextInt(); // xに整数値を読み込む

		System.out.println("その値±5の乱数を生成しました。");
		System.out.println("値は" + (x - 5 + rand.nextInt(11)) + "です。");

	}

}
