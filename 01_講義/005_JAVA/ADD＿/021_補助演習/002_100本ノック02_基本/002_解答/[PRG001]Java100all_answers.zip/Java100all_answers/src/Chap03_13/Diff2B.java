package 
Chap03_13;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-13<br>
 * 二つの整数値を読み込んで、それらの値の差を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数ａ：10<br>
 * 整数ｂ：1<br>
 * それらの差は9です。<br>
 * <br>
 * @author SystemShared
 */

class Diff2B {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数ａ："); int a = stdIn.nextInt();
		System.out.print("整数ｂ："); int b = stdIn.nextInt();

		int diff = a >= b ? a - b : b - a;

		System.out.println("それらの差は" + diff + "です。");
	}
}
