package
Chap06_06;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-6<br>
 * 配列の要素数と、個々の要素の値を読み込んで、各要素の値を表示するプログラムを作成せよ。<br>
 * 表示の形式は、初期化子と同じ形式、すなわち、各要素の値をコンマで区切って{}で囲んだ形で表示すること。<br>
 * <br>
 * <実行例><br>
 * 要素数：3<br>
 * a[0] = 1<br>
 * a[1] = 2<br>
 * a[2] = 3<br>
 * {1, 2, 3}<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素に値を読み込んで初期化子形式で表示
class PrintArray {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を読み込む
		int[] a = new int[n]; //配列を生成

		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "] = ");
			a[i] = stdIn.nextInt();
		}

		System.out.print("{");

		if (n >= 2){
			for (int i = 0; i < n - 1; i++){ //先頭n-1個の要素を表示
				System.out.print(a[i] + ", ");
			}
		}
		if (n >= 1){
			System.out.print(a[n - 1]);
		}
		System.out.println("}");
	}
}