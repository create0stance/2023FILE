package
Chap07_08;
import java.util.Random;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-8<br>
 * a以上b未満の乱数を生成して、その値を返却するメソッドrandomを作成せよ。<br>
 * 内部で乱数を生成する標準ライブラリを呼び出すこと。<br>
 * int random(int a, int b)<br>
 * なお、bの値がaより小さい場合には、aの値をそのまま返却すること。<br>
 * <br>
 * ＜実行例＞<br>
 * 乱数を生成します。<br>
 * 下限値：10<br>
 * 上限値：20<br>
 * 生成した乱数は1977です。<br>
 * <br>
 * @author SystemShared
 */

//指定された範囲の乱数を生成するメソッド
class RandomTester {

	//a以上b未満の乱数を生成
	static int random(int a, int b) {
		if (b <= a){
			return a;
		}else {
			Random rand = new Random();
			return a + rand.nextInt(b - a + 1);
		}
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("乱数を生成します。");
		System.out.print("下限値：");
		int min = stdIn.nextInt();
		System.out.print("上限値：");
		int max = stdIn.nextInt();

		System.out.println("生成した乱数は" + random(min, max) + "です。");
	}
}