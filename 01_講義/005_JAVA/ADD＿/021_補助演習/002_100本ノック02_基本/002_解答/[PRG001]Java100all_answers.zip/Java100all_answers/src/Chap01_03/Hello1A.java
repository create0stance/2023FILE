package Chap01_03;
/**
 * 第1章 画面に文字を表示しよう<br>
 * 問題1-3<br>
 * 『初めてのJavaプログラム。』と『画面に出力しています。』を、改行することなく連続して表示するプログラムを作成せよ。<br>
 *<br>
 * <実行例><br>
 * 初めてのJavaプログラム。画面に出力しています。<br>
 *<br>
 * @author SystemShared
 */

public class Hello1A {
   public static void main(String[] args) {
	   System.out.println("初めてのJavaプログラム。画面に出力しています。");

   }
}
