package 
Chap02_08;
import java.util.Scanner;
/**
 * 第2章 変数を使おう<br>
 * 問題2-8<br>
 * 二つの実数値を読み込み、その和と平均を求めて表示するプログラムを作成せよ。<br>
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。<br>
 * <br>
 * <実行例><br>
 * xの値：12<br>
 * yの値：34<br>
 * 合計は46.0です。<br>
 * 平均は23.0です。<br>
 * <br>
 * @author SystemShared
 */

public class SumAveDouble {
	public static void main(String[] args){
		Scanner stdIn = new Scanner(System.in);

		System.out.print("xの値：");
		double x = stdIn.nextDouble();

		System.out.print("yの値：");
		double y = stdIn.nextDouble();

		System.out.println("合計は" + (x + y) + "です。");
		System.out.println("平均は" + (x + y) / 2 + "です。");
	}

}