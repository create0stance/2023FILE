package
Chap03_10;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-10<br>
 * 正の整数値を読み込んで、それを３で割った値に応じて『その値は３で割り切れます。』『その値<br>
 * を３で割った余りは１です。』『その値を３で割った余りは２です。』のいずれかを表示するプロ<br>
 * グラムを作成せよ。<br>
 * ※正でない値を読み込んだ場合は、『正でない値が入力されました。』と表示すること。<br>
 * <br>
 * <実行例><br>
 * 整数値：13<br>
 * その値を３で割った余りは１です。<br>
 * <br>
 * @author SystemShared
 */

class Modulo3 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int n = stdIn.nextInt();

		if (n > 0){
			if (n % 3 == 0){
				System.out.println("その値は３で割り切れます");
			}else if (n % 3 == 1){
				System.out.println("その値を３で割った余りは１です。");
			}else{
				System.out.println("その値を３で割った余りは２です。");
			}
		}else{
			System.out.println("正でない値が入力されました。");
		}
	}
}
