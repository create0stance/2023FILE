package Chap02_16;
/**
 * 第2章 変数を使おう<br>
 * 問題2-15<br>
 * String型の変数を文字列で初期化したり、変数に文字列を代入したりするプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 文字列s1はABCです。<br>
 * 文字列s2はXYZです。<br>
 * 文字列s1はFBIです。<br>
 * 文字列s2はXYZです。<br>
 * <br>
 * @author System Shared
 */
public class StringTester {
	public static void main(String[] args) {
		String s1 = "ABC";	// 初期化
		String s2 = "XYZ";	// 初期化

		System.out.println("文字列s1は"+ s1 +"です。"); // 表示
		System.out.println("文字列s2は"+ s2 +"です。"); // 表示

		s1 = "FBI";	// 代入（値を書き換える）

		System.out.println("文字列s1は"+ s1 +"です。"); // 表示
		System.out.println("文字列s2は"+ s2 +"です。"); // 表示

	}

}
