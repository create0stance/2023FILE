package
Chap03_20;
import  java.util.Random;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-20<br>
 * ０，１，２のいずれかの値の乱数を生成し、０であれば"グー"を、１であれば"チョキ"を、２であ<br>
 * れば"パー"を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * コンピュータが生成した手：チョキ<br>
 * <br>
 * @author SystemShared *
 */

class FingerFlashing {

	public static void main(String[] args) {
		Random rand = new Random();

		System.out.print("コンピュータが生成した手：");
		int hand = rand.nextInt(3);			// ０～２の乱数

		switch (hand) {
		case 0:
			System.out.println("グー");
			break;
		case 1:
			System.out.println("チョキ");
			break;
		case 2:
			System.out.println("パー");
			break;
		}
	}
}