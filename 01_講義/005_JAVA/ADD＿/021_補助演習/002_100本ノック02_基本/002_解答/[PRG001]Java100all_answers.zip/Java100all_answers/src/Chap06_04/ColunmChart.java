package
Chap06_04;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-4<br>
 * int型の配列の各要素に1～10の乱数を代入し、各要素の値を縦向きの棒グラフ(記号文字*の並び)で表示するプログラムを作成せよ。<br>
 * 要素数はキーボードから読み込むこと。最下段には、インデックスを10で割った剰余を表示すること。<br>
 * <br>
 * <実行例><br>
 * 要素数：5<br>
 *     *<br>
 * *   *<br>
 * *   *<br>
 * *   *<br>
 * * * *<br>
 * * * *<br>
 * * * *   *<br>
 * * * * * *<br>
 * * * * * *<br>
 * * * * * *<br>
 * ----------<br>
 * 0 1 2 3 4<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素に乱数を代入して縦棒グラフで表示
class ColunmChart {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を読み込む
		int[] a = new int[n]; //配列を生成

		for (int i = 0; i < n; i++){
			a[i] = 1 + rand.nextInt(10); //1～10の乱数
		}

		for (int i = 10; i >= 1; i--) {
			for (int j = 0; j < n; j++){
				if (a[j] >= i){
					System.out.print("* ");
				}else{
					System.out.print("  ");
				}
			}
			System.out.println();
		}

		for (int i = 0; i < 2 * n; i++){
			System.out.print('-');
		}
		System.out.println();

		for (int i = 0; i < n; i++){
			System.out.print(i % 10 + " ");
		}
		System.out.println();
	}
}