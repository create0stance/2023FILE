package
Chap03_02;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-2<br>
 * 整数値を読み込んで、その絶対値を求めて表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数値：-5<br>
 * その絶対値は5です。<br>
 * <br>
 * @author SystemShared
 */

class Absolute1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int n = stdIn.nextInt();

		if (n >= 0){
			System.out.println("その絶対値は" + n + "です。");
		}else{
			System.out.println("その絶対値は" + (-n) + "です。");
		}
	}
}