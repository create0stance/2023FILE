package
Chap06_16;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-16<br>
 * 曜日を表示して、その英語表現を入力させる英単語学習プログラム(正解表示機能付き)を作成せよ。<br>
 * ・出題する曜日は乱数で生成する。<br>
 * ・学習者が望む限り、何度も繰り返せる。<br>
 * ・同一曜日を連続して出題しない。<br>
 * <br>
 * <実行例><br>
 * 英語の曜日名を小文字で入力してください。<br>
 * 金曜日：sunday<br>
 * 違います。どうしますか？1…再入力/0…正解を見る：0<br>
 * 金曜日は"friday"です。<br>
 * 正解です。もう一度？1…Yes/2…No：<br>
 * <br>
 * @author SystemShared
 */

//曜日を表す英単語の学習プログラム(正解表示機能付き)
class DayCAI2 {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);
		String[] dayJapanese = {"日", "月", "火", "水", "木", "金", "土"};
		String[] dayEnglish = {"sunday", "monday", "tuesday", "wedesday", "thursday", "friday", "saturday"};

		System.out.println("英語の曜日名を小文字で入力してください。");

		int retry; //もう一度
		int last = -1; //前回の月

		do {
			int day; //出題する曜日：0～6の乱数
			do {
				day = rand.nextInt(7);
			} while (day == last);
			last = day;

			int action;
			do {
				System.out.print(dayJapanese[day] + "曜日：");
				String s = stdIn.next();

				if (s.equals(dayEnglish[day])) { //正解
					System.out.print("正解です。");
					break;
				}
				System.out.print("違います。");
				do {
					System.out.print("どうしますか？1…再入力/0…正解を見る：");
					action = stdIn.nextInt();
				} while (action != 0 && action != 1);
				if (action == 0){
					System.out.println(dayJapanese[day] + "曜日は\"" + dayEnglish[day] + "\"です。"); //正解表示
				}
			} while (action == 1);

			System.out.print("正解です。もう一度？1…Yes/2…No：");
			retry = stdIn.nextInt();
		} while (retry == 1);
	}
}