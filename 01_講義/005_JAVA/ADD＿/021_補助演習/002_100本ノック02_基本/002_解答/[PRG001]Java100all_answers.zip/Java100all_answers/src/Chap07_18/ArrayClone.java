package Chap07_18;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-18<br>
 * 配列aと同じ配列（要素数が同じで、すべての要素の値あ同じ配列）を生成して返却するメソッド<br>
 * arrayCloneを作成せよ。<br>
 * int[] arrayClone(int[] a)<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 5<br>
 * x[0] : 10<br>
 * x[1] : 20<br>
 * x[2] : 30<br>
 * x[3] : 40<br>
 * x[4] : 50<br>
 * 配列xの複製yを作りました。<br>
 * y[0] = 10<br>
 * y[1] = 20<br>
 * y[2] = 30<br>
 * y[3] = 40<br>
 * y[4] = 50<br>
 * <br>
 * @author System Shared
 *
 */
// 配列の複製を作成
public class ArrayClone {

	// --- 配列aの複製を作成して返却 ---//
	static int[] arrayClone(int[] a) {
		int[] c = new int[a.length]; // 要素数はaと同じ
		for (int i = 0; i < c.length; i++) { // 全要素をコピー
			c[i] = a[i];
		}
		return c;
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();

			int[] x = new int[num]; // 要素numの配列

			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			int[] y = arrayClone(x); // 配列xの複製
			System.out.println("配列xの複製yを作りました。");
			for (int i = 0; i < num; i++) { // 配列yを表示
				System.out.println("y[" + i + "] = " + y[i]);
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
