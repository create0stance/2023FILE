package Chap04_12;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-12<br>
 * 正の整数値を0までカウントダウンする問題4-5をfor文で実現せよ（ただし、繰り返し終了後の変数xの値は表示しなくてもよい）。<br>
 * <br>
 * <実行例><br>
 * カウントダウンします。<br>
 * 正の整数値 ： 4<br>
 * 4<br>
 * 3<br>
 * 2<br>
 * 1<br>
 * 0<br>
 * <br>
 *
 * @author System Shared
 */
// 正の整数値を0までカウントダウン（for文）
public class CountDownFor {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.println("カウントダウンします。");

		int x;
		do {
			System.out.print("正の整数値 ： ");
			x = stdIn.nextInt();
		} while (x <= 0);
		for (; x >= 0; x--) {
			System.out.println(x); // xの値ｗ表示
		}
	}
}
