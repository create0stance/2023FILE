package
Chap06_11;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-11<br>
 * 連続する要素が同じ値をもつことのないように問題6-10のプログラムを改良したプログラムを作成せよ。<br>
 * たとえば{1, 3, 5, 5, 3, 2}とならないようにすること。<br>
 * <br>
 * <実行例><br>
 * 要素数：5<br>
 * a[0] = 7<br>
 * a[1] = 1<br>
 * a[2] = 5<br>
 * a[3] = 8<br>
 * a[4] = 9<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素を1～10の乱数で埋め尽くす(連続する要素が重複しないうようにする)
class ArrayRandX {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を読み込む
		int[] a = new int[n]; //配列を生成

		a[0] = 1 + rand.nextInt(10);

		for (int i = 1; i < n; i++) {
			do {
				a[i] = 1 + rand.nextInt(10);
			} while (a[i] == a[i - 1]);
		}

		for (int i = 0; i < n; i++){
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}