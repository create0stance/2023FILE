package 
Chap04_05;
import java.util.Scanner;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-5<br>
 * キーボードから読み込んだ整数値から0までのカウントダウンを表示するプログラムを作成せよ。<br>
 * カウントダウン終了後の変数の値を確認できるようにすること。<br>
 * <br>
 * <実行例><br>
 * カウントダウンします。<br>
 * 正の整数値：-3<br>
 * 正の整数値：5<br>
 * 5<br>
 * 4<br>
 * 3<br>
 * 2<br>
 * 1<br>
 * 0<br>
 * xの値は-1になりました。<br>
 * <br>
 * @author SystemShared
 */

//正の整数値を0までカウントダウン(その1)
class CountDawn1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("カウントダウンします。");
		int x;
		do {
			System.out.print("正の整数値：");
			x = stdIn.nextInt();
		} while (x <= 0);

		while (x >= 0) {
			System.out.println(x); //xの値を表示
			x--; //xの値をデクリメント(値を一つ減らす)
		}
		System.out.println("xの値は" + x + "になりました。"); //xの値を表示
	}
}