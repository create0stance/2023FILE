package Chap02_02;
/**
 * 第2章 変数を使おう<br>
 * 問題2-2<br>
 * 二つの変数xとyの合計と平均を求めて表示するプログラムを作成せよ。なお、xとyには適当な値を代入しておくこと。<br>
 * <br>
 * <実行例><br>
 * xの値は63です。<br>
 * yの値は18です。<br>
 * 合計は81です。<br>
 * 平均は40です。<br>
 * <br>
 * @author SystemShared
 */

public class SumAve1 {
   public static void main(String[] args){
	   int x;
	   int y;

	   x = 63;
	   y = 18;

	   System.out.println("xの値は" + x + "です。");
	   System.out.println("yの値は" + y + "です。");
	   System.out.println("合計は" + (x + y) + "です。" );
	   System.out.println("平均は" + (x + y) / 2 + "です。");

   }
}