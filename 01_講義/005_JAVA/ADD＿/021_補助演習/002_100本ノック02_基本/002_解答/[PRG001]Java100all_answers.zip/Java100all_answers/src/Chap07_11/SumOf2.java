package Chap07_11;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-11<br>
 * 配列aの全要素の合計を求めるメソッドsumOfを作成せよ。<br>
 * int sumOf(int[] a)<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 5<br>
 * x[0] : 22<br>
 * x[1] : 5<br>
 * x[2] : 11<br>
 * x[3] : 32<br>
 * x[4] : 120<br>
 * 全要素の合計は190です。<br>
 * <br>
 * 
 * @author System Shared
 * 
 */
// 配列の全要素の合計を求める（その２：拡張for文）
public class SumOf2 {

	// --- 配列aの全要素の合計を求める ---//
	static int sumOf(int[] a) {
		int sum = 0;
		for (int i : a) {
			sum += i;
		}
		return sum;
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();
			int[] x = new int[num]; // 要素数numの配列

			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			System.out.println("全要素の合計は" + sumOf(x) + "です。");
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}