package 
Chap04_02;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-2<br>
 * 3桁の正の整数値(100～999)を読み込むプログラムを作成せよ。<br>
 * 3桁の正の整数値でない値が入力された場合は、再入力されること。<br>
 * <br>
 * <実行例><br>
 * 3桁の正の整数値：59<br>
 * 3桁の正の整数値：1052<br>
 * 3桁の正の整数値：235<br>
 * 235と入力しましたね。<br>
 * <br>
 * @author SystemShared
 */

class ThreeDigits {

	public static void main(String[] args)throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String input = "";

		int x; //読み込む値
		do {
			System.out.print("3桁の正の整数値：");
			input = br.readLine();
			x = Integer.parseInt(input);
		} while (x < 100 || x > 999);

		System.out.println(x + "と入力しましたね。");
	}
}