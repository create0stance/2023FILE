package Chap07_25;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-25<br>
 * 2次元配列aと同じ配列（要素数が同じで、すべての要素の値が同じ配列）を生成して返却する<br>
 * メソッドaryClone2を作成せよ。<br>
 * int[][] aryClone2(int[][] a)<br>
 * <br>
 * <実行例><br>
 * 行列の行数 ： 2<br>
 * 行列の列数 ： 3<br>
 * a[0][0] : 1<br>
 * a[0][1] : 2<br>
 * a[0][2] : 3<br>
 * a[1][0] : 4<br>
 * a[1][1] : 5<br>
 * a[1][2] : 6<br>
 * 行列a<br>
 * 1 2 3 <br>
 * 4 5 6 <br>
 * 行列aの複製<br>
 * 1 2 3 <br>
 * 4 5 6<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 2次元配列の複製を作成
public class AryClone2 {

	// --- 2次元配列aの複製を作成して返却 ---//
	static int[][] aryClone2(int[][] a) {
		int[][] c = new int[a.length][];

		for (int i = 0; i < a.length; i++) {
			c[i] = new int[a[i].length];
			for (int j = 0; j < a[i].length; j++) {
				c[i][j] = a[i][j];
			}
		}
		return c;
	}

	// --- 行列mの全要素を表示 ---//
	static void printMatrix(int[][] m) {
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[i].length; j++) {
				System.out.print(m[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("行列の行数 ： ");
			int height = stdIn.nextInt();
			System.out.print("行列の列数 ： ");
			int width = stdIn.nextInt();

			int[][] a = new int[height][width];
			for (int i = 0; i < a.length; i++) {
				for (int j = 0; j < a[i].length; j++) {
					System.out.printf("a[%d][%d] : ", i, j);
					a[i][j] = stdIn.nextInt();
				}
			}
			int[][] ca = aryClone2(a);
			System.out.println("行列a");
			printMatrix(a);
			System.out.println("行列aの複製");
			printMatrix(ca);
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
