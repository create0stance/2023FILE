package
Chap03_17;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-17<br>
 * 二つの整数値を読み込んで、小さいほうの値と大きいほうの値の両方を表示するプログラムを作<br>
 * 成せよ。二つの整数値が等しい場合は、『二つの値は同じです。』と表示すること。<br>
 * <br>
 * <実行例><br>
 * 整数ａ：10<br>
 * 整数ｂ：7<br>
 * 小さいほうの値は7です。<br>
 * 大きいほうの値は10です。<br>
 * <br>
 * @author SystemShared
 */

class MinMaxEq {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数ａ：");	int a = stdIn.nextInt();
		System.out.print("整数ｂ：");	int b = stdIn.nextInt();

		if (a == b){
			System.out.println("二つの値は同じです。");
		}else {
			int min, max;		//小さいほうの値／大きい方の値
			if (a < b) {		//ａがｂより小さければ
				min = a;
				max = b;
			} else {
				min = b;
				max = a;
			}
			System.out.println("小さいほうの値は" + min + "です。");
			System.out.println("大きいほうの値は" + max + "です。");
		}

	}
}
