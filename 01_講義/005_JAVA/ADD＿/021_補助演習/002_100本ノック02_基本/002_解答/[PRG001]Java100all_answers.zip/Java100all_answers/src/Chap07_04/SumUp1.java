package Chap07_04;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-4<br>
 * 1からnまでの全整数の和を求めて返却するメソッドを作成する。<br>
 * int umUp(int n)<br>
 * <br>
 * ＜実行例＞<br>
 * 1からxまでの和を求めます。<br>
 * xの値：10<br>
 * 1から10までの和は55です。<br>
 * <br>
 * @author SystemShared
 */

//1からnまでの和を求める(その1)
class SumUp1 {

	//1からnまでの和を求める
	static int sumUp(int n) {
		int sum = 0; //合計
		for (int i = 1; i <= n; i++){
			sum += i; //sumにiを加える
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("1からxまでの和を求めます。");
		int x;
		do {
			System.out.print("xの値：");
			x = stdIn.nextInt();
		} while (x <= 0);
		System.out.println("1から" + x + "までの和は" + sumUp(x) + "です。");
	}
}
