package
Chap03_15;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-15<br>
 * キーボードから読み込んだ三つの整数値の最小値を求めて表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数ａ：2<br>
 * 整数ｂ：4<br>
 * 整数ｃ：6<br>
 * 最小値は2です。<br>
 * <br>
 * @author SystemShared
 */

class Min3 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数ａ：");	int a = stdIn.nextInt();
		System.out.print("整数ｂ：");	int b = stdIn.nextInt();
		System.out.print("整数ｃ：");	int c = stdIn.nextInt();

		int min = a;
		if (b < min){
			min = b;
		}
		if (c < min){
			min = c;
		}

		System.out.println("最小値は" + min + "です。");
	}
}
