package 
Chap06_02;
/**
 * 第6章 配列<br>
 * 問題6-2<br>
 * 要素型がint型で要素数が5の配列の要素に対して、先頭から順に5、4、3、2、1を代入して表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * a[0] = 5<br>
 * a[1] = 4<br>
 * a[2] = 3<br>
 * a[3] = 2<br>
 * a[4] = 1<br>
 * <br>
 * @author SystemShared
 */

//配列の各要素に5、4、3、2、1を代入して表示
class IntArrayFor {

	public static void main(String[] args) {
		int[] a = new int[5]; //配列の宣言

		for (int i = 0; i < a.length; i++)
			a[i] = 5 - i;

		for (int i = 0; i < a.length; i++)
			System.out.println("a[" + i + "] = " + a[i]);
	}
}
