package Chap01_01;
/**
 * 第1章 画面に文字を表示しよう<br>
 * 問題1-1<br>
 * コンソール画面に『初めてのJavaプログラム。』と『画面に出力しています。』とを、連続して一行ずつ表示するプログラムを作成せよ。<br>
 *<br>
 * <実行例><br>
 * 初めてのJavaプログラム。<br>
 * 画面に出力しています。<br>
 *<br>
 * @author SystemShared
 */

public class Hello {

   public static void main(String[] args) {
	   System.out.println("初めてのJavaプログラム。");
	   System.out.println("画面に出力しています。");
   }

}
