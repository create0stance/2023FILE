package Chap04_27;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-27<br>
 * キーボードから次々と整数値を読み込んで、合計と平均を求めるプログラムを作成せよ。加算する<br>
 * 整数の個数は最初に読み込むこと。なお、読み込みは合計が1,000お超えない範囲で行うものとする。<br>
 * <br>
 * <実行例1><br>
 * 整数を加算します。<br>
 * 何個加算しますか ： 5<br>
 * 整数（0で終了） ： 127<br>
 * 整数（0で終了） ： 534<br>
 * 整数（0で終了） ： 392<br>
 * 合計が1,000を超えました。<br>
 * 最後の数値は無視します。<br>
 * 合計は661です。<br>
 * 平均は330です。<br>
 * <br>
 *
 * @author System Shared
 */
// 読み込んだ整数を加算（合計が1,000を超えない範囲で加算する。）
public class SumBreak2Ave {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("整数を加算します。");
		System.out.print("何個加算しますか ： ");
		int n = stdIn.nextInt(); // 加算する個数

		int sum = 0; // 合計値
		int i;
		for (i = 0; i < n; i++) {
			System.out.print("整数（0で終了） ： ");
			int t = stdIn.nextInt();
			if (sum + t > 1000) {
				System.out.println("合計が1,000を超えました。");
				System.out.println("最後の数値は無視します。");
				break; // for文から抜け出る
			}
			sum += t;
		}
		System.out.println("合計は" + sum + "です。");
		if (i != 0) {
			System.out.println("平均は" + sum / i + "です。");
		}
	}
}