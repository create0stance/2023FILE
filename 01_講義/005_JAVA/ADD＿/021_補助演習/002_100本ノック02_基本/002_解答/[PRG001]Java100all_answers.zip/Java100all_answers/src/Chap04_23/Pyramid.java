package Chap04_23;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-23<br>
 * n段のピラミッドを表示するプログラムを作成せよ。<br>
 * 第i行目には(i-1)*2+1個の'*'記号を表示して、最終行である第n行目には(n-1)*2+1個の'*'記号を表示すること。<br>
 * <br>
 * <実行例><br>
 * ピラミッドを表示します。<br>
 * 段数は ： 5<br>
 * *<br>
 * ***<br>
 * *****<br>
 * *******<br>
 * *********<br>
 * <br>
 *
 * @author System Shared
 */
// ピラミッドを表示
public class Pyramid {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("ピラミッドを表示します。");
		System.out.print("段数は ： ");
		int n = stdIn.nextInt();

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n - i; j++) {
				System.out.print(' ');
			}
			for (int j = 1; j <= 2 * i - 1; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}
}