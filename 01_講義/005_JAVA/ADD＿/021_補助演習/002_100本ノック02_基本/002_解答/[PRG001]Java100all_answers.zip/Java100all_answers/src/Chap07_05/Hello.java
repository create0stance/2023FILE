package 
Chap07_05;
/**
 * 第7章 メソッド<br>
 * 問題7-5<br>
 * 『こんにちは。』と表示してメソッドhelloを作成せよ。<br>
 * <br>
 * ＜実行例＞<br>
 * こんにちは。<br>
 * こんにちは。<br>
 * こんにちは。<br>
 * <br>
 * @author SystemShared
 */

//『こんにちは。』と表示するメソッド
class Hello {

	//『こんにちは。』と表示して改行する
	static void hello() {
		System.out.println("こんにちは。");
	}

	public static void main(String[] args) {
		hello();
		hello();
		hello();
	}
}