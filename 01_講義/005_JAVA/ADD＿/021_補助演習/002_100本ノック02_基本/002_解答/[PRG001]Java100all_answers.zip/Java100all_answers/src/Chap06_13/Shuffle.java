package 
Chap06_13;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-13<br>
 * 配列の要素の並びをシャッフルする(ランダムな順となるようにかき混ぜる)プログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 要素数：3<br>
 * a[0] = 5<br>
 * a[1] = 10<br>
 * a[2] = 15<br>
 * 要素をかき混ぜました。<br>
 * a[0] = 10<br>
 * a[1] = 15<br>
 * a[2] = 5<br>
 * <br>
 * @author SystemShared
 */

//配列の要素の並びをシャッフルする(かき混ぜる)
class Shuffle {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を読み込む
		int[] a = new int[n]; //配列を生成

		for (int i = 0;i < n; i++) {
			System.out.print("a[" + i + "] = ");
			a[i] = stdIn.nextInt();
		}

		for (int i = 0; i < 2 * n; i++) {
			int idx1 = rand.nextInt(n);
			int idx2 = rand.nextInt(n);
			int t = a[idx1];
			a[idx1] = a[idx2];
			a[idx2] = t;
		}

		System.out.println("要素をかき混ぜました。");
		for (int i = 0; i < n; i++){
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}