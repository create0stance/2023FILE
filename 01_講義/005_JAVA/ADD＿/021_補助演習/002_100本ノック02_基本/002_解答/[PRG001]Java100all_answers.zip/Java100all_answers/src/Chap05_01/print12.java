package 
Chap05_01;
/**
 * 第5章 基本型と演算<br>
 * 問題5-1<br>
 * ８進数の１２、１０進数の１２、１６進数の１２を１０進数で表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 8進数の12は10進数で10です。<br>
 * 10進数の12は10進数で12です。<br>
 * 16進数の12は10進数で18です。<br>
 * <br>
 * @author System Shared
 */

class print12 {

	public static void main(String[] args) {

	System.out.println(" 8進数の12は10進数で" +  012 + "です。");
	System.out.println("10進数の12は10進数で" +   12 + "です。");
	System.out.println("16進数の12は10進数で" + 0x12 + "です。");
	}
}
