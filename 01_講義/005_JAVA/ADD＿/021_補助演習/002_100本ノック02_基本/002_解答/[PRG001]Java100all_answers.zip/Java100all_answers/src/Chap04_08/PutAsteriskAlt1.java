package
Chap04_08;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-8<br>
 * 読み込んだ値の個数だけ記号文字を表示するプログラムを作成せよ(最後に改行文字を出力する)。<br>
 * 表示は*と+を交互に行うこと。<br>
 * <br>
 * <実行例1><br>
 * 何個表示しますか：12<br>
 * *+*+*+*+*+*+<br>
 * <br>
 * <実行例2><br>
 * 何個表示しますか：11<br>
 * *+*+*+*+*+*<br>
 * <br>
 * @author SystemShared
 */

//読み込んだ個数だけ*と+を交互に表示(その1)
class PutAsteriskAlt1 {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("何個表示しますか：");
		int n = Integer.parseInt(br.readLine());

		if (n > 0) {
			int i = 0;
			while (i < n) {
				if (i % 2 == 0){ //iが偶数であれば'*'を出力
					System.out.print('*');
				}else{ //iが奇数であれば'+'を出力
					System.out.print('+');
				}
				i++;

			}
		}
	}

}
