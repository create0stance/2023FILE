package
Chap02_04;
/**
 * 第2章 変数を使おう<br>
 * 問題2-4<br>
 * 三つのint型変数に値を代入し、合計と平均を求めるプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * xの値は63です。<br>
 * yの値は18です。<br>
 * zの値は52です。<br>
 * 合計は133です。<br>
 * 平均は44です。<br>
 * <br>
 * @author SystemShared
 */

public class SumAve3A {
   public static void main(String[] args){
	   int x,y,z;

	   x = 63;
	   y = 18;
	   z = 52;

	   System.out.println("xの値は" + x + "です。");
	   System.out.println("yの値は" + y + "です。");
	   System.out.println("yの値は" + z + "です。");
	   System.out.println("合計は" + (x + y + z) + "です。" );
	   System.out.println("平均は" + (x + y + z) / 3 + "です。");

   }
}