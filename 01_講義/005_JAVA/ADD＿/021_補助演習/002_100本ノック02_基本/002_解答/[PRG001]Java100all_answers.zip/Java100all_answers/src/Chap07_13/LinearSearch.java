package Chap07_13;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-13<br>
 * 配列aかｒkeyと同じ値をもつ要素を探索するメソッドlinearSearchとlinearSearcRお作成せよ。<br>
 * キーと同じ値の要素が複数個存在する場合、linearSearchは最も先頭に位置する要素をみつけ、<br>
 * linearSearchRは最も末尾に位置する要素を見つけること。<br>
 * int linearSearch(int[] a, int key)<br>
 * int linearSearchR(int[] a, int key)<br>
 * <br>
 * <実行例><br>
 * 要素数 : 8<br>
 * x[0] : 5<br>
 * x[1] : 22<br>
 * x[2] : 74<br>
 * x[3] : 32<br>
 * x[4] : 120<br>
 * x[5] : 22<br>
 * x[6] : 68<br>
 * x[7] : 70<br>
 * 探す値 : 74<br>
 * その値はx[2]にあります。<br>
 * <br>
 * @author System Shared
 *
 */
// 線形探索
public class LinearSearch {

	// --- 配列aの要素からkeyと一致する最も先頭の要素を線形探索 ---//
	static int linearSearch(int[] a, int key) {
		for (int i = 0; i < a.length; i++) {
			if (a[i] == key) {
				return i; // 探索成功（インデックスを返却）
			}
		}
		return -1; // 探査失敗（-1を返却）
	}

	// --- 配列aの要素からkeyと一致する最も末尾の要素を線形探索 ---//
	static int linearSearchR(int[] a, int key) {
		for (int i = a.length - 1; i >= 0; i--) {
			if (a[i] == key) {
				return i; // 探索成功（インデックスを返却）
			}
		}
		return -1; // 探索成功（インデックスを返却）
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 : ");
			int num = stdIn.nextInt();
			int[] x = new int[num]; // 要素数numの配列

			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			System.out.print("探す値 : "); // キー値の読み込み
			int ky = stdIn.nextInt();

			int idxTop = linearSearch(x, ky); // 配列xから値がkyの要素を探索
			int idxBtm = linearSearchR(x, ky); // 配列xから値がkyお要素を探索

			if (idxTop == -1) {
				System.out.println("その値の要素は存在しません。");
			} else if (idxTop == idxBtm) {
				System.out.println("その値はx[" + idxTop + "]にあります。");
			} else {
				System.out.println("その値の要素は複数存在します。");
				System.out.println("最も先頭のものはx[" + idxTop + "]にあります。");
				System.out.println("最も末尾のものはx[" + idxBtm + "]にあります。");
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}