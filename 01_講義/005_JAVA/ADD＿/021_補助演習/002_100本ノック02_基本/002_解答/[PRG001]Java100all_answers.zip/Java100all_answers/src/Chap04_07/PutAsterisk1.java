package 
Chap04_07;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-7<br>
 * キーボードから読み込んだ値の個数だけ*を表示するプログラムを作成せよ。<br>
 * 最後に改行文字を出力すること。<br>
 * ただし、読み込んだ値が1未満であれば、改行文字を表示してはならない。<br>
 * <br>
 * <実行例><br>
 * 何個*を表示しますか：10<br>
 * **********<br>
 * <br>
 * @author SystemShared
 */

//読み込んだ個数だけ*を表示(その1)
class PutAsterisk1 {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("何個*を表示しますか：");

		int n = Integer.parseInt(br.readLine());

		if (n > 0) {
			int i = 0;
			while (i < n) {
				System.out.print('*');
				i++;
			}
			System.out.println();
		}
	}
}