package Chap07_20;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-20<br>
 * 配列aから要素a[idx]を削除した配列を返却するメソッドarrayRmvOfを作成せよ。<br>
 * int[] arrayRmvOf(int[] a, int idx)<br>
 * 削除はa[idx]より後ろの全要素を一つ前方にずらすことによって行うこと。<br>
 * 【例】配列aの要素が{1, 3, 4, 7, 9, 11}のときにarrayRmvOf{a, 2}と呼び出された場合、<br>
 * 返却する配列の要素は{1, 3, 7, 9, 11}となる。<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 6<br>
 * x[0] : 1<br>
 * x[1] : 3<br>
 * x[2] : 4<br>
 * x[3] : 7<br>
 * x[4] : 9<br>
 * x[5] : 11<br>
 * 削除する要素のインデックス ： 2<br>
 * y[0] = 1<br>
 * y[1] = 3<br>
 * y[2] = 7<br>
 * y[3] = 9<br>
 * y[4] = 11<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 配列から要素を削除した配列を返却
public class ArrayRemoveOf {
	// --- 配列aからa[idx]を削除した配列を返却 ---//
	static int[] arrayRmvOf(int[] a, int idx) {
		if (idx < 0 || idx >= a.length) {
			return a.clone(); // aの複製をそのまま返却
		} else {
			int[] c = new int[a.length - 1];
			int i = 0;
			for (; i < idx; i++) {
				c[i] = a[i];
			}
			for (; i < a.length - 1; i++) {
				c[i] = a[i + 1];
			}
			return c;
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();
			int[] x = new int[num]; // 要素数numの配列

			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			System.out.print("削除する要素のインデックス ： ");
			int idx = stdIn.nextInt();

			int[] y = arrayRmvOf(x, idx); // 配列xからx[idx]を削除した配列を生成

			for (int i = 0; i < y.length; i++) {
				System.out.println("y[" + i + "] = " + y[i]);
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
