package
Chap06_10;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-10<br>
 * 要素数がint型である配列をつくり、全要素を1～10の乱数で埋め尽くす(1以上10以下の値を代入する)プログラムを作成せよ。<br>
 * 要素数はキーボードから読み込むこと。<br>
 * <br>
 * <実行例><br>
 * 要素数：2<br>
 * a[0] = 3<br>
 * a[1] = 8<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素を1～10の乱数で埋め尽くす
class ArrayRand {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を読み込む
		int[] a = new int[n]; //配列を生成

		for (int i = 0; i < n; i++){
			a[i] = 1 + rand.nextInt(10);
		}

		for (int i = 0; i < n; i++){
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}
