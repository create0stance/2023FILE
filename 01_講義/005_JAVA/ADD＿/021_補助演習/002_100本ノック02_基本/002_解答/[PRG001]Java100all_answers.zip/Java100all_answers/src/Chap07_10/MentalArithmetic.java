package 
Chap07_10;
import java.util.Random;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-10<br>
 * 以下の四つの問題をランダムに出題する3桁の整数の暗算トレーニングプログラムを作成せよ。<br>
 *  x + y + z<br>
 *  x + y - z<br>
 *  x - y + z<br>
 *  x - y - z<br>
 *  <br>
 * ＜実行例＞<br>
 * 暗算力トレーニング！！<br>
 * 525 + 637 - 909 = 253<br>
 * もう一度？<Yes…1/No…0>：1<br>
 * 530 - 973 - 457 = 241<br>
 * 違いますよ！！<br>
 * 530 - 973 - 457 = -900<br>
 * もう一度？<Yes…1/No…0>：0<br>
 * <br>
 * @author SystemShared
 */

//暗算力トレーニング(3桁の整数の加減算)
class MentalArithmetic {
	static Scanner stdIn = new Scanner(System.in);

	//続行の確認
	static boolean confirmRetry() {
		int cont;
		do {
			System.out.print("もう一度？<Yes…1/No…0>：");
			cont = stdIn.nextInt();
		} while (cont != 0 && cont != 1);
		return cont == 1;
	}

	public static void main(String[] args) {
		Random rand = new Random();

		System.out.println("暗算力トレーニング！！");
		do {
			int x = rand.nextInt(900) + 100; //3桁の数
			int y = rand.nextInt(900) + 100; //3桁の数
			int z = rand.nextInt(900) + 100; //3桁の数
			int pattern = rand.nextInt(4); //パターン番号

			int kotae;
			switch (pattern) {
			case 0:
				kotae = x + y + z;
				break;
			case 1:
				kotae = x + y - z;
				break;
			case 2:
				kotae = x - y + z;
				break;
			default:
				kotae = x - y - z;
				break;
			}

			while (true) {
				System.out.print(x + ((pattern < 2) ? " + " : " - ") + y + ((pattern % 2 == 0) ? " + " : " - ") + z + " = ");
				int k = stdIn.nextInt(); //解答を読み込む
				if (k == kotae)
					break;
				System.out.println("違いますよ！！");
			}
		} while (confirmRetry());
	}
}