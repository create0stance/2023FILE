package 
Chap02_09;
import java.util.Scanner;
/**
 * 第2章 変数を使おう<br>
 * 問題2-9<br>
 * 三角形の底辺と高さを読み込んで、その面積を表示するプログラムを作成せよ。<br>
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。<br>
 * <br>
 * <実行例>
 * 三角形の面積を求めます。<br>
 * 底辺：12<br>
 * 高さ：3<br>
 * 面積は18.0です。<br>
 * <br>
 * @author SystemShared
 */

public class Triangle {
	public static void main(String[] args){
		Scanner stdIn = new Scanner(System.in);

		System.out.println("三角形の面積を求めます。");

		System.out.print("底辺：");
		double width = stdIn.nextDouble();

		System.out.print("高さ：");
		double height = stdIn.nextDouble();

		System.out.println("面積は" + (width * height / 2) + "です。");
	}

}