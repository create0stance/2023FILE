package 
Chap03_18;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-18<br>
 * 二つの整数値を読み込んで降順（大きい順）にソートするプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 変数ａ：5<br>
 * 変数ｂ：9<br>
 * ａ≧ｂとなるようにソートしました。<br>
 * 変数ａは9です。<br>
 * 変数ｂは5です。<br>
 * <br>
 * @author SystemShared
 */

class Sort2Descending {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("変数ａ：");	int a = stdIn.nextInt();
		System.out.print("変数ｂ：");	int b = stdIn.nextInt();

		if (a < b) {		// ａがｂより小さければ
			int t = a;		// それらの値を変換
			a = b;
			b = t;
		}
		System.out.println("ａ≧ｂとなるようにソートしました。");
		System.out.println("変数ａは" + a + "です。");
		System.out.println("変数ｂは" + b + "です。");
	}
}
