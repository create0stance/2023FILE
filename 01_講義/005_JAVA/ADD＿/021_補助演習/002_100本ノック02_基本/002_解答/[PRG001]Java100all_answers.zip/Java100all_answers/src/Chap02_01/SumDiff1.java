package Chap02_01;
/**
 * 第2章 変数を使おう<br>
 * 問題2-1<br>
 * 二つの整数値82と17の和と差を表示するプログラムを作成せよ（いろいろな表示方法を試してみること）。<br>
 * <br>
 * <実行例><br>
 * 99<br>
 * 65<br>
 * <br>
 * @author SystemShared
 */

public class SumDiff1 {
	public static void main(String[] args) {
		System.out.println(82 + 17);
		System.out.println(82 - 17);
	}
}