package 
Chap02_15;

import java.util.Scanner;

/**
 * 第2章 変数を使おう<br>
 * 問題2-15<br>
 * 住所を読み込んで、その住所を反復表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 住所 ： 千葉県　松戸市<br>
 * お住まいのは千葉県　松戸市ですね。<br>
 * <br>
 * @author System Shared
 */
public class Address {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("住所 ： ");
		String address = stdIn.nextLine();	//住所

		System.out.println("お住まいのは"+ address +"ですね。");

	}

}
