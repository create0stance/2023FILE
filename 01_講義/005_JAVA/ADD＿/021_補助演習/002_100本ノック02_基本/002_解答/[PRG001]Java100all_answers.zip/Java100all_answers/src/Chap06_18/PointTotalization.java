package 
Chap06_18;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-18<br>
 * 6人の2科目(国語・数学)の点数を読み込んで、科目ごとの平均点、学生ごとの平均点を求めるプログラムを作成せよ。<br>
 * <br>
 * <実行例>
 * 6人の国語・数学の点数を入力せよ。<br>
 *  1番…国語：12<br>
 * 　　　数学：23<br>
 *  2番…国語：34<br>
 * 　　　数学：45<br>
 *  3番…国語：56<br>
 * 　　　数学：67<br>
 *  4番…国語：78<br>
 * 　　　数学：89<br>
 *  5番…国語：90<br>
 * 　　　数学：100<br>
 *  6番…国語：54<br>
 * 　　　数学：43<br>
 * No.　国語　数学 平均<br>
 *  1    12    23  17.5<br>
 *  2    34    45  39.5<br>
 *  3    56    67  61.5<br>
 *  4    78    89  83.5<br>
 *  5    90   100  95.0<br>
 *  6    54    43  48.5<br>
 * 平均  54.0  61.2<br>
 * <br>
 * @author SystemShared
 */

//6人の2科目(国語・数学)の点数から科目ごと/学生ごとの平均点、学生ごとの平均点を求める
class PointTotalization {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		final int NINZU = 6; //人数
		int[][] point = new int[NINZU][2]; //点数
		int[] sumStudent = new int[NINZU]; //各学生の点数の合計
		int[] sumSubject = new int[2]; //各科目の点数の合計

		System.out.printf("%d人の国語・数学の点数を入力せよ。\n", NINZU);

		for (int i = 0; i < NINZU; i++) {
			System.out.printf("%2d番…国語：", i + 1);
			point[i][0] = stdIn.nextInt();
			System.out.print("　　　数学：");
			point[i][1] = stdIn.nextInt();

			sumStudent[i] = point[i][0] + point[i][1]; //学生の合計
			sumSubject[0] += point[i][0]; //国語の合計
			sumSubject[1] += point[i][1]; //数学の合計
		}

		System.out.println("No.　国語　数学 平均");
		for (int i = 0; i < NINZU; i++)
			System.out.printf("%2d%6d%6d%6.1f\n", i + 1, point[i][0], point[i][1], (double)sumStudent[i] / 2);
			System.out.printf("平均%6.1f%6.1f\n", (double)sumSubject[0] / NINZU, (double)sumSubject[1] / NINZU);
	}
}