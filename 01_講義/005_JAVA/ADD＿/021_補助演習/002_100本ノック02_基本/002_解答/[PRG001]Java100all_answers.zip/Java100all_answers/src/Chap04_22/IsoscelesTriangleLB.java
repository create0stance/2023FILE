package Chap04_22;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-22<br>
 * 記号文字*を並べて直角の二等辺三角形を表示するプログラムを作成せよ。直角が左下側、左上側、<br>
 * 右下側、右上側の三角形を表示するプログラムをそれぞれ作成せよ。<br>
 * <br>
 * <実行例><br>
 * 左下直角の二等辺三角形を表示します。<br>
 * 段数は ： 5<br>
 * *<br>
 * **<br>
 * ***<br>
 * ****<br>
 * *****<br>
 * <br>
 *
 * @author System Shared
 */
// 左下側が直角の二等辺三角形を表示
public class IsoscelesTriangleLB {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("左下直角の二等辺三角形を表示します。");
		System.out.print("段数は ： ");
		int n = stdIn.nextInt();

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}
}