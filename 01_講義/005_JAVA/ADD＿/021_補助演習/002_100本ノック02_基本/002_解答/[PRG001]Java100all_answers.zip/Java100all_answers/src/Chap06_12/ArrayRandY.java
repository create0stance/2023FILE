package
Chap06_12;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-12<br>
 * 異なる要素が同じ値をもつことのないように問題6-10のプログラムを改良したプログラムを作成せよ。<br>
 * たとえば{1, 3, 5, 6, 1, 2}とならないようにすること(配列の要素数は10以下であるとする)。<br>
 * <br>
 * <実行例><br>
 * 要素数：9<br>
 * a[0] = 8<br>
 * a[1] = 6<br>
 * a[2] = 10<br>
 * a[3] = 2<br>
 * a[4] = 3<br>
 * a[5] = 7<br>
 * a[6] = 4<br>
 * a[7] = 5<br>
 * a[8] = 9<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素を1～10の乱数で埋め尽くす(すべての要素が重複しないようにする)
class ArrayRandY {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		int n; //要素数
		do {
			System.out.print("要素数：");
			n = stdIn.nextInt(); //要素数を読み込む
		} while (n > 10);
		int[] a = new int[n]; //配列を生成

		for (int i = 0; i < n; i++) {
			int j = 0;
			do {
				a[i] = 1 + rand.nextInt(10);
				for (j = 0; j < i; j++){
					if (a[j] == a[i]){
						break;
					}
				}
			} while (j < i);
		}

		for (int i = 0; i < n; i++) {
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}