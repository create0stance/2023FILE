package Chap04_26;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-26<br>
 * キーボードから次々と整数値を読み込んで、合計と平均を求めるプログラムを作成せよ。加算する<br>
 * 整数の個数は最初に読み込むこと。なお、0が入力されたら読み込みを終了すること。<br>
 * <br>
 * <実行例1><br>
 * 整数を加算します。<br>
 * 何個加算しますか ： 2<br>
 * 整数（0で終了） ： 15<br>
 * 整数（0で終了） ： 37<br>
 * 合計は52です。<br>
 * 平均は26です。<br>
 * <br>
 * <実行例2><br>
 * 整数を加算します。<br>
 * 何個加算しますか ： 5<br>
 * 整数（0で終了） ： 82<br>
 * 整数（0で終了） ： 45<br>
 * 整数（0で終了） ： 0<br>
 * 合計は127です。<br>
 * 平均は63です。<br>
 * <br>
 *
 * @author System Shared
 */
// 読み込んだ整数を加算（0が入力されたら終了）
public class SumBreak1Ave {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("整数を加算します。");
		System.out.print("何個加算しますか ： ");
		int n = stdIn.nextInt(); // 加算する個数

		int sum = 0; // 合計値
		int i;
		for (i = 0; i < n; i++) {
			System.out.print("整数（0で終了） ： ");
			int t = stdIn.nextInt();
			if (t == 0) {
				break; // for文から抜け出る
			}
			sum += t;
		}
		System.out.println("合計は" + sum + "です。");
		if (i != 0) {
			System.out.println("平均は" + sum / i + "です。");
		}
	}
}