package
Chap07_02;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-2<br>
 * 三つのint型a,b,cの最小値を求めるメソッドminを作成せよ。<br>
 * int min(int a, int b, int c)<br>
 * <br>
 * ＜実行例＞<br>
 * 整数a：1<br>
 * 整数b：10<br>
 * 整数c：30<br>
 * 最小値は1です。<br>
 * <br>
 * @author SystemShared
 */

//三つの整数地の最小値を求める
class Min3 {

	//a,b,cの最小値を返却
	static int min(int a, int b, int c) {
		int min = a;
		if (b < min){
			min = b;
		}
		if (c < min){
			min = c;
		}
		return min;
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数a：");
		int a = stdIn.nextInt();
		System.out.print("整数b：");
		int b = stdIn.nextInt();
		System.out.print("整数c：");
		int c = stdIn.nextInt();

		System.out.println("最小値は" + min(a, b, c) + "です。");
	}
}