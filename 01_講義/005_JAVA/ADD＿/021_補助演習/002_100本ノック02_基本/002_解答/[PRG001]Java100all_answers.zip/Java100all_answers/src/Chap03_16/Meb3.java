package
Chap03_16;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-16<br>
 * キーボードから読み込んだ三つの整数値の中央値を求めて表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数ａ：1<br>
 * 整数ｂ：4<br>
 * 整数ｃ：5<br>
 * 中央値は4です。<br>
 * <br>
 * @author SystemShared
 */

class Meb3 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数ａ：");	int a = stdIn.nextInt();
		System.out.print("整数ｂ：");	int b = stdIn.nextInt();
		System.out.print("整数ｃ：");	int c = stdIn.nextInt();

		int med;
		if (a >= b){
			if (b >= c){
				med = b;
			}else if (a <= c){
				med = a;
			}else{
				med = c;
			}
		}else if (a > c){
			med = a;
		}else if (b > c){
			med = c;
		}else{
			med = b;
		}
		System.out.println("中央値は" + med + "です。");
	}
}
