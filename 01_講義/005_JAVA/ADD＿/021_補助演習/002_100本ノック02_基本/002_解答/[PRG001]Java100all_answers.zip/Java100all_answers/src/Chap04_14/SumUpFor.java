package Chap04_14;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-14<br>
 * 1からnまでの和を求めるプログラムをfor文で実現せよ。<br>
 * <br>
 * <実行例><br>
 * 1からnまでの和を求める。<br>
 * nの値 ： 5<br>
 * 1から5までの和は15です。<br>
 * <br>
 *
 * @author System Shared
 */
// 1からnまでの和を求める
public class SumUpFor {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("1からnまでの和を求める。");

		int n;
		do {
			System.out.print("nの値 ： ");
			n = stdIn.nextInt();
		} while (n <= 0);
		int sum = 0; // 合計
		for (int i = 1; i <= n; i++) {
			sum += i; // sumにiを加える
		}
		System.out.println("1から" + n + "までの和は" + sum + "です。");
	}
}
