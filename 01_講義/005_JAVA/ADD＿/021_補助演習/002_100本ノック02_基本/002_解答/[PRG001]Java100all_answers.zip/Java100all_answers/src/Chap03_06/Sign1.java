package
Chap03_06;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-6<br>
 * 前問のプログラムの最後のelseを、else if (n == 0)に変更したらどうなるかを検証せよ。<br>
 * <br>
 * <実行例><br>
 * 整数値：-1<br>
 * その値は負です。<br>
 * <br>
 * @author SystemShared
 */

class Sign1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		int n = stdIn.nextInt();

		if (n > 0){
			System.out.println("その値は正です。");
		}else if (n < 0){
			System.out.println("その値は負です。");
		}else if (n == 0){
			System.out.println("その値は０です。");
		}
	}
}
