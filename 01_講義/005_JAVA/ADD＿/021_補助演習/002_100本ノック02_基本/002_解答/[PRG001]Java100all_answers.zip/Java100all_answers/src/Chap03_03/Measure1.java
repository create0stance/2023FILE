package
Chap03_03;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-3<br>
 * 二つの正の整数値を酔いこんで、後者が前者の約数であれば『ＢはＡの約数です。』と表示し<br>
 * そうでなければ『ＢはＡの約数ではありません。』と表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 変数Ａ：8<br>
 * 変数Ｂ：6<br>
 * ＢはＡの約数ではありません。<br>
 * <br>
 * @author SystemShared
 */

class Measure1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("変数Ａ：");
		int a = stdIn.nextInt();
		System.out.print("変数Ｂ：");
		int b = stdIn.nextInt();

		if (a % b == 0){
			System.out.println("ＢはＡの約数です。");
		}else{
			System.out.println("ＢはＡの約数ではありません。");
		}

	}
}
