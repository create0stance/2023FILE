package 
Chap07_09;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-9<br>
 * 『せいの整数値：』と表示してキーボードから正の整数値を読み込んで、その値を返却するメソッドreadPlusIntを作成せよ。<br>
 * 0や負の値が入力されたら再入力させること。<br>
 * int readPlusInt()<br>
 * <br>
 * ＜実行例＞<br>
 * 正の整数値：56<br>
 * 逆から読むと65です。<br>
 * もう一度？<Yes…1/No…0>：1<br>
 * 正の整数値：92<br>
 * 逆から読むと29です。<br>
 * もう一度？<Yes…1/No…0>：0<br>
 * <br>
 * @author SystemShared
 */

//正の整数値を逆から読み込んで表示
class InverseNumber {
	static Scanner stdIn = new Scanner(System.in);

	//正の整数値を読み込んで返却
	static int readPlusInt() {
		int x;
		do {
			System.out.print("正の整数値：");
			x = stdIn.nextInt();
		} while (x <= 0);
		return x;
	}

	public static void main(String[] args) {
		int x;
		do {
			int n = readPlusInt();

			System.out.print("逆から読むと");
			while (n > 0) {
				System.out.print(n % 10); //nの最下位桁を表示
				n /= 10; //nを10で割る
			}
			System.out.println("です。");

			do {
				System.out.print("もう一度？<Yes…1/No…0>：");
				x = stdIn.nextInt();
			} while (x != 0 && x != 1);
		} while (x == 1);
	}
}