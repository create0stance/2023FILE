package
Chap06_07;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-7<br>
 * テストの点数の合計点・平均点・最高点・最低点を求めて表示するプログラムを作成せよ。<br>
 * 人数と点数は、キーボードから読み込むこと。<br>
 * <br>
 * <実行例><br>
 * 人数：2<br>
 * 点数を入力せよ。<br
 * 1番の点数：85<br>
 * 2番の点数：66<br>
 * 合計点は151点です。<br>
 * 平均点は75.5点です。<br>
 * 最高点は85点です。<br>
 * 最低点は66点です。<br>
 * <br>
 * @author SystemShared
 */

//点数を読み込んで合計点・平均点・最高点・最低点を表示
class PointSumAve {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("人数：");
		int ninzu = stdIn.nextInt(); //人数を読み込む
		int[] tensu = new int[ninzu]; //点数

		System.out.println("点数を入力せよ。");
		int sum = 0; //合計
		for (int i = 0; i < ninzu; i++) {
			System.out.print((i + 1) + "番の点数：");
			tensu[i] = stdIn.nextInt(); //tensu[i]を読み込む
			sum += tensu[i]; //sumにtensu[i]を加算
		}

		int max = tensu[0]; //最高点
		int min = tensu[0]; //最低点
		for (int i = 1; i < ninzu; i++) {
			if (tensu[i] > max){
				max = tensu[i];
			}
			if (tensu[i] < min){
				min = tensu[i];
			}
		}

		System.out.println("合計点は" + sum + "点です。");
		System.out.println("平均点は" + (double)sum / ninzu + "点です。");
		System.out.println("最高点は" + max + "点です。");
		System.out.println("最低点は" + min + "点です。");
	}
}