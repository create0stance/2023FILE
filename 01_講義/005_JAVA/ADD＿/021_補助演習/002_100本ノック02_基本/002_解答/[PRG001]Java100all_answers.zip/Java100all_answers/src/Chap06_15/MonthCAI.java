package
Chap06_15;
import java.util.Random;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-15<br>
 * 月を1～の数値として表示して、その英語表現を入力させる英単語学習プログラムを作成せよ。<br>
 * ・出題する月の値は乱数で生成する。<br>
 * ・学習者が望む限り、ん度も繰り返せる。<br>
 * ・同一月を連続して出題しない。<br>
 * 文字列s1とs2が等しい(すべての文字が等しい)かどうかの判定は、s1.equals(s2)によって行える(p.488)。<br>
 * <br>
 * <実行例><br>
 * 英語の月名を入力してください。<br>
 * なお、先頭は大文字で、2文字目以降は小文字とします。<br>
 * 9月：December<br>
 * 違います。9月：September<br>
 * 正解です。もう一度？1…Yes/2…No：<br>
 * <br>
 * @author SystemShared
 */

//月を表す英単語の学習プログラム
class MonthCAI {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);
		String[] monthString = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

		System.out.println("英語の月名を入力してください。");
		System.out.println("なお、先頭は大文字で、2文字目以降は小文字とします。");

		int retry; //もう一度
		int last = -1; //前回の月

		do {
			int month; //出題する月：0～11の乱数
			do {
				month = rand.nextInt(12);
			} while (month == last);
			last = month;

			while (true) {
				System.out.print((month + 1) + "月：");
				String s = stdIn.next();

				if (s.equals(monthString[month])) {//正解
					break;
				}
				System.out.print("違います。");
			}

			System.out.print("正解です。もう一度？1…Yes/2…No：");
			retry = stdIn.nextInt();
		} while (retry == 1);
	}
}