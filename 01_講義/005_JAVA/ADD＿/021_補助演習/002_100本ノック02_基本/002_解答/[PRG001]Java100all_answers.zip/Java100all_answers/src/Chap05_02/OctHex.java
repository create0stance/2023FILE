package
Chap05_02;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第5章 基本型と演算<br>
 * 問題5-2<br>
 * １０進整数を読み込んで、その値を８進数と１６進数で表示するプログラムを作成せよ。<br>
 * 入力値はBufferedReaderを使って取得せよ。<br>
 * <br>
 * <実行例><br>
 * 整数：27<br>
 * 8進数では33です。<br>
 * 16進数では1bです。<br>
 * <br>
 * @author System Shared
 */

class OctHex {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("整数：");
		int x = Integer.parseInt(br.readLine());

		System.out.printf(" 8進数では%oです。\n", x);	//  8進数で表示
		System.out.printf("16進数では%xです。\n", x);	// 16進数で表示
	}
}
