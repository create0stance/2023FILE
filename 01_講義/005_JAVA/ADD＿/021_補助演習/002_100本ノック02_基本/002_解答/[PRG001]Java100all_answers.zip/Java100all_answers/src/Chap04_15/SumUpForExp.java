package Chap04_15;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-15<br>
 * 前問のプログラムを書き換えて、加算の"式"を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例1><br>
 * 1からnまでの和を求めます。<br>
 * nの値 ： 1<br>
 * 1 = 1<br>
 * <br>
 * <実行例2><br>
 * 1からnまでの和を求めます。<br>
 * nの値 ： 3<br>
 * 1 + 2 + 3 = 6<br>
 * <br>
 * <実行例3><br>
 * 1からnまでの和を求めます。<br>
 * nの値 ： 5<br>
 * 1 + 2 + 3 + 4 + 5 = 15<br>
 * <br>
 *
 * @author System Shared
 */
// 1からまでの和を求める（計算式を表示）
public class SumUpForExp {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("1からnまでの和を求めます。");
		int n;
		do {
			System.out.print("nの値 ： ");
			n = stdIn.nextInt();
		} while (n <= 0);
		int sum = 0;
		for (int i = 1; i < n; i++) {
			System.out.print(i + " + ");
			sum += i; // sumにiを加える
		}
		System.out.print(n + " = ");
		sum += n; // sumにnを加える
		System.out.println(sum);

	}
}
