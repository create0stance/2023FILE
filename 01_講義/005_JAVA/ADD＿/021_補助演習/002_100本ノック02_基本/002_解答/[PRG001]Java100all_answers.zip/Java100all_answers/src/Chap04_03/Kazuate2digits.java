package
Chap04_03;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-3<br>
 * 2桁の整数値(10～99)を当てさせる<<数当てゲーム>>を作成せよ。<br>
 * <br>
 * <実行例><br>
 * 数当てゲーム開始！！<br>
 * 10～99の数を当ててください。<br>
 * いくつかな：50<br>
 * もっと小さな値だよ。<br>
 * いくつかな：25<br>
 * もっと大きな値だよ。<br>
 * いくつかな：31<br>
 * 正解です。<br>
 * <br>
 * @author SystemShared
 */

//数当てゲーム(10～99を当てさせる)
class Kazuate2digits {

	public static void main(String[] args) throws IOException{
		Random rand = new Random();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String input = "";

		int no = 10 + rand.nextInt(90);

		System.out.println("数当てゲーム開始！！");
		System.out.println("10～99の数を当ててください。");

		int x; //プレイヤーが入力した値
		do {
			System.out.print("いくつかな：");
			input = br.readLine();
			x = Integer.parseInt(input);

			if (x > no){
				System.out.println("もっと小さな値だよ。");
			}else if (x < no){
				System.out.println("もっと大きな値だよ。");
			}
		} while (x != no);

		System.out.println("正解です。");
	}
}