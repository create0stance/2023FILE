package
Chap03_14;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-14<br>
 * 二つの整数値を読み込んで、それらの値の差が10以下であれば、『それらの差は10以下です。』<br>
 * と表示し、そうでなければ『それらの差は11以上です。』と表皮するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数Ａ：1<br>
 * 整数Ｂ：10<br>
 * それらの差は10以下です。<br>
 * <br>
 * @author SystemShared
 */

class Diff2digits1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数Ａ："); int a = stdIn.nextInt();
		System.out.print("整数Ｂ："); int b = stdIn.nextInt();

		int diff = a >= b ? a - b : b - a;

		if (diff <= 10){
			System.out.println("それらの差は10以下です。");
		}else{
			System.out.println("それらの差は11以上です。");
		}
	}
}
