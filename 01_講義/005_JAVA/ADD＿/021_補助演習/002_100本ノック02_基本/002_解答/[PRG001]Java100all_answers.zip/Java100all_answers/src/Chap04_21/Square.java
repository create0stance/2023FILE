package Chap04_21;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-21<br>
 * 記号文字*を並べてn段の正方形を表意するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 正方形を表示します。<br>
 * 段数は ： 3<br>
 * ***<br>
 * ***<br>
 * ***<br>
 * <br>
 *
 * @author System Shared
 */
// 正方形を表示
public class Square {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("正方形を表示します。");
		System.out.print("段数は ： ");
		int n = stdIn.nextInt();

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}
}
