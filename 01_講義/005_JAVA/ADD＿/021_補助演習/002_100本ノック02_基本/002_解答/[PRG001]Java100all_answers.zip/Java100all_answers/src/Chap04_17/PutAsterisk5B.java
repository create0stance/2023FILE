package Chap04_17;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-17<br>
 * 読み込んだ個数だけ*を表示する問題4-11を書き換えて、5個表示するごとに改行するプログラムを作成せよ。<br>
 * <br>
 * <実行例1><br>
 * 何個*を表示しますか ： 15<br>
 * *****<br>
 * *****<br>
 * *****<br>
 * <br>
 * <実行例2><br>
 * 何個*を表示しますか ： 14<br>
 * *****<br>
 * *****<br>
 * ****<br>
 * <br>
 *
 * @author System Shared
 */
// 読み込んだ個数だけ*を表示／5個ごとに改行（その２）
public class PutAsterisk5B {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("何個*を表示しますか ： ");
		int n = stdIn.nextInt();
		if (n > 0) {
			for (int i = 0; i < n / 5; i++) {
				System.out.println("*****");
			}
			int rest = n % 5;
			if (rest > 0) {
				for (int i = 0; i < rest; i++) {
					System.out.print('*');
				}
				System.out.println();
			}
		}
	}
}
