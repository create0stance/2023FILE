package
Chap05_06;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第5章 基本型と演算<br>
 * 問題5-6<br>
 * 三つの整数値を読み込んで、その合計と平均を表示するプログラムを作成せよ。<br>
 * 平均はキャスト演算子を利用して求め、実数として表示すること。<br>
 * <br>
 * <実行例><br>
 * 整数値xとyとxの平均値を求めます。<br>
 * xの値：7<br>
 * yの値：8<br>
 * zの値：10<br>
 * xとyとzの平均値は8.333です。<br>
 * <br>
 * @author System Shared
 */

class Average3B {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("整数値xとyとxの平均値を求めます。");
		System.out.print("xの値：");	int x = Integer.parseInt(br.readLine());
		System.out.print("yの値：");	int y = Integer.parseInt(br.readLine());
		System.out.print("zの値：");	int z = Integer.parseInt(br.readLine());

		double ave = (double)(x + y + z) / 3;						// 平均値
		System.out.println("xとyとzの平均値は" + ave + "です。");	// 表示
	}

}
