package
Chap06_14;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-14<br>
 * 配列aの全要素を配列bに対して逆順にコピーするプログラムを作成せよ。<br>
 * なお、二つの配列の要素数は同一であると仮定してよい。<br>
 * <br>
 * <実行例><br>
 * 要素数：3<br>
 * a[0] = 1<br>
 * a[1] = 4<br>
 * a[2] = 9<br>
 * aの全要素を逆順にbにコピーしました。<br>
 * b[0] = 9<br>
 * b[1] = 4<br>
 * b[2] = 1<br>
 * <br>
 * @author SystemShared
 */

//配列の全要素を逆順にコピーして表示
class CopyArrayReverse {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数：");
		int n = stdIn.nextInt(); //要素数を取り込む
		int[] a = new int[n]; //配列aを生成
		int[] b = new int[n]; //配列bを生成

		for (int i = 0; i < n; i++) { //配列aに値を読み込む
			System.out.print("a[" + i + "] = ");
			a[i] = stdIn.nextInt();
		}

		for (int i = 0; i < n; i++){ //配列aの全要素を逆順に配列bにコピー
			b[i] = a[n - i - 1];
		}

		System.out.println("aの全要素を逆順にbにコピーしました。");

		for (int i = 0; i < n; i++){ //配列bを表示
			System.out.println("b[" + i + "] = " + b[i]);
		}
	}
}