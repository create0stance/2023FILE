package Chap01_05;
/**
 * 第1章 画面に文字を表示しよう<br>
 * 問題1-5<br>
 * 各行に1文字ずつ自分の名前を表示するプログラムを作成せよ。なお、姓と名の間は1行あけること。<br>
 * <br>
 * <実行例><br>
 * 電<br>
 * 子<br>
 * <br>
 * 太<br>
 * 郎<br>
 * <br>
 * @author SystemShared
 */

public class PrintName2A {
   public static void main(String[] args) {
	   System.out.println("電");
	   System.out.println("子");
	   System.out.println();
	   System.out.println("太");
	   System.out.println("郎");

   }
}