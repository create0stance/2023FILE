package
Chap06_20;
import java.util.Scanner;
/**
 * 第6章 配列<br>
 * 問題6-20<br>
 * クラス数、各クラスの人数・全員の点数を読みこんで、点数の合計点と平均点を求めるプログラムを作成せよ。<br>
 * 合計点と平均点は、クラスごとのものと、全体のものとを表示すること。<br>
 * <br>
 * <実行例><br>
 * クラス数：2<br>
 * <br>
 * 1組の人数：3<br>
 * 1組1番の点数：80<br>
 * 1組2番の点数：75<br>
 * 1組3番の点数：50<br>
 * <br>
 * 2組の人数：1<br>
 * 2組1番の点数：100<br>
 * 　組|　　合計　平均<br>
 * ----+----------------<br>
 *  1組|    205   68.3<br>
 *  2組|    100  100.0<br>
 * ----+----------------<br>
 * 　計|    305   76.3<br>
 * <br>
 * @author SystemShared
 */

//クラスごとに人数が異なる学生の点数の集計
class PointClass {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("クラス数：");
		int classNum = stdIn.nextInt();

		int[][] point = new int[classNum][];

		int ninzu = 0; //全クラスの人数の合計
		for (int i = 0; i < point.length; i++) {
			System.out.printf("\n%d組の人数：", i + 1);
			int num = stdIn.nextInt();
			point[i] = new int[num];
			ninzu += num;
			for (int j = 0; j < point[i].length; j++) {
				System.out.printf("%d組%d番の点数：", i + 1, j + 1);
				point[i][j] = stdIn.nextInt();
			}
		}

		System.out.println("　組|　　合計　平均");
		System.out.println("----+----------------");
		int total = 0;
		for (int i = 0; i < point.length; i++) {
			int sum = 0;
			for (int j = 0; j < point[i].length; j++){
				sum += point[i][j];
			}
			total += sum;
			System.out.printf("%2d組|%7d%7.1f\n", i + 1, sum, (double)sum / point[i].length);
		}
		System.out.println("----+----------------");
		System.out.printf("　計|%7d%7.1f\n", total, (double)total / ninzu);

	}

}
