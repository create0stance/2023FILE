package Chap07_21;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-21<br>
 * 配列aから要素a[idx]を先頭とするn個の要素を削除した配列を返却するメソッドarrayRmvOfNを作成せよ。<br>
 * int[] arrayRmvOfN(int[] a, int idx, int n)<br>
 * 削除はa[idx]より後ろの全要素をn個前方にずらすことによって行うこと。<br>
 * 【例】配列aの要素が{1, 3, 4, 7, 9, 11}のときにarrayRmvOfN{a, 1, 3}と呼び出された場合、<br>
 * 返却する配列の要素は{1, 9, 11}となる。<br>
 * <br>
 * <実行例><br>
 * 要素数 ： 6<br>
 * x[0] : 1<br>
 * x[1] : 3<br>
 * x[2] : 4<br>
 * x[3] : 7<br>
 * x[4] : 9<br>
 * x[5] : 11<br>
 * 削除する要素のインデックス ： 1<br>
 * 削除するようおの個数 ： 3<br>
 * y[0] = 1<br>
 * y[1] = 9<br>
 * y[2] = 11<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 配列から連続要素を削除した配列を返却
public class ArrayRemoveOfN {
	// --- 配列aからa[idx]を先頭とするn個の要素を削除した配列を返却 ---//
	static int[] arrayRmvOfN(int[] a, int idx, int n) {
		if (n < 0 || idx < 0 || idx >= a.length) {
			return a.clone();
		} else {
			if (idx + n > a.length) {
				n = a.length - idx;
			}
			int[] c = new int[a.length - n];
			int i = 0;
			for (; i < idx; i++) {
				c[i] = a[i];
			}
			for (; i < a.length - n; i++) {
				c[i] = a[i + n];
			}
			return c;
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("要素数 ： ");
			int num = stdIn.nextInt();
			int[] x = new int[num]; // 要素数numの配列

			for (int i = 0; i < num; i++) {
				System.out.print("x[" + i + "] : ");
				x[i] = stdIn.nextInt();
			}
			System.out.print("削除する要素のインデックス ： ");
			int idx = stdIn.nextInt();

			System.out.print("削除するようおの個数 ： ");
			int n = stdIn.nextInt();

			// 配列xからx[idx]を先頭とするn個の要素を削除した配列を生成
			int[] y = arrayRmvOfN(x, idx, n);

			for (int i = 0; i < y.length; i++) { // 配列yを表示
				System.out.println("y[" + i + "] = " + y[i]);
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
