package
Chap03_01;
import java.util.Scanner;
/**
 * 第3章 プログラムの流れの分岐<br>
 * 問題3-1<br>
 * 整数値を読み込んで、値が負であれば『その値は負です。』と表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 整数値：-1<br>
 * その値は負です。<br>
 * <br>
 * @author SystemShared
 */

//読み込んだ整数値は負の値か？
class Negative {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("整数値：");
		int n = stdIn.nextInt();

		if (n < 0){
			System.out.println("その値は負です。");
		}
	}
}