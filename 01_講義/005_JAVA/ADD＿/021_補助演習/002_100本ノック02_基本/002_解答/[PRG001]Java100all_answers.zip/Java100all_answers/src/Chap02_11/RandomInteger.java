package 
Chap02_11;

import java.util.Random;

/**
 * 第2章 変数を使おう<br>
 * 問題2-11<br>
 * 以下に示すプログラムを作成せよ。<br>
 * ・１桁の正の整数値（すなわち１以上９以下の値）をランダムに生成して表示。<br>
 * ・１桁の負の整数値（すなわち-９以上-１以下の値）をランダムに生成して表示。<br>
 * ・２桁の正の整数値（すなわち１０以上９９以下の値）をランダムに生成して表示。<br>
 * <br>
 * <実行例><br>
 * 3個の乱数を生成しました。<br>
 * 1桁の正の整数：8<br>
 * 1桁の負の整数：-6<br>
 * 2桁の正の整数：41<br>
 * <br>
 * @author System Shared
 */
// 整数の乱数を生成して表示
public class RandomInteger {
	public static void main(String[] args) {
		Random rand = new Random();

		int n1 = 1 + rand.nextInt(9); // １桁の正の整数値(1～9)
		int n2 = -1 - rand.nextInt(9); // １桁の負の整数値(-1～-9)
		int n3 = 10 + rand.nextInt(90); // ２桁の正の整数値(10～99)

		System.out.println("3個の乱数を生成しました。");
		System.out.println("1桁の正の整数：" + n1);
		System.out.println("1桁の負の整数：" + n2);
		System.out.println("2桁の正の整数：" + n3);

	}

}
