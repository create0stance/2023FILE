package Chap04_13;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-13<br>
 * 前問とは逆に、0から正の整数値までカウントアップするプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * カウントアップします。<br>
 * 正の整数値 ： 4<br>
 * 0<br>
 * 1<br>
 * 2<br>
 * 3<br>
 * 4<br>
 * <br>
 *
 * @author System Shared
 */
// 正の整数値を0からカウトアップ
public class CountUp {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.println("カウントアップします。");

		int x;
		do {
			System.out.print("正の整数値 ： ");
			x = stdIn.nextInt();
		} while (x <= 0);
		for (int i = 0; i <= x; i++) {
			System.out.println(i); // iの値を表示
		}
	}

}
