package 
Chap05_07;
/**
 * 第5章 基本型と演算<br>
 * 問題5-7<br>
 * int型変数に対して実数値を代入して、その値を表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * a = 10<br>
 * <br>
 * @author System Shared
 */

class FloatToInteger {

	public static void main(String[] args) {
		int a;

		a = (int)10.312;
//      a = 10.0;			// エラー

		System.out.println("a = " + a);
	}
}
