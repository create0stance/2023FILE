package Chap07_17;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-17<br>
 * 配列aと配列bの全要素の値を交換するメソッドaryExchngを作成せよ。<br>
 * void aryExchng(int[] a, int[] b)<br>
 * 二つの配列の要素数が等しくない場合は、小さいほうの要素数分の要素を交換すること。<br>
 * 【例】配列aの要素が{1, 2, 3, 4, 5, 6, 7}で、配列bの要素が{5, 4, 3, 2, 1}のときに、<br>
 * aryExchng(a, b)と呼び出した後で、配列aは{5, 4, 3, 2, 1, 6, 7}となり、配列bは{1, <br>
 * 2, 3, 4, 5}とならなければならない。<br>
 * <br>
 * <実行例><br>
 * 配列aの要素数 ： 7<br>
 * a[0] : 1<br>
 * a[1] : 2<br>
 * a[2] : 3<br>
 * a[3] : 4<br>
 * a[4] : 5<br>
 * a[5] : 6<br>
 * a[6] : 7<br>
 * 配列bの要素数 ： 5<br>
 * b[0] : 5<br>
 * b[1] : 4<br>
 * b[2] : 3<br>
 * b[3] : 2<br>
 * b[4] : 1<br>
 * 配列aとbの全要素を交換しました。<br>
 * a[0] = 5<br>
 * a[1] = 4<br>
 * a[2] = 3<br>
 * a[3] = 2<br>
 * a[4] = 1<br>
 * a[5] = 6<br>
 * a[6] = 7<br>
 * b[0] = 1<br>
 * b[1] = 2<br>
 * b[2] = 3<br>
 * b[3] = 4<br>
 * b[4] = 5<br>
 * <br>
 *
 * @author System Shared
 *
 */
// 二つの配列の全要素の値を交換
public class AryExchng {

	// --- 配列aとbの全要素の値を交換 ---//
	static void aryExchng(int[] a, int[] b) {
		int n = a.length < b.length ? a.length : b.length;
		for (int i = 0; i < n; i++) {
			int t = a[i];
			a[i] = b[i];
			b[i] = t;
		}
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);

			System.out.print("配列aの要素数 ： ");
			int na = stdIn.nextInt(); // 配列aの要素数

			int[] a = new int[na]; // 要素naの配列

			for (int i = 0; i < na; i++) {
				System.out.print("a[" + i + "] : ");
				a[i] = stdIn.nextInt();
			}
			System.out.print("配列bの要素数 ： ");
			int nb = stdIn.nextInt(); // 配列aの要素数

			int[] b = new int[nb]; // 要素nbの配列

			for (int i = 0; i < nb; i++) {
				System.out.print("b[" + i + "] : ");
				b[i] = stdIn.nextInt();
			}
			aryExchng(a, b);

			System.out.println("配列aとbの全要素を交換しました。");
			for (int i = 0; i < na; i++) { // 配列aを表示
				System.out.println("a[" + i + "] = " + a[i]);
			}
			for (int i = 0; i < nb; i++) { // 配列bを表示
				System.out.println("b[" + i + "] = " + b[i]);
			}
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}
