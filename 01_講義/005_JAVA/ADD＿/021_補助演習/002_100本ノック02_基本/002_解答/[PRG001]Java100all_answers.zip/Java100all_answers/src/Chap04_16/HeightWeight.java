package Chap04_16;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-16<br>
 * 身長と標準体重の対応表を表示うるプログラムを作成せよ。表示する身長の範囲（開始値／終了値／増分）は、<br>
 * 整数値として読み込むこと。<br>
 * ※標準体重は(身長 - 100) × 0.9 によって求められる。<br>
 * <br>
 * <実行例><br>
 * 何cmから ： 150<br>
 * 何cmまで ： 180<br>
 * 何cmごと ： 5<br>
 * 身長　標準体重<br>
 * -------------<br>
 * 150 45.0<br>
 * 155 49.5<br>
 * 160 54.0<br>
 * 165 58.5<br>
 * 170 63.0<br>
 * 175 67.5<br>
 * 180 72.0<br>
 * <br>
 *
 * @author System Shared
 */
public class HeightWeight {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("何cmから ： ");
		int hMin = stdIn.nextInt();

		System.out.print("何cmまで ： ");
		int hMax = stdIn.nextInt();

		System.out.print("何cmごと ： ");
		int step = stdIn.nextInt();

		System.out.println("身長　標準体重");
		System.out.println("-------------");

		for (int i = hMin; i <= hMax; i += step) {
			System.out.println(i + "  " + 0.9 * (i - 100));
		}
	}
}
