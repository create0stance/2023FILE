package Chap04_24;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-24<br>
 * n段の数字ピラミッドを表示するプログラムを作成せよ。<br>
 * 第i行目にはi % 10を表示すること。<br>
 * <br>
 * <実行例1><br>
 * 数字ピラミッドを表示します。<br>
 * 段数は ： 5<br>
 * 1<br>
 * 222<br>
 * 33333<br>
 * 4444444<br>
 * 555555555<br>
 * <br>
 * <実行例2><br>
 * 数字ピラミッドを表示します。<br>
 * 段数は ： 12<br>
 * 1<br>
 * 222<br>
 * 33333<br>
 * 4444444<br>
 * 555555555<br>
 * 66666666666<br>
 * 7777777777777<br>
 * 888888888888888<br>
 * 99999999999999999<br>
 * 0000000000000000000<br>
 * 111111111111111111111<br>
 * 22222222222222222222222<br>
 * <br>
 *
 * @author System Shared
 */
// 数字のピラミッドを表示
public class DigitPyramid {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("数字ピラミッドを表示します。");
		System.out.print("段数は ： ");
		int n = stdIn.nextInt();

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n - i; j++) {
				System.out.print(' ');
			}
			for (int j = 1; j <= 2 * i - 1; j++) {
				System.out.print(i % 10);
			}
			System.out.println();
		}
	}
}