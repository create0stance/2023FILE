package Chap04_29;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-29<br>
 * 5個の整数から構成されるグループの合計を求めるプログラムを作成せよ。グループは全部で10個であり、<br>
 * 各整数値はキーボードから読み込む。ただし、99999を入力すると全体の入力を終了し、88888を入力<br>
 * すると現在読み込み中のグループの入力を終了すること。<br>
 * <br>
 * <実行例><br>
 * 整数を加算します。 ■第1グループ 整数 ： 175 整数 ： 634 整数 ： 394 整数 ： 88888 ■第2グループ 整数 ： 555 整数 ：
 * 777 整数 ： 88888 ■第3グループ 整数 ： 99999
 *
 * 合計は2535です。
 *
 * @author System Shared
 *
 */
// 読み込んだ整数のグループを加算（整数5個×10グループ）
public class SumGroup2 {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("整数を加算します。");
		int total = 0; // 全グループの合計

		Outer: for (int i = 1; i <= 10; i++) {
			System.out.println("■第" + i + "グループ");

			for (int j = 0; j < 5; j++) {
				System.out.print("整数 ： ");
				int t = stdIn.nextInt();
				if (t == 99999) {
					break Outer;
				} else if (t == 88888) {
					continue Outer;
				}
				total += t;
			}
		}
		System.out.println("\n合計は" + total + "です。");
	}
}