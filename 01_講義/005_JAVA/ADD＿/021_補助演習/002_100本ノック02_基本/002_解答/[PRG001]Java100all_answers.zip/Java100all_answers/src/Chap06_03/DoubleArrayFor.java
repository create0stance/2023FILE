package 
Chap06_03;
/**
 * 第6章 配列<br>
 * 問題6-3<br>
 * 要素数がdouble型で要素数が5の配列の要素に対して、先頭から順に1.1、2.2、3.3、4.4、5.5を代入して表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * a[0] = 1.1<br>
 * a[1] = 2.2<br>
 * a[2] = 3.3000000000000003<br>
 * a[3] = 4.4<br>
 * a[4] = 5.5<br>
 * <br>
 * @author SystemShared
 */

//配列の各要素に1.1、2.2、3.3、4.4、5.5を代入して表示
class DoubleArrayFor {

	public static void main(String[] args) {
		double[] a = new double[5]; //配列の宣言

		for (int i = 0; i < a.length; i++)
			a[i] = (i + 1) * 1.1;

		for (int i = 0; i < a.length; i++)
			System.out.println("a[" + i + "] = " + a[i]);
	}
}
