package 
Chap05_03;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * 第5章 基本型と演算<br>
 * 問題5-3<br>
 * float型の変数とdouble型の変数に実数値を読み込んで表示するプログラムを作成せよ。<br>
 * <br>
 * <実行例><br>
 * 変数xはfloat型で、変数yはdouble型です。<br>
 * x : 0.12345678901234567890<br>
 * y : 0.12345678901234567890<br>
 * x = 0.12345679<br>
 * y = 0.12345678901234568<br>
 * <br>
 * @author System Shared
 */

class FloatDoubleScanPrint {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("変数xはfloat型で、変数yはdouble型です。");
		System.out.print("x : ");
		float  x = Float.parseFloat(br.readLine());
		System.out.print("y : ");
		double y = Double.parseDouble(br.readLine());

		System.out.println("x = " + x);
		System.out.println("y = " + y);
	}

}
