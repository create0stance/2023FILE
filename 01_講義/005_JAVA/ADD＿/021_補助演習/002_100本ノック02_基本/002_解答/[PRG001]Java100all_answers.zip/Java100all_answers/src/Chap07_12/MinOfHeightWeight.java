package Chap07_12;

import java.util.Scanner;

/**
 * 第7章 メソッド<br>
 * 問題7-12<br>
 * 配列aの要素の最小値を求めるメソッドminOfを作成せよ。<br>
 * int minOf(int[] a)<br>
 * <br>
 * <実行例><br>
 * 人数は ： 4<br>
 * 4人の身長と体重を入力せよ。<br>
 * 1番目の身長 ： 175<br>
 * 1番目の体重 ： 72<br>
 * 2番目の身長 ： 163<br>
 * 2番目の体重 ： 82<br>
 * 3番目の身長 ： 150<br>
 * 3番目の体重 ： 49<br>
 * 4番目の身長 ： 181<br>
 * 4番目の体重 ： 76<br>
 * 最も背が低い人の身長    ： 150cm<br>
 * 最も痩せている人の体重 ： 49kg<br>
 * <br>
 * @author System Shared
 *
 */
// 最も背が低い人の身長と最も痩せている人の体重を求める。
public class MinOfHeightWeight {

	// --- 配列aの最小値を求めて返却 ---//
	static int minOf(int[] a) {
		int min = a[0];
		for (int i = 1; i < a.length; i++) {
			if (a[i] < min) {
				min = a[i];
			}
		}
		return min;
	}

	public static void main(String[] args) {
		try {
			Scanner stdIn = new Scanner(System.in);
			System.out.print("人数は ： "); // 人数を読み込む
			int ninzu = stdIn.nextInt();

			int[] height = new int[ninzu]; // 身長用の配列を生成
			int[] weight = new int[ninzu]; // 体重用の配列を生成

			System.out.println(ninzu + "人の身長と体重を入力せよ。");

			for (int i = 0; i < ninzu; i++) {
				System.out.print((i + 1) + "番目の身長 ： ");
				height[i] = stdIn.nextInt();
				System.out.print((i + 1) + "番目の体重 ： ");
				weight[i] = stdIn.nextInt();
			}
			System.out.println("最も背が低い人の身長    ： " + minOf(height) + "cm");
			System.out.println("最も痩せている人の体重 ： " + minOf(weight) + "kg");
		} catch (Exception e) {
			System.out.println("入力可能な文字は半角数字のみです。");
		}
	}
}