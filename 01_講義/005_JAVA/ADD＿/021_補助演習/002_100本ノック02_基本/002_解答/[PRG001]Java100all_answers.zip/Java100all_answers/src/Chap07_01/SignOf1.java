package
Chap07_01;
import java.util.Scanner;
/**
 * 第7章 メソッド<br>
 * 問題7-1<br>
 * 受け取ったint型引数の値nが負であれば-1を返却し、0であれば0を返却し、正であれば1を返却するメソッドsignOfを作成せよ。<br>
 * int signOf(int n)
 * <br>
 * ＜実行例1＞<br>
 * 整数x：10<br>
 * signOf(x)は1です。<br>
 * <br>
 * ＜実行例2＞<br>
 * 整数x：-10<br>
 * signOf(x)は-1です。<br>
 * <br>
 * @author SystemShared
 */

//受け取った整数の符号を判定(その1)
class SignOf1 {

	//nの符号を判定
	static int signOf(int n) {
		int sign = 0;

		if (n > 0){
			sign = 1;
		}else if (n < 0){
			sign = -1;
		}
		return sign;
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数x：");
		int x = stdIn.nextInt();

		int s = signOf(x);
		System.out.println("signOf(x)は" + s + "です。");
	}
}