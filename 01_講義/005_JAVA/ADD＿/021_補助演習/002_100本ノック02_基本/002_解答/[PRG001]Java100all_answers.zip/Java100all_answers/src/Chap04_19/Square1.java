package Chap04_19;

import java.util.Scanner;

/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-19<br>
 * 1からnまでの整数値の2乗値を表示するプログラムを作成せよ。（nの値は読み込むこと）<br>
 * <br>
 * <実行例><br>
 * nの値 ： 3<br>
 * 1の2乗は1<br>
 * 2の2乗は4<br>
 * 3の2乗は9<br>
 * <br>
 *
 * @author System Shared
 */
// 整数値の2乗値を表示（その１）
public class Square1 {
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("nの値 ： ");
		int n = stdIn.nextInt();

		for (int i = 1; i <= n; i++) {
			System.out.println(i + "の2乗は" + i * i);
		}
	}
}
