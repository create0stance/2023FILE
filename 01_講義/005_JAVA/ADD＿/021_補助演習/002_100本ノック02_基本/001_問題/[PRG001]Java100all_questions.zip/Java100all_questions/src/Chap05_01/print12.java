/**
 * 第5章 基本型と演算
 * 問題5-1
 * ８進数の１２、１０進数の１２、１６進数の１２を１０進数で表示するプログラムを作成せよ。
 *
 * <実行例>
 * 8進数の12は10進数で10です。
 * 10進数の12は10進数で12です。
 * 16進数の12は10進数で18です。
 *
 * @author System Shared
 */

package 
Chap05_01;

class print12 {

	public static void main(String[] args) {

	}
}
