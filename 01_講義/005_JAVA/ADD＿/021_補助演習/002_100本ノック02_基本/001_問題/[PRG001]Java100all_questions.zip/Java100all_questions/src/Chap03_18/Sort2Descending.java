/**
 * 第3章 プログラムの流れの分岐
 * 問題3-18
 * 二つの整数値を読み込んで降順（大きい順）にソートするプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 変数ａ：5
 * 変数ｂ：9
 * ａ≧ｂとなるようにソートしました。
 * 変数ａは9です。
 * 変数ｂは5です。
 *
 * @author SystemShared
 */

package 
Chap03_18;

class Sort2Descending {

	public static void main(String[] args) {

	}
}
