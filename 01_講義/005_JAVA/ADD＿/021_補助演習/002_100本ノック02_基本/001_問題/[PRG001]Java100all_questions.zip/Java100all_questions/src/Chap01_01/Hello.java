/**
 * 第1章 画面に文字を表示しよう
 * 問題1-1
 * コンソール画面に『初めてのJavaプログラム。』と『画面に出力しています。』とを、連続して一行ずつ表示するプログラムを作成せよ。
 *
 * <実行例>
 * 初めてのJavaプログラム。
 * 画面に出力しています。
 *
 * @author SystemShared
 */

package
Chap01_01;

public class Hello {
   public static void main(String[] args) {
	   System.out.println("Hello!!");
   }

}