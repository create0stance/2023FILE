﻿package
Chap04_18;


/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-18
 * 読み込み整数値のすべての約数と、その個数を表示するプログラムを作成せよ。
 *
 * <実行例>
 * 整数値 ： 12
 * 1 2 3 4 6 12
 * 約数は6個です。
 *
 * @author System Shared
 */
// 読み込んだ整数値のすべての約数を表示
public class Neasure {
	public static void main(String[] args) {

	}
}
