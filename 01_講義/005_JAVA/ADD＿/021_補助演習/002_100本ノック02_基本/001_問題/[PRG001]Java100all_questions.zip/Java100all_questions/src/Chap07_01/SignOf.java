/**
 * 第7章 メソッド
 * 問題7-1
 * 受け取ったint型引数の値nが負であれば-1を返却し、0であれば0を返却し、正であれば1を返却するメソッドsignOfを作成せよ。
 * int signOf(int n)
 *
 * ＜実行例1＞
 * 整数x：10
 * signOf(x)は1です。
 *
 * ＜実行例2＞
 * 整数x：-10
 * signOf(x)は-1です。
 *
 * @author SystemShared
 */

package 
Chap07_01;

import java.util.Scanner;

//受け取った整数の符号を判定(その1)
class SignOf {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数x：");
		int x = stdIn.nextInt();

		int s = signOf(x);
		System.out.println("signOf(x)は" + s + "です。");
	}
}