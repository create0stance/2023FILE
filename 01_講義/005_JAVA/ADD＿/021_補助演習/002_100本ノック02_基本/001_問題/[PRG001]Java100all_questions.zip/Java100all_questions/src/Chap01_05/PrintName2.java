/**
 * 第1章 画面に文字を表示しよう
 * 問題1-5
 * 各行に1文字ずつ自分の名前を表示するプログラムを作成せよ。なお、姓と名の間は1行あけること。
 *
 * <実行例>
 * 電
 * 子
 *
 * 太
 * 郎
 *
 * @author SystemShared
 */

package
Chap01_05;

public class PrintName2 {
   public static void main(String[] args) {

   }
}