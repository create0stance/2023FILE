/**
 * 第3章 プログラムの流れの分岐
 * 問題3-5
 * キーボードから読み込んだ整数値の符号を判定して表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数値：-1
 * その値は負です。
 *
 * @author SystemShared
 */

// 読み込んだ整数値の符号（正／負／０）を判定して表示
package
Chap03_05;

class Sign {

	public static void main(String[] args) {

	}
}
