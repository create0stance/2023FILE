/**
 * 第5章 基本型と演算
 * 問題5-3
 * float型の変数とdouble型の変数に実数値を読み込んで表示するプログラムを作成せよ。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 変数xはfloat型で、変数yはdouble型です。
 * x : 0.12345678901234567890
 * y : 0.12345678901234567890
 * x = 0.12345679
 * y = 0.12345678901234568
 *
 * @author System Shared
 */

package 
Chap05_03;

class FloatDoubleScanPrint {

	public static void main(String[] args){
	}

}
