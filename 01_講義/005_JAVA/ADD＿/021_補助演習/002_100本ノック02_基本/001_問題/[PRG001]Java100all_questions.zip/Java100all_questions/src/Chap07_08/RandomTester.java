/**
 * 第7章 メソッド
 * 問題7-8
 * a以上b未満の乱数を生成して、その値を返却するメソッドrandomを作成せよ。
 * 内部で乱数を生成する標準ライブラリを呼び出すこと。
 * int random(int a, int b)
 * なお、bの値がa以下の場合には、aの値をそのまま返却すること。
 *
 * ＜実行例＞
 * 乱数を生成します。
 * 下限値：10
 * 上限値：20
 * 生成した乱数は1977です。
 *
 * @author SystemShared
 */

package
Chap07_08;

import java.util.Scanner;

//指定された範囲の乱数を生成するメソッド
class RandomTester {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("乱数を生成します。");
		System.out.print("下限値：");
		int min = stdIn.nextInt();
		System.out.print("上限値：");
		int max = stdIn.nextInt();

		System.out.println("生成した乱数は" + random(min, max) + "です。");
	}
}