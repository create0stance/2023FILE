/**
 * 第6章 配列
 * 問題6-13
 * 配列の要素の並びをシャッフルする(ランダムな順となるようにかき混ぜる)プログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラス、乱数を生成するにあたりRandomクラスを用いよ。
 *
 * <実行例>
 * 要素数：3
 * a[0] = 5
 * a[1] = 10
 * a[2] = 15
 * 要素をかき混ぜました。
 * a[0] = 10
 * a[1] = 15
 * a[2] = 5
 *
 * @author SystemShared
 */

package 
Chap06_13;

class Shuffle {

	public static void main(String[] args) {

	}
}