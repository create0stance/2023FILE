/**
 * 第3章 プログラムの流れの分岐
 * 問題3-20
 * ０，１，２のいずれかの値の乱数を生成し、０であれば"グー"を、１であれば"チョキ"を、２であ
 * れば"パー"を表示するプログラムを作成せよ。
 * 乱数を生成するにあたりRandomクラスを用いよ。
 *
 * <実行例>
 * コンピュータが生成した手：チョキ
 *
 * @author SystemShared *
 */

package 
Chap03_20;

class FingerFlashing {

	public static void main(String[] args) {

	}
}