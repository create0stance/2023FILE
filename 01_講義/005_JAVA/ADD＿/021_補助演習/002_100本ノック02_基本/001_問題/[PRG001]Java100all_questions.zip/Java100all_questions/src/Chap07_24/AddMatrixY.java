package Chap07_24;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-24 行列xとyの和を格納した2次元配列を返すメソッドを作成せよ。（行数および列数が同一の配列
 * をxとyに受け取ることを前提としてよい） int[][] addMatrix(int[][] x, int[][] y)
 *
 * <実行例> 行列の行数 ： 2 行数の列数 ： 3 a[0][0] : 1 a[0][1] : 2 a[0][2] : 3 a[1][0] : 4
 * a[1][1] : 5 a[1][2] : 6 b[0][0] : 6 b[0][1] : 3 b[0][2] : 4 b[1][0] : 5
 * b[1][1] : 1 b[1][2] : 2 行列a 1 2 3 4 5 6
 *
 * 行列b 6 3 4 5 1 2
 *
 * 行列c 7 5 7 9 6 8
 *
 *
 * @author System Shared
 *
 */
// 二つの行列の和を求める
public class AddMatrixY {

	// --- 行列xとyの和を格納した配列を返却 ---//
	static int[][] addMatrix(int[][] x, int[][] y) {

	}

	// --- 行列mの全要素を表示 ---//
	static void printMatrix(int[][] m) {
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[i].length; j++) {
				System.out.print(m[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("行列の行数 ： ");
		int height = stdIn.nextInt();
		System.out.print("行数の列数 ： ");
		int width = stdIn.nextInt();
		int[][] a = new int[height][width];
		int[][] b = new int[height][width];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.printf("a[%d][%d] : ", i, j);
				a[i][j] = stdIn.nextInt();
			}
		}
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[i].length; j++) {
				System.out.printf("b[%d][%d] : ", i, j);
				b[i][j] = stdIn.nextInt();
			}
		}
		int[][] c = addMatrix(a, b); // aとbの和をcに代入
		System.out.println("行列a");
		printMatrix(a);
		System.out.println("\n行列b");
		printMatrix(b);
		System.out.println("\n行列c");
		printMatrix(c);

	}
}
