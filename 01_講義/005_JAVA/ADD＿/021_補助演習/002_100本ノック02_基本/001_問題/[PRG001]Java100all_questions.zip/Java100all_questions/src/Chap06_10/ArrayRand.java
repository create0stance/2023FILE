/**
 * 第6章 配列
 * 問題6-10
 * 要素数がint型である配列をつくり、全要素を1～10の乱数で埋め尽くす(1以上10以下の値を代入する)プログラムを作成せよ。
 * 要素数はキーボードから読み込むこと。
 * キーボードから値を読み込むにあたりScannerクラス、乱数を生成するにあたりRandomクラスを用いよ。
 *
 * <実行例>
 * 要素数：2
 * a[0] = 3
 * a[1] = 8
 *
 * @author SystemShared
 */

package 
Chap06_10;

class ArrayRand {

	public static void main(String[] args) {

	}
}