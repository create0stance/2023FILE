/**
 * 第2章 変数を使おう
 * 問題2-3
 * 小数点をもつ実数値をxとyに代入するように変更してその結果を考察せよ。
 *
 * <実行例>
 * xの値は63.4です。
 * yの値は18.3です。
 * 合計は81.7です。
 * 平均は40.85です。
 *
 * @author SystemShared
 */

package
Chap02_03;

public class SumAveError {
   public static void main(String[] args){
	   int num1 = 63;
	   int num2 = 18;

	   System.out.println(num1);
	   System.out.println(num2);

	   num1 = num2;

	   num1 = 0;
	   System.out.println(num1);
	   System.out.println(num2);
   }
}