/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-2
 * 3桁の正の整数値(100～999)を読み込むプログラムを作成せよ。
 * 3桁の正の整数値でない値が入力された場合は、再入力されること。
 * 入力値はBufferedReaderをつかって取得せよ。
 *
 * <実行例>
 * 3桁の正の整数値：59
 * 3桁の正の整数値：1052
 * 3桁の正の整数値：235
 * 235と入力しましたね。
 *
 * @author SystemShared
 */

package 
Chap04_02;

class ThreeDigits {

	public static void main(String[] args){
	}
}