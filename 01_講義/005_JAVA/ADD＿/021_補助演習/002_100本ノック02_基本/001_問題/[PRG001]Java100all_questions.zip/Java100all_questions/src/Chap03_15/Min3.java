/**
 * 第3章 プログラムの流れの分岐
 * 問題3-15
 * キーボードから読み込んだ三つの整数値の最小値を求めて表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数ａ：2
 * 整数ｂ：4
 * 整数ｃ：6
 * 最小値は2です。
 *
 * @author SystemShared
 */

package 
Chap03_15;

class Min3 {

	public static void main(String[] args) {

	}
}
