/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-4
 * 二つの整数値を読み込んで、小さいほうの数以上で大きいほうの数以下の全整数の小さいほうから順に表示するプログラムを作成せよ。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 整数A：33
 * 整数B：28
 * 28 29 30 31 32 33
 *
 * @author SystemShared
 */

package 
Chap04_04;

class EnumScope {

	public static void main(String[] args){
	}
}
