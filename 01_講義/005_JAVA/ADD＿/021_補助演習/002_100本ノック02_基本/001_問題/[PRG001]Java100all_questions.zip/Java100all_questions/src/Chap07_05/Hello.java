/**
 * 第7章 メソッド
 * 問題7-5
 * 『こんにちは。』と表示してメソッドhelloを作成せよ。
 *
 * ＜実行例＞
 * こんにちは。
 * こんにちは。
 * こんにちは。
 *
 * @author SystemShared
 */

package 
Chap07_05;

//『こんにちは。』と表示するメソッド
class Hello {

	public static void main(String[] args) {
		hello();
		hello();
		hello();
	}
}