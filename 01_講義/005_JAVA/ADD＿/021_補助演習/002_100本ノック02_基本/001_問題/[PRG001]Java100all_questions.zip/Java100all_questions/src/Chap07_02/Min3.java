/**
 * 第7章 メソッド
 * 問題7-2
 * 三つのint型a,b,cの最小値を求めるメソッドminを作成せよ。
 * int min(int a, int b, int c)
 *
 * ＜実行例＞
 * 整数a：1
 * 整数b：10
 * 整数c：30
 * 最小値は1です。

 * @author SystemShared
 */

package 
Chap07_02;

import java.util.Scanner;

//三つの整数地の最小値を求める
class Min3 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数a：");
		int a = stdIn.nextInt();
		System.out.print("整数b：");
		int b = stdIn.nextInt();
		System.out.print("整数c：");
		int c = stdIn.nextInt();

		System.out.println("最小値は" + min(a, b, c) + "です。");
	}
}