package Chap07_19;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-19 配列aの要素の中で値がxである全要素のインデックスを先頭から順に格納した配列を返却する
 * メソッドarraySrchIdxを作成せよ。 int[] arraySrchIdx(int[] a, int x) 【例】配列aの要素が{1, 5, 4,
 * 8, 5, 5, 7}でarraySrchIdx(a, 5)と呼び出された場合、 返却する配列は{1, 4,
 * 5}となる（値が5である要素のインデックスを並べたものとなる）。
 *
 * <実行例> 要素数 ： 7 x[0] : 1 x[1] : 5 x[2] : 4 x[3] : 8 x[4] : 5 x[5] : 5 x[6] : 7
 * 探索する値 ： 5 一致する要素のインデックス 1 4 5
 *
 *
 * @author System Shared
 *
 */
// ある値と一致する全要素のインデックスを抽出
public class ArraySearchIndex {

	// --- 配列aからxと一致する全要素のインデックスを抽出した配列を返却 ---//
	static int[] arraySrchIdx(int[] a, int x) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] x = new int[num]; // 要素数numの配列
		for (int i = 0; i < num; i++) {
			System.out.print("x[" + i + "] : ");
			x[i] = stdIn.nextInt();
		}
		System.out.print("探索する値 ： ");
		int n = stdIn.nextInt();
		int[] b = arraySrchIdx(x, n);
		if (b.length == 0) {
			System.out.println("一致する要素はありません。");
		} else {
			System.out.println("一致する要素のインデックス");
			for (int i = 0; i < b.length; i++) { // 配列bを表示
				System.out.println(b[i]);
			}
		}
	}
}
