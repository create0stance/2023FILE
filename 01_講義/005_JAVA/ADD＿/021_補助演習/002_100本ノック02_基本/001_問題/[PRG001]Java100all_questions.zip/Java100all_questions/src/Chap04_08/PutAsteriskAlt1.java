package 
Chap04_08;
/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-8
 * 読み込んだ値の個数だけ記号文字を表示するプログラムを作成せよ(最後に改行文字を出力する)。
 * 表示は*と+を交互に行うこと。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例1>
 * 何個表示しますか：12
 * *+*+*+*+*+*+
 *
 * <実行例2>
 * 何個表示しますか：11
 * *+*+*+*+*+*
 *
 * @author SystemShared
 */

//読み込んだ個数だけ*と+を交互に表示(その1)
class PutAsteriskAlt1 {

	public static void main(String[] args){
	}

}
