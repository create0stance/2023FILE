/**
 * 第6章 配列
 * 問題6-9
 * double型の配列の全要素の合計値と平均値を求めるプログラムを作成せよ。
 * 要素数と全要素の値はキーボードから読み込むこと。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 要素数：3
 * a[0] = 4
 * a[1] = 5
 * a[2] = 6
 * 全要素の合計は15.0です。
 * 全要素の平均は5.0です。
 *
 * @author SystemShared
 */

package 
Chap06_09;

class ArraySumAve {

	public static void main(String[] args) {

	}
}
