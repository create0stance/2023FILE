/**
 * 第5章 基本型と演算
 * 問題5-4
 * 論理型の変数にtrueやfalseを代入して、その値を表示するプログラムを作成せよ。
 * @author System Shared
 */

package 
Chap05_04;

class PrintBoolean {

	public static void main(String[] args) {
	}
}
