/**
 * 第2章 変数を使おう
 * 問題2-2
 * 二つの変数xとyの合計と平均を求めて表示するプログラムを作成せよ。なお、xとyには適当な値を代入しておくこと。
 *
 * <実行例>
 * xの値は63です。
 * yの値は18です。
 * 合計は81です。
 * 平均は40です。
 *
 * @author SystemShared
 */

package 
Chap02_02;

public class SumAve1 {
   public static void main(String[] args){

   }
}