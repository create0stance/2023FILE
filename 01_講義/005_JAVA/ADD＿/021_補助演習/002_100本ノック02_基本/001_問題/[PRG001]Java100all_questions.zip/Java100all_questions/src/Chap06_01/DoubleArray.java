/**
 * 第6章 配列
 * 問題6-1
 * 要素型がdouble型で要素数が5の配列を生成して、その全要素の値を表示するプログラムを作成せよ。
 *
 * <実行例>
 * a[0] = 0.0
 * a[1] = 0.0
 * a[2] = 0.0
 * a[3] = 0.0
 * a[4] = 0.0
 *
 * @author SystemShared
 */

package 
Chap06_01;

class DoubleArray {

	public static void main(String[] args) {

	}
}
