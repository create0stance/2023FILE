package Chap07_15;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-15 配列aから要素a[idx]を先頭とするn個の要素を削除するメソッドaryRmvNを作成せよ。 void
 * aryRmvN(int[] a, int idx, int n)
 * 削除はa[idx]より後ろの全要素をn個前方にずらすことによって行うこと。なお、移動されず にあまってしまう要素の値は変更しなくてよい。
 * 【
 * 【例】配列aの要素が{1, 3, 4, 7, 9, 11}のときにaryRmvN{a, 1, 3}と呼び出した後の配列aの要素 は{1, 9, 11, 7, 9, 11}となる。
 *
 * <実行例> 要素数 ： 6 a[0] : 1 a[1] : 3 a[2] : 4 a[3] : 7 a[4] : 9 a[5] : 11
 * 削除する開始インデックス : 1 削除する要素の数 ： 3 a[0] = 1 a[1] = 9 a[2] = 11 a[3] = 7 a[4] = 9
 * a[5] = 11
 *
 * @author System Shared
 *
 */
// 配列からの連続要素の削除
public class AryRmvN {
	// --- 配列aからa[idx]をxを挿入（以降の要素を後方へずらす） ---//
	static void aryRmvN(int[] a, int idx, int x) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] a = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("a[" + i + "] : ");
			a[i] = stdIn.nextInt();
		}
		System.out.print("挿入する要素のインデックス : ");
		int idx = stdIn.nextInt();

		System.out.print("挿入する値 ： ");
		int x = stdIn.nextInt();

		aryRmvN(a, idx, x); // 配列aのa[idx]にxを挿入

		for (int i = 0; i < num; i++) { // 配列aを表示
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}