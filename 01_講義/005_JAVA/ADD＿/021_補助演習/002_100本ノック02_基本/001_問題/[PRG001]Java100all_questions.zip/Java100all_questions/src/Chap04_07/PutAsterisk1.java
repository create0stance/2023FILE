package 
Chap04_07;
/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-7
 * キーボードから読み込んだ値の個数だけ*を表示するプログラムを作成せよ。
 * 最後に改行文字を出力すること。
 * ただし、読み込んだ値が1未満であれば、改行文字を表示してはならない。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 何個*を表示しますか：10
 * **********
 *
 * @author SystemShared
 */


class PutAsterisk1 {

	public static void main(String[] args){
	}
}