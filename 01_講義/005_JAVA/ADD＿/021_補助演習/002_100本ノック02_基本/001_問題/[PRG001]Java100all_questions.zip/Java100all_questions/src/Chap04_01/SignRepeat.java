/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-1
 * 読み込んだ整数値の符号を判定して表示するChap03_05（Sign.java）を、好きなだけ何度でも繰り返して入力・表示できるように
 * プログラムを作成せよ。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 整数値：12
 * その値は正です。
 * もう一度？1…Yes/0…No：1
 * 整数値：-531
 * その値は負です。
 * もう一度？1…Yes/0…No：0
 *
 * @author SystemShared
 */

package
Chap04_01;

class SignRepeat {

	public static void main(String[] args){

	}
}