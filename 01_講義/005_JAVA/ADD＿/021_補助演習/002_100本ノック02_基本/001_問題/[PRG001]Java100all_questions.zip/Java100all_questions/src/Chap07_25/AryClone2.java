package Chap07_25;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-25 2次元配列aと同じ配列（要素数が同じで、すべての要素の値が同じ配列）を生成して返却する
 * メソッドaryClone2を作成せよ。 int[][] aryClone2(int[][] a)
 *
 * <実行例> 行列の行数 ： 2 行列の列数 ： 3 a[0][0] : 1 a[0][1] : 2 a[0][2] : 3 a[1][0] : 4
 * a[1][1] : 5 a[1][2] : 6 行列a 1 2 3 4 5 6 行列aの複製 1 2 3 4 5 6
 *
 *
 * @author System Shared
 *
 */
// 2次元配列の複製を作成
public class AryClone2 {

	// --- 2次元配列aの複製を作成して返却 ---//
	static int[][] aryClone2(int[][] a) {

	}

	// --- 行列mの全要素を表示 ---//
	static void printMatrix(int[][] m) {
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[i].length; j++) {
				System.out.print(m[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("行列の行数 ： ");
		int height = stdIn.nextInt();
		System.out.print("行列の列数 ： ");
		int width = stdIn.nextInt();

		int[][] a = new int[height][width];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.printf("a[%d][%d] : ", i, j);
				a[i][j] = stdIn.nextInt();
			}
		}
		int[][] ca = aryClone2(a);
		System.out.println("行列a");
		printMatrix(a);
		System.out.println("行列aの複製");
		printMatrix(ca);
	}
}
