package
Chap04_13;


/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-13
 * 前問とは逆に、0から正の整数値までカウントアップするプログラムを作成せよ。
 *
 * <実行例>
 * カウントアップします。
 * 正の整数値 ： 4
 * 0
 * 1
 * 2
 * 3
 * 4
 *
 * @author System Shared
 */
// 正の整数値を0からカウトアップ
public class CountUp {
	public static void main(String[] args) {

	}

}
