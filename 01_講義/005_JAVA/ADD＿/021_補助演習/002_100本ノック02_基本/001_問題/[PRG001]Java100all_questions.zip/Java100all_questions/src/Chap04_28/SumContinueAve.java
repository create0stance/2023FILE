package Chap04_28;


/**
 * 第4章 プログラムの流れの繰返し<br>
 * 問題4-28<br>
 * キーボードから次々と整数値を読み込んで、負でない値の合計と平均を求めるプログラムを作成せよ。<br>
 * なお、読み込んだ負の数の個数は平均を求める際の分母から除外すること。<br>
 * <br>
 * <実行例><br>
 * 整数を加算します。<br>
 * 何個加算しますか ： 3<br>
 * 整数 ： 2<br>
 * 整数 ： -5<br>
 * 負の数は加算しません。<br>
 * 整数 ： 13<br>
 * 合計は15です。<br>
 * 平均は7です。<br>
 * <br>
 * @author System Shared
 */
// 読み込んだ整数を加算（負の値は加算しない）
public class SumContinueAve {
	public static void main(String[] args) {

	}
}