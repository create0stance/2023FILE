/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-3
 * 2桁の整数値(10～99)を当てさせる<<数当てゲーム>>を作成せよ。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 数当てゲーム開始！！
 * 10～99の数を当ててください。
 * いくつかな：50
 * もっと小さな値だよ。
 * いくつかな：25
 * もっと大きな値だよ。
 * いくつかな：31
 * 正解です。
 *
 * @author SystemShared
 *
 */

package 
Chap04_03;

class Kazuate2digits {

	public static void main(String[] args){
	}
}