﻿package
Chap02_15;


/**
 * 第2章 変数を使おう
 * 問題2-15
 * 住所を読み込んで、その住所を反復表示するプログラムを作成せよ。
 * 実行例に　(空白文字)が入っていることに注意。
 *
 * <実行例>
 * 住所 ： 千葉県　松戸市
 * お住まいは千葉県　松戸市ですね。
 *
 * @author System Shared
 */
public class Address {
	public static void main(String[] args) {
	}

}
