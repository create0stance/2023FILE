package
Chap04_14;


/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-14
 * 1からnまでの和を求めるプログラムをfor文で実現せよ。
 *
 * <実行例>
 * 1からnまでの和を求める。
 * nの値 ： 5
 * 1から5までの和は15です。
 *
 * @author System Shared
 */
// 1からnまでの和を求める
public class SumUpFor {
	public static void main(String[] args) {

	}
}
