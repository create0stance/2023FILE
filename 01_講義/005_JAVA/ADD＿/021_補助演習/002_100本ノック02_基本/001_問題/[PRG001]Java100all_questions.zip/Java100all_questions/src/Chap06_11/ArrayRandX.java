/**
 * 第6章 配列
 * 問題6-11
 * 連続する要素が同じ値をもつことのないように問題6-10のプログラムを改良したプログラムを作成せよ。
 * たとえば{1, 3, 5, 5, 3, 2}とならないようにすること。
 * キーボードから値を読み込むにあたりScannerクラス、乱数を生成するにあたりRandomクラスを用いよ。
 *
 * <実行例>
 * 要素数：5
 * a[0] = 7
 * a[1] = 1
 * a[2] = 5
 * a[3] = 8
 * a[4] = 9
 *
 * @author SystemShared
 */

package 
Chap06_11;

class ArrayRandX {

	public static void main(String[] args) {

	}
}