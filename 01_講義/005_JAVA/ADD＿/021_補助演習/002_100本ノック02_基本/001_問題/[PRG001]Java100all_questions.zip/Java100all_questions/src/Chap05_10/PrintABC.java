/**
 * 第5章 基本型と演算
 * 問題5-10
 * "ABC\n"と表示するプログラムを作成せよ。（二重引用符などの記号文字も表示すること）。
 *
 * <実行例>
 * "ABC\n"
 *
 * @author System Shared
 */

package
Chap05_10;

class PrintABC {

	public static void main(String[] args) {

	}
}
