/**
 * 第7章 メソッド
 * 問題7-6
 * 引数mで指定された月の季節を表示するメソッドprintSeasonを作成せよ。
 * mが3,4,5であれば『春』、6,7,8であれば『夏』、9,10,11であれば『秋』、12,1,2であれば『冬』と表示し、それ以外の値であれば何も表示しないこと。
 * void printSeason(int m)
 *
 * ＜実行例1＞
 * 何月ですか(1～12)：8
 * その月の季節は夏です。
 *
 * ＜実行例2＞
 * 何月ですか(1～12)：12
 * その月の季節は冬です。
 *
 * @author SystemShared
 */

package
Chap07_06;

import java.util.Scanner;

//指定された月の季節を表示するメソッド
class PrintSeason {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		int month;
		do {
			System.out.print("何月ですか(1～12)：");
			month = stdIn.nextInt();
		} while (month < 1 || month > 12);

		System.out.print("その月の季節は");
		printSeason(month);
		System.out.print("です。");
	}
}