/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-5
 * キーボードから読み込んだ整数値から0までのカウントダウンを表示するプログラムを作成せよ。
 * カウントダウン終了後の変数の値を確認できるようにすること。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * カウントダウンします。
 * 正の整数値：-3
 * 正の整数値：5
 * 5
 * 4
 * 3
 * 2
 * 1
 * 0
 * xの値は-1になりました。
 *
 * @author SystemShared
 */

package 
Chap04_05;

class CountDown1 {

	public static void main(String[] args){
	}
}