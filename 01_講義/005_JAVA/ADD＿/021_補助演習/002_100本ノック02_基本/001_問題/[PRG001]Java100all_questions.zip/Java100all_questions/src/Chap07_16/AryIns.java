package Chap07_16;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-16 配列aの要素a[idx]にxを挿入するメソッドaryInsを作成せよ。 void aryIns(int[] a, int
 * idx, int x) 挿入に伴っa[idx]～a[a.length - 2]を一つ後方へずらさなければならない。 【例】配列aの要素が{1, 3, 4,
 * 7, 9, 11}のときにaryIns{a, 2, 99}と呼び出した後の配列aの要素 は{1, 3, 99, 4, 7, 9}となる。
 *
 * <実行例> 要素数 ： 6 a[0] : 1 a[1] : 3 a[2] : 4 a[3] : 7 a[4] : 9 a[5] : 11
 * 挿入する要素のインデックス : 2 挿入する値 ： 99 a[0] = 1 a[1] = 3 a[2] = 99 a[3] = 4 a[4] = 7
 * a[5] = 9
 *
 * @author System Shared
 *
 */
// 配列からへ要素の挿入
public class AryIns {
	// --- 配列aからa[idx]をxを挿入（以降の要素を後方へずらす） ---//
	static void aryRmvN(int[] a, int idx, int x) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] a = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("a[" + i + "] : ");
			a[i] = stdIn.nextInt();
		}
		System.out.print("挿入する要素のインデックス : ");
		int idx = stdIn.nextInt();

		System.out.print("挿入する値 ： ");
		int x = stdIn.nextInt();

		aryRmvN(a, idx, x); // 配列aのa[idx]にxを挿入

		for (int i = 0; i < num; i++) { // 配列aを表示
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}