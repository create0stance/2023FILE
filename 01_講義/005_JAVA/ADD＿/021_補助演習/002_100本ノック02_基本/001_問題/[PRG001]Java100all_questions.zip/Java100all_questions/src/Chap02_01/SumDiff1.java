/**
 * 第2章 変数を使おう
 * 問題2-1
 * 二つの整数値82と17の和と差を表示するプログラムを作成せよ（いろいろな表示方法を試してみること）。
 *
 * <実行例>
 * 99
 * 65
 *
 * @author SystemShared
 */

package 
Chap02_01;

public class SumDiff1 {
   public static void main(String[] args) {

   }
}