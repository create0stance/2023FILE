/**
 * 第6章 配列
 * 問題6-14
 * 配列aの全要素を配列bに対して逆順にコピーするプログラムを作成せよ。
 * なお、二つの配列の要素数は同一であると仮定してよい。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 要素数：3
 * a[0] = 1
 * a[1] = 4
 * a[2] = 9
 * aの全要素を逆順にbにコピーしました。
 * b[0] = 9
 * b[1] = 4
 * b[2] = 1
 *
 * @author SystemShared
 */

package 
Chap06_14;

class CopyArrayReverse {

	public static void main(String[] args) {

	}
}