﻿/**
 * 二つの整数値82と17の和と差を求めて表示（演算結果のみを表示）
 *
 * <実行例>
 * 82 + 17 = 99
 * 82 - 17 = 65
 *
 * @author SystemShared
 */

package 
Chap02_01;

class SumDiff2 {

	public static void main(String[] args) {

	}
}