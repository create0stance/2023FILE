package Chap07_11;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-11 配列aの全要素の合計を求めるメソッドsumOfを作成せよ。 int sumOf(int[] a)
 *
 * <実行例> 要素数 ： 5 x[0] : 22 x[1] : 5 x[2] : 11 x[3] : 32 x[4] : 120 全要素の合計は190です。
 *
 *
 * @author System Shared
 *
 */
// 配列の全要素の合計を求める（その１：基本for文）
public class SumOf1 {

	// --- 配列aの全要素の合計を求める ---//
	static int sumOf(int[] a) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] x = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("x[" + i + "] : ");
			x[i] = stdIn.nextInt();
		}
		System.out.println("全要素の合計は" + sumOf(x) + "です。");
	}
}