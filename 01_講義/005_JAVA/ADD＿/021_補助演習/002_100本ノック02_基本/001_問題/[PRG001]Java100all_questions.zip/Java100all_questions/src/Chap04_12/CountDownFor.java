package
Chap04_12;


/**
 *
 * 第4章 プログラムの流れの繰返し
 * 問題4-12
 * 正の整数値を0までカウントダウンするChap04_05(CountDown1.java)を（for文かwhile文）まだ作成していないほうの文を使って
 * 実現せよ（ただし、繰り返し終了後の変数xの値は表示しなくてもよい）。
 *
 * <実行例>
 * カウントダウンします。
 * 正の整数値 ： 4
 * 4
 * 3
 * 2
 * 1
 * 0
 *
 * @author System Shared
 */
// 正の整数値を0までカウントダウン（for文）
public class CountDownFor {
	public static void main(String[] args) {

	}
}
