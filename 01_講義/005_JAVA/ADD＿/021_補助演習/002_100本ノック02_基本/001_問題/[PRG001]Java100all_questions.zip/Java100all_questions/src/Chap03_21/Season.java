/**
 * 第3章 プログラムの流れの分岐
 * 問題3-21
 * 月を１～１２の整数値として読み込んで、それに対応する季節を表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 何月ですか：5
 * 春
 *
 * @author SystemShared *
 */

package 
Chap03_21;

class Season {

	public static void main(String[] args) {

	}
}