/**
 * 第7章 メソッド
 * 問題7-7
 * 文字cをn個表示するメソッドputCharsと、そのメソッドを内部で呼び出して文字'*'をn個だけ連続表示するメソッドputStarsを作成せよ。
 * さらに、それらのメソッドを利用して直角三角形を表示するプログラムを作成せよ。
 *
 * ＜実行例＞
 * 左下直角の三角形を表示します。
 * 段数は：5
 * *
 * **
 * ***
 * ****
 * *****
 *
 * @author SystemShared
 */

package 
Chap07_07;

import java.util.Scanner;

//左下が直角の直角三角形を表示
class IsoscelesTriangleLB {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("左下直角の三角形を表示します。");
		System.out.print("段数は：");
		int n = stdIn.nextInt();

		for (int i = 1; i <= n; i++) {
			putStars(i);
			System.out.println();
		}
	}
}