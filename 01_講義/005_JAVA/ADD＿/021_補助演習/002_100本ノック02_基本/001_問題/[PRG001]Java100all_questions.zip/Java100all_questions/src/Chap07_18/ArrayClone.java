package Chap07_18;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-18 配列aと同じ配列（要素数が同じで、すべての要素の値が同じ配列）を生成して返却するメソッド arrayCloneを作成せよ。
 * int[] arrayClone(int[] a)
 *
 * <実行例> 要素数 ： 5 x[0] : 10 x[1] : 20 x[2] : 30 x[3] : 40 x[4] : 50
 * 配列xの複製yを作りました。 y[0] = 10 y[1] = 20 y[2] = 30 y[3] = 40 y[4] = 50
 *
 * @author System Shared
 *
 */
// 配列の複製を作成
public class ArrayClone {

	// --- 配列aの複製を作成して返却 ---//
	static int[] arrayClone(int[] a) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();

		int[] x = new int[num]; // 要素numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("x[" + i + "] : ");
			x[i] = stdIn.nextInt();
		}
		int[] y = arrayClone(x); // 配列xの複製
		System.out.println("配列xの複製yを作りました。");
		for (int i = 0; i < num; i++) { // 配列yを表示
			System.out.println("y[" + i + "] = " + y[i]);
		}
	}
}
