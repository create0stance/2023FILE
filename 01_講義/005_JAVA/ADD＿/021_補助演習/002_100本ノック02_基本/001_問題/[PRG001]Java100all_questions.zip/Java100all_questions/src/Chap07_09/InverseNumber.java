/**
 * 第7章 メソッド
 * 問題7-9
 * 『正の整数値：』と表示してキーボードから正の整数値を読み込んで、その値を返却するメソッドreadPlusIntを作成せよ。
 * 0や負の値が入力されたら再入力させること。ただし入力にはScannerクラスを用いる事。
 * int readPlusInt()
 *
 * ＜実行例＞
 * 正の整数値：56
 * 逆から読むと65です。
 * もう一度？<Yes…1/No…0>：1
 * 正の整数値：92
 * 逆から読むと29です。
 * もう一度？<Yes…1/No…0>：0
 *
 * @author SystemShared
 */

package
Chap07_09;

import java.util.Scanner;

//正の整数値を逆から読み込んで表示
class InverseNumber {

	public static void main(String[] args) {
		int x;
		Scanner stdIn = new Scanner(System.in);
		do {
			int n = readPlusInt();

			System.out.print("逆から読むと");
			while (n > 0) {
				System.out.print(n % 10); //nの最下位桁を表示
				n /= 10; //nを10で割る
			}
			System.out.println("です。");

			do {
				System.out.print("もう一度？<Yes…1/No…0>：");
				x = stdIn.nextInt();
			} while (x != 0 && x != 1);
		} while (x == 1);
	}
}