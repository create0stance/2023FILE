package
Chap04_06;
/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-6
 * 前回のCountDown2のx--が--xになっていたら、どのような出力が得られるか検討せよ。
 * プログラムを作成して実行結果を確認すること。
 * @author SystemShared
 */

//正の整数値を0までカウントダウン(誤り)
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class CountDown2Pre {

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String input = "";

		System.out.println("カウントダウンします。");
		int x;
		do {
			System.out.print("正の整数値：");
			input = br.readLine();
			x = Integer.parseInt(input);
		} while (x <= 0);

		while (x >= 0)
			System.out.println(--x); //xの値を表示してデクリメント

		System.out.println("xの値は" + x + "になりました。"); //xの値を表示
	}
}