package
Chap04_11;

/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-11
 * 記号文字を任意の個数だけ出力するChap04_07（PutAsterisk1.java）をfor文で実現せよ。
 *
 * <実行例>
 * 何個*を表示しますか ： 12
 * ************
 *
 * @author System Shared
 */
// 読み込んだ個数だけ*を表示
public class PutAsteriskFor {
	public static void main(String[] args) {

	}

}
