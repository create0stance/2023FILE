/**
 * 第3章 プログラムの流れの分岐
 * 問題3-13
 * 二つの整数値を読み込んで、それらの値の差を表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数ａ：10
 * 整数ｂ：1
 * それらの差は9です。
 *
 * @author SystemShared
 */

package 
Chap03_13;

class Diff2 {

	public static void main(String[] args) {

	}
}