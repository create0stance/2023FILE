/**
 * 第1章 画面に文字を表示しよう
 * 問題1-2
 * プログラム中の文の終端を示すセミコロン;が欠如しているとどうなるか。プログラムをコンパイルして検証せよ。
 *
 * <実行例>
 * Exception in thread "main" java.lang.Error: コンパイル問題が未解決です:
 *
 * @author SystemShared
 */

package 
Chap01_02;

public class HelloError {
   public static void main(String[] args) {

   }
}