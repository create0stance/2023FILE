/**
 * 第6章 配列
 * 問題6-2
 * 要素型がint型で要素数が5の配列の要素に対して、先頭から順に5、4、3、2、1を代入して表示するプログラムを作成せよ。
 *
 * <実行例>
 * a[0] = 5
 * a[1] = 4
 * a[2] = 3
 * a[3] = 2
 * a[4] = 1
 *
 * @author SystemShared
 */

package 
Chap06_02;

class IntArrayFor {

	public static void main(String[] args) {

	}
}
