package Chap04_22;


/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-22
 * 記号文字*を並べて直角の二等辺三角形を表示するプログラムを作成せよ。直角が左下側、左上側、
 * 右下側、右上側の三角形を表示するプログラムをそれぞれ作成せよ。
 *
 * <実行例>
 * 右上直角の二等辺三角形を表示します。
 * 段数は ： 5
 * *****
 *  ****
 *   ***
 *    **
 *     *
 *
 *
 * @author System Shared
 */
// 右上側が直角の二等辺三角形を表示
public class IsoscelesTriangleRU {
	public static void main(String[] args) {

	}
}