/**
 * 第6章 配列
 * 問題6-6
 * 配列の要素数と、個々の要素の値を読み込んで、各要素の値を表示するプログラムを作成せよ。
 * 表示の形式は、初期化と同じ形式、すなわち、各要素の値をコンマで区切って{}で囲んだ形で表示すること。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 要素数：3
 * a[0] = 1
 * a[1] = 2
 * a[2] = 3
 * {1, 2, 3}
 *
 * @author SystemShared
 */

package
Chap06_06;

class PrintArray {

	public static void main(String[] args) {

	}
}