/**
 * 第3章 プログラムの流れの分岐
 * 問題3-4
 * 前問のプログラムを論理補数演算子！を用いて置きかえよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 変数Ａ：8
 * 変数Ｂ：4
 * ＢはＡの約数です。
 *
 * @author SystemShared
 */

package 
Chap03_04;

class Measure2 {

	public static void main(String[] args) {

	}
}