package
Chap02_14;

import java.util.Scanner;

/**
 * 第2章 変数を使おう
 * 問題2-14
 * 名前の姓と名とを個別のキーボードから読み込んで、挨拶を行うプログラムを作成せよ。
 * この問題で、キーボードから読み込む値は「文字列」であることに注意せよ。
 *
 * <実行例>
 * 姓 ： 電子
 * 名 ： 太郎
 * こんにちは電子太郎さん。
 *
 * @author System Shared
 */
public class Greeting {
	public static void main(String[] args) {

	}

}
