/**
 * 第6章 配列
 * 問題6-17
 * 配列変数の値を表示するプログラムを作成せよ。
 *
 * <実行例>
 * a = [I@e53108
 * a = null
 *
 * @author SystemShared
 */

package Chap06_17;

class PrintArrayVariable {

	public static void main(String[] args) {

	}
}