package Chap07_14;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-14 配列aから要素a[idx]を削除するメソッドaryRmvを作成せよ。 void aryRmv(int[] a, int
 * idx) 削除はa[idx]より後ろの全要素を一つ前方にずらすことによって行うこと。なお、移動されず にあまってしまう末尾要素a[a.length -
 * 1]の値は変更しなくてよい。
 * 【例】配列aの要素が{1, 3, 4, 7, 9, 11}のときにaryRmvN{a, 2}と呼び出した後の配列aの要素 は{1, 3, 7, 9,11, 11}となる
 *
 * <実行例> 要素数 ： 6 a[0] : 1 a[1] : 3 a[2] : 4 a[3] : 7 a[4] : 9 a[5] : 11
 * 削除する要素のインデックス : 2 a[0] = 1 a[1] = 3 a[2] = 7 a[3] = 9 a[4] = 11 a[5] = 11
 *
 * @author System Shared
 *
 */
// 配列からの要素の削除
public class AryRmv {
	// --- 配列aからa[idx]を削除（以降の要素を前方へずらす） ---//
	static void aryRmv(int[] a, int idx) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] a = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("a[" + i + "] : ");
			a[i] = stdIn.nextInt();
		}
		System.out.print("削除する要素のインデックス : ");
		int idx = stdIn.nextInt();

		aryRmv(a, idx); // 配列aからa[idx]を削除

		for (int i = 0; i < num; i++) { // 配列aを表示
			System.out.println("a[" + i + "] = " + a[i]);
		}
	}
}