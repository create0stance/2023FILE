package Chap07_23;

/**
 * 第7章 メソッド
 * 問題7-23
 * 行列xとyの和を求めてzに格納するメソッドaddMatrixを作成せよ。
 * boolen addMatrix(int[][] x, int[][] y, int[][] z)
 * 三つの配列の要素数が等しければ加算を行ってtrueを返し、等しくなければ加算を行わずに
 * falseを返すこと。
 *
 * <実行例>
 * 行列a
 * 1 2 3
 * 4 5 6
 *
 * 行列b
 * 6 3 4
 * 5 1 2
 *
 * 行列c
 * 7 5 7
 * 9 6 8
 *
 * @author System Shared
 *
 */
// 二つ行列の和を求める
public class AddMatrixX {

	//--- 行列xとyの和をzに代入 ---//
	static boolean addMatrix(int[][] x, int[][] y, int[][] z){

	}
	//--- 行列mの全要素を表示 ---//
	static void printMatrix(int[][] m){
		for(int i = 0; i < m.length; i++){
			for(int j = 0; j < m[i].length; j++){
				System.out.print(m[i][j] +" ");
			}
		System.out.println();
		}
	}
	public static void main(String[] args) {
			int[][] a = {{1, 2, 3},{4, 5, 6}};
			int[][] b = {{6, 3, 4},{5, 1, 2}};
			int[][] c = new int[2][3];

			if(addMatrix(a, b, c)){ // aとbの和をに代入
				System.out.println("行列a");
				printMatrix(a);
				System.out.println("\n行列b");
				printMatrix(b);
				System.out.println("\n行列c");
				printMatrix(c);
			}
	}
}