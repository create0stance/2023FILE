package Chap07_21;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-21 配列aから要素a[idx]を先頭とするn個の要素を削除した配列を返却するメソッドarrayRmvOfNを作成せよ。
 * int[] arrayRmvOfN(int[] a, int idx, int n)
 * 削除はa[idx]より後ろの全要素をn個前方にずらすことによって行うこと。 【例】配列aの要素が{1, 3, 4, 7, 9,
 * 11}のときにarrayRmvOfN{a, 1, 3}と呼び出された場合、 返却する配列の要素は{1, 9, 11}となる。
 *
 * <実行例> 要素数 ： 6 x[0] : 1 x[1] : 3 x[2] : 4 x[3] : 7 x[4] : 9 x[5] : 11
 * 削除する要素のインデックス ： 1 削除するようおの個数 ： 3 y[0] = 1 y[1] = 9 y[2] = 11
 *
 *
 * @author System Shared
 *
 */
// 配列から連続要素を削除した配列を返却
public class ArrayRemoveOfN {
	// --- 配列aからa[idx]を先頭とするn個の要素を削除した配列を返却 ---//
	static int[] arrayRmvOfN(int[] a, int idx, int n) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] x = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("x[" + i + "] : ");
			x[i] = stdIn.nextInt();
		}
		System.out.print("削除する要素のインデックス ： ");
		int idx = stdIn.nextInt();

		System.out.print("削除するようおの個数 ： ");
		int n = stdIn.nextInt();

		// 配列xからx[idx]を先頭とするn個の要素を削除した配列を生成
		int[] y = arrayRmvOfN(x, idx, n);

		for (int i = 0; i < y.length; i++) { // 配列yを表示
			System.out.println("y[" + i + "] = " + y[i]);
		}
	}
}
