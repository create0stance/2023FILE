/**
 * 第2章 変数を使おう
 * 問題2-10
 * 球の表面積と体積を求めるプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 球の表面積と体積を求めます。
 * 半径：1
 * 表面積は12.56です。
 * 体　積は4.1866666666666665です。
 *
 * @author SystemShared
 */

package 
Chap02_10;

public class Grove {
	public static void main(String[] args){

	}

}