package 
Chap04_09;
/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-9
 * 正の整数値を読み込んで、その桁数を出力するプログラムを作成せよ。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 正の整数値の桁数を求めます。
 * 正の整数値：1254
 * その数は4桁です。
 *
 * @author SystemShared
 */

//正の整数値の桁数を求める
class DigitNo {

	public static void main(String[] args){
	}
}