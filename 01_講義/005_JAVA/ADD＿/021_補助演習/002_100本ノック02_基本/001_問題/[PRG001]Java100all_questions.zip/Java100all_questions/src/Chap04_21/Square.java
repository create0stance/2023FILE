package
Chap04_21;


/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-21
 * 記号文字*を並べてn段の正方形を表意するプログラムを作成せよ。
 *
 * <実行例>
 * 正方形を表示します。
 * 段数は ： 3
 * ***
 * ***
 * ***
 *
 * @author System Shared
 */
// 正方形を表示
public class Square {
	public static void main(String[] args) {

	}
}
