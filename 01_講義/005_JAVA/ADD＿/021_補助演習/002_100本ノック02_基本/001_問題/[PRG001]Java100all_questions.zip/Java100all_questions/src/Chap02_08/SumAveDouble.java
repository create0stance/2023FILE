/**
 * 第2章 変数を使おう
 * 問題2-8
 * 二つの実数値を読み込み、その和と平均を求めて表示するプログラムを作成せよ。
 * なお、実数値は、小数点以下を持つ値も扱えるようにすること。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * xの値：9.75
 * yの値：2.5
 * 合計は12.25です。
 * 平均は6.125です。
 *
 * @author SystemShared
 */

package
Chap02_08;

public class SumAveDouble {
	public static void main(String[] args){

	}

}