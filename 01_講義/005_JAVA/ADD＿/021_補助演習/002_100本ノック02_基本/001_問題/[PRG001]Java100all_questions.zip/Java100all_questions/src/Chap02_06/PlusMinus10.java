/**
 * 第2章 変数を使おう
 * 問題2-6
 * キーボードから読み込んだ整数値に10を加えた値と10を減じた値を出力するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数値：100
 * 10を加えた値は110です。
 * 10を減じた値は90です。
 *
 * @author SystemShared
 */

package 
Chap02_06;

public class PlusMinus10 {
	public static void main(String[] args){

	}

}