/**
 * 第3章 プログラムの流れの分岐
 * 問題3-2
 * 整数値を読み込んで、その絶対値を求めて表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数値：-5
 * その絶対値は5です。
 *
 * @author SystemShared
 */

package 
Chap03_02;

class Absolute {

	public static void main(String[] args) {

	}
}