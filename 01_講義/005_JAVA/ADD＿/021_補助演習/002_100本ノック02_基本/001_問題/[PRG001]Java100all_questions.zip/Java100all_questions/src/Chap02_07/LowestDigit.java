/**
 * 第2章 変数を使おう
 * 問題2-7
 * キーボードから読み込んだ整数値の最下位桁を除いた値と、最下位桁を表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数値：123
 * 最下位桁を除いた値は12です。
 * 最下位桁は3です。

 *
 * @author SystemShared
 */

package 
Chap02_07;

public class LowestDigit {
	public static void main(String[] args){

	}

}