/**
 * 第5章 基本型と演算
 * 問題5-2
 * １０進整数を読み込んで、その値を８進数と１６進数で表示するプログラムを作成せよ。
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 整数：27
 * 8進数では33です。
 * 16進数では1bです。
 *
 * @author System Shared
 */

package 
Chap05_02;

class OctHex {

	public static void main(String[] args){
	}
}
