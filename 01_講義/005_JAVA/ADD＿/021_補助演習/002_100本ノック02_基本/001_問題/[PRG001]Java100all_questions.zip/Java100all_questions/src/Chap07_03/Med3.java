/**
 * 第7章 メソッド
 * 問題7-3
 * 三つのint型a,b,cの中央値を求めるメソッドmedを作成せよ。
 * int med(int a, int b, int c)
 *
 * ＜実行例＞
 * 整数a：1
 * 整数b：3
 * 整数c：2
 * 中央値は2です。
 *
 * @author SystemShared
 */

package
Chap07_03;

import java.util.Scanner;

//三つの整数値の中央値を求める
class Med3 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数a：");
		int a = stdIn.nextInt();
		System.out.print("整数b：");
		int b = stdIn.nextInt();
		System.out.print("整数c：");
		int c = stdIn.nextInt();

		System.out.println("中央値は" + med3(a, b, c) + "です。");
	}
}