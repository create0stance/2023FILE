/**
 * 第2章 変数を使おう
 * 問題2-5
 * キーボードから読み込んだ整数値をそのまま反復して表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 *
 * <実行例>
 * 整数値：100
 * 100と入力しましたね。
 *
 * @author SystemShared
 */

package
Chap02_05;

import java.util.Scanner;

public class ScanInteger {
	public static void main(String[] args){

		// Sannerクラスを使用する
		Scanner stdIn = new Scanner(System.in);

		System.out.print("整数値：");
		// ヒント：stdIn.nextInt()で値を読み込み、変数に代入する

	}
}