package
Chap04_19;


/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-19
 * 1からnまでの整数値の2乗値を表示するプログラムを作成せよ。（nの値は読み込むこと）
 *
 * <実行例>
 * nの値 ： 3
 * 1の2乗は1
 * 2の2乗は4
 * 3の2乗は9
 *
 * @author System Shared
 */
// 整数値の2乗値を表示（その１）
public class Square {
	public static void main(String[] args) {

	}
}
