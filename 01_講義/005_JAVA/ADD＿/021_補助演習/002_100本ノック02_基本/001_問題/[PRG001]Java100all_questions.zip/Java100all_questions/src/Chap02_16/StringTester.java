package Chap02_16;
/**
 * 第2章 変数を使おう
 * 問題2-15
 * String型の変数を文字列で初期化したり、変数に文字列を代入したりするプログラムを作成せよ。
 *
 * <実行例>
 * 文字列s1はABCです。
 * 文字列s2はXYZです。
 * 文字列s1はFBIです。
 * 文字列s2はXYZです。
 *
 * @author System Shared
 */
public class StringTester {
	public static void main(String[] args) {

	}

}
