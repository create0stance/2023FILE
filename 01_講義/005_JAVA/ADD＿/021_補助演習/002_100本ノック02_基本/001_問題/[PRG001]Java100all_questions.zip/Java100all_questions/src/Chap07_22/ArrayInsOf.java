package Chap07_22;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-22 配列aの要素a[idx]にxを挿入し配列を返却するメソッドarrayInsOfを作成せよ。 int[]
 * arrayInsOf(int[] a, int idx, int x) 挿入い伴ってa[idx]以降の全要素を一つ後方にずらすこと。
 * 【例】たとえば配列aの要素が{1, 3, 4, 7, 9, 11}のときにarrayInsOf{a, 2, 99}と呼び出され
 * た場合、返却する配列の要素は{1, 3, 99, 4, 7, 9, 11}となる。
 * 
 * <実行例> 要素数 ： 6 x[0] : 1 x[1] : 3 x[2] : 4 x[3] : 7 x[4] : 9 x[5] : 11
 * 挿入するインデックス ： 2 挿入する値 ： 99 y[0] = 1 y[1] = 3 y[2] = 99 y[3] = 4 y[4] = 7 y[5]
 * = 9 y[6] = 11
 * 
 * 
 * @author System Shared
 * 
 */
// 配列に要素を挿入した配列を返却
public class ArrayInsOf {
	// --- 配列aのa[idx]にxを挿入した配列を返却 ---//
	static int[] arrayInsOf(int[] a, int idx, int x) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] x = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("x[" + i + "] : ");
			x[i] = stdIn.nextInt();
		}
		System.out.print("挿入するインデックス ： ");
		int idx = stdIn.nextInt();

		System.out.print("挿入する値 ： ");
		int n = stdIn.nextInt();

		// 配列xのx[idx]にを挿入した配列を生成
		int[] y = arrayInsOf(x, idx, n);

		for (int i = 0; i < y.length; i++) { // 配列yを表示
			System.out.println("y[" + i + "] = " + y[i]);
		}
	}
}
