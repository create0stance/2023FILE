/**
 * 第5章 基本型と演算
 * 問題5-7
 * int型変数に対して実数値(10.312)を代入して、その値を表示するプログラムを作成せよ。
 *
 * <実行例>
 * a = 10
 *
 * @author System Shared
 *
 */

package 
Chap05_07;

class FloatToInteger {

	public static void main(String[] args) {
	}
}
