package Chap07_17;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-17 配列aと配列bの全要素の値を交換するメソッドaryExchngを作成せよ。 void aryExchng(int[] a,
 * int[] b) 二つの配列の要素数が等しくない場合は、小さいほうの要素数分の要素を交換すること。 【例】配列aの要素が{1, 2, 3, 4, 5,
 * 6, 7}で、配列bの要素が{5, 4, 3, 2, 1}のときに、 aryExchng(a, b)と呼び出した後で、配列aは{5, 4, 3, 2,
 * 1, 6, 7}となり、配列bは{1, 2, 3, 4, 5}とならなければならない。
 *
 * <実行例> 配列aの要素数 ： 7 a[0] : 1 a[1] : 2 a[2] : 3 a[3] : 4 a[4] : 5 a[5] : 6 a[6]
 * : 7 配列bの要素数 ： 5 b[0] : 5 b[1] : 4 b[2] : 3 b[3] : 2 b[4] : 1
 * 配列aとbの全要素を交換しました。 a[0] = 5 a[1] = 4 a[2] = 3 a[3] = 2 a[4] = 1 a[5] = 6 a[6]
 * = 7 b[0] = 1 b[1] = 2 b[2] = 3 b[3] = 4 b[4] = 5
 *
 *
 * @author System Shared
 *
 */
// 二つの配列の全要素の値を交換
public class AryExchng {

	// --- 配列aとbの全要素の値を交換 ---//
	static void aryExchng(int[] a, int[] b) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("配列aの要素数 ： ");
		int na = stdIn.nextInt(); // 配列aの要素数

		int[] a = new int[na]; // 要素naの配列

		for (int i = 0; i < na; i++) {
			System.out.print("a[" + i + "] : ");
			a[i] = stdIn.nextInt();
		}
		System.out.print("配列bの要素数 ： ");
		int nb = stdIn.nextInt(); // 配列aの要素数

		int[] b = new int[nb]; // 要素nbの配列

		for (int i = 0; i < nb; i++) {
			System.out.print("b[" + i + "] : ");
			b[i] = stdIn.nextInt();
		}
		aryExchng(a, b);

		System.out.println("配列aとbの全要素を交換しました。");
		for (int i = 0; i < na; i++) { // 配列aを表示
			System.out.println("a[" + i + "] = " + a[i]);
		}
		for (int i = 0; i < nb; i++) { // 配列bを表示
			System.out.println("b[" + i + "] = " + b[i]);
		}
	}
}
