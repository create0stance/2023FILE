/**
 * 第6章 配列
 * 問題6-5
 * 要素数5のint型配列の各要素を先頭から順に5、4、3、2、1で初期化して表示するプログラムを作成せよ。
 *
 * <実行例>
 * a[0] = 5
 * a[1] = 4
 * a[2] = 3
 * a[3] = 2
 * a[4] = 1
 *
 * @author SystemShared
 */

package 
Chap06_05;

class IntArray54321 {

	public static void main(String[] args) {

	}
}
