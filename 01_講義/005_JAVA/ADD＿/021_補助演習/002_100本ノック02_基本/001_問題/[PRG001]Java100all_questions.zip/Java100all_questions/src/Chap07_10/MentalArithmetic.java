package
Chap07_10;
import java.util.Random;
import java.util.Scanner;
/**
 * 第7章 メソッド
 * 問題7-10
 * 以下の四つの問題をランダムに出題する3桁の整数の暗算トレーニングプログラムを作成せよ。
 * ただし入力にはScannerクラスを用いる事。
 *  x + y + z
 *  x + y - z
 *  x - y + z
 *  x - y - z
 *
 * ＜実行例＞
 * 暗算力トレーニング！！
 * 525 + 637 - 909 = 253
 * もう一度？<Yes…1/No…0>：1
 * 530 - 973 - 457 = 241
 * 違いますよ！！
 * 530 - 973 - 457 = -900
 * もう一度？<Yes…1/No…0>：0
 *
 * @author SystemShared
 */

//暗算力トレーニング(3桁の整数の加減算)
class MentalArithmetic {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);
		System.out.println("暗算力トレーニング！！");
		do {
			int x = rand.nextInt(900) + 100; //3桁の数
			int y = rand.nextInt(900) + 100; //3桁の数
			int z = rand.nextInt(900) + 100; //3桁の数
			int pattern = rand.nextInt(4); //パターン番号

			int kotae;
			switch (pattern) {
			case 0:
				kotae = x + y + z;
				break;
			case 1:
				kotae = x + y - z;
				break;
			case 2:
				kotae = x - y + z;
				break;
			default:
				kotae = x - y - z;
				break;
			}

			while (true) {
				System.out.print(x + ((pattern < 2) ? " + " : " - ") + y + ((pattern % 2 == 0) ? " + " : " - ") + z + " = ");
				int k = stdIn.nextInt(); //解答を読み込む
				if (k == kotae)
					break;
				System.out.println("違いますよ！！");
			}
		} while (confirmRetry());
	}
}