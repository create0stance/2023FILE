/**
 * 第5章 基本型と演算
 * 問題5-5
 * 三つの整数値を読み込んで、その合計と平均を表示するプログラムを作成せよ。
 * 平均は実数として表示すること
 * 入力値はBufferedReaderを使って取得せよ。
 *
 * <実行例>
 * 整数値xとyとxの平均値を求めます。
 * xの値：7
 * yの値：8
 * zの値：10
 * xとyとzの平均値は8.333です。
 *
 * @author System Shared
 */

package 
Chap05_05;

class Average3A {

	public static void main(String[] args){
	}
}
