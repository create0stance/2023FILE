/**
 * 第6章 配列
 * 問題6-16
 * 曜日を表示して、その英語表現を入力させる英単語学習プログラムを作成せよ。
 * ・出題する曜日は乱数で生成する。
 * ・学習者が望む限り、何度も繰り返せる。
 * ・同一曜日を連続して出題しない。
 * キーボードから値を読み込むにあたりScannerクラス、乱数を生成するにあたりRandomクラスを用いよ。
 *
 * <実行例>
 * 英語の曜日名を小文字で入力してください。
 * 月曜日：sunday
 * 違います。月曜日：monday
 * 正解です。もう一度？1…Yes/2…No：
 *
 * @author SystemShared
 */

package 
Chap06_16;

class DayCAI1 {

	public static void main(String[] args) {

	}
}