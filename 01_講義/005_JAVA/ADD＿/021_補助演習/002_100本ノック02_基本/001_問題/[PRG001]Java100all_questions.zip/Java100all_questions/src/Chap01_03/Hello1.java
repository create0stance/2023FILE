/**
 * 第1章 画面に文字を表示しよう
 * 問題1-3
 * 『初めてのJavaプログラム。』と『画面に出力しています。』を、改行することなく連続して表示するプログラムを作成せよ。
 *
 * <実行例>
 * 初めてのJavaプログラム。画面に出力しています。
 *
 * @author SystemShared
 */

package 
Chap01_03;

public class Hello1 {
   public static void main(String[] args) {

   }
}
