/**
 * 第7章 メソッド
 * 問題7-4
 * 1からnまでの全整数の和を求めて返却するメソッドを作成する。
 * int umUp(int n)
 *
 * ＜実行例＞
 * 1からxまでの和を求めます。
 * xの値：10
 * 1から10までの和は55です。
 *
 * @author SystemShared
 */

package 
Chap07_04;

import java.util.Scanner;

//1からnまでの和を求める(その1)
class SumUp {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("1からxまでの和を求めます。");
		int x;
		do {
			System.out.print("xの値：");
			x = stdIn.nextInt();
		} while (x <= 0);
		System.out.println("1から" + x + "までの和は" + sumUp(x) + "です。");
	}
}
