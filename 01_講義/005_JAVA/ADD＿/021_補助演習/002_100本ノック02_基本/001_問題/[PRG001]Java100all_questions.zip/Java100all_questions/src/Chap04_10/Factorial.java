package 
Chap04_10;
/**
 * 第4章 プログラムの流れの繰返し
 * 問題4-10
 * 正の整数値nを読み込んで、1からnまでの積を求めるプログラムを作成せよ。
 * 入力値はBufferedReaderを使って取得すること
 *
 * <実行例>
 * 正の整数値：5
 * 1から5までの積は120です。
 *
 * @author SystemShared
 */

class Factorial {

	public static void main(String[] args){
	}
}