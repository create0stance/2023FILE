/**
 * 第2章 変数を使おう
 * 問題2-9
 * 三角形の底辺と高さを読み込んで、その面積を表示するプログラムを作成せよ。
 * なお、実数値は、小数点以下を持つ値も扱えるようにすること。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 三角形の面積を求めます。
 * 底辺：12.0
 * 高さ：3.0
 * 面積は18.0です。
 *
 * @author SystemShared
 */

package
Chap02_09;

public class Triangle {
	public static void main(String[] args){

	}

}