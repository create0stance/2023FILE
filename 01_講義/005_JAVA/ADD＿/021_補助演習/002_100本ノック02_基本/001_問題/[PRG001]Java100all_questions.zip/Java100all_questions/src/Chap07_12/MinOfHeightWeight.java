package Chap07_12;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-12 配列aの要素の最小値を求めるメソッドminOfを作成せよ。 int minOf(int[] a)
 * 
 * <実行例> 人数は ： 4 4人の身長と体重を入力せよ。 1番目の身長 ： 175 1番目の体重 ： 72 2番目の身長 ： 163 2番目の体重 ：
 * 82 3番目の身長 ： 150 3番目の体重 ： 49 4番目の身長 ： 181 4番目の体重 ： 76 最も背が低い人の身長 ： 150cm
 * 最も痩せている人の体重 ： 49kg
 * 
 * @author System Shared
 * 
 */
// 最も背が低い人の身長と最も痩せている人の体重を求める。
public class MinOfHeightWeight {

	// --- 配列aの最小値を求めて返却 ---//
	static int minOf(int[] a) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.print("人数は ： "); // 人数を読み込む
		int ninzu = stdIn.nextInt();

		int[] height = new int[ninzu]; // 身長用の配列を生成
		int[] weight = new int[ninzu]; // 体重用の配列を生成

		System.out.println(ninzu + "人の身長と体重を入力せよ。");

		for (int i = 0; i < ninzu; i++) {
			System.out.print((i + 1) + "番目の身長 ： ");
			height[i] = stdIn.nextInt();
			System.out.print((i + 1) + "番目の体重 ： ");
			weight[i] = stdIn.nextInt();
		}
		System.out.println("最も背が低い人の身長    ： " + minOf(height) + "cm");
		System.out.println("最も痩せている人の体重 ： " + minOf(weight) + "kg");
	}
}