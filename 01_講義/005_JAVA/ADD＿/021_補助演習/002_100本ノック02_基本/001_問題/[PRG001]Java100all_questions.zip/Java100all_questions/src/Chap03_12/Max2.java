/**
 * 第3章 プログラムの流れの分岐
 * 問題3-12
 * 二つの実数値を読み込んで、大きいほうの値を表示するプログラムを作成せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 実数ａ:1.0
 * 実数ｂ:3.0
 * 大きいほうの値は3.0です。
 *
 * @author SystemShared
 */

package
Chap03_12;

class Max2 {

	public static void main(String[] args) {

	}
}
