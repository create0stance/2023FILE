/**
 * 第1章 画面に文字を表示しよう
 * 問題1-4
 * 各行に1文字ずつ自分の名前を表示するプログラムを作成せよ。
 *
 * <実行例>
 * 電
 * 子
 * 太
 * 郎
 *
 * @author SystemShared
 */

package 
Chap01_04;

public class PrintName1 {
   public static void main(String[] args) {

   }
}