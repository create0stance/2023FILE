/**
 * 第3章 プログラムの流れの分岐
 * 問題3-6
 * 前問のプログラムの最後のelseを、else if (n == 0)に変更したらどうなるかを検証せよ。
 * キーボードから値を読み込むにあたりScannerクラスを用いよ。
 *
 * <実行例>
 * 整数値：-1
 * その値は負です。
 *
 * @author SystemShared
 */

package 
Chap03_06;

class Sign1 {

	public static void main(String[] args) {

	}
}
