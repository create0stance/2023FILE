package Chap07_20;

import java.util.Scanner;

/**
 * 第7章 メソッド 問題7-20 配列aから要素a[idx]を削除した配列を返却するメソッドarrayRmvOfを作成せよ。 int[]
 * arrayRmvOf(int[] a, int idx) 削除はa[idx]より後ろの全要素を一つ前方にずらすことによって行うこと。
 * 【例】配列aの要素が{1, 3, 4, 7, 9, 11}のときにarrayRmvOf{a, 2}と呼び出された場合、 返却する配列の要素は{1, 3,
 * 7, 9, 11}となる。
 *
 * <実行例> 要素数 ： 6 x[0] : 1 x[1] : 3 x[2] : 4 x[3] : 7 x[4] : 9 x[5] : 11
 * 削除する要素のインデックス ： 2 y[0] = 1 y[1] = 3 y[2] = 7 y[3] = 9 y[4] = 11
 *
 *
 * @author System Shared
 *
 */
// 配列から要素を削除した配列を返却
public class ArrayRemoveOf {
	// --- 配列aからa[idx]を削除した配列を返却 ---//
	static int[] arrayRmvOf(int[] a, int idx) {

	}

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		System.out.print("要素数 ： ");
		int num = stdIn.nextInt();
		int[] x = new int[num]; // 要素数numの配列

		for (int i = 0; i < num; i++) {
			System.out.print("x[" + i + "] : ");
			x[i] = stdIn.nextInt();
		}
		System.out.print("削除する要素のインデックス ： ");
		int idx = stdIn.nextInt();

		int[] y = arrayRmvOf(x, idx); // 配列xからx[idx]を削除した配列を生成

		for (int i = 0; i < y.length; i++) {
			System.out.println("y[" + i + "] = " + y[i]);
		}
	}
}
