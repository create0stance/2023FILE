/**
 * 第2章 変数を使おう
 * 問題2-4
 * 三つのint型変数に値を代入し、合計と平均を求めるプログラムを作成せよ。
 *
 * <実行例>
 * xの値は63です。
 * yの値は18です。
 * zの値は52です。
 * 合計は133です。
 * 平均は44です。
 *
 * @author SystemShared
 */

package
Chap02_04;

public class SumAve3 {
   public static void main(String[] args){

   }
}