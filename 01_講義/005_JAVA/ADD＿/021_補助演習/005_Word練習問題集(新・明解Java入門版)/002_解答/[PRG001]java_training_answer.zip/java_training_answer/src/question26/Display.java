package question26;

public class Display extends Question26_1{

	void show(){
		System.out.println("馬には乗ってみよ人には添うてみよ");
	}

}
