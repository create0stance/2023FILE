package question20;


public class Question20_1 {

    /** 整数格納用 */
	private int num = 0;

	/** 小数点付き数値格納用*/
	private double sum = 0.0;

	/**
	 * 整数を設定する
	 *
	 * @param num 整数
	 */
	public void setNum(int num) {
		this.num = num;
	}

	/**
	 * 設定された整数を返す
	 *
	 * @return 整数
	 */
	public int getNum() {
		return num;
	}

	/**
	 * 小数点付き数値を設定する
	 *
	 * @param sum 小数点付き数値
	 */
	public void setSum(double sum) {
		this.sum = sum;
	}

	/**
	 * 小数点付き数値を返す
	 *
	 * @return 小数点付き数値
	 */
	public double getSum() {
		return sum;
	}
}
