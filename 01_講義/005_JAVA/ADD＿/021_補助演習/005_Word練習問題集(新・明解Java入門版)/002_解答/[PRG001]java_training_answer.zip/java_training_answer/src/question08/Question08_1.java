package question08;

public class Question08_1 {
	public static void main(String[] args) {

		int number = 10;

		if (number >= 10) {
			System.out.println("numberの値は10以上です");
		}

		System.out.println("処理を終了します");
	}
}
