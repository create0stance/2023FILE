package question27;

public interface Question27_1 {
	void display();

}
