package question14;

public class Dog {
    String name;
    int age;
    String favoriteFood;

    void setName(String name) {
        this.name =  name;
    }

    void setProfile(int age, String favoriteFood) {
        this.age = age;
        this.favoriteFood = favoriteFood;
    }

    void show() {
        System.out.println("名前は" + this.name + "です");
    }

    void profile() {
        System.out.println("年齢は" + this.age + "歳です");
        System.out.println("好きな食べ物は" + this.favoriteFood + "です");
    }
}
