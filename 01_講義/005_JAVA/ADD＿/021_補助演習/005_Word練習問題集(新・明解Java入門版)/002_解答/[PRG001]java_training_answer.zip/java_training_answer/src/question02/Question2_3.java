package question02;

public class Question2_3 {
	public static void main(String[] args) {

		System.out.print("出力の練習　");
		System.out.println("３回目");
		System.out.println("出力を終了します");

	}
}
