package question25;

public class Question25_3 {
	public static void main(String[] args) {

		String str = new String("エリマキトカゲ");

		if ("エリマキトカゲ".equals(str)) {
			System.out.println("エリマキトカゲは人気があります");
		}

	}
}
