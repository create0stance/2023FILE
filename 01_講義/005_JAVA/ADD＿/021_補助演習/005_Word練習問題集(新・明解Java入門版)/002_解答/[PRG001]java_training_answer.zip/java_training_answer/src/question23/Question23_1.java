package question23;

public class Question23_1 extends Inheritance {

}