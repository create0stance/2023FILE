package question28;

public class TestException {

    void inputArray(int[] array, int index, int num) throws Question28_3 {

        try{
            array[index] = num;
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new Question28_3();
        }
    }

}
