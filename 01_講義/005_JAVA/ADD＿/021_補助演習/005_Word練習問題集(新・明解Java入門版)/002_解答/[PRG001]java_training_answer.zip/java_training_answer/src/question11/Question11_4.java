package question11;

import java.util.ArrayList;
import java.util.List;

public class Question11_4 {
	public static void main(String[] args) {

		List<String> strList = new ArrayList<>();
		strList.add("orange");
		strList.add("grape");
		strList.add("strawberry");

		for(String str : strList){
			System.out.println(str);
		}
	}
}