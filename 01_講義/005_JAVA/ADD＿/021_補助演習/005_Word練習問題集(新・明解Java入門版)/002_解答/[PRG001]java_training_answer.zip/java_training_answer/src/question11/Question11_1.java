package question11;

import java.util.ArrayList;
import java.util.List;

public class Question11_1 {
	public static void main(String[] args) {

		List<String> strList = new ArrayList<>();
		strList.add("みかん");
		strList.add("ぶどう");
		strList.add("いちご");
		
		System.out.println(strList.get(0));
		System.out.println(strList.get(1));
		System.out.println(strList.get(2));
	}
}
