package question17;

public class Question17_2 {

	private Question17_2(){
		System.out.println("コンストラクタです");
	}

}
