package question05;

public class Question05_3 {

    public static void main(String[] args) {
        int x = 12;
        double y = 1.6;
        String string = "こんにちは";
        boolean b = true;

        System.out.println(x);
        System.out.println(y);
        System.out.println(string);
        System.out.println(b);
    }
}
