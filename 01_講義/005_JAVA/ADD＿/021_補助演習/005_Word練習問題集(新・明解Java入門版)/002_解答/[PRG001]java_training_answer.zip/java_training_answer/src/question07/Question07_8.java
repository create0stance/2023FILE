package question07;

import java.io.IOException;
import java.util.Scanner;

public class Question07_8 {
    public static void main(String[] args) throws IOException {
        final double tax = 1.10;
        Scanner stdIn = new Scanner(System.in); 

        int price1 = stdIn.nextInt();
        int tax_price1 = (int) (price1 * tax);

        int price2 = stdIn.nextInt();
        int tax_price2 = (int) (price2 * tax);

        int price3 = stdIn.nextInt();
        int tax_price3 = (int) (price3 * tax);

        int sum = tax_price1 + tax_price2 + tax_price3;
        // int sum += tax_price1;
        // sum += ・・・でも可。
        System.out.println("合計" + sum + "円");
        int average = (int) sum / 3;
        System.out.println("平均" + average + "円");
        
        stdIn.close();
    }
}
