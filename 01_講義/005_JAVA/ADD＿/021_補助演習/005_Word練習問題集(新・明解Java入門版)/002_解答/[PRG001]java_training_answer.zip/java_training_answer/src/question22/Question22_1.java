package question22;

import question21.Question21_1;

public class Question22_1 {
	public static void main(String[] args) {

		Question21_1 question = new Question21_1();
		question.question1();
	}
}
