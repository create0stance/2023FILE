package question07;

import java.util.Scanner;
import java.io.IOException;

public class Question07_7 {
    public static void main(String[] args) throws IOException {
        final double tax = 1.10;
        Scanner stdIn = new Scanner(System.in);

        int price = stdIn.nextInt();
        int tax_price = (int) (price * tax);

        System.out.println("税込み" + tax_price + "円");
        
        stdIn.close();
    }
}
