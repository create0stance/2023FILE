package question17;

public class Question17_1 {

    Question17_1() {
        System.out.println("コンストラクタです");
    }

    Question17_1(String str) {
        System.out.println(str);
    }

    Question17_1(int num, String str) {
        System.out.println(num + "回目の" + str);
    }
}
