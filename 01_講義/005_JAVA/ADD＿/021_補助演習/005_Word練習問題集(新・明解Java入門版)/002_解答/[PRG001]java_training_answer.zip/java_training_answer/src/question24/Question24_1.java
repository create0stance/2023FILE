package question24;

public class Question24_1 extends Parent{

    void show(){
        System.out.println("他己紹介をします");
    }
}
