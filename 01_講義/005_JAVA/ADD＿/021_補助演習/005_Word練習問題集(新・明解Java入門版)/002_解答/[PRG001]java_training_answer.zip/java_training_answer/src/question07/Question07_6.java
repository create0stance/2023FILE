package question07;

public class Question07_6 {
	public static void main(String[] args) {

		int num1 = 5;
		int num2 = 2;
		double num3 = 2.0;

		System.out.println("num1÷num2は" + (num1 / num2) + "になります");
		System.out.println("num1÷num3は" + (num1 / num3) + "になります");
	}
}
