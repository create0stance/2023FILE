package question16;

public class Question16_3 {
	public static void main(String[] args) {

		Profile profile = new Profile();
		profile.show();
	}
}
