package question06;

import java.io.IOException;
import java.util.Scanner;

public class Question06_1 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in);

		String str = stdIn.nextLine();
		System.out.println(str + "夜の20時です");
		
		stdIn.close();
	}
}
