package question25;

public class Frog {

	public String toString() {
		String str = "井の中の蛙、大海を知らず";
		return str;
	}
}
