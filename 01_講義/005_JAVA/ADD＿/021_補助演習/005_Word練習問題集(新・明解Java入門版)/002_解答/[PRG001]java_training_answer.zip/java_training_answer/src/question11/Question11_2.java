package question11;

import java.util.ArrayList;
import java.util.List;

public class Question11_2 {
	public static void main(String[] args) {

		List<String> animal = new ArrayList<String>();
		animal.add("イヌ");
		animal.add("クマ");
		animal.add("フクロウ");

		animal.remove(1);
		
		System.out.println("動物は" + animal + "がいます。");
	}
}