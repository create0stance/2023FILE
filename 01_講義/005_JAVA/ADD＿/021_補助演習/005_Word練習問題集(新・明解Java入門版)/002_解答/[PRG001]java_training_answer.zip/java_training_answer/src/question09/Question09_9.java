package question09;

public class Question09_9 {
    public static void main(String[] args) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("＊");
            }
            System.out.println();
        }
    }
}
