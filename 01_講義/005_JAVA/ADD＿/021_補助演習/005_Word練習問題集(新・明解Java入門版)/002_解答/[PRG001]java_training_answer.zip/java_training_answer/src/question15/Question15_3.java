package question15;

public class Question15_3 {
    public static void main(String[] args) {
        Phone iPhone = new Phone();

        iPhone.tel = "08012345678";
        iPhone.mailAddress = "tanaka@tokyo.com";

        iPhone.setInfo("09098765432", "suzuki@tokyo.com");

        String tel = iPhone.getTel();
        String mailAddress = iPhone.getMail();

        System.out.println(tel);
        System.out.println(mailAddress);
    }
}
