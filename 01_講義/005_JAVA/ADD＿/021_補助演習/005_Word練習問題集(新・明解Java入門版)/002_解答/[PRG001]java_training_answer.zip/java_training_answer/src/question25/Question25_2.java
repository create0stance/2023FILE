package question25;

public class Question25_2 {
	public static void main(String[] args) {
		Frog frog1 = new Frog();
		Frog frog2 = frog1;

		if (frog1.equals(frog2)) {
			System.out.println("変数frog1と2は同じものです");
		}
	}

}
