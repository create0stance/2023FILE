package question13;

public class Question13_2 {
	public static void main(String[] args) {

		Cat cat = new Cat();

		cat.height = 52.3;
		cat.weight = 4.8;
		cat.favoriteFood = "ささみ";
		cat.profile();

	}
}
