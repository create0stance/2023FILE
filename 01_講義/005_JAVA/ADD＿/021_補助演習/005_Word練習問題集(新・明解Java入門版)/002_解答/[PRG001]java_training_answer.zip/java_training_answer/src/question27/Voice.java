package question27;

public class Voice implements Talk_1{
    public void bark() {
        System.out.println("犬が吠えました");
    }

    public void cry() {
        System.out.println("猫が鳴きました");
    }
}
