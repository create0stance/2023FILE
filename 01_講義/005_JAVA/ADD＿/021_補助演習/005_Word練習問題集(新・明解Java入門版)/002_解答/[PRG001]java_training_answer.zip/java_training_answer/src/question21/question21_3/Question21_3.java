package question21.question21_3;

public class Question21_3 {

	public void question3() {
		System.out.println("こんばんは");
	}

}
