package question23;

public class Question23_3 {
	public static void main(String[] args) {

		new Question23_1();
	}
}
