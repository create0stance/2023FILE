package question13;

public class Question13_1 {
	public static void main(String[] args) {

		Cat cat = new Cat();

		cat.name = "コタロウ";
		cat.age = 7;
		cat.show();
	}
}
