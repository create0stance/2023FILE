package question21;

public class Question21_1 {

	public void question1() {
		System.out.println("おはようございます");
	}
}
