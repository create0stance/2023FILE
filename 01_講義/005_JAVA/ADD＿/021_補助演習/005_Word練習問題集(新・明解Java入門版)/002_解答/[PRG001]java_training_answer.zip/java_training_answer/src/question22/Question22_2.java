package question22;

import question21.question21_2.Question21_2;
import question21.question21_3.Question21_3;

public class Question22_2 {
	public static void main(String[] args) {

		Question21_2 question2 = new Question21_2();
		Question21_3 question3 = new Question21_3();
		question2.question2();
		question3.question3();
	}
}
