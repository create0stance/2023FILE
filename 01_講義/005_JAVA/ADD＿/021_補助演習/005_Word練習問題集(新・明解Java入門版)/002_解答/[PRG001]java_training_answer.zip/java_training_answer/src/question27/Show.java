package question27;

public class Show implements Question27_1,Preparation {

    public void display() {
        System.out.println("インターフェイスを実装しました");
    }

	public void show(){
		System.out.println("インターフェイスを二つ実装しました");
	}

}
