package question26;

public class Question26_2 {
	public static void main(String[] args) {

		Display display = new Display();
		display.show();
	}
}
