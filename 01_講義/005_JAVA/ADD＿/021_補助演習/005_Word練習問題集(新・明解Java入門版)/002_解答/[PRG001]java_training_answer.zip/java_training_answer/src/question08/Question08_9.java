package question08;

import java.io.IOException;
import java.util.Scanner;

public class Question08_9 {
    public static void main(String[] args) throws IOException {
        System.out.println("整数を入力してください。");
        Scanner stdIn = new Scanner(System.in); 

        int num = stdIn.nextInt();

        if (num % 2 == 0) {
            System.out.println(num + "は偶数です。");
        } else {
            System.out.println(num + "は奇数です。");
        }
        
        stdIn.close();
    }
}
