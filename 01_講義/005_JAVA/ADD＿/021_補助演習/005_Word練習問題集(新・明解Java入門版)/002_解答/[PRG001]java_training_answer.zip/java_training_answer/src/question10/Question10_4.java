package question10;

public class Question10_4 {
    public static void main(String[] args) {

        int[][] num = new int[2][3];

        num[0][0] = 10;
        num[0][1] = 20;
        num[0][2] = 30;
        num[1][0] = 40;
        num[1][1] = 50;
        num[1][2] = 60;

        System.out.println("1段目の値は" + num[0][0] + "です");
        System.out.println("1段目の値は" + num[0][1] + "です");
        System.out.println("1段目の値は" + num[0][2] + "です");
        System.out.println("2段目の値は" + num[1][0] + "です");
        System.out.println("2段目の値は" + num[1][1] + "です");
        System.out.println("2段目の値は" + num[1][2] + "です");

    }
}
