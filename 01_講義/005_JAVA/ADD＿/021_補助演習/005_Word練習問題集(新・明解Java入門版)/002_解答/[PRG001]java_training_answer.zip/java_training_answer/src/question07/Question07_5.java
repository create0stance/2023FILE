package question07;

public class Question07_5 {
	public static void main(String[] args) {

		int inum = 10;
		double dnum;

		dnum = inum;
		System.out.println("inumをdnumに代入すると" + dnum + "になります");
	}
}