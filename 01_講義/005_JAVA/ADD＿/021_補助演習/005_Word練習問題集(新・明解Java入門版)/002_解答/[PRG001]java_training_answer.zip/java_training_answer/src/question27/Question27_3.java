package question27;

public class Question27_3 {
	public static void main(String[] args) {

		Show show = new Show();
		show.display();
		show.show();
	}
}
