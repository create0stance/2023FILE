package question14;

public class Question14_2 {
    public static void main(String[] args) {

        Dog dog = new Dog();
        dog.setProfile(5, "ジャーキー");
        dog.profile();
    }
}
