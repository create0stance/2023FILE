package question27;

interface Preparation {
	void show();
}
