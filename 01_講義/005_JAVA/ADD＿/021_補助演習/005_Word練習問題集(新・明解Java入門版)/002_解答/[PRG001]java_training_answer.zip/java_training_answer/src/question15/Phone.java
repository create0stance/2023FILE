package question15;

public class Phone {
    String tel;
    String mailAddress;

    void setTel(String tel) {
        this.tel = tel;
    }

    void setMail(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    void setInfo(String tel, String mailAddress) {
        this.tel = tel;
        this.mailAddress = mailAddress;
    }

    String getTel() {
        return this.tel;
    }

    String getMail() {
        return this.mailAddress;
    }
}
