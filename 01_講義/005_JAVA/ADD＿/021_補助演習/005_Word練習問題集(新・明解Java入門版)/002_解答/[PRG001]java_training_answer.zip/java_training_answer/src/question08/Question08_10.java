package question08;

import java.io.IOException;
import java.util.Scanner;

public class Question08_10 {
    public static void main(String[] args) throws IOException {
        System.out.println("整数を入力してください。");
        Scanner stdIn = new Scanner(System.in); 

        int num = stdIn.nextInt();

        if (num % 10 == 0) {
            System.out.println(num + "は10の倍数です。");
        } else {
            System.out.println(num + "は10の倍数ではありません。");
        }
        
        stdIn.close();
    }
}
