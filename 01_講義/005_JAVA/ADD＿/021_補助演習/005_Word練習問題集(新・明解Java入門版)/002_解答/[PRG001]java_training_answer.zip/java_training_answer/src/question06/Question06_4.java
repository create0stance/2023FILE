package question06;

import java.io.IOException;
import java.util.Scanner;

public class Question06_4 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in);
				

		String str1 = stdIn.nextLine();
		String str2 = stdIn.nextLine();
		String str3 = stdIn.nextLine();

		System.out.println(str1 + str2 + str3);
		
		stdIn.close();
	}
}
