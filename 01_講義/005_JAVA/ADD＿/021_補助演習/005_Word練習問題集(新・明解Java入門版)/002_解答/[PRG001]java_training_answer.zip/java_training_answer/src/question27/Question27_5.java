package question27;

public class Question27_5 {

    public static void main(String[] args) {
        Voice voice = new Voice();
        voice.bark();
        voice.cry();
    }

}
