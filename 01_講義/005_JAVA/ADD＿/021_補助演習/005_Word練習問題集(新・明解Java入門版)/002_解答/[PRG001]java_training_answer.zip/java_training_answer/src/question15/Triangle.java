package question15;

public class Triangle {

	int triangleCalc(int bottom, int height) {

		int result = bottom * height / 2;
		return result;
	}
}
