package question07;

public class Question07_2 {
	public static void main(String[] args) {

		int sum = 10;
		System.out.println("sumに1を足すと" + ++sum + "です");
		System.out.println("sumから1を引くと" + --sum + "です");

	}
}
