package question26;

abstract class Question26_1 {

	abstract void show();
}
