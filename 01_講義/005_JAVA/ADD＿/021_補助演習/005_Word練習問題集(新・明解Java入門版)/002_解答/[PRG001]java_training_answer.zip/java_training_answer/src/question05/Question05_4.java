package question05;

public class Question05_4 {
    public static void main(String[] args) {
        System.out.println("今日は、" + 11 + "月" + 22 + "日（木）");

        int i1 = 20;
        int i2 = 30;
        char c = 'A';
        double d = 3.14;
        String str = "明日から3連休！！！";

        System.out.println(str + i1);

        System.out.println("円周率はいつでも" + d);

        System.out.println(i1 + "+" + i2 + " = " + (i1 + i2));
        // 以下の記述でも可
        System.out.println("20+30" + (i1 + i2));

        System.out.print(c);

        System.out.print(i1);

        System.out.println();
        // 以下の記述でも可
        System.out.println(c + "" + i1);

        System.out.println(i2 + " ÷ " + i1 + "の余りは、" + i2 % i1);
    }
}
