package question21.question21_2;

public class Question21_2 {

	public void question2() {
		System.out.println("こんにちは");
	}
}
