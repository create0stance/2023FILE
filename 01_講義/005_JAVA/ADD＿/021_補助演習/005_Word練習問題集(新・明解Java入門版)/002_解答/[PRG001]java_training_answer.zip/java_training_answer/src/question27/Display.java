package question27;

public class Display implements Question27_1 {

	public void display() {
		System.out.println("インターフェイスを実装しました");
	}
}
