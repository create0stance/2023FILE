package question16;

class Question16_1 {

	private int num;
	private double gas;

	public void setNum(int num) {
		this.num = num;
	}

	public void setGas(double gas) {
		this.gas = gas;
	}

	public int getNum() {
		return num;
	}

	public double getGas() {
		return gas;
	}
}
