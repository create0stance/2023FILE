package question26;

public class Question26_3 {
	public static void main(String[] args) {

		Display display = new Display();
		Question26_2 question26_2 = new Question26_2();

		if (display instanceof Question26_1) {
			System.out.println("DisplayクラスとQuestion26_1は等しいです");
		}

		if (question26_2 instanceof Question26_2) {
			System.out.println("作成した変数はQuestion26_2クラスになります");
		}
	}
}
