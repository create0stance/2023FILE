package question08;

public class Question08_2 {
	public static void main(String[] args) {

		int number = 30;

		if (number >= 30) {
			System.out.println("numberの値は30以上です");
		} else {
			System.out.println("numberの値は30未満です");
		}

		System.out.println("処理を終了します");
	}
}
