package question06;

import java.io.IOException;
import java.util.Scanner;

public class Question06_3 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in);
		double num = stdIn.nextDouble();

		System.out.println("サイズが" + num + "の靴を購入します");
		
		stdIn.close();
	}
}
