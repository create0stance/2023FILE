package question02;

public class Question2_2 {
	public static void main(String[] args) {

		System.out.print("出力の練習　");
		System.out.print("２回目");

	}
}
