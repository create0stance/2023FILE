package question10;

public class Question10_3 {
    public static void main(String[] args) {

        int[] sum = { 10, 20, 30, 40, 50 };

        System.out.println("1番目の中身は" + sum[0]);
        System.out.println("2番目の中身は" + sum[1]);
        System.out.println("3番目の中身は" + sum[2]);
        System.out.println("4番目の中身は" + sum[3]);
        System.out.println("5番目の中身は" + sum[4]);

        System.out.println("処理を終了します");
    }
}
