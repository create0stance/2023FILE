package question06;

import java.io.IOException;
import java.util.Scanner;

public class Question06_2 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in);

		int num = stdIn.nextInt();

		System.out.println("今年で" + num + "歳になります");
		
		stdIn.close();
	}
}
