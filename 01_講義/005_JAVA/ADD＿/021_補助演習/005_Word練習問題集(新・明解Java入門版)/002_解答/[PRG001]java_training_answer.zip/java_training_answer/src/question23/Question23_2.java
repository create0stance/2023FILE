package question23;

public class Question23_2 {
	public static void main(String[] args) {

		Question23_1 inheritance = new Question23_1();

		inheritance.setHobby("趣味はサッカーです");
		System.out.println(inheritance.getHobby());
	}

}
