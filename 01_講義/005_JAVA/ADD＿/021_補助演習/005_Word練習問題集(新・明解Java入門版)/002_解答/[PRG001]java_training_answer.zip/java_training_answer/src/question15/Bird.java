package question15;

public class Bird {
	String name;

	void setName(String name) {
		this.name = name;
	}

	String getName() {
		return name;
	}
}
