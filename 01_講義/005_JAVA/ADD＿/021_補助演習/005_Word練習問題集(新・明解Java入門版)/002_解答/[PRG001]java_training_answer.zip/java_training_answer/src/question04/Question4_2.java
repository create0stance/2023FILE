package question04;

public class Question4_2 {
	public static void main(String[] args) {

		System.out.print(10);
		System.out.print('桁' + "\n");
		System.out.print(30.8);
		System.out.println('回');

	}
}
