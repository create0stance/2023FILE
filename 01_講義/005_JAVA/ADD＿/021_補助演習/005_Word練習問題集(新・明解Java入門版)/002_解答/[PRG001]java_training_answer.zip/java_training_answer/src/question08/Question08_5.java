package question08;

import java.io.IOException;
import java.util.Scanner;

public class Question08_5 {
    public static void main(String[] args) throws IOException {

        Scanner stdIn = new Scanner(System.in); 
        System.out.println("1か2を入力してください");
        int num = stdIn.nextInt();

        System.out.println("もう一度1か2を入力してください");
        int num2 = stdIn.nextInt();

        if (num == 1 && num2 == 1) {
            System.out.println("1が2回入力されました");
        }
        
        stdIn.close();
    }
}
