package question24;

public class Parent {
	
	void show(){
		System.out.println("自己紹介をします");
	}
}
