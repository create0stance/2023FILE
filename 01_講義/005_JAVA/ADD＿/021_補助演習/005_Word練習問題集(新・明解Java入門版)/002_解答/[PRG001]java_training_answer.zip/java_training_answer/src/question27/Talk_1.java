package question27;

public interface Talk_1 extends Talk_2 {
	void bark();
}
