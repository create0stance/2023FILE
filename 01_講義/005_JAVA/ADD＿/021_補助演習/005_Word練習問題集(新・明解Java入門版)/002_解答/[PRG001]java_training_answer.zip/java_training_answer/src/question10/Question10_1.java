package question10;

public class Question10_1 {
	public static void main(String[] args) {

		// 1つめ
		int[] sample;
		sample = new int[5];

		// 2つめ
		int[] sample2 = new int[5];
	}
}
