package question28;

import java.util.Scanner;

public class Question28_2 {
	public static void main(String[] args) {

		Scanner stdIn = new Scanner(System.in); 
		System.out.println("数値を入力してください");
		
		try {
			int num = stdIn.nextInt();
			System.out.println(num + "が入力されました");
		} catch (Exception e) {
			System.out.println("例外が発生しました");
		} finally{
			System.out.println("システムを終了します");
		}
		
		stdIn.close();
	}
}
