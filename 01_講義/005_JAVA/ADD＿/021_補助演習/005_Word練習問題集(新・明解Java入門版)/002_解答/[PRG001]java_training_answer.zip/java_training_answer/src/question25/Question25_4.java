package question25;

public class Question25_4 {
	public static void main(String[] args) {

		Frog frog = new Frog();
		System.out.println("今回パッケージに含まれているのは" + frog.getClass() + "です");
	}
}
