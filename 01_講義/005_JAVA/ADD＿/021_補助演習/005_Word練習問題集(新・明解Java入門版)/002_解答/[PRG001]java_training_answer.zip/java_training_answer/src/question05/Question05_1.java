package question05;

public class Question05_1 {
	public static void main(String[] args) {

		byte variableByte;
		short variableShort;
		int variableInt;
		long variableLong;
		float variableFloat;
		double variableDouble;
	}
}
