package question27;

public class Question27_2 {
	public static void main(String[] args) {

		Display display = new Display();
		display.display();
	}
}
