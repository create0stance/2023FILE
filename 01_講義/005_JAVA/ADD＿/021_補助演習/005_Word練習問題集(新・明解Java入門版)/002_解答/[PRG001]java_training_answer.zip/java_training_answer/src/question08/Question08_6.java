package question08;

import java.io.IOException;
import java.util.Scanner;

public class Question08_6 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in); 
		System.out.println("1か2を入力してください");
		int num = stdIn.nextInt();

		if (num == 1 || num == 2) {
			System.out.println("1か2が入力されました");
		}
		
		stdIn.close();
	}
}
