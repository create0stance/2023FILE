package question14;

public class Question14_1 {
    public static void main(String[] args) {

        Dog dog = new Dog();
        dog.setName("ダニエル");
        dog.show();
    }
}
