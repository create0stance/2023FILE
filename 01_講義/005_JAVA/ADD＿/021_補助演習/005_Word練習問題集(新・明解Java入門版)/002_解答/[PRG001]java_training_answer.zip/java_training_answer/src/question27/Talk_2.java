package question27;

public interface Talk_2 {
	void cry();
}
