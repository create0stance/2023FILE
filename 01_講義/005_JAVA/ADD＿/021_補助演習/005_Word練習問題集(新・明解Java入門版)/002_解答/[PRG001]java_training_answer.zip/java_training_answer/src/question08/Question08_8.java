package question08;

import java.io.IOException;
import java.util.Scanner;

public class Question08_8 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in); 
		System.out.println("1を入力してください");
		int num = stdIn.nextInt();

		String str2 = (num == 1) ? "1" : "1以外";
		System.out.println(str2 + "が入力されました");
		
		stdIn.close();
	}
}
