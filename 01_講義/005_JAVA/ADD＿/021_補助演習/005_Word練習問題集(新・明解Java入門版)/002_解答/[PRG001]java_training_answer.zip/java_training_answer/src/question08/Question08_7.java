package question08;

import java.io.IOException;
import java.util.Scanner;

public class Question08_7 {
	public static void main(String[] args) throws IOException {

		Scanner stdIn = new Scanner(System.in); 
		System.out.println("1以上の数値を入力してください");
		int num = stdIn.nextInt();

		boolean errFlag = false;
		if (num < 1) {
		    errFlag = true;
		}
		if (!errFlag) {
		    System.out.println("正常な入力です");
		}
		
		stdIn.close();
	}
}
