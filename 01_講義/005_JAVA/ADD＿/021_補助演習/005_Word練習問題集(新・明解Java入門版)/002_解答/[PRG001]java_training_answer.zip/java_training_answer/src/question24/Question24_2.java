package question24;

public class Question24_2 {
    public static void main(String[] args) {
        Question24_1 question = new Question24_1();

        question.show();
    }
}
