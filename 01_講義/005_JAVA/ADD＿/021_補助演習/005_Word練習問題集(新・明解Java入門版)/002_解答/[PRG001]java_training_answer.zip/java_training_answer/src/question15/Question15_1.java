package question15;

public class Question15_1 {
	public static void main(String[] args) {

		Bird bird = new Bird();

		bird.setName("ぴーちゃん");
		System.out.println("名前は" + bird.getName() + "です");
	}
}
