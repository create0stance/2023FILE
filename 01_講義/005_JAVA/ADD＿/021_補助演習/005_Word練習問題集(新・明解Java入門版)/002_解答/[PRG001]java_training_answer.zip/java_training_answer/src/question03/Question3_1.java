package question03;

public class Question3_1 {
	public static void main(String[] args) {
		System.out.println("ようこそJavaへ");
	}
}
