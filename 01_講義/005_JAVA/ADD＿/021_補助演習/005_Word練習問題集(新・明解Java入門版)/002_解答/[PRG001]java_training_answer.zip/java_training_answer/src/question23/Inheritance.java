package question23;

public class Inheritance {

	Inheritance() {
		System.out.println("Inheritanceクラスを継承したクラスがオブジェクト化されました");
	}

	private String hobby;

	void setHobby(String hobby) {
		this.hobby = hobby;
	}

	String getHobby() {
		return hobby;
	}
}
