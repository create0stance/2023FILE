package question25;

public class Question25_1 {
	public static void main(String[] args) {
		Frog frog = new Frog();
		System.out.println(frog);
	}
}

