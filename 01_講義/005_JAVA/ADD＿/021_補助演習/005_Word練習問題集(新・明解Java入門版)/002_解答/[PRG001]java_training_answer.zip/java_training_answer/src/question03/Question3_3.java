package question03;

//コメントは一例になります

class Question3_3 {
    public static void main(String[] args) {

		// メッセージの出力
		System.out.print("表示を　");
		System.out.println("行います");
		System.out.print("終了します");
	}
}
