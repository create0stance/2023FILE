package question28;

public class Question28_3 extends Exception{

}
