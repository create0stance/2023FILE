/*問題②
 * ログイン機能を実装します。以下の条件に従って記述しなさい。
 *
 * ①Employeeクラス
 * 	・フィールド
 * 		int id;
		int pass;
		String name;
		double sal;
 * 　	※カプセル化すること
 * 	・各フィールドに対してsetter,getterを持つ。（編集タブまたはソースタブにある生成機能を用いてよい。）
 * 	・toStringメソッドを定義する。（ソースタブの「toString()生成」を選択する。）
 *
 * ②Checkクラス
 * 	loginメソッドを持つ。
 * 		・戻り値：boolean型
 * 		・メソッド名：login
 * 		・引数：Employee型
 * 		・if文　条件：引数のEmployeeオブジェクトがnullでない
 * 				処理：trueをreturn
 * 		・falseをreturn
 *
 * ③DBクラス
 * 	・フィールド、コンストラクタは以下をコピペする。
 *
 *	//フィールド
 * 	List<Employee> empList;
	//コンストラクタ
	public DB() {

		empList = new ArrayList<Employee>();
		Employee employee1 = new Employee(1, 1111, "柄澤", 22.2);
		Employee employee2 = new Employee(2, 2222, "岡野", 23.3);
		Employee employee3 = new Employee(3, 3333, "堀江", 24.4);
		Employee employee4 = new Employee(4, 4444, "山田", 25.5);
		Employee employee5 = new Employee(5, 5555, "横川", 26.6);
		Collections.addAll(empList, employee1, employee2, employee3, employee4, employee5);

	}

	findByIdPassメソッドを持つ。
		・戻り値：Employee型
 * 		・メソッド名：findByIdPass
 * 		・引数：int id ,int pass
 * 		・拡張for文（Employee型:empList）内に
 * 			if文　条件：引数id==Employeeオブジェクトのid
 * 						かつ
 * 						引数pass==Employeeオブジェクトのpass
 * 					処理：employeeオブジェクトをreturnする。
 * 		・nullをreturnする
 *
 * ④EmpMainクラス
 * 	メインメソッド内に
 * 		・コンソール入力でidとpassを入力し数値に変換。
 * 		・DBオブジェクトを生成する。
 * 		・idとpassを引数にしてfindByIdPassメソッドを呼び出し、Employeeオブジェクトに代入
 * 		・Checkオブジェクトを生成する。
 * 		・Employeeオブジェクトを引数にしてloginメソッドを呼び出し、boolean型に代入。
 * 		・if文　条件：上記のbooleanがtrue
 * 				処理："ログイン成功"　Employeeオブジェクトを出力
 * 				それ以外の出力："ログイン失敗"と出力
 *
 【出力例①】
ログインIDを入力してください
1
ログインパスワードを入力してください
1111
ログイン成功
Employee [id=1, pass=1111, name=柄澤, sal=22.2]

【出力例②】
ログインIDを入力してください
5
ログインパスワードを入力してください
5555
ログイン成功
Employee [id=5, pass=5555, name=横川, sal=26.6]

【出力例③】
ログインIDを入力してください
1
ログインパスワードを入力してください
2222
ログイン失敗

 *
 * */

package other.loginCheck;


public class Main {

	public static void main(String[] args) {

		System.out.println("システムにログインします");
		int id = 0;
		String password = null;
		try {
			id = new ConsoleReader().inputId();
			password = new ConsoleReader().inputPassword();
		} catch (IllegalInputException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		EmployeeLedger employeeLedger = new EmployeeLedger();

		// 戻り値がEmployee型のメソッド
		Employee loginUser = employeeLedger.findByIdPass(id, password);

		LoginCheck loginCheck = new LoginCheck();
		// 引数がEmployee型のメソッド
		boolean canLogin = loginCheck.login(loginUser);
		if (canLogin) {
			System.out.println("ログイン成功");
			System.out.println(loginUser.getName() + "さん、ようこそ");
			System.out.println(loginUser);
		} else {
			System.out.println("ログイン失敗");

		}

	}

}
