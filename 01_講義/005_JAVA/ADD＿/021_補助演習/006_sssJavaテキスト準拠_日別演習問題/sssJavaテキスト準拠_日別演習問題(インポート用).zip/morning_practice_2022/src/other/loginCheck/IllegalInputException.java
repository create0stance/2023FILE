package other.loginCheck;

public class IllegalInputException extends Exception {

	public IllegalInputException() {
	}

	public IllegalInputException(String message) {
		super(message);
	}

}
