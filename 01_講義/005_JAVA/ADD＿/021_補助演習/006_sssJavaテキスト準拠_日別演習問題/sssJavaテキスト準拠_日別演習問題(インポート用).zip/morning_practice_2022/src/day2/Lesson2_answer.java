//問題

//パッケージ名 day2
//クラス名 Lesson2.java

//標準入力機能（BufferedReader）を用いて以下の出力をしなさい

//出力例
//name? >>鈴木一郎
//私の名前は鈴木一郎です。

package day2;

import java.io.IOException;

public class Lesson2_answer {

	public static void main(String[] args) throws IOException {
		//以下に処理を記述



	}

}
