package other.loginCheck;

public class LoginCheck {

	boolean login(Employee employee) {

		if (employee != null) {
			return true;
		}
		return false;

	}

}
