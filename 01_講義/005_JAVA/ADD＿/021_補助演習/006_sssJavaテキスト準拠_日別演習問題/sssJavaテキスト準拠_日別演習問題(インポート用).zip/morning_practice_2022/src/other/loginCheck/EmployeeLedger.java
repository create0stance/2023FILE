package other.loginCheck;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeLedger {

	private List<Employee> empList;

	public EmployeeLedger() {

		this.empList = new ArrayList<Employee>();
		Employee employee1 = new Employee(1111, "112233", "柄澤", 22.2);
		Employee employee2 = new Employee(2222, "aabbcc", "岡野", 23.3);
		Employee employee3 = new Employee(3333, "1a2b", "堀江", 24.4);
		Employee employee4 = new Employee(4444, "Qwerty", "山田", 25.5);
		Employee employee5 = new Employee(5555, "1v3adADW", "横川", 26.6);
		Collections.addAll(this.empList, employee1, employee2, employee3, employee4, employee5);

	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public Employee findByIdPass(int id, String password) {

		Employee returnEmployee = null;

		for (Employee employee : empList) {
			int empId = employee.getId();
			String empPass = employee.getPassword();
			if (empId == id && empPass.equals(password)) {
				returnEmployee = employee;
			}
		}
		return returnEmployee;
	}

}
