//追加問題

//パッケージ名 day2
//クラス名 Lesson3.java

//3つの任意の整数をコンソールから入力し、税込み金額（消費税は8％計算）の合計を出しなさい。
//また、平均金額を求めなさい。
//キャストしてすべて整数値で求めること。
//【出力例】
//金額①を入力してください>>210
//金額②を入力してください>>300
//金額③を入力してください>>350
//①から③の合計は税込み928円
//①から③の平均は税込み309円

package day2;

import java.io.IOException;

public class Lesson3_answer {

	public static void main(String[] args) throws IOException {

		//以下に処理を記述



	}

}
