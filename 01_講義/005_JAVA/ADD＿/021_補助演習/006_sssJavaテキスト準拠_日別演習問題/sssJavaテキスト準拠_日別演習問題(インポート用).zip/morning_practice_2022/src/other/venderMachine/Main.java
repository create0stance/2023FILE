/*ソースコードリーディング等にお使いください。*/

package other.venderMachine;

public class Main {

	public static void main(String[] args) {

		//自動販売機オブジェクト生成
		VenderMachine venderMachine = new VenderMachine();
		
		//人間オブジェクト生成と「人間」を通じて自動販売機を操作する
		Human human = new Human("植木");
		human.insertCoin(venderMachine);
		human.buyDrink(venderMachine);
		human.show();
		
		//自動販売機情報の表示
		venderMachine.show();

	}

}
