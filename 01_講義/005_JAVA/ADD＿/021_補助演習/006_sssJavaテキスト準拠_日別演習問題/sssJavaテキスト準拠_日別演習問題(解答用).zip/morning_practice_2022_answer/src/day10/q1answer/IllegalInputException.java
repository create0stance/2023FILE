package day10.q1answer;

public class IllegalInputException extends Exception {

	public IllegalInputException() {
	}

	public IllegalInputException(String message) {
		super(message);
	}

}
