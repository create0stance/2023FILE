package day9.q2answer;

public class Piano extends Instrument {

	private double weight;

	public Piano(String maker) {
		// Instrumentのコンストラクタを呼び出し
		super(maker);
		weight = 80.5;
	}

	@Override
	public String toString() {
		return "Piano [weight=" + weight + ", maker=" + maker + "]";
	}

	public void playMusic() {
		System.out.println(maker + "のピアノを弾きます。");

	}

}
