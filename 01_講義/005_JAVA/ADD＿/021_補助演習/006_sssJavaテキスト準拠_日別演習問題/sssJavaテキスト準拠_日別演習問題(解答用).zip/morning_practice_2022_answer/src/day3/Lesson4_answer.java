//問題

//パッケージ名 day3
//クラス名 Lesson4.java

// ・FizzBuzz問題
//		コンソールから任意の整数を入力し、3で割れる場合は「Fizz」、5で割り切れる場合は「Buzz」、
//		3と5両方の数字で割り切れる場合「FizzBuzz」とコンソールに出力してください。
//		どちらの数字でも割り切れない場合は、数字をそのままコンソールに出力します。
//		//（補足：3の倍数は(変数%3==0)と表します。）
//【出力例①】
//input number? >>30
//FizzBuzz
//
//【出力例②】
//input number? >>27
//Fizz
//
//【出力例③】
//input number? >>55
//Buzz
//
//【出力例④】
//input number? >>13
//13

package day3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lesson4_answer {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("input number? >>");
		int number = Integer.parseInt(br.readLine());

		if (number % 15 == 0) {// (number % 3 == 0 && number % 5 == 0)でもOK
			System.out.println("FizzBuzz");
		} else if (number % 3 == 0) {
			System.out.println("Fizz");
		} else if (number % 5 == 0) {
			System.out.println("Buzz");
		} else {
			System.out.println(number);
		}

	}

}
