//追加問題

//パッケージ名 day2
//クラス名 Lesson3.java

//3つの任意の整数をコンソールから入力し、税込み金額（消費税は8％計算）の合計を出しなさい。
//また、平均金額を求めなさい。
//キャストしてすべて整数値で求めること。
//【出力例】
//金額①を入力してください>>210
//金額②を入力してください>>300
//金額③を入力してください>>350
//①から③の合計は税込み928円
//①から③の平均は税込み309円

package day2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lesson3_answer {

	public static void main(String[] args) throws IOException {

		int sum = 0;// 合計金額
		int average = 0;// 平均金額

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("金額①を入力してください>>");
		String input = br.readLine();// コンソールから入力します
		int price = Integer.parseInt(input);// int型にパースします
		int tax_price = (int) (price * 1.08);// キャストします

		sum += tax_price;// sumへ税込み金額を代入

		System.out.print("金額②を入力してください>>");
		input = br.readLine();
		price = Integer.parseInt(input);
		tax_price = (int) (price * 1.08);

		sum += tax_price;

		System.out.print("金額③を入力してください>>");
		input = br.readLine();
		price = Integer.parseInt(input);
		tax_price = (int) (price * 1.08);

		sum += tax_price;

		System.out.println("①から③の合計は税込み" + sum + "円");
		average = (int) sum / 3;
		System.out.println("①から③の平均は税込み" + average + "円");

	}

}
