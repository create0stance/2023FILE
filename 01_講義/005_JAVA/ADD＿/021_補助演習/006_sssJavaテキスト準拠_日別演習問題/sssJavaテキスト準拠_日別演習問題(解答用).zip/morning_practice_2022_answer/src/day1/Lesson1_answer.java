//問題
//パッケージ名 day1
//クラス名 Lesson1.java

//"出力します"とコンソールに出力してください。
//続けて12、 1.6、 "こんにちは"、 trueをそれぞれ変数に代入しコンソールに出力してください。
//変数名は任意とします
//また上記から変数を１つを選び、代入する値を1行コメントで記入しなさい。（コメント例 〇〇を代入する）

//【出力例】
//出力します
//12
//1.6
//こんにちは
//true

package day1;

public class Lesson1_answer {

	public static void main(String[] args) {

		System.out.println("出力します");
		int i = 12;
		// 1.6を代入する。
		double d = 1.6;
		String s = "こんにちは";
		boolean b = true;

		System.out.println(i);
		System.out.println(d);
		System.out.println(s);
		System.out.println(b);

	}

}
