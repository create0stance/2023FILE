package other.loginCheck;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import day10.q1answer.IllegalInputException;

public class ConsoleReader {

	public int inputId() throws IllegalInputException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("4桁のIDを入力して下さい");
		System.out.print("input ID? >>");
		String inputString = null;
		try {
			inputString = br.readLine();
		} catch (IOException e) {
			throw new IllegalInputException("不正な操作が行われました");

		}

		if (!inputString.matches("[0-9]{4}")) {
			throw new IllegalInputException("不正な入力:" + inputString);
		}

		int id = Integer.parseInt(inputString);

		return id;
	}

	public String inputPassword() throws IllegalInputException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("パスワードを入力して下さい");
		System.out.print("input password? >>");
		String inputString = null;
		try {
			inputString = br.readLine();
		} catch (IOException e) {
			throw new IllegalInputException("不正な操作が行われました");
		}

		if (!inputString.matches("[a-zA-Z0-9]{4,16}")) {
			throw new IllegalInputException("不正な入力:" + inputString);
		}

		return inputString;
	}

}
