package day9.q1;

import java.io.IOException;

public interface Playable {

	int doJanken() throws IOException;
}
