//問題 

//パッケージ名 day6.q1
//クラス名1 Phone.java 電話クラス
//クラス名2 Main.java オブジェクト生成し、プログラムを実行するクラス

//電話オブジェクトを生成し、電話をかけます。その後に電話料金を表示します

//以下の条件を満たすクラスを作成しなさい。
//※「+」はpublic、「-」はprivateを表す
//【Phoneクラス】
//	・フィールド
//		- fee:int 料金フィールド
//	・メソッド
//		+ initFee():戻り値の型 void 
//			・"今月の電話料金を初期化します（\\980）"を表示します
//			・feeに980を代入します
//		+ call():戻り値の型 void 
//			・"電話をかけます（+\\150）"を表示します
//			・feeに150を加算します
//		+ feeフィールドのsetter,getter(ソースタブの機能を用いて定義する)
//【Mainクラス】
//	・メソッド
//		+ main(args:String[]):戻り値の型 void 
//			・Phoneオブジェクトを生成します
//			・Phone#initFee()を呼び出します
//			・Phone#call()を任意の回数、呼び出します
//			・Phone#getFee()を呼び出し電話料金を表示します

//【出力例】
//シェアード電話に加入しました
//今月の電話料金を初期化します（\980）
//電話をかけます（+\150）
//電話をかけます（+\150）
//今月の電話料金は\1280です

package day6.q1;

class Main {

	public static void main(String[] args) {

		System.out.println("シェアード電話に加入しました");
		Phone phone = new Phone();
		phone.initFee();

		phone.call();
		phone.call();

		System.out.println("今月の電話料金は\\" + phone.getFee() + "です");
	}

}
