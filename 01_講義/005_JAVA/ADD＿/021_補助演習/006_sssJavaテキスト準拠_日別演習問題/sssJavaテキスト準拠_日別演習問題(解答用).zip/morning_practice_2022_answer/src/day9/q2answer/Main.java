//追加問題
//！この問題は決まった回答はありません。配布クラスから自分でクラス設計を考えしょう

//作成済みのPianoクラスとDrumsクラスがある。
//今後、様々な楽器クラスを作成することが予想されるために
//この二つから共通クラスとしてInstrumentクラスを準備しておきたい。
//
//以下の条件に従って解答しなさい。
//パッケージ名 day9.q2
//クラス名1 Piano.java ピアノクラス(既存クラス、要修正)
//クラス名2 Drums.java ドラムクラス（既存クラス、要修正）
//クラス名3 Instrument.java 楽器クラス（新規作成）
//クラス名4 Main.java オブジェクト生成し、プログラムを実行するクラス

//※「+」はpublic、「-」はprivate、「__」はstaticメンバを表す
//【Instrumentクラス】
//	・抽象クラスとして定義する
//	・フィールド、コンストラクタ、メソッドはPiano、Drumsから共通部を抽出し定義すること
//	・最低一つは抽象メソッドを定義すること

//【Piano、Drumsクラス（修正部のみ記述）】
//	・Instrumentクラスを継承してエラーが出ないか、確認すること。
//	・必要に応じて変更しても構わない。ただし、アクセサメソッド以外のもともとあったメソッドは残すこと。
//	・toString()をオーバーライドし出力例のように文字列表示できるようにする

//【Mainクラス】
//	・メソッド
//		+ __main(args:String[]):戻り値の型 void 
//			・Instrument型の配列を生成し、Piano,Drumsオブジェクトを代入する。
//			・拡張for文で配列要素を取り出し、二つのオブジェクトの出力と共通のメソッドを実行する。
//【出力例】
//Piano [weight=80.5, maker=Yamaha]
//Yamahaのピアノを弾きます。
//Drums [constitution=バスドラム・スネアドラム・タムタム・シンバルのセットです, maker=Pearl]
//Pearlのドラムを演奏します。

package day9.q2answer;

public class Main {

	public static void main(String[] args) {

		Instrument instruments[] = new Instrument[2];
		instruments[0] = new Piano("Yamaha");
		instruments[1] = new Drums("Pearl");

		// 拡張for文で取り出して演奏します。
		for (Instrument instrument : instruments) {
			System.out.println(instrument);
			instrument.playMusic();
		}

	}

}
