/**
 * 保育園のお仕事
 *
 * 例外処理②
 *
 * ケーキを何個かいただいたので、園児たちに分けることにしました。
 * 入力されたの園児の人数が0の時はArithmeticException
 * をcatchして「ケーキを食べる園児がいません。」と表示し、
 * それ以外の場合は「1人○個になります。」と表示する。
 * public void divide(int cakes, int childs)メソッドを
 * 保育士クラスに作成してください。
 *
 * <実行例>
 * 保育太郎が出勤しました。
 * 保育次郎が出勤しました。
 * 保育三郎が出勤しました。
 * 園児①が登園しました。
 * 園児②が登園しました。
 * 園児③が登園しました。
 *
 * いただいたケーキの数を入力してください＞○
 *
 * 園児の人数を入力してください＞○
 *
 * ケーキを食べる園児がいません。
 *
 *
 * --------------------------------------------------------------------
 * ArithmeticExceptionクラスの解説
 * --------------------------------------------------------------------
 * 算術計算で例外的条件が発生したときにスローされる例外クラスです。
 * 例えば、整数をゼロで除算したときなどに発生します。
 *
 * また、他の例外クラスと同様にJava.langパッケージに所属しているため、
 * import文を記述する必要はありません
 *
 */

package exception.challenge02.Nurserry.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import exception.challenge02.Nurserry.logic.Nurse;
import exception.challenge02.Nurserry.logic.NurserySchoolChild;

public class NurserySchool {

    public static void main(String[] args) throws IOException {

		//必要な処理を記述する
    }
}
