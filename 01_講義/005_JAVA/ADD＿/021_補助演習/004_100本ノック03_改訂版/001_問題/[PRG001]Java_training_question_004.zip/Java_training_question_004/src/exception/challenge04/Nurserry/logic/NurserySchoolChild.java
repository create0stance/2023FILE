package exception.challenge04.Nurserry.logic;

public class NurserySchoolChild {

		//必要な処理を記述する

}
