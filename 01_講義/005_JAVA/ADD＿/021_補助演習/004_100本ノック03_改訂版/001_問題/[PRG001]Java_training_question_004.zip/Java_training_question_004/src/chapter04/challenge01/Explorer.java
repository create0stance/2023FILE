/**
 * 探検隊のお仕事
 *
 * 探検隊の募集
 *
 * コメントの位置にfor文を記述して
 * 実行例と同じメッセージを表示してください。
 *
 * <実行例>
 *  隊長：
 *  探検隊の隊員を5名募集します。
 *
 *  応募する人の名前を入れてください＞○○
 *
 *  隊長：
 *  ○○さん合格！
 *
 *  応募する人の名前を入れてください＞△△
 *
 *  隊長：
 *  △△さん合格！
 *
 *  ～～～～～～～～ 中略 ～～～～～～～～～
 *
 *  応募する人の名前を入れてください＞□□
 *
 *  隊長：
 *  □□さん合格！
 *
 *  定員に達しました。募集を締め切ります。
 *
 */

package chapter04.challenge01;

import java.io.IOException;
import java.util.Scanner;

public class Explorer {

	public static void main(String[] args) throws IOException {

		//処理を記述
	}
}
