/**
 * マカロン屋さんのお仕事
 *
 * 在庫を減らす
 *
 * [問題5]までの表示を行った後で
 * 3種のマカロンそれぞれの在庫を減らす処理を追記し
 * 以下の実行例と同じものを最後に表示してください。
 *
 * <実行例>
 *
 * ～～～～～～～～～省略～～～～～～～～～～～
 *
 * 本日のおすすめ商品です。
 *
 * シトロン      \250 ・・・ 残り22個
 * ショコラ      \280 ・・・ 残り28個
 * ピスターシュ  \320 ・・・ 残り24個
 *
 */

package chapter02.challenge04;

import java.io.IOException;
import java.util.Scanner;

public class Patisserie {

	public static void main(String[] args) throws IOException {

		//処理を記述
	}

}
