/**
 * マカロン屋さんのお仕事
 *
 * 商品の展示
 *
 * [問題1]の表示を行った後で
 * 以下の実行例と同じものを表示してください。
 *
 * <実行例>
 *
 * ～～～～～～～～～省略～～～～～～～～～～～
 *
 * 本日のおすすめ商品です。
 *
 * シトロン      \250 2000
 * ショコラ      \280 560
 * ピスターシュ  \320 1920
 *
 */

package chapter01.challenge02;

public class Patisserie {

	public static void main(String[] args) {

		//処理を記述

	}

}

