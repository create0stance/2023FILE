/**
 * 武士のお仕事
 *
 * インターフェース②
 *
 * 文化人インターフェースを作る。
 *
 * 抽象メソッドlearn()を持つ文化人インターフェースICelebrityを
 * 作成し、藩士クラスと浪人クラスにそれぞれ実装し、<実行例>と
 * 同じメッセージを表示してください。
 *
 * <実行例>
 * 藩士1：
 * 茶道を嗜むよ～。
 *
 * 浪人1：
 * 塾を開くよ～。
 *
 *
 */

package chapter08.challenge08;

//ICelebrityインターフェイス

//Samuraiクラス

//Retainerクラス

//Roninクラス

public class CastleTown {

	public static void main(String[] args) {
		System.out.println("藩士1：");
		Retainer retainer1 = new Retainer();
		retainer1.learn();

		System.out.println("\n浪人1：");
		Ronin ronin1 = new Ronin();
		ronin1.learn();

	}
}
