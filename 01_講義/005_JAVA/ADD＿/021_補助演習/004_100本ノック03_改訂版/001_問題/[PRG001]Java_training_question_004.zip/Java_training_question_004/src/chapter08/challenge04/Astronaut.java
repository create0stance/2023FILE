/**
 * 宇宙飛行士のお仕事
 *
 * Stringクラス②（length、subString）
 *
 * 宇宙船が次の目的地β星に到着しました。
 * β星は不思議な星です。β星人たちは
 * 自分の持物を必ず5文字以内で表記します。
 * 例えば、「apple」は「apple」のまま使いますが、
 * 「orange」は「orang」に変更して使います。
 *
 * β星人クラスBetalianを新たに作成してください。
 * BetalianはString型フィールドitemを持ち、
 * メソッドsetItem()で登録します。setItem()は
 * 5文字以上ある名前については、6文字目以降を削ってから
 * itemに登録します。
 *
 * <実行例>
 *
 * β星人にアイテムを渡してください＞orange
 *
 * β星人：
 * ありがとうベータ！
 * このorang大事にするベータ。
 *
 */

package chapter08.challenge04;

import java.io.IOException;
import java.util.Scanner;

class Betalian {
		//ここに必要な処理を記述する


public class Astronaut {

    public static void main(String[] args) throws IOException {

        System.out.print("β星人にアイテムを渡してください＞");
		Scanner stdIn = new Scanner(System.in);
        String present = stdIn.next();

		//ここに必要な処理を記述する


        System.out.println("\nβ星人：");
        System.out.println("ありがとうベータ！");
        System.out.println("この" + item + "大事にするベータ。");
        
    }
}
