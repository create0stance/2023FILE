/**
 * 宇宙飛行士のお仕事
 *
 * メソッドに参照渡し
 *
 * 地球に帰ってきました。
 * 帰路さまざまな障害を乗り越えて来ましたので、
 * 宇宙船がかなりの損傷を受けています。
 * ドックに預けて修理をしてもらいましょう。
 *
 * 宇宙船クラス（Spaceship）にダメージ(damage)とsetter、getterを記述し、
 * ドッククラス（Dock）にメソッドpublic void repairShip(Spaceship ship)
 * を記述してください。
 * メソッドrepairShip(Spaceship ship)は引数shipのダメージを0にします。
 *
 * <実行例>
 *
 * 宇宙飛行士：
 * やっとのことで帰ってきたけど、損傷がひどいな。
 * 修理に出そう。
 *
 * ダメージを入力してください＞200
 *
 * 現在のダメージ：200
 *
 * 宇宙飛行士：
 * よし！ドックから戻ってきたぞ！
 *
 * 現在のダメージ：0
 *
 */

package chapter08.challenge06;

import java.io.IOException;
import java.util.Scanner;

class Spaceship {
		//ここに必要な処理を記述する

}

class Dock {
		//ここに必要な処理を記述する

}

public class Astronaut {

    public static void main(String[] args) throws IOException {

        System.out.println("宇宙飛行士：");
        System.out.println("やっとのことで帰ってきたけど、損傷がひどいな。");
        System.out.println("修理に出そう。\n");

		//ここに必要な処理を記述する


        System.out.println("\n現在のダメージ：" + damage);

		//ここに必要な処理を記述する


        System.out.println("\n宇宙飛行士：");
        System.out.println("よし！ドックから戻ってきたぞ！\n");

        damage = spaceship.getDamage();

        System.out.println("現在のダメージ：" + damage);
        
    }
}
