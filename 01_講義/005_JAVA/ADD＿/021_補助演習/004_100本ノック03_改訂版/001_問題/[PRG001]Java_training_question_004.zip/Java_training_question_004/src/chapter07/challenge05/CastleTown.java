/**
 * 武士のお仕事
 *
 * toString()メソッドの利用
 *
 * toString()メソッドを適切にオーバーライドする。
 *
 * 問題1で作成した藩士クラスと問題2で作成した浪人クラスで
 * それぞれtoString()メソッドをオーバーライドし、<実行例>
 * と同じ結果になるように適切な処理記述しなさい。
 * （※Samuraiクラスにフィールドprotected String nameを追記）
 * （※藩士、浪人ともに名前はコンストラクタで設定する）
 * （※System.out.printlnを利用する）
 *
 * <実行例>
 * 藩士クラスのtoString()メソッドを確認します。
 *
 * 拙者は○△□藩士、テスト太郎ともうす。
 *
 * 浪人クラスのtoString()メソッドを確認します。
 *
 * 拙者は武州○△□村の浪人、テスト兵衛ともうす。
 *
 */

package chapter07.challenge05;

		//処理を記述

public class CastleTown {

	public static void main(String[] args) {
		//処理を記述
	}
}
