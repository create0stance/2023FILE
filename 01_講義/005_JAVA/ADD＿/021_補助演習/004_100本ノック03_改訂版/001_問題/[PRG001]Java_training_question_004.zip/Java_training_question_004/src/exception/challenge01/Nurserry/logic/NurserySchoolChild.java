package exception.challenge01.Nurserry.logic;

public class NurserySchoolChild {

		//必要な処理を記述する

}
