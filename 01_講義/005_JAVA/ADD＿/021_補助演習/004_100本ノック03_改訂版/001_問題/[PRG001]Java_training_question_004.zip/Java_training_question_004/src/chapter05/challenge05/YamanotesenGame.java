package chapter05.challenge05;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class YamanotesenGame {

	// 山手線の駅名を配列（定数）に格納しておく
	public static final String[] STATION_NAMES = { "品川", "大崎", "五反田", "目黒", "恵比寿", "渋谷", "原宿", "代々木", "新宿", "新大久保",
			"高田馬場", "目白", "池袋", "大塚", "巣鴨", "駒込", "田端", "西日暮里", "日暮里", "鴬谷", "上野", "御徒町", "秋葉原", "神田", "東京", "有楽町",
			"新橋", "浜松町", "田町" };

	/**
	 *
	 * 山手線ゲームを実行するメソッド
	 *
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		// 未回答の（残りの）駅の数
		int rest = STATION_NAMES.length;

		// player = trueならば、人間（「あなた」）の番
		// falseならばコンピュータの番
		boolean player = true;

		System.out.println("※※※ 山手線ゲーム ※※※");
		System.out.println("      ゲームスタート！    \n");

		//コードを挿入

		System.out.println("あなたの勝ちです！");

		stdIn.close();
	}
}
