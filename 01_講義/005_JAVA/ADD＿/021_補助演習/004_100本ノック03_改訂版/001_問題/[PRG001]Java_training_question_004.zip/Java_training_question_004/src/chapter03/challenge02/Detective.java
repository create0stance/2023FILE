/**
 * 名探偵のお仕事
 *
 * 犯行現場の捜査①（宝石を置いていた場所）
 *
 * コメントの位置にif～else文を入れて
 * 身長が185を超えている場合と超えていない場合の
 * 二通りの処理の流れができるようにしてください
 *
 * <身長が185を超えている場合の実行例>
 * 探偵：
 * 宝石を置いていた場所はどこですか？
 * 依頼主：
 * あの棚の上です
 * 探偵：
 * 犯人は...
 *
 * 背の高い人ですね
 *
 * <身長が185を超えていない場合の実行例>
 *
 * 探偵：
 * 宝石を置いていた場所はどこですか？
 *
 * 依頼主：
 * あの棚の上です
 * 探偵：
 *
 * 犯人は...
 *
 * 背の低い人ですね
 *
 */

package chapter03.challenge02;

public class Detective {

	public static void main(String[] args) {

		int height = 190;

		System.out.println("探偵：");
		System.out.println("宝石を置いていた場所はどこですか？\n");
		System.out.println("依頼主：");
		System.out.println("あの棚の上です。\n");
		System.out.println("探偵：");
		System.out.println("犯人は...");

		if (height > 185) {
			System.out.println("背の高い人ですね");
		} else {
			System.out.println("背の低い人ですね");
		}

	}

}
