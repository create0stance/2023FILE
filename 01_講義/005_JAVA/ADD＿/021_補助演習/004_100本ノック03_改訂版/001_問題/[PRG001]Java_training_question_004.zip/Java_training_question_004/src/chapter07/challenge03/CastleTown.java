/**
 * 武士のお仕事
 *
 * オーバーライド①
 *
 * 侍クラス（Samurai）のメソッドをオーバーライドする。
 *
 * 侍クラス（Samurai）にwork()メソッド（戻り値void）を追記し、
 * 藩士クラスでオーバーライドしてください。
 *
 * <実行例>
 * 侍は働きます。
 *
 * 侍1：
 * 何かして働くよ～。
 *
 * 具体的に言うと藩士は年貢を取り立てます。
 *
 * 藩士1：
 * 年貢を取り立てるよ～。
 *
 */

package chapter07.challenge03;

		//処理を記述

public class CastleTown {

	public static void main(String[] args) {
		//処理を記述
	}
}
