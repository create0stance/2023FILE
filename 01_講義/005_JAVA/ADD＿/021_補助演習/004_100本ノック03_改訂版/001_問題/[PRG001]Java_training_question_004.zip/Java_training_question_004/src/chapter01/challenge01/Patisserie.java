/**
 * マカロン屋さんのお仕事
 *
 * 開店メッセージの表示
 *
 * 実行例と同じメッセージを表示してください。
 *
 * <実行例>
 * たいへんお待たせしました。
 *【ポエール・ネルメ】
 * ただいまより開店です！！
 *
 */

package chapter01.challenge01;

public class Patisserie {

	public static void main(String[] args) {

		//処理を記述
	}

}
