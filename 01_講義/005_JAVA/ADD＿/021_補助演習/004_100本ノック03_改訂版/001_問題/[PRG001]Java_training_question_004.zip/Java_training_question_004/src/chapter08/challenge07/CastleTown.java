/**
 * 武士のお仕事
 *
 * 抽象クラス
 *
 * 抽象クラス、抽象メソッドを作る。
 *
 * 侍クラスのwork()メソッドを抽象化してください。
 *
 * <実行例>
 * 侍は働きます。
 *
 * 具体的に言うと藩士は年貢を取り立てます。
 *
 * 藩士1：
 * 年貢を取り立てるよ～。
 *
 * 具体的に言うと浪人は傘張りをします。
 *
 * 浪人1：
 * 傘張るよ～。
 *
 */

package chapter08.challenge07;

//Samuraiクラス

//Retainerクラス

//Roninクラス

public class CastleTown {

    public static void main(String[] args) {
        System.out.println("侍は働きます。");

        System.out.println("\n具体的に言うと藩士は年貢を取り立てます。\n");

        System.out.println("藩士1：");

		//ここに必要な処理を記述する

        System.out.println("\n具体的に言うと浪人は傘張りをします。\n");

        System.out.println("浪人1：");

		//ここに必要な処理を記述する

    }
}
