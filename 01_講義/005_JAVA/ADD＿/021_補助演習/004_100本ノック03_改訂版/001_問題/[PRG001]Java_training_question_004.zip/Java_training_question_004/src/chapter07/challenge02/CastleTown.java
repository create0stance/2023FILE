/**
 * 武士のお仕事
 *
 * 侍クラスを継承する②
 *
 * 侍クラス（Samurai）を継承する
 * 浪人クラス（Ronin）を作る。
 *
 * 侍クラス（Samurai）を継承する浪人クラス（Ronin）を作り、
 * covered()メソッド（戻り値void） を足してください。
 *
 * <実行例>
 * 侍は戦います。
 *
 * 侍1：
 * 戦うよ～。
 *
 * 浪人はそれに加えて傘張りもします。
 *
 * 浪人1：
 * 戦うよ～。
 * 傘張りするよ～。
 *
 */

package chapter07.challenge02;

	//処理を記述


public class CastleTown {

	public static void main(String[] args) {
		//処理を記述

	}

}
