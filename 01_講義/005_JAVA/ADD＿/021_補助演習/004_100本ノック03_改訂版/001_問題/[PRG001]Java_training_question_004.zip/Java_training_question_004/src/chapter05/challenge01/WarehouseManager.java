/**
 * 倉庫番のお仕事
 *
 * 倉庫管理の基礎①
 *
 * 倉庫管理業を営むXO商事に入社したYさん。
 * 立派な倉庫管理者を目指しています。
 *
 * コメントの位置に適切なコードを記述し、
 * 実行例と同じメッセージを表示してください。
 *
 * <実行例>
 *  Z先輩：
 *  それではこれより新人研修の第1回目を始めます。
 *
 *  Yさん：
 *  はい、よろしくお願いします。
 *
 *  Z先輩：
 *  まず始めに文字配列charArrayを作り、a,b,cを格納してください。
 *
 *  Yさん：
 *  はい......出来ました。
 *
 *  Z先輩：
 *  次に文字列配列strArrayを作り、abc,def,ghiを格納してください。
 *
 *  Yさん：
 *  はい......出来ました。
 *
 *  Z先輩：
 *  最後に数値配列intArrayを作り、1,2,3を格納してください。
 *
 *  Yさん：
 *  はい......出来ました。
 *
 *  Z先輩：
 *  配列charArrayの1個目の要素は何ですか。
 *
 *  Yさん：
 *  【※ここに値を出力】です。
 *
 *  Z先輩：
 *  配列strArrayの2個目の要素は何ですか。
 *
 *  Yさん：
 *  【※ここに値を出力】です。
 *
 *  Z先輩：
 *  配列intArrayの添字(index)の2にあたる値は何ですか。
 *
 *  Yさん：
 *  【※ここに値を出力】です。
 *
 *  Z先輩：
 *  はい良く出来ました。これで本日の研修を終了します。
 *
 */

package chapter05.challenge01;

public class WarehouseManager {

	public static void main(String[] args) {

		System.out.println("Z先輩：");
		System.out.println("それではこれより新人研修の第1回目を始めます。\n");
		System.out.println("Yさん：");
		System.out.println("はい、よろしくお願いします。\n");

		System.out.println("Z先輩：");
		System.out.println("まず始めに文字配列charArrayを作り、a,b,cを格納してください。\n");

		// ここからコードを挿入

		System.out.println("です。\n");
		System.out.println("Z先輩：");
		System.out.println("はい良く出来ました。これで本日の研修を終了します。");
	}

}
