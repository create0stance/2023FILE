package exception.challenge04.Nurserry.logic;

import exception.challenge04.Nurserry.Exception.CriticalConditionException;

public class Nurse {
		//必要な処理を記述する
}
