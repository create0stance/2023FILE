/**
 * 武士のお仕事
 *
 * 侍クラスを継承する①
 *
 * 侍クラス（Samurai）を継承する
 * 藩士クラス（Retainer）を作る。
 *
 * 侍クラス（Samurai）を継承する藩士クラス（Retainer）を作り、
 * getPaid()メソッド（戻り値void） を足してください。
 *
 * <実行例>
 * 侍は戦います。
 *
 * 侍1：
 * 戦うよ～。
 *
 * 藩士はそれに加えて給料をもらいます。
 *
 * 藩士1：
 * 戦うよ～。
 * 給料をもらうよ～。
 *
 */

package chapter07.challenge01;

	//処理を記述

public class CastleTown {

	public static void main(String[] args) {
		//処理を記述
	}

}
