/**
 * 倉庫番のお仕事
 *
 * 袋の中身を調べる
 *
 * 正式に配属になったYさん。
 * 初めての仕事は、AB興産から預かっている荷物の検査です。
 * 荷物は全部で5袋あり、その中で数値の5が入っている袋が
 * 何袋目なのかを調べなければなりません。
 *
 * 袋にはそれぞれ1～5の数値が入っており、
 * どの袋にどの数値が入っているのかはランダムに決定します。
 * （全部に5が入ってることもあれば、
 *   5が入っている袋が1袋もない場合もある）
 *
 * コメントの位置に適切なコードを記述し、
 * 実行例と同じメッセージを表示してください。
 *
 * <発見できた場合の実行例>
 *  E主任：
 *  AB興産の荷物の検査結果を教えてください。
 *
 *  Yさん：
 *  はい、
 *  【※ここに値を出力】袋目
 *  【※ここに値を出力】袋目
 *  に入っていました。
 *
 * <発見できなかった場合の実行例>
 *  E主任：
 *  AB興産の荷物の検査結果を教えてください。
 *
 *  Yさん：
 *  はい、
 *  入っていませんでした。
 *
 */

package chapter05.challenge03;

import java.util.Random;

public class WarehouseManager {

	public static void main(String[] args) {

		int[] ABKosanArray = new int[5];
		Random random = new Random();

		for (int i = 0; i < ABKosanArray.length; i++) {
			// Math.random
			// ABKosanArray[i] = (int) (Math.random() * 10) % 5 + 1;

			// Randomクラス
			ABKosanArray[i] = random.nextInt(11) % 5 + 1;

		}

		System.out.println("E主任：");
		System.out.println("AB興産の荷物の検査結果を教えてください。\n");

		System.out.println("Yさん：");
		System.out.println("はい、");

		boolean hitFlag = false;
		for (int i = 0; i < ABKosanArray.length; i++) {
			if (ABKosanArray[i] == 5) {
				hitFlag = true;
				System.out.println((i + 1) + "袋目");
			}
		}

		if (hitFlag) {
			System.out.println("に入っていました。");
		} else {
			System.out.println("入っていませんでした。");
		}

	}
}
