/**
 * 探検隊のお仕事
 *
 * ワニが現れた
 *
 * 進行方向にワニが3匹現れました。
 * このワニはそれぞれグーワニ、チョキワニ、パーワニの何れかです。
 *
 * グーワニは手をパーかグーにして見せるとおとなしくなり、
 * チョキワニは手をグーかチョキにして見せるとおとなしくなり、
 * パーワニは手をチョキかパーにして見せるとおとなしくなるのですが、
 * この3種は外見がまったく一緒で見分けがつきません。
 * （つまり、3匹がそれぞれ1種ずつである場合も
 *   3匹ともグーワニである可能性もあります。）
 * （※【int alligator = (int) (Math.random() * 10 % 3) + 1;】が
 *   ランダムに数値を作成する処理です。
 *   この処理によって、変数alligatorに1か2か3の数値が代入されます。）
 *
 *
 * この道を通り抜けるためには、 3匹にそれぞれ勝つか引き分けるか
 * しなければなりません。負けるとその時点でチャレンジ終了となります。
 *
 * コメントの位置にwhile文とif文を利用した処理を記述して
 * 実行例と同じメッセージを表示してください。
 *
 * <実行例>
 *  隊長：
 *  ワニ3匹発見！
 *  グーワニかチョキワニかパーワニのどれかです。
 *
 *  隊長：
 *  どの手を出して通り抜けますか
 *  （グー… 1 : チョキ… 2 : パー… 3）＞2
 *
 *  隊長：
 *  相手はチョキワニでした。
 *  1匹目通り抜け成功！
 *
 *  隊長：
 *  どの手を出して通り抜けますか
 *  （グー… 1 : チョキ… 2 : パー… 3）＞3
 *
 *  隊長：
 *  相手はグーワニでした。
 *  2匹目通り抜け成功！
 *
 *  隊長：
 *  どの手を出して通り抜けますか
 *  （グー… 1 : チョキ… 2 : パー… 3）＞1
 *
 *  隊長：
 *  相手はグーワニでした。
 *  3匹目通り抜け成功！
 *
 *  隊長：
 *  川を渡り切りました。
 *
 * <通り抜けに失敗した場合の実行例>
 *  隊長：
 *  相手はグーワニでした。
 *  通り抜けに失敗しました...
 *
 * <範囲外の手が入力された場合の実行例>
 *
 *  隊長：
 *  そんな手はありませんよ。もう一度入れてください。
 *
 * --------------------------------------------------------------------
 * 補足：Math.random()の解説
 * --------------------------------------------------------------------
 *
 * ・Mathクラス
 * 数学的な計算を行う機能をまとめたクラスです。
 *
 * ・random()
 * 0.0以上で1.0より小さい、正の符号の付いたdouble型の数値を返します。乱数を生成するために
 * 利用される処理です。
 *
 * 戻り値：double型
 * 引数：なし
 * ※「戻り値」や「引数」はテキストのLesson8で学習する要素ですが、ここではあまり難しく考えないでください。
 *
 * この問題では1～3の乱数を求める必要があります。
 * しかし、Math.random()は0.0以上で1.0より小さいdouble型の乱数を返すため、
 * そのまま利用するだけでは1～3の乱数を取得できません。、
 *
 * Math.random()の結果を10倍すれば0.0以上で10より小さい数値にすることができます。
 * この数値を3で割った余り(剰余)を求めれば0.0以上で3.0より小さい数値にすることができます。
 * この問題で必要なのは1～3の範囲の変数なので、剰余の値に1を足せば1.0以上で4.0より小さいdouble型の
 * 数値を作り出すことができます。
 *
 *
 */

package chapter05.challenge07;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Explorer {

	public static void main(String[] args) throws IOException {

		System.out.println("隊長：");
		System.out.println("ワニ3匹発見！\n");
		System.out.println("グーワニかチョキワニかパーワニのどれかです。\n");

		int alligator = 0;
		int hand = 0;
		int i = 0;

		Scanner stdIn = new Scanner(System.in);
		while (i < 3) {

			System.out.println("隊長：");
			System.out.println("どの手を出して通り抜けますか");
			System.out.print("（グー… 1 : チョキ… 2 : パー… 3）＞");

			hand = stdIn.nextInt();

			// Math.random()を使う場合
			// alligator = (int) (Math.random() * 10 % 3) + 1;

			// Randomクラスを使う場合
			Random random = new Random();
			alligator = random.nextInt(3) + 1;

			if (hand == 1) {
				if (alligator == 1 || alligator == 2) {
					System.out.println("\n隊長：");
					String kind = (alligator == 1) ? "グーワニ" : "チョキワニ";
					System.out.println("相手は" + kind + "でした。");
					System.out.println((i + 1) + "匹目通り抜け成功！\n");
				} else {
					System.out.println("\n隊長：");
					System.out.println("相手は：パーワニでした。");
					break;
				}
			} else if (hand == 2) {
				if (alligator == 2 || alligator == 3) {
					System.out.println("\n隊長：");
					String kind = (alligator == 2) ? "チョキワニ" : "パーワニ";
					System.out.println("相手は" + kind + "でした。");
					System.out.println((i + 1) + "匹目通り抜け成功！\n");
				} else {
					System.out.println("\n隊長：");
					System.out.println("相手は：グーワニでした。");
					break;
				}
			} else if (hand == 3) {
				if (alligator == 3 || alligator == 1) {
					System.out.println("\n隊長：");
					String kind = (alligator == 3) ? "パーワニ" : "グーワニ";
					System.out.println("相手は" + kind + "でした。");
					System.out.println((i + 1) + "匹目通り抜け成功！\n");
				} else {
					System.out.println("\n隊長：");
					System.out.println("相手は：チョキワニでした。");
					break;
				}
			} else {
				System.out.println("\n隊長：");
				System.out.println("そんな手はありませんよ。もう一度入れてください。\n");
				i--;
			}
			i++;
		}

		if (i == 3) {
			System.out.println("隊長：");
			System.out.println("川を渡り切りました。");
		} else {
			System.out.println("通り抜けに失敗しました...");
		}

		stdIn.close();

	}
}
