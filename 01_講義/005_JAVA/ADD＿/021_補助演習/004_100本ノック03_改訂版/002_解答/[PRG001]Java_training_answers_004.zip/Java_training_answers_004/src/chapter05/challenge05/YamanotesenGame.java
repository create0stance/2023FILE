package chapter05.challenge05;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class YamanotesenGame {

	// 山手線の駅名を配列（定数）に格納しておく
	public static final String[] STATION_NAMES = { "品川", "大崎", "五反田", "目黒", "恵比寿", "渋谷", "原宿", "代々木", "新宿", "新大久保",
			"高田馬場", "目白", "池袋", "大塚", "巣鴨", "駒込", "田端", "西日暮里", "日暮里", "鴬谷", "上野", "御徒町", "秋葉原", "神田", "東京", "有楽町",
			"新橋", "浜松町", "田町" };

	/**
	 *
	 * 山手線ゲームを実行するメソッド
	 *
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		// 未回答の（残りの）駅の数
		int rest = STATION_NAMES.length;

		// player = trueならば、人間（「あなた」）の番
		// falseならばコンピュータの番
		boolean player = true;

		System.out.println("※※※ 山手線ゲーム ※※※");
		System.out.println("      ゲームスタート！    \n");

		while (rest > 0) {
			String stationName;
			if (player) {
				stationName = stdIn.next();
			} else {
				int num = rand.nextInt(rest);
				stationName = STATION_NAMES[num];
				System.out.println(stationName);
			}

			// 配列から、入力された駅名を探す
			boolean found = false;
			for (int i = 0; i < rest; i++) {
				if (STATION_NAMES[i].equals(stationName)) {
					found = true;
					// 配列から、入力された駅名を消す（後ろの要素を左シフトする）
					for (int j = i; j < rest - 1; j++) {
						STATION_NAMES[j] = STATION_NAMES[j + 1];
					}
					rest--;
					break;
				}
			}

			// プレイヤーが正答できなかった場合
			if (player && !found) {
				System.out.println("あなたの負けです！");
				stdIn.close();
				return;
			}

			// コンピュータと人間の順番を切り替える
			player = !player;

		}

		System.out.println("あなたの勝ちです！");

		stdIn.close();
	}
}
