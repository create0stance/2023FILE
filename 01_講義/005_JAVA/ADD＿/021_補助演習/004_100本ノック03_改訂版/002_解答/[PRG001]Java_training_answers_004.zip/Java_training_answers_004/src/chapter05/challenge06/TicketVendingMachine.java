/**
 * 券売機
 * 
 * 牛丼屋の券売機を作成したい
 * この券売機は以下の流れで引換券を発券する
 * ０．Enterを押す（タッチパネル券売機で最初にタッチするイメージ）
 * １．商品を選ぶ(3つまで)※1
 * ２．商品の合計金額以上を投入（入力）する
 * ３．おつりを計算する
 * ４．選ばれた商品それぞれの引換券（シリアルナンバー付き※2）を発券する
 * ５．おつりを返却する※3
 * ６．１に戻る
 * ※1：商品は番号で選択する
 * ※1：商品番号が存在しない場合は選びなおさせる
 * ※2：シリアルナンバーは券売機が動作してから共通で採番される連番(seqNo)である
 * ※2：引換券は「商品名[seqNo]」の形式とする
 * ※3：お釣りが1円以上ある場合のみ返却する
 * 
 * 上記の動作を実現するプログラムを作成せよ
 * 
 * 動作例）
 * ご利用の方はEnterを押してください(何か入力してenter)＞a
 * 
 * いらっしゃいませ！当店の商品はこちらです！
 * 1．牛丼（並）　　　：380円
 * 2．牛丼（大盛）　　：530円
 * 3．ネギたっぷり牛丼：490円
 * 4．チキンカレー　　：590円
 * 5．お肉満腹定食　　：980円
 * 9．終了
 * 
 * 1つ目の商品をお選びください(3つまで)＞1
 * 2つ目の商品をお選びください(3つまで)＞10
 * ※その商品は現在お取り扱いがございません※
 * 2つ目の商品をお選びください(3つまで)＞4
 * 3つ目の商品をお選びください(3つまで)＞9
 * ありがとうございます。
 * 
 * 料金は920円です。
 * 料金を投入してください＞1000
 * 
 * 引換券を発券いたします：
 * 牛丼（並）[1], チキンカレー[2]
 * 
 * //お釣りがある場合
 * おつりを返却いたします：
 * 20円
 * 
 * ご利用ありがとうございました
 * 
 * いらっしゃいませ！当店の商品はこちらです！
 * ...（以下、動作を止めるまで続行）
 * 
 * ----商品が選ばれなかった場合-----
 * 1つ目の商品をお選びください(3つまで)＞9
 * 
 * ご利用ありがとうございました
 * 
 * いらっしゃいませ！当店の商品はこちらです！
 * ...（以下、動作を止めるまで続行）
 * 
 */

package chapter05.challenge06;

import java.util.Scanner;

public class TicketVendingMachine {

	// シリアルナンバーを保存するクラス変数
	static int seqNo;

	public static void main(String[] args) {
		// 商品の一覧
		String[] products = { "牛丼（並）", "牛丼（大盛）", "ネギたっぷり牛丼", "チキンカレー", "お肉満腹定食" };
		// 商品の料金一覧
		int[] price = { 380, 530, 490, 590, 980 };

		Scanner stdIn = new Scanner(System.in);
		// 無限ループ
		while (true) {
			System.out.print("ご利用の方はEnterを押してください(何か入力してenter)＞");
			stdIn.next();

			System.out.println("いらっしゃいませ！当店の商品はこちらです！");
			System.out.println("1．牛丼（並）　　　：380円");
			System.out.println("2．牛丼（大盛）　　：530円");
			System.out.println("3．ネギたっぷり牛丼：490円");
			System.out.println("4．チキンカレー　　：590円");
			System.out.println("5．お肉満腹定食　　：980円");
			System.out.println("9．終了\n");

			int[] choiceProducts = new int[3];

			for (int i = 0; i < choiceProducts.length; i++) {
				System.out.print(i + 1 + "つ目の商品をお選びください(3つまで)＞");
				int choiceNum = stdIn.nextInt();
				if (choiceNum > 0 && choiceNum < 6) {
					choiceProducts[i] = choiceNum;
				} else if (choiceNum == 9) {
					break;
				} else {
					System.out.println("※その商品は現在お取り扱いがございません※");
					i--;
				}
			}

			if (choiceProducts[0] == 0) {
				System.out.println("ご利用ありがとうございました\n");
				stdIn.close();
				continue;
			}

			System.out.println("ありがとうございます");

			int sumPrice = 0;
			for (int num : choiceProducts) {
				if (num == 0) {
					continue;
				}
				sumPrice += price[num - 1];
			}

			System.out.println("料金は" + sumPrice + "円です");
			int feedInCosts = 0;
			boolean notEnough = true;
			while (notEnough) {
				System.out.print("料金を投入してください＞");
				feedInCosts += stdIn.nextInt();
				if (sumPrice <= feedInCosts) {
					break;
				}
			}

			System.out.println("引換券を発券いたします：");
			for (int i = 0; i < choiceProducts.length; i++) {
				if (choiceProducts[i] == 0) {
					continue;
				}
				seqNo++;
				System.out.print(products[choiceProducts[i] - 1] + "[" + seqNo + "], ");
			}
			System.out.println("\n");

			int change = feedInCosts - sumPrice;

			if (change > 0) {
				System.out.println("おつりを返却いたします：");
				System.out.println(change + "円");
			}

			System.out.println("\nご利用ありがとうございました\n");
		}
	}
}
