/**
 * 読まれなかった数字
 * 
 * 1～100の数字がランダムに、一度ずつ読まれる
 * ただし、1～100の数字のうち、ランダムに1つだけ読まれない
 * この1つの数字を特定するプログラムを作成せよ
 * 
 * 例）
 * 1～100の数字がランダムに一度ずつ読まれるが、49のみ読まれない
 * 
 * 数字を読み上げます：
 * [2, 80, 73, 90, 75, 11, 93, 17, 24, 55, 98, 69, 52, 14, 82, 67, 61, 33, 30, 46, 3, 28, 27, 95, 63, 79, 35, 39, 76, 72, 26, 54, 12, 94, 62, 10, 5, 96, 8, 6, 74, 60, 40, 42, 99, 53, 16, 71, 31, 77, 81, 29, 23, 91, 41, 59, 34, 21, 57, 64, 37, 65, 87, 86, 56, 20, 32, 45, 68, 1, 88, 13, 49, 4, 18, 89, 83, 97, 100, 78, 85, 92, 48, 22, 9, 43, 36, 58, 66, 19, 84, 70, 51, 7, 38, 15, 44, 47, 25]
 * 
 * //ここに49を特定する何らかの処理を追加
 * 
 * 読まれなかった数字は＞49
 * 
 * 正解は49！さすがだ！
 * 
 */

package chapter04.challenge07;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class UnreadableNumbers {

	public static void main(String[] args) {

		// 1～100のうち、ランダムで1つの数字を準備（読まれなかった数字）
		Random rand = new Random();
		int unreadableNum = (int) rand.nextInt(100) + 1;

		// 1～100の数字を用意するための配列
		List<Integer> readNumList = new ArrayList<Integer>();

		// 1～100の数字を配列に代入
		for (int i = 0; i < 100; i++) {
			// 読まれなかった数字は配列に入れない
			if (i == unreadableNum) {
				continue;
			}
			// 配列へ数字を代入
			readNumList.add(i + 1);
		}

		// 配列の中の数字をシャッフルする
		Collections.shuffle(readNumList);

		// 配列要素を文字列出力する
		System.out.println("数字を読み上げます：");
		System.out.println(readNumList);

		// ここから読まれなかった数字（unreadableNum）を特定するコードを記述する。

		// 1～100をすべて足した数字を用意（5050）
		int sum100 = 0;
		for (int i = 0; i < 100; i++) {
			sum100 += i + 1;
		}

		// 読まれた数字（readNum）をすべて足す
		int sum = 1;
		for (int num : readNumList) {
			sum += num;
		}

		// sum100からsumを引いた数字が読まれなかった数字
		System.out.println(sum100 + " - " + sum + " = " + (sum100 - sum));

		// ここまで

		// 回答を入力する
		System.out.print("読まれなかった数字は＞");
		Scanner stdIn = new Scanner(System.in);
		int inputInt = stdIn.nextInt();

		// 回答の正否を判定
		if (inputInt == unreadableNum) {
			System.out.println("\n正解は" + unreadableNum + "！さすがだ！");
		} else {
			System.out.println("\n正解は" + unreadableNum + "！残念！");
		}

		stdIn.close();

	}

}
