/**
 * 武士のお仕事
 *
 * 侍クラスを継承する②
 *
 * 侍クラス（Samurai）を継承する
 * 浪人クラス（Ronin）を作る。
 *
 * 侍クラス（Samurai）を継承する浪人クラス（Ronin）を作り、
 * covered()メソッド（戻り値void） を足してください。
 *
 * <実行例>
 * 侍は戦います。
 *
 * 侍1：
 * 戦うよ～。
 *
 * 浪人はそれに加えて傘張りもします。
 *
 * 浪人1：
 * 戦うよ～。
 * 傘張りするよ～。
 *
 */

package chapter07.challenge02;

class Samurai {

	void fight() {
		System.out.println("戦うよ～。");
	}

}

class Ronin extends Samurai {

	void covered() {
		System.out.println("傘張りするよ～。");
	}
}

public class CastleTown {

	public static void main(String[] args) {
		System.out.println("侍は戦います。\n");

		System.out.println("侍1：");

		Samurai samurai1 = new Samurai();
		samurai1.fight();

		System.out.println("\n浪人はそれに加えて傘張りもします。\n");

		System.out.println("浪人1：");

		Ronin ronin1 = new Ronin();
		ronin1.fight();
		ronin1.covered();
	}

}
