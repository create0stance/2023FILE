/**
 * 武士のお仕事
 *
 * 侍クラスを継承する①
 *
 * 侍クラス（Samurai）を継承する
 * 藩士クラス（Retainer）を作る。
 *
 * 侍クラス（Samurai）を継承する藩士クラス（Retainer）を作り、
 * getPaid()メソッド（戻り値void） を足してください。
 *
 * <実行例>
 * 侍は戦います。
 *
 * 侍1：
 * 戦うよ～。
 *
 * 藩士はそれに加えて給料をもらいます。
 *
 * 藩士1：
 * 戦うよ～。
 * 給料をもらうよ～。
 *
 */

package chapter07.challenge01;

class Samurai {

	void fight() {
		System.out.println("戦うよ～。");
	}

}

class Retainer extends Samurai {

	void getPaid() {
		System.out.println("給料をもらうよ～。");
	}
}

public class CastleTown {

	public static void main(String[] args) {
		System.out.println("侍は戦います。\n");

		System.out.println("侍1：");

		Samurai samurai1 = new Samurai();
		samurai1.fight();

		System.out.println("\n藩士はそれに加えて給料をもらいます。\n");

		System.out.println("藩士1：");

		Retainer retainer1 = new Retainer();
		retainer1.fight();
		retainer1.getPaid();
	}

}
