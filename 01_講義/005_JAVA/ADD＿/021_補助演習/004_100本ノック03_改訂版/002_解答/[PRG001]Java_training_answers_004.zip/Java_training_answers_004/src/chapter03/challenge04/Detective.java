/**
 * 名探偵のお仕事
 *
 * 逃走経路
 *
 * コメントの位置に入力処理、switch文を入れて
 * 三通りの処理の流れができるようにしてください
 *
 * <実行例>
 * 探偵：
 * 邸を出た後の逃走経路について考えてみましょう。
 *
 * 助手：
 * 私の調査によると、逃走経路は3つあります。
 * パターンＡ：裏山に向かって延びる道です。人目につき難い道です。
 * パターンＢ：大通りに向かって延びる道です。人通りが多いです。
 * パターンＣ：住宅街に向かって延びる道です。人通りは少ないのですが、途中犬がいます。
 *
 * 探偵：
 * 目撃証言はないし、犬の鳴き声も聞こえなかったらしい
 * ということは逃走経路は...
 *
 * 1．パターンＡ
 * 2．パターンＢ
 * 3．パターンＣ
 * 数字を選んでここに入力＞
 *
 *
 * <1が入力された場合の実行例>
 * 探偵：
 * やっぱりその経路が一番可能性が高いね。
 *
 * <2が入力された場合の実行例>
 * 探偵：
 * その可能性は低いかな。
 *
 * <3が入力された場合の実行例>
 * 探偵：
 * 犬がよく知っている人物ならあり得るね。
 *
 * <1～3のどれでもない場合の実行例>
 * 探偵：
 * 他に道はありませんよ。
 *
 *
 */

package chapter03.challenge04;

import java.io.IOException;
import java.util.Scanner;

public class Detective {

	public static void main(String[] args) throws IOException {

		System.out.println("探偵：");
		System.out.println("邸を出た後の逃走経路について考えてみましょう。\n");
		System.out.println("助手：");
		System.out.println("私の調査によると、逃走経路は3つあります。");
		System.out.println("パターンＡ：裏山に向かって延びる道です。人目につき難い道です。");
		System.out.println("パターンＢ：大通りに向かって延びる道です。人通りが多いです。");
		System.out.println("パターンＣ：住宅街に向かって延びる道です。人通りは少ないのですが、途中犬がいます。\n");
		System.out.println("探偵：");
		System.out.println("目撃証言はないし、犬の鳴き声も聞こえなったらしい");
		System.out.println("ということは逃走経路は...\n");
		System.out.println("1．パターンＡ");
		System.out.println("2．パターンＢ");
		System.out.println("3．パターンＣ");
		System.out.print("数字を選んでここに入力＞");

		Scanner stdIn = new Scanner(System.in);
		int route = stdIn.nextInt();

		switch (route) {
		case 1:
			System.out.println("\n探偵：");
			System.out.println("やっぱりその経路が一番可能性が高いね。");
			break;
		case 2:
			System.out.println("\n探偵：");
			System.out.println("その可能性は低いかな。");
			break;
		case 3:
			System.out.println("\n探偵：");
			System.out.println("犬がよく知っている人物ならあり得るね。");
			break;
		default:
			System.out.println("\n探偵：");
			System.out.println("他に道はありませんよ。");
		}

		stdIn.close();

	}

}
