/**
 * ロボット工場のお仕事
 *
 * ロボットの作成
 *
 *（株）BK板金佃島工場では、新しい自社製品として
 * ロボットの開発を目指しています。
 * 開発主幹はその道の権威であるG博士、
 * 助手を務めるのは同社の新入社員Rさんです。
 *
 * コメントの位置に適切なコードを記述し、
 * 実行例と同じメッセージを表示してください。
 *
 * <実行例>
 *  G博士：
 *  今日は試作品１号、その名も「RF1」を作ってみるぞ！
 *
 *  Rさん：
 *  どんなロボットなんですか？
 *
 *  G博士：
 *  RF1は惣菜作成ロボットじゃ。材料を入れると惣菜が出てくる予定。
 *
 *  Rさん：
 *  予定？
 *
 *  G博士：
 *  今はまだエネルギーを貯められるだけ。
 *
 *  Rさん：
 *  そういうのもロボットって言うんですね。
 *
 *  G博士：
 *  早速ロボットを作ってエネルギーを10メモリ分入れてくれ。
 *
 *  Rさん：
 *  はい......１台作ってエネルギーを入れました。
 *
 */

package chapter06.challenge01;

class Robot {
	int energy;
}

public class RobotMaker {

	public static void main(String[] args) {

		System.out.println("G博士：");
		System.out.println("今日は試作品１号、その名も「RF1」を作ってみるぞ！\n");
		System.out.println("Rさん：");
		System.out.println("どんなロボットなんですか？\n");
		System.out.println("G博士：");
		System.out.println("RF1は惣菜作成ロボットじゃ。材料を入れると惣菜が出てくる予定。\n");
		System.out.println("Rさん：");
		System.out.println("予定？\n");
		System.out.println("G博士：");
		System.out.println("今はまだエネルギーを貯められるだけじゃ。\n");
		System.out.println("Rさん：");
		System.out.println("そういうのもロボットって言うんですね。\n");
		System.out.println("G博士：");
		System.out.println("早速ロボットを作ってエネルギーを10メモリ分入れてくれ。\n");

		Robot robot = new Robot();
		robot.energy = 10;

		System.out.println("Rさん：");
		System.out.println("はい......１台作ってエネルギーを入れました。\n");

	}

}
