package exception.challenge04.Nurserry.Exception;

public class CriticalConditionException extends Exception{
    private static final long serialVersionUID = 1L;

}
