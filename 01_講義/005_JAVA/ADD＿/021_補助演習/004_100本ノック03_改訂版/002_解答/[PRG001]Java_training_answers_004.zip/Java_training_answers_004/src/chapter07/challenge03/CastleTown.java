/**
 * 武士のお仕事
 *
 * オーバーライド①
 *
 * 侍クラス（Samurai）のメソッドをオーバーライドする。
 *
 * 侍クラス（Samurai）にwork()メソッド（戻り値void）を追記し、
 * 藩士クラスでオーバーライドしてください。
 *
 * <実行例>
 * 侍は働きます。
 *
 * 侍1：
 * 何かして働くよ～。
 *
 * 具体的に言うと藩士は年貢を取り立てます。
 *
 * 藩士1：
 * 年貢を取り立てるよ～。
 *
 */

package chapter07.challenge03;

class Samurai {

	void fight() {
		System.out.println("戦うよ～。");
	}

	void work() {
		System.out.println("何かして働くよ～");
	}

}

class Retainer extends Samurai {

	void getPaid() {
		System.out.println("給料をもらうよ～。");
	}

	void work() {
		System.out.println("年貢を取り立てるよ～。");
	}
}

public class CastleTown {

	public static void main(String[] args) {
		System.out.println("侍は働きます。\n");

		System.out.println("侍1：");

		Samurai samurai1 = new Samurai();
		samurai1.work();

		System.out.println("\n具体的に言うと藩士は年貢を取り立てます。\n");

		System.out.println("藩士1：");

		Retainer retainer1 = new Retainer();
		retainer1.work();

	}
}
