/**
 * 武士のお仕事
 *
 * 抽象クラス
 *
 * 抽象クラス、抽象メソッドを作る。
 *
 * 侍クラスのwork()メソッドを抽象化してください。
 *
 * <実行例>
 * 侍は働きます。
 *
 * 具体的に言うと藩士は年貢を取り立てます。
 *
 * 藩士1：
 * 年貢を取り立てるよ～。
 *
 * 具体的に言うと浪人は傘張りをします。
 *
 * 浪人1：
 * 傘張るよ～。
 *
 */

package chapter08.challenge07;

abstract class Samurai {

    protected String name;

    void fight() {
        System.out.println("戦うよ～。");
    }

    abstract void work();

}

class Retainer extends Samurai {

    protected String domain;

    public Retainer() {

    }

    public Retainer(String name, String domain) {
        this.name = name;
        this.domain = domain;
    }

    void getPaid() {
        System.out.println("給料をもらうよ～。");
    }

    void work() {
        System.out.println("年貢を取り立てるよ～。");
    }

    public String toString() {
        return "拙者は" + domain + "藩士、" + name + "ともうす。";
    }

    public boolean equals(Object object) {
        boolean isMatch;
        Retainer retainer = (Retainer) object;
        if (this.domain.equals(retainer.domain)) {
            isMatch = true;
        } else {
            isMatch = false;
        }
        return isMatch;
    }
}

class Ronin extends Samurai {

    public Ronin() {

    }

    public Ronin(String name) {
        this.name = name;
    }

    void covered() {
        System.out.println("傘張りするよ～。");
    }

    void work() {
        System.out.println("傘張るよ～。");
    }

    public String toString() {
        return "拙者は武州○△□村の浪人、" + name + "ともうす。";
    }
}

public class CastleTown {

    public static void main(String[] args) {
        System.out.println("侍は働きます。");

        System.out.println("\n具体的に言うと藩士は年貢を取り立てます。\n");

        System.out.println("藩士1：");

        Retainer retainer1 = new Retainer();
        retainer1.work();

        System.out.println("\n具体的に言うと浪人は傘張りをします。\n");

        System.out.println("浪人1：");

        Ronin ronin1 = new Ronin();
        ronin1.work();
    }
}
