/**
 * ロボット工場のお仕事
 *
 * 材料によって作るメニューを変える
 *
 * 引数として渡された食材の分量を計算して
 * 的確な料理を返すメソッドを追加します。
 *
 * コメントの位置に適切なコードを記述し、
 * 実行例と同じメッセージを表示してください。
 *
 * <実行例>
 *  Rさん：
 *  もうちょっと高度な調理機能が欲しいですね。
 *
 *  G博士：
 *  では材料の分量に応じて作るメニューを変える機能を入れてみようかの。
 *
 *  Rさん：
 *  そんなことが出来るんですか！
 *
 *  G博士：
 *  出来るとも。小麦粉170g、砂糖50g、卵1個、バター80gがそろえばクッキーを作る。
 *
 *  G博士：
 *  クッキーが出来ない場合で、卵2個、バター5gがそろえばオムレツを作る。
 *
 *  G博士：
 *  卵のみの場合はゆで卵を作る。
 *
 *  G博士：
 *  それ以外の場合は何も作らないようにするんじゃ。
 *
 *  Rさん：
 *  それは凄そうですね。完成をお待ちしています。
 *
 *  G博士：
 *  ......出来たぞ！早速動かしてみよう。
 *
 *  小麦粉の量を入力してください（グラム）＞○
 *
 *  砂糖の量を入力してください（グラム）＞○
 *
 *  卵の個数を入力してください＞○
 *
 *  バターの量を入力してください（グラム）＞○
 *
 *  <料理を作成する条件を満たす場合の実行例>
 *  【※調理できる料理】が出来ました。
 *
 *  <料理を作成する条件を満たさない場合の実行例>
 *  何も作れません。
 *
 */

package chapter06.challenge05;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

class Robot {
	int energy;
	int water;
	String name;

	void pumpWater() {
		System.out.println("水を" + water + "リットル出します。\n");
	}

	void randomWater() {
		Random random = new Random();
		// water = (int) (Math.random() * 10) % 9 + 1;
		water = random.nextInt(11) % 9 + 1;
	}

	void setWater(int water) {
		this.water = water;
	}

	void makeOmelet(int eggNum, int butterNum) {
		int bestOmeletNum1 = eggNum / 2;
		int bestOmeletNum2 = butterNum / 5;

		if (bestOmeletNum1 > bestOmeletNum2) {
			System.out.println("\n" + bestOmeletNum2 + "人分のオムレツを作成しました。\n");
		} else {
			System.out.println("\n" + bestOmeletNum1 + "人分のオムレツを作成しました。\n");
		}
	}

	int getWater() {
		return water;
	}

	String makeEggDishes(int flourNum, int sugarNum, int eggNum, int butterNum) {
		int flour = flourNum - 170;
		int sugar = sugarNum - 50;
		int egg = eggNum - 2;
		int butter = butterNum - 80;

		String menu = null;
		if ((flour >= 0) && (sugar >= 0) && (egg >= -1) && (butter >= 0)) {
			menu = "クッキー";
		} else if ((egg >= 0) && (butter >= -75)) {
			menu = "オムレツ";
		} else if (egg >= -1) {
			menu = "ゆで卵";
		} else {
			menu = null;
		}
		return menu;
	}
}

public class RobotMaker {

	public static void main(String[] args) throws IOException {

		System.out.println("Rさん：");
		System.out.println("もうちょっと高度な調理機能が欲しいですね。\n");
		System.out.println("G博士：");
		System.out.println("では材料の分量に応じて作るメニューを変える機能を入れてみようかの。\n");
		System.out.println("Rさん：");
		System.out.println("そんなことが出来るんですか！\n");
		System.out.println("G博士：");
		System.out.println("出来るとも。小麦粉170g、砂糖50g、卵1個、バター80gがそろえばクッキーを作る。\n");
		System.out.println("G博士：");
		System.out.println("クッキーが出来ない場合で、卵2個、バター5gがそろえばオムレツを作る。\n");
		System.out.println("G博士：");
		System.out.println("卵のみの場合はゆで卵を作る。\n");
		System.out.println("G博士：");
		System.out.println("それ以外の場合は何も作らないようにするんじゃ。\n");
		System.out.println("Rさん：");
		System.out.println("それは凄そうですね。完成をお待ちしています。\n");
		System.out.println("G博士：");
		System.out.println("......出来たぞ！早速動かしてみよう。\n");

		Scanner stdIn = new Scanner(System.in);

		System.out.print("小麦粉の量を入力してください（グラム）＞");
		int flourNum = stdIn.nextInt();

		System.out.print("\n砂糖の量を入力してください（グラム）＞");
		int sugarNum = stdIn.nextInt();

		System.out.print("\n卵の個数を入力してください＞");
		int eggNum = stdIn.nextInt();

		System.out.print("\nバターの量を入力してください（グラム）＞");
		int butterNum = stdIn.nextInt();

		Robot robot = new Robot();
		String menu = robot.makeEggDishes(flourNum, sugarNum, eggNum, butterNum);
		if (menu != null) {
			System.out.println("\n" + menu + "が出来ました。");
		} else {
			System.out.println("\n何も作れません。");
		}
		
		stdIn.close();
	}

}
