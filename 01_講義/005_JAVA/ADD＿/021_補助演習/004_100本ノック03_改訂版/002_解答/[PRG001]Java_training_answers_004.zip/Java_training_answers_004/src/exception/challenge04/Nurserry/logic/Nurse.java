package exception.challenge04.Nurserry.logic;

import exception.challenge04.Nurserry.Exception.CriticalConditionException;

public class Nurse {
    private String name;

    public Nurse(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void takeTemperature(NurserySchoolChild child)
            throws CriticalConditionException {
        if (child.getTemperature() >= 38) {
            System.out.println("\n" + child.getName() + "は重体です。");
            throw new CriticalConditionException();
        } else {
            System.out.println("\n" + child.getName() + "の体温は"
                    + child.getTemperature() + "度です。");
        }
    }
}
