/**
 * 名探偵のお仕事
 *
 * 容疑者の絞り込み
 *
 * 論理演算子&&を利用し、
 * コメントの位置に適切なコードを記述してください。
 *
 * <実行例>
 * 探偵：
 * 容疑者の特定は出来ていますか？
 *
 * 助手：
 * 私の調査によると、容疑者はＬ氏、Ｍ氏、Ｎ氏、Ｏ氏の4名が挙がっています。
 * 各人の特徴は、次の通りです。
 *
 * Ｌ氏：依頼主の知人。体重100kg、身長190cmの巨漢。
 * Ｍ氏：依頼主の隣人。体重65kg、身長170cmの中肉中背。
 * Ｎ氏：依頼主の後輩。体重79kg、身長186cmの痩せ身。
 * Ｏ氏：通りすがりの人。体重70kg、身長192cmのヒョロ長。
 *
 * 探偵：
 * あなたが犯人だと思う人の身長と体重を入れてみてください。
 *
 * 身長をここに入力＞○○
 * 体重をここに入力＞○○
 *
 *
 * <犯人の可能性がある場合の実行例>
 * 探偵：
 * その方は犯人である可能性がありますね。
 *
 * <犯人の可能性がない場合の実行例>
 * 探偵：
 * その方は犯人ではありませんね。
 *
 */

package chapter03.challenge05;

import java.io.IOException;
import java.util.Scanner;

public class Detective {

	public static void main(String[] args) throws IOException {

		System.out.println("探偵：");
		System.out.println("容疑者の特定は出来ていますか？\n");
		System.out.println("助手：");
		System.out.println("私の調査によると、容疑者はＬ氏、Ｍ氏、Ｎ氏、Ｏ氏の4名が挙がっています。");
		System.out.println("各人の特徴は、次の通りです。\n");
		System.out.println("Ｌ氏：依頼主の知人。体重100kg、身長190cmの巨漢。");
		System.out.println("Ｍ氏：依頼主の隣人。体重65kg、身長170cmの中肉中背。");
		System.out.println("Ｎ氏：依頼主の後輩。体重79kg、身長186cmの痩せ身。");
		System.out.println("Ｏ氏：通りすがりの人。体重70kg、身長192cmのヒョロ長。\n");
		System.out.println("探偵：");
		System.out.println("あなたが犯人だと思う人の身長と体重を入れてみてください。\n");

		Scanner stdIn = new Scanner(System.in);
		System.out.print("身長をここに入力＞");
		int height = stdIn.nextInt();
		System.out.print("体重をここに入力＞");
		int weight = stdIn.nextInt();

		if (height > 185 && (weight < 80 && weight >= 60)) {
			System.out.println("\n探偵：");
			System.out.println("その方は犯人である可能性がありますね。");
		} else {
			System.out.println("\n探偵：");
			System.out.println("その方は犯人ではありませんね。");
		}

		stdIn.close();

	}

}
