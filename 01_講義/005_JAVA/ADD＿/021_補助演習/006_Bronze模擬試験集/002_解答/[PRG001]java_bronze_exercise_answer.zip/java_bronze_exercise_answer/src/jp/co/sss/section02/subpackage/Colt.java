package jp.co.sss.section01.subpackage;

public class Colt {

    public Colt(){
        System.out.println("import complete");
    }

}