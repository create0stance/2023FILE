/**
 * ���̃R�[�h���R���p�C���A���s����Ƃǂ̂悤�Ȍ��ʂɂȂ�܂���
 * (1�I��)
 * 
 * A) true true false false false
 * B) true true false false true
 * C) false false false false false
 * D) false true false true false
 * 
 */

public class Question009 {
    public static void main(String[] args) {
        int x = 5;
        int y = 3;
        int z = 2;

        System.out.print(x == y);
        System.out.print(" ");
        System.out.print(x > y);
        System.out.print(" ");
        System.out.print(x != (y + z));
        System.out.print(" ");
        System.out.print(!(y <= z));
        System.out.print(" ");
        System.out.print((y % z) == 0);
    }
    
}

