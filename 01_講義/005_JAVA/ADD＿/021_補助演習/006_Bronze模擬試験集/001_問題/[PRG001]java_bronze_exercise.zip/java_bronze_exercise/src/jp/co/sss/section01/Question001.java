/**
 * Account�N���X�̃R���X�g���N�^��`�Ƃ��Đ��������̂͂ǂꂩ
 * �i2�I���j
 * 
 */

 class Account001 {
    private int balance;

    // A
    // Account001() {
    //     balance = 0;
    // }

    // B
    // public void Account001() {
    //     balance = 0;
    // }

    // C
    // public Accounts001(int balance){
    //     this.balance = balance;
    // }

    // D
    // private Account001(int valance) {
    //     this.balance = balance;
    // }

    // E
    // final Account001() {
    //     balance = 0;
    // }
}

public class Question001 {
    public static void main(String[] args) {
        Account001 account = new Account001();
    }
}

