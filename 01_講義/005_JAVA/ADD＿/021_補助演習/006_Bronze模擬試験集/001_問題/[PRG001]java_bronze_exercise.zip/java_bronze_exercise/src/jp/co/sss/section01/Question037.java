/**
 * ���̃R�[�h���R���p�C���A���s����Ƃǂ̂悤�Ȍ��ʂɂȂ�܂���
 * �i1�I���j
 * 
 * A) Base2
 *    Derived2
 * 
 * B) Base1
 *    Derived2
 * 
 * C) Derived2
 *    Base1
 * 
 * D) Derived2
 *    Base2
 * 
 * E) Derived1
 *    Base1
 */


class Base037 {
    Base037() {
        System.out.println("Base1");
    }

    Base037(String str) {
        System.out.println("Base2");
    }
}

class Derived extends Base037 {
    Derived() {
        System.out.println("Derived1");
    }

    Derived(String str) {
        System.out.println("Derived2");
    }
}

public class Question037 {
    public static void main(String[] args) {
        Derived obj = new Derived("demo");
    }

}

