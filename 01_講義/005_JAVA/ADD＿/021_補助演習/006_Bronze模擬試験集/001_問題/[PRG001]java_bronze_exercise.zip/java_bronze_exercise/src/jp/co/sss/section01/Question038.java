/**
 * �z��array�̗v�f�����ׂďo�͂���̂ɓK�����R�[�h��
 * �I�����Ă��������B
 * �i1�I���j
 */


public class Question038 {
    public static void main(String[] args) {
        int[] array = new int[5];
        array[0] = 1;
        array[1] = 2;
        array[2] = 3;
        array[3] = 4;
        array[4] = 5;

        // A
        // for (int i = 0; i < array.length; i++) {
        //     System.out.println(array[i]);
        // }

        // B
        // while(int i = 0; i < array.length;) {
        //     System.out.println(array[i]);
        //     i++;
        // }

        // C
        // for (int i = 1; i < array.length; i++) {
        //     System.out.println(array[i]);
        // }

        // D
        // while(int i = 1; i < array.length;) {
        //     System.out.println(array[i]);
        //     i++;
        // }
    }

}

