/**
 * insert code here�ɑ}�����Đ����printFlavor()�����삷��̂͂ǂ̃R�[�h�ł���
 * �i1�I���j
 * 
 * A) printFlavor();
 * B) coffee.printFlavor();
 * C) (Coffee)coffee.printFlavor();
 * D) (CafeLatte)coffee.printFlavor();
 * E) ((CafeLatte)coffee).printFlavor();
 */


class Coffee {
    String flavor;
}

class CafeLatte extends Coffee {

    CafeLatte(String flavor) {
        this.flavor = flavor;
    }

    public void printFlavor() {
        System.out.println("Add : " + flavor);
    }
}

public class Question055 {
    public static void main(String[] args) {
        Coffee coffee = new CafeLatte("Milk");
        // insert code here
    }

}
