/**
 * ���̃R�[�h���R���p�C���A���s����Ƃǂ̂悤�Ȍ��ʂɂȂ�܂���
 * 
 * A) not equal
 *    equal
 * 
 * B) equal
 *    equal
 * 
 * C) not equal
 *    not equal
 * 
 * D) equal
 *    not equal
 */


public class Question002 {
    public static void main(String[] args) {
        String var1 = "Java";
        String var2 = "Java";
        String var3 = new String("Java");

        if (var1 == var2) {
            System.out.println("equal");
        } else {
            System.out.println("not equal");
        }

        if (var1 == var3) {
            System.out.println("equal");
        } else {
            System.out.println("not equal");
        }
    }

}

