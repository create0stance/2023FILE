
public class Question001 {
    public static void main(String[] args) {
        /**
         * �z��̐錾�Ƃ��ėL���Ȃ��̂�I��ł�������
         * �i3�I���j
         * 
         * A) int[] array = new int(3);
         * 
         * B) int[] array = null; 
         *    array = new int[3];
         * 
         * C) int array[3];
         * 
         * D) int array = new int[3];
         * 
         * E) int[] array = {10, 20, 30, 40};
         * 
         * F) int[] array = new int[3];
         * 
         * G) int[] array = new int()[3];
         * 
         */
    }
}

