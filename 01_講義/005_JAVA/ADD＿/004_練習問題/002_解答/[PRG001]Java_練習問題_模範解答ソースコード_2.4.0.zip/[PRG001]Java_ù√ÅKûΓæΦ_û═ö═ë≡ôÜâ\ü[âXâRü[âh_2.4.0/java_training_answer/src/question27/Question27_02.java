package question27;

import question26.question2602.Question26_02;
import question26.question2603.Question26_03;

public class Question27_02 {
	public static void main(String[] args) {
		Question26_02 q2602 = new Question26_02();
		Question26_03 q2603 = new Question26_03();
		q2602.question2();
		q2603.question3();
	}
}
