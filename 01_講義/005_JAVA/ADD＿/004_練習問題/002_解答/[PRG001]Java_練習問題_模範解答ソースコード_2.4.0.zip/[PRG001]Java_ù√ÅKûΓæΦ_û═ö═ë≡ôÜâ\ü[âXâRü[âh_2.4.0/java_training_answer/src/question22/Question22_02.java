package question22;

public class Question22_02 {
	public static void main(String[] args) {
		Question22_01 q2201 = new Question22_01();
		q2201.show();
	}
}
