package question18;

public class Question18_01 {
	static int num;

	static void message() {
		System.out.println("メッセージを表示します");
		System.out.println("numの初期値は" + num + "です");
	}

	public static void main(String[] args) {
		message();
	}
}
