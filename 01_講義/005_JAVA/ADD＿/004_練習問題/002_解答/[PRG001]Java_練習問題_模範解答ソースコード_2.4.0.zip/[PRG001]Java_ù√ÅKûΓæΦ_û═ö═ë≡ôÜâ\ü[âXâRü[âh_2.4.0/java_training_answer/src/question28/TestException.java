package question28;

/**
 * テスト例外クラス
 */
public class TestException extends Exception{
	public TestException() {}
	public TestException(String msg) {
		super(msg);
	}
	

}
