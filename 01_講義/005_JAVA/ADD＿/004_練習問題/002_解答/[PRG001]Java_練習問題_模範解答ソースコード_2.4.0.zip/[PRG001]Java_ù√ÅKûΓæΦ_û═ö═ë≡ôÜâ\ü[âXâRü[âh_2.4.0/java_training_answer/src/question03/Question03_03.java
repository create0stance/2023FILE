package question03;

class Question03_03 {
    public static void main(String[] args) {
		// メッセージの出力
		System.out.print("表示を");
		System.out.println("行います");
		System.out.print("終了します");
	}
}
