package question14;

public class Question14_02 {
	public static void main(String[] args) {
		Triangle triangle = new Triangle();

		int calc = triangle.triangleCalc(4, 3);
		System.out.println("三角形の面積は" + calc + "です");
	}
}
