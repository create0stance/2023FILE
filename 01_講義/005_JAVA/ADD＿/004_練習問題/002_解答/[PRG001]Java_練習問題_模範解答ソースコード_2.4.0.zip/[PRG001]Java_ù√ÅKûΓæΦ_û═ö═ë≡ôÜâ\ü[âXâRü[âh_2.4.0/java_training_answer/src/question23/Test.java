package question23;

/**
 * テストクラス
 */
public class Test {
	/** 文字列 */
	private String str;

	/**
	 * 文字列を取得
	 *
	 * @return 文字列
	 */
	public String getStr() {
		return str;
	}

	/**
	 * 文字列を設定
	 *
	 * @param str 文字列
	 */
	public void setStr(String str) {
		this.str = str;
	}
}
