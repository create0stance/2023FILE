package question12;

/**
 * 猫クラス
 */
class Cat {
	/** 名前 */
	String name;
	/** 年齢 */
	int age;
	/** 身長 */
	double height;
	/** 体重 */
	double weight;
	/** 好きな食べ物 */
	String favoriteFood;
}
