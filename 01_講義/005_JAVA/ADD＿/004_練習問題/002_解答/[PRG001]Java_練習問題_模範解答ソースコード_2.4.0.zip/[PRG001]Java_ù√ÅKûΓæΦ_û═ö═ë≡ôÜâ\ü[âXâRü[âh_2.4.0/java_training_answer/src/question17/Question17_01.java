package question17;

public class Question17_01 {
	Question17_01() {
		System.out.println("コンストラクタです");
	}

	Question17_01(String str) {
		System.out.println("2つ目のコンストラクタです");
	}

	Question17_01(int num, String str) {
		System.out.println("3つ目のコンストラクタです");
	}
}
