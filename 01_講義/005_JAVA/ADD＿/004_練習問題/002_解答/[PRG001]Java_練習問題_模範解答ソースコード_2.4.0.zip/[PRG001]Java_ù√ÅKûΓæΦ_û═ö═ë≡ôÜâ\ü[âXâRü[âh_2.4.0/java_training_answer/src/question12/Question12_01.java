package question12;

public class Question12_01 {
	public static void main(String[] args) {
		Cat cat = new Cat();

		cat.name = "コタロウ";
		cat.age = 7;

		System.out.println("名前は" + cat.name + "です");
		System.out.println("年齢は" + cat.age + "歳です");
	}
}
