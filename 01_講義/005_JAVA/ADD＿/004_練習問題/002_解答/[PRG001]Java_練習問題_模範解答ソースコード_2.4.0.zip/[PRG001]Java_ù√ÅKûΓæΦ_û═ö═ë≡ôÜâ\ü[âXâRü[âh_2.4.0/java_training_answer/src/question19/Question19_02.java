package question19;

public class Question19_02 {
	public static void main(String[] args) {
		String str = "こんにちは、こんばんは。";
		System.out.println(str);
		System.out.println("4文字目は\'" + str.charAt(3) + "\'になります");
	}
}
