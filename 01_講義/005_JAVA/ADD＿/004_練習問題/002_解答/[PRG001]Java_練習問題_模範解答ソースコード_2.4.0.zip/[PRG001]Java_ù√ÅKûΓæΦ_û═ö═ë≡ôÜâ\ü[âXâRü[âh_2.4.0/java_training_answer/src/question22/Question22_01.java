package question22;

public class Question22_01 extends Parent {
	void show() {
		System.out.println("オーバーライドしたshow()メソッドです");
	}
}
