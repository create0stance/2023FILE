package question22;
/**
 * 親クラス
 */
public class Parent {

	/**
	 * 画面出力
	 */
	void show() {
		System.out.println("show()メソッドです");
	}
}
