package question25;

/**
 * 準備インターフェイス
 */
interface Preparation {
	void show();
}
