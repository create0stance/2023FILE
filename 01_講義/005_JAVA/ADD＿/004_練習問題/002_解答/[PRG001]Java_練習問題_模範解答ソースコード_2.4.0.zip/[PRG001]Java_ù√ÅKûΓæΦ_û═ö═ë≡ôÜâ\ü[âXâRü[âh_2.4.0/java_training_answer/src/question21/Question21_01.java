package question21;

public class Question21_01 extends Inheritance {

}