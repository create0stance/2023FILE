package question19;

public class Question19_01 {
	public static void main(String[] args) {
		String str = "おはようございます。";
		System.out.println(str);
		System.out.println("文字数は" + str.length() + "になります");
	}
}
