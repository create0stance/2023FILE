package question25;

public class Question25_05 {
	public static void main(String[] args) {
		Voice voice = new Voice();
		voice.bark();
		voice.cry();
	}
}
