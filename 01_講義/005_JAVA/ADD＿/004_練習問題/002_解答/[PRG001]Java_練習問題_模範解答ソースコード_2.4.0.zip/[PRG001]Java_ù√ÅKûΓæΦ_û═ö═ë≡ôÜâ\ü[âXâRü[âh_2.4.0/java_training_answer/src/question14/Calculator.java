package question14;
/**
 * 電卓クラス
 */
public class Calculator {

    /**
     * 足し算を行う
     *
     * @param num1 足される数
     * @param num2 足す数
     * @return 計算結果
     *
     */
	int sum(int num1 ,int num2) {
		int result = num1 + num2;
		return result;
	}
}
