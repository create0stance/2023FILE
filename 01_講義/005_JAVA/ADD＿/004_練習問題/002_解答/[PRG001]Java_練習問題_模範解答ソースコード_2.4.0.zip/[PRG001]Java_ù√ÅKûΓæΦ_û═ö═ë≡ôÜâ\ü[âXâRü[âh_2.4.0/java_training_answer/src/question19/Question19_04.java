package question19;

public class Question19_04 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("ありがとう");
		System.out.println(sb);

		System.out.println("文字列の追加を行います");

		sb.append("ございました");
		System.out.println(sb);
	}
}
