package question25;

/**
 * ディスプレイクラス
 */
public class DisplayImpl implements Question25_01 {


	/**
	 * メソッドの実行を確認するための処理
	 */
	public void display() {
		System.out.println("インターフェイスを実装しました");
	}
}
