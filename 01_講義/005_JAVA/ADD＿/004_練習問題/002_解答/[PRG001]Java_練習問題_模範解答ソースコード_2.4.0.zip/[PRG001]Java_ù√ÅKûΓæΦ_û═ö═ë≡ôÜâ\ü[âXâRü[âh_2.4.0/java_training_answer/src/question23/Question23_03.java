package question23;

public class Question23_03 {
	public static void main(String[] args) {
		String str = new String("エリマキトカゲ");

		if ("エリマキトカゲ".equals(str)) {
			System.out.println("文字列は エリマキトカゲ です");
		}
	}
}
