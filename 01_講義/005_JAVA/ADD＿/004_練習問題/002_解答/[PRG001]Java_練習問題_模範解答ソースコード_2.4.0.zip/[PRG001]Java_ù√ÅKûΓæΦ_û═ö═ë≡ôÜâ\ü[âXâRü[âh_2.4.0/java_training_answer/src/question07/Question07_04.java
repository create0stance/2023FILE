package question07;

public class Question07_04 {
	public static void main(String[] args) {
		double dnum = 10.5;
		int inum = (int)dnum;
		System.out.println("dnumをinumに代入すると" + inum + "になります");
	}
}
