package question26;

/**
 * 26_01クラス
 */
public class Question26_01 {
	/**
	 * おはようございますと画面出力
	 */
	public void question1() {
		System.out.println("おはようございます");
	}
}
