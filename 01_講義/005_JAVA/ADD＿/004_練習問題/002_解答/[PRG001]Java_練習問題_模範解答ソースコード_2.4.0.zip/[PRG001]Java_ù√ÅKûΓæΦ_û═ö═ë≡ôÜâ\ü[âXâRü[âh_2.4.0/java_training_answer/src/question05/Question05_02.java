package question05;

public class Question05_02 {
	public static void main(String[] args) {
		int spam = 50;
		System.out.println("変数の値は" + spam + "です");

		double ham = 10.5;
		System.out.println("変数の値は" + ham + "です");

		boolean eggs = true;
		System.out.println("変数の値は" + eggs + "です");
	}
}
