package question26.question2602;

/**
 * 26_02クラス
 */
public class Question26_02 {
	/**
	 * こんにちはと画面出力
	 */
	public void question2() {
		System.out.println("こんにちは");
	}
}
