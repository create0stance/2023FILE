package question23;

public class Question23_01 {
	public static void main(String[] args) {
		Frog frog = new Frog();
		System.out.println(frog);
	}
}

