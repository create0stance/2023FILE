package question16;

public class Question16_01 {
	public void test() {
		System.out.println("テスト");
	}

	public void test(String str) {
		System.out.println(str);
	}

	public void test(int num, String str) {
		System.out.println(num + "回目の" + str);
	}
}
