package question08;

public class Question08_02 {
	public static void main(String[] args) {
		int[] test ={88, 62, 54, 76, 45};

		int sum = test[0] + test[1] + test[2] + test[3] + test[4];

		System.out.println("全員のテストの合計は" + sum + "点です");
	}
}
