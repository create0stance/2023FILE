package question21;

public class Question21_02 {
	public static void main(String[] args) {
		Question21_01 q2101 = new Question21_01();

		q2101.setHobby("サッカー");

		System.out.println("趣味は" + q2101.getHobby() + "です");
	}

}
