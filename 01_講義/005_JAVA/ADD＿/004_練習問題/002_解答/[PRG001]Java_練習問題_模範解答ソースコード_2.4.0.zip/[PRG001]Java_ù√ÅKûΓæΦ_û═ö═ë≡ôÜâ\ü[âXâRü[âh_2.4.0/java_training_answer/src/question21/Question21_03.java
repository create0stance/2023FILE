package question21;

public class Question21_03 {
	public static void main(String[] args) {
		new Question21_01();
	}
}
