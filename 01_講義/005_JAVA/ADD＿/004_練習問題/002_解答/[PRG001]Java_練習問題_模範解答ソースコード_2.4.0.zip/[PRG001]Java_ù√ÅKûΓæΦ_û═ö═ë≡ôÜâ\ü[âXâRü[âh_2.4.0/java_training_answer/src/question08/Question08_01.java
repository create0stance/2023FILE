package question08;

public class Question08_01 {
	public static void main(String[] args) {
		// 1つ目
		int[] sample;
		sample = new int[5];

		// 2つ目
		int[] sample2 = new int[5];
	}
}
