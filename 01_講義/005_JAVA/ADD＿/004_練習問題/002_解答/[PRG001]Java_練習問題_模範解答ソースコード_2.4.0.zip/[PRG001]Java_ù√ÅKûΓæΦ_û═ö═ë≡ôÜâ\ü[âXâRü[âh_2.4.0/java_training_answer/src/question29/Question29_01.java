package question29;

import java.util.ArrayList;
import java.util.List;

public class Question29_01 {
	public static void main(String[] args) {
		List<String> fruits = new ArrayList<>();

		fruits.add("みかん");
		fruits.add("ぶどう");
		fruits.add("いちご");

		System.out.println(fruits.get(0));
		System.out.println(fruits.get(1));
		System.out.println(fruits.get(2));
	}
}
