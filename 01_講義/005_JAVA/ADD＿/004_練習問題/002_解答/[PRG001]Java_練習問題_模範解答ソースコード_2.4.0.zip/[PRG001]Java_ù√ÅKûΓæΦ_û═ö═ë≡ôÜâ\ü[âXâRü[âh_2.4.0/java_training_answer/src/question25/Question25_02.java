package question25;

public class Question25_02 {
	public static void main(String[] args) {
		DisplayImpl display = new DisplayImpl();
		display.display();
	}
}
