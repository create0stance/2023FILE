package question19;

public class Question19_05 {
	public static void main(String[] args) {
		int num = 30;
		int sum = 50;

		System.out.println("数値の比較をします");
		System.out.println("変数numとsumで大きい方の値は" + Math.max(num, sum) + "です");
	}
}
