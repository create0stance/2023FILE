package question26.question2603;

/**
 * 26_03クラス
 */
public class Question26_03 {
	/**
	 * こんばんはと画面出力
	 */
	public void question3() {
		System.out.println("こんばんは");
	}
}
