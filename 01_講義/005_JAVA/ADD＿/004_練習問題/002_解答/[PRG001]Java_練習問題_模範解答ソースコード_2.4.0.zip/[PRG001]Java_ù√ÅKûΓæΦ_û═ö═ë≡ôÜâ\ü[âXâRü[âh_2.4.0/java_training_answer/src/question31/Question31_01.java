package question31;

public class Question31_01 {
	public static void main(String args[]) {
		int intNumber = 80;
		double doubleNumber = 10.5;
		double sum = intNumber + doubleNumber;

		System.out.println("合計値は" + sum + "です");
	}
}
