package question24;

/**
 * ディスプレイクラス
 */
public class Display extends Question24_01 {
	void show(){
		System.out.println("馬には乗ってみよ人には添うてみよ");
	}
}
