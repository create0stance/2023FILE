package question11;

public class Question11_01 {
	public static void main(String[] args) {
		int number = 2;

		if (number == 2) {
			System.out.println("numberは2です");
		} else if (number >= 1) {
			System.out.println("numberは1以上です");
		} else {
			System.out.println("numberはそれ以外の数値です");
		}

		System.out.println("処理を終了します");
	}
}
