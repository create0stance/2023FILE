package question25;

/**
 * Talk_2インターフェイス
 */
public interface Talk_2 {
	void cry();
}
