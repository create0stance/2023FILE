package question05;

public class Question05_04 {
	public static void main(String[] args) {
		int i1 = 20;
		int i2 = 30;
		char c = 'A';
		double d = 3.14;
		String str = "明日から3連休！！！";

		System.out.println(str);
		System.out.println("円周率はいつでも" + d + "です。");

		System.out.print(c);
		System.out.print(i1);
		System.out.println(i2);
		// 以下の記述でも可
		//System.out.println("" + c + i1 + i2);
	}
}
