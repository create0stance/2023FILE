package question25;

/**
 * Talk_1インターフェイス
 */
public interface Talk_1 extends Talk_2 {
	void bark();
}
