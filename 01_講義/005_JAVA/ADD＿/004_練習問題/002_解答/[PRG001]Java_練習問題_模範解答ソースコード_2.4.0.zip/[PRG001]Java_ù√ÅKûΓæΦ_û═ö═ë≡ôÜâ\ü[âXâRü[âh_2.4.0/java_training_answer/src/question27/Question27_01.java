package question27;

import question26.Question26_01;

public class Question27_01 {
	public static void main(String[] args) {
		Question26_01 q2601 = new Question26_01();
		q2601.question1();
	}
}
