package question14;

public class Question14_03 {
	public static void main(String[] args) {
		Circle circle = new Circle();

		double result = circle.circleCalc(3.0);
		System.out.println("円の面積は" + result + "です");
	}
}
