package question10;

public class Question10_01 {
	public static void main(String[] args) {
		for (int i = 0; i < 3; i++) {
			System.out.println((i + 1) + "回目の処理");
		}
		System.out.println("処理を終了します");
	}
}
