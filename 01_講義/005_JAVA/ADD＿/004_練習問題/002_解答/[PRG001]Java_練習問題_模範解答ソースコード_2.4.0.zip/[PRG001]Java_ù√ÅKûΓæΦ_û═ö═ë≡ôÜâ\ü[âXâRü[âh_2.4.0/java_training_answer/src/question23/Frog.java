package question23;

/**
 * 蛙クラス
 */
public class Frog {

	/**
	 * toStringをオーバーライドして文字列を返す
	 *
	 * @return str 文字列
	 */
	public String toString() {
		String str = "井の中の蛙、大海を知らず";
		return str;
	}
}
