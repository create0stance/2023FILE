package question03;

public class Question03_02 {
	public static void main(String[] args) {
		System.out.println("赤パジャマ");
		System.out.println("青パジャマ");
		System.out.println("黄パジャマ");
	}
}
