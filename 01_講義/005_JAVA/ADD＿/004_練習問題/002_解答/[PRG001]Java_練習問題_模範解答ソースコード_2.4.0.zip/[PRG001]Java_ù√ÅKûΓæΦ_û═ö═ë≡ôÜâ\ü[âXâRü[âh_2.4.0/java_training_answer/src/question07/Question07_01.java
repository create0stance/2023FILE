package question07;

public class Question07_01 {
	public static void main(String[] args) {
		System.out.println("12＋3は" + (12 + 3) + "です");
		System.out.println("12－3は" + (12 - 3) + "です");
		System.out.println("12×3は" + (12 * 3) + "です");
		System.out.println("12÷3は" + (12 / 3) + "です");
		System.out.println("4÷3の余りは" + (4 % 3) + "です");
	}
}
