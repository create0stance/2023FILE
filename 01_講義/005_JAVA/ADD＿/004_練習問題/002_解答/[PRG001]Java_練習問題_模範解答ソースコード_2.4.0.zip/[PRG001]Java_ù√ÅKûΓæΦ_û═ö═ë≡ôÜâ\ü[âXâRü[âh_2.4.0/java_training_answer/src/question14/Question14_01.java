package question14;

public class Question14_01 {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();

		int result = calculator.sum(1, 2);
		System.out.println("足し算の結果は" + result + "です");
	}
}
