package question07;

public class Question07_05 {
	public static void main(String[] args) {
		int inum = 10;
		double dnum = inum;
		System.out.println("inumをdnumに代入すると" + dnum + "になります");
	}
}