package question24;

public class Question24_02 {
	public static void main(String[] args) {
		Display display = new Display();
		display.show();
	}
}
