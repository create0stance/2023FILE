package question23;

public class Question23_04 {
	public static void main(String[] args) {
		Test test1 = new Test();
		Test test2 = new Test();

		System.out.println("1つ目のハッシュコードは" + test1 + "です");
		System.out.println("2つ目のハッシュコードは" + test2 + "です");
	}
}
