package question13;

public class Question13_01 {
	public static void main(String[] args) {
		Dog dog = new Dog();

		dog.showName("ダニエル");

	}
}
