package question13;

public class Question13_02 {
	public static void main(String[] args) {
		Dog dog = new Dog();

		dog.showAge(5);
		dog.showProfile(5, "ジャーキー");
	}
}
