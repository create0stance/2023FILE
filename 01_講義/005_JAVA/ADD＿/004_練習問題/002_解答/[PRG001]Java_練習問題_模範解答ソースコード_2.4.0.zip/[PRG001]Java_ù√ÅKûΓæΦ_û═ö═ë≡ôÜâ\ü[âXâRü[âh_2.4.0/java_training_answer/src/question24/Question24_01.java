package question24;

abstract class Question24_01 {
	abstract void show();
}
