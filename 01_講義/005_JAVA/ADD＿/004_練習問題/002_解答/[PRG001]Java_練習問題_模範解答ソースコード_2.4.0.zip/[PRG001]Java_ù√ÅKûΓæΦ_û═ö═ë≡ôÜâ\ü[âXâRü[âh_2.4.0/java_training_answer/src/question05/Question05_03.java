package question05;

public class Question05_03 {
	public static void main(String[] args) {
		int i = 12;
		double d = 1.6;
		String str = "こんにちは";
		boolean b = true;

		System.out.println(i);
		System.out.println(d);
		System.out.println(str);
		System.out.println(b);
	}
}
