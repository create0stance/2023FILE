package question25;

/**
 * Showクラス
 */
public class Show implements Question25_01, Preparation {
	/**
	 * display
	 */
	public void display() {
		System.out.println("インターフェイスQuestion25_01を実装しました");
	}

	/**
	 * show
	 */
	public void show() {
		System.out.println("インターフェイスPreparationを実装しました");
	}
}
