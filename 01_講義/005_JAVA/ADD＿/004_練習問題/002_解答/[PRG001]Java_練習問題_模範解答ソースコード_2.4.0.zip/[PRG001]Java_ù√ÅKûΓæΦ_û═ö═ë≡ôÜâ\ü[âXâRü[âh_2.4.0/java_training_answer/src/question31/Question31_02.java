package question31;

public class Question31_02 {
	public static void main(String args[]) {
		int num;
		num = 5 * 6;
		int messageNo = 0;
		String[] str = {"30以上50未満", "25以上30未満"};

		if (messageNo == 0) {
			if (30 <= num && num < 50) {
				System.out.println(str[messageNo]);
			}
		} else if (messageNo == 1) {
			if (25 <= num && num < 30) {
				System.out.println(str[messageNo]);
			}
		}

		System.out.println("処理を終了します");
	}
}
