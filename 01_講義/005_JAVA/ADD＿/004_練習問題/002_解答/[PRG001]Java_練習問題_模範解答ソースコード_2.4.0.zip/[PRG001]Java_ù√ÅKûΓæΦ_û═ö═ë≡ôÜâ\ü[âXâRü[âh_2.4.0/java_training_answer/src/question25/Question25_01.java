package question25;

public interface Question25_01 {
	void display();
}
