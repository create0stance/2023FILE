package question25;

public class Question25_03 {
	public static void main(String[] args) {
		Show show = new Show();
		show.show();
		show.display();
	}
}
