package jp.co.exercise.rps;

import java.util.Random;
import java.util.Scanner;

/**
 * 団体じゃんけんプログラム
 * 
 * @author k-mori
 *
 */
public class GroupRPS2 {

	/** グー */
	public static final int ROCK = 0;
	/** チョキ */
	public static final int SCISSORS = 1;
	/** パー */
	public static final int PAPER = 2;
	/** 表示用じゃんけんの手 */
	public static final String[] HAND = { "グー", "チョキ", "パー" };
	/** チームメンバーの人数 */
	public static final int MEMBER_NUM = 5;
	/** 先鋒 */
	public static final int SENPO = 0;
	/** 次鋒 */
	public static final int JIHO = 1;
	/** 中堅 */
	public static final int CHUKEN = 2;
	/** 副将 */
	public static final int FUKUSHO = 3;
	/** 大将 */
	public static final int TAISHO = 4;
	/** 表示用選手の肩書 */
	public static final String[] POSITION = { "先鋒", "次鋒", "中堅", "副将", "大将" };
	/** プレイヤーの勝利メッセージ */
	public static final String MESSAGE_WIN = "プレイヤーが勝ちました！\n";
	/** プレイヤーの負けメッセージ */
	public static final String MESSAGE_DEFEAT = "PCが勝ちました！\n";
	/** 引き分けメッセージ */
	public static final String MESSAGE_DRAW = "引き分けです！\n";
	/** プレイヤーチームの勝利メッセージ */
	public static final String MESSAGE_TEAM_WIN = "プレイヤーチームの勝ちです！";
	/** プレイヤーチームの負けメッセージ */
	public static final String MESSAGE_TEAM_DEFEAT = "PCチームの勝ちです！";
	/** じゃんけん開始メッセージ */
	public static final String MESSAGE_MATCH_START = "「じゃんけんの手を選択してください」";
	/** じゃんけんの手選択メッセージ */
	public static final String MESSAGE_SELECTION_HAND = "1:グー\n2:チョキ\n3:パー\n＞";
	/** じゃんけんの手選択エラーメッセージ */
	public static final String MESSAGE_SELECTION_HAND_ERR = "1～3を選択してください\n";

	// ここから追加機能用の定数
	/** 試合の最大回数 */
	public static final int MAX_MATCH_NUM = 9;
	/** 試合記録の要素数 */
	public static final int REPORT_ELEMENTS_NUM = 4;
	/** 試合記録の要素 プレイヤー側ポジション */
	public static final int REPORT_POSITION_PL = 0;
	/** 試合記録の要素 PC側ポジション */
	public static final int REPORT_POSITION_PC = 1;
	/** 試合記録の要素 プレイヤー側の手 */
	public static final int REPORT_HAND_PL = 2;
	/** 試合記録の要素 PC側の手 */
	public static final int REPORT_HAND_PC = 3;
	/**
	 * 試合結果表示用じゃんけんの手<br>
	 * 試合結果で文字数をあわせるために全角空白を追加している
	 */
	public static final String[] HAND_RESULT = { "グー　", "チョキ", "パー　" };

	/**
	 * mainメソッド 試合の記録一覧表示機能を追加実装
	 * 
	 * @param args
	 *            無し
	 */
	public static void main(String[] args) {
		// オブジェクトはループの外で生成しておく
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();

		// プレイヤーの現在のポジション
		int positionPL = 0;
		// PCの現在のポジション
		int positionPC = 0;
		// 試合結果を記録しておく配列
		// 1次元目は試合回数、2次元目に各試合のデータを格納する
		String[][] resultReportArray = new String[MAX_MATCH_NUM][REPORT_ELEMENTS_NUM];
		// 試合回数をカウントする変数
		int matchCount = 0;

		System.out.println("【じゃんけん開始】");
		System.out.println("「プレイヤーとPCチームの先鋒は前へ」");

		// プレイヤーかPCのポジションが大将以下である間は勝負を続ける
		while (positionPL < MEMBER_NUM && positionPC < MEMBER_NUM) {
			// 勝ち負け判定の論理値
			boolean isWinPL = false;

			System.out.println(MESSAGE_MATCH_START);
			System.out.print(MESSAGE_SELECTION_HAND);
			// プレイヤーの手の選択
			int selectHandPL = stdIn.nextInt() - 1;

			// プレイヤーの手が0～2（1～3)でないなら選択をやり直す
			if (selectHandPL != ROCK && selectHandPL != SCISSORS && selectHandPL != PAPER) {
				System.out.println(MESSAGE_SELECTION_HAND_ERR);
				continue;
			}

			// PCの手を0～2からランダムに選択
			int selectHandPC = random.nextInt(3);

			// 現在のポジションを表示
			System.out.println("【" + POSITION[positionPL] + "-" + POSITION[positionPC] + " 戦】");
			// お互いの手を表示
			System.out.println(HAND[selectHandPL] + " vs " + HAND[selectHandPC]);

			// 同じ手の場合はあいこ、じゃんけんをやり直す
			if (selectHandPL == selectHandPC) {
				System.out.println(MESSAGE_DRAW);
				continue;
			}

			// プレイヤーの手を基準に勝ち負けを判定
			switch (selectHandPL) {
			case ROCK:
				// プレイヤーの手がグーのとき、PCの手がチョキなら勝ち
				if (selectHandPC == SCISSORS) {
					isWinPL = true;
				}
				break;
			case SCISSORS:
				// プレイヤーの手がチョキのとき、PCの手がパーなら勝ち
				if (selectHandPC == PAPER) {
					isWinPL = true;
				}
				break;
			case PAPER:
				// プレイヤーの手がパーのとき、PCの手がグーなら勝ち
				if (selectHandPC == ROCK) {
					isWinPL = true;
				}
				break;
			default:
				break;
			}

			// 勝ち負け結果の処理
			// プレイヤーが勝ちならPCチームのポジションを変更
			if (isWinPL) {
				// 選手の組み合わせを配列resultReportArrayに格納
				resultReportArray[matchCount][REPORT_POSITION_PL] = POSITION[positionPL] + "*";
				resultReportArray[matchCount][REPORT_POSITION_PC] = POSITION[positionPC];
				System.out.println(MESSAGE_WIN);
				// PCチームのポジションを変更
				positionPC++;
				// PCチームのメンバーが残っているならメッセージを出力
				if (positionPC < MEMBER_NUM) {
					System.out.println("「PCチームの" + POSITION[positionPC] + "は前へ」");
				}
				// プレイヤーが負けならプレイヤーチームのポジションを変更
			} else {
				// 選手の組み合わせを配列resultReportArrayに格納
				resultReportArray[matchCount][REPORT_POSITION_PL] = POSITION[positionPL];
				resultReportArray[matchCount][REPORT_POSITION_PC] = POSITION[positionPC] + "*";
				System.out.println(MESSAGE_DEFEAT);
				// プレイヤーチームのポジションを変更
				positionPL++;
				// プレイヤーチームのメンバーが残っているならメッセージを出力
				if (positionPL < MEMBER_NUM) {
					System.out.println("「プレイヤーチームの" + POSITION[positionPL] + "は前へ」");
				}
			}
			// 選んだ手を配列resultReportArrayに格納
			resultReportArray[matchCount][REPORT_HAND_PL] = HAND_RESULT[selectHandPL];
			resultReportArray[matchCount][REPORT_HAND_PC] = HAND_RESULT[selectHandPC];

			// 試合回数を+1
			matchCount++;

		}

		// ゲーム終了処理
		System.out.println("【ゲーム終了】");

		// 勝敗を判断
		// PCチームのポジションが大将より後ろならプレイヤーチームの勝利
		if (positionPC > TAISHO) {
			System.out.println(MESSAGE_TEAM_WIN);
			// PCチームのポジションが大将以前ならプレイヤーチームの負け
		} else {
			System.out.println(MESSAGE_TEAM_DEFEAT);
		}
		System.out.println();

		// 試合結果の記録を表示する
		System.out.println("           組  |  PL     PC     ");
		System.out.println("--------------------------------");
		// 配列resultReportArrayを展開するfor文
		for (int i = 0; i < resultReportArray.length; i++) {
			// 配列要素にnullがあったら記録を出力し終えたと判断してbreakする
			if (resultReportArray[i][REPORT_POSITION_PL] == null) {
				break;
			}
			// 試合結果を出力
			System.out.printf(" %-3s - %-3s |  %-3s %-3s \n", resultReportArray[i][REPORT_POSITION_PL],
					resultReportArray[i][REPORT_POSITION_PC], resultReportArray[i][REPORT_HAND_PL],
					resultReportArray[i][REPORT_HAND_PC]);
		}
		System.out.println("--------------------------------");
		
		stdIn.close();

	}

}
