package jp.co.exercise.rps;

import java.util.Random;
import java.util.Scanner;

/**
 * 団体じゃんけんプログラム
 * 
 * @author k-mori
 *
 */
public class GroupRPS {

	/** グー */
	public static final int ROCK = 0;
	/** チョキ */
	public static final int SCISSORS = 1;
	/** パー */
	public static final int PAPER = 2;
	/** 表示用じゃんけんの手 */
	public static final String[] HAND = { "グー", "チョキ", "パー" };
	/** チームメンバーの人数 */
	public static final int MEMBER_NUM = 5;
	/** 先鋒 インデックス */
	public static final int SENPO = 0;
	/** 次鋒 インデックス */
	public static final int JIHO = 1;
	/** 中堅 インデックス */
	public static final int CHUKEN = 2;
	/** 副将 インデックス */
	public static final int FUKUSHO = 3;
	/** 大将 インデックス */
	public static final int TAISHO = 4;
	/** 表示用選手の肩書 */
	public static final String[] POSITION = { "先鋒", "次鋒", "中堅", "副将", "大将" };
	/** プレイヤーの勝利メッセージ */
	public static final String MESSAGE_WIN = "プレイヤーが勝ちました！\n";
	/** プレイヤーの負けメッセージ */
	public static final String MESSAGE_DEFEAT = "PCが勝ちました！\n";
	/** 引き分けメッセージ */
	public static final String MESSAGE_DRAW = "引き分けです！\n";
	/** プレイヤーチームの勝利メッセージ */
	public static final String MESSAGE_TEAM_WIN = "プレイヤーチームの勝ちです！";
	/** プレイヤーチームの負けメッセージ */
	public static final String MESSAGE_TEAM_DEFEAT = "PCチームの勝ちです！";
	/** じゃんけん開始メッセージ */
	public static final String MESSAGE_MATCH_START = "「じゃんけんの手を選択してください」";
	/** じゃんけんの手選択メッセージ */
	public static final String MESSAGE_SELECTION_HAND = "1:グー\n2:チョキ\n3:パー\n＞";
	/** じゃんけんの手選択エラーメッセージ */
	public static final String MESSAGE_SELECTION_HAND_ERR = "1～3を選択してください\n";
	
	/**
	 * mainメソッド
	 * 基本機能を実装
	 * 
	 * @param args
	 *            無し
	 */
	public static void main(String[] args) {
		// オブジェクトはループの外で生成しておく
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();

		// プレイヤーの現在のポジション
		int positionPL = 0;
		// PCの現在のポジション
		int positionPC = 0;

		System.out.println("【じゃんけん開始】");
		System.out.println("「プレイヤーとPCチームの先鋒は前へ」");

		// プレイヤーかPCのポジションが大将以下である間は勝負を続ける
		while (positionPL < MEMBER_NUM && positionPC < MEMBER_NUM) {
			// 勝ち負け判定の論理値
			boolean isWinPL = false;

			System.out.println(MESSAGE_MATCH_START);
			System.out.print(MESSAGE_SELECTION_HAND);
			// プレイヤーの手の選択
			int selectHandPL = stdIn.nextInt() - 1;

			// プレイヤーの手が0～2（1～3)でないなら選択をやり直す
			if (selectHandPL != ROCK && selectHandPL != SCISSORS && selectHandPL != PAPER) {
				System.out.println(MESSAGE_SELECTION_HAND_ERR);
				continue;
			}

			// PCの手を0～2からランダムに選択
			int selectHandPC = random.nextInt(3);

			// 現在のポジションを表示
			System.out.println("【" + POSITION[positionPL] + "-" + POSITION[positionPC] + " 戦】");
			// お互いの手を表示
			System.out.println(HAND[selectHandPL] + " vs " + HAND[selectHandPC]);

			// 同じ手の場合は引き分け、じゃんけんをやり直す
			if (selectHandPL == selectHandPC) {
				System.out.println(MESSAGE_DRAW);
				continue;
			}

			// プレイヤーの手を基準に勝ち負けを判定
			switch (selectHandPL) {
			case ROCK:
				// プレイヤーの手がグーのとき、PCの手がチョキなら勝ち
				if (selectHandPC == SCISSORS) {
					isWinPL = true;
				}
				break;
			case SCISSORS:
				// プレイヤーの手がチョキのとき、PCの手がパーなら勝ち
				if (selectHandPC == PAPER) {
					isWinPL = true;
				}
				break;
			case PAPER:
				// プレイヤーの手がパーのとき、PCの手がグーなら勝ち
				if (selectHandPC == ROCK) {
					isWinPL = true;
				}
				break;
			default:
				break;
			}

			// 勝ち負け結果の処理
			// プレイヤーが勝ちならPCチームのポジションを変更
			if (isWinPL) {
				System.out.println(MESSAGE_WIN);
				positionPC++;
				// PCチームのメンバーが残っているならメッセージを出力
				if (positionPC < MEMBER_NUM) {
					System.out.println("「PCチームの" + POSITION[positionPC] + "は前へ」");
				}
			// プレイヤーが負けならプレイヤーチームのポジションを変更
			} else {
				System.out.println(MESSAGE_DEFEAT);
				positionPL++;
				// プレイヤーチームのメンバーが残っているならメッセージを出力
				if (positionPL < MEMBER_NUM) {
					System.out.println("「プレイヤーチームの" + POSITION[positionPL] + "は前へ」");
				}
			}

		}

		// ゲーム終了処理
		System.out.println("【ゲーム終了】");

		// 勝敗を判断
		// PCチームのポジションが大将より後ろならプレイヤーチームの勝利
		if (positionPC > TAISHO) {
			System.out.println(MESSAGE_TEAM_WIN);
			// PCチームのポジションが大将以内ならプレイヤーチームの負け
		} else {
			System.out.println(MESSAGE_TEAM_DEFEAT);
		}
		
		stdIn.close();

	}

}
