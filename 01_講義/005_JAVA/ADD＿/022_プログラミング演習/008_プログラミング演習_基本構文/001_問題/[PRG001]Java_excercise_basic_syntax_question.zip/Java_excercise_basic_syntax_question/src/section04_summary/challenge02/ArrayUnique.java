/**
 * 重複なしの配列
 * 
 * Random.nextInt(int)を使って配列にランダムな値を代入します。
 * ただし、配列中の値が重複しない（ユニーク）となるように代入してください。
 * 
 * 実行例：
 * 数字を読み上げます：
 * 10 5 2 1 9 4 7 8 6 3
 *  
 */

package section04_summary.challenge02;

public class ArrayUnique {

	public static void main(String[] args) {
		
	}

}
