/**
 * 配列要素のシャッフル
 *
 * 配列要素の中身がランダムな順番になるようにかき混ぜる（シャッフルする）
 * プログラムを作成してください。
 *
 * Randomクラスが数値のランダムに関する機能を持っています。
 * Random random = new Random();
 * int num = 10;
 * int i = random.nextInt(num); // 0～9までの値をランダムに1つ代入する
 *
 * 実行例：
 *
 * シャッフル前：
 * 1 2 3 4 5 6 7 8 9 10
 * シャッフル後：
 * 3 8 4 7 10 6 1 5 9 2
 *
 */

package section04_summary.challenge02;

public class ArrayShuffle {

	public static void main(String[] args) {

	}

}
