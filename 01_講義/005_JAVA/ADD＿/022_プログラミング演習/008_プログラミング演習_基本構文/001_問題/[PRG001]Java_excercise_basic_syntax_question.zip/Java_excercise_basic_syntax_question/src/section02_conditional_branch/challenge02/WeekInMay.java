/**
 * 今月の曜日
 * 今月の日付を入力させ、その日の曜日を表示させてください。
 * 
 * 条件；
 * 　switch文で実装してください。
 * 　1～31以外の数字を入力された場合は、注意のメッセージを表示してください。
 * 
 * 実行例：
 * （正しい入力の場合）
 * 今日は5月の何日ですか＞15
 * 5月15日は金曜日です。
 * 
 * （正しくない入力の場合）
 * 今日は5月の何日ですか＞0
 * 1～31を入力してください。
 * 
 * 
 */
package section02_conditional_branch.challenge02;

public class WeekInMay {

	public static void main(String[] args) {

	}

}
