/**
 * 横棒グラフの表示
 * 
 * 実行例.txtを参考に棒グラフを表示してください。
 * 配列の要素数を入力させ、その数だけ縦棒グラフを表示してください。
 * 棒グラフは*で表し、数は1～10個でランダムとします。
 * 一番左にはインデックスの下1桁を表示してください。
 * 
 */
package section04_summary.challenge03;

public class BarGraph {

	public static void main(String[] args) {

	}

}
