/**
 * クラスの成績
 *
 * 実行例を参考に、クラス毎の成績を計算して一覧を出力してください
 *
 * クラス数と各クラスの人数を入力させ、人数分の点数を入力し、成績を計算します
 * 合計点は整数、平均点は有効数字1桁の実数で表示してください
 *
 * ※標準出力の桁数を制御するにはSystem.out.printfまたはString.formatを使用します
 * 　調べてもよくわからない場合は、桁数を揃えずに出力してください
 *
 */
package section04_summary.challenge07;

public class GradeList {

	public static void main(String[] args) {

	}

}
