/**
 * バブルソート
 * 入力された数字10個を昇順に並べ替えるプログラムを作成してください。
 * 
 * ソートアルゴリズムには様々な種類がありますが、今回はバブルソートを使用します。
 * 
 * まず、並べ替える数字の入っている箱が横一列に並んでいるとイメージします。
 * 1個目の箱と2個目の箱を比較し、2個目のほうが小さいなら数字を交換します。
 * 次は1個目の箱と3個目の箱を比較し、3個目のほうが小さいなら数字を交換します。
 * この比較を順番にすべての箱（数字）で行っていきます。
 * 1個目の箱が終わったら次は2個目の箱を基準に3個目以降の箱を比較していきます。
 * 最終的に左から順に小さい数字になるように並べ替えます。
 * このように、小さい数値(または大きい数値)が順々に沸き登っていくようなソートアルゴリズムを、バブルソート呼びます。
 * 
 * 実行例：
 * 
 * ソート前：
 * 15 63 50 1 4 68 100 3 42 7 
 * ソート後：
 * 1 3 4 7 15 42 50 63 68 100 
 * 
 */
package section04_summary.challenge05;

import java.util.Random;
import java.util.Scanner;

public class BubbleSort {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();
		int[] array = new int[10];

		// 数字を10個用意
		for (int i = 0; i < array.length; i++) {
			array[i] = random.nextInt(100) + 1;
		}

		// ソート前を出力
		System.out.println("ソート前：");
		for (int i : array) {
			System.out.print(i + " ");
		}

		// ソートの実施
		// 0番目～最後までを対象とする
		for (int i = 0; i < array.length; i++) {
			// i+1番目～最後までを比較対象とする
			for (int j = i + 1; j < array.length; j++) {
				// j番目がi番目より小さいなら、数字を入れ替える
				if (array[j] < array[i]) {
					// iの数字を避難
					int tmp = array[i];
					// jの数字をiへ代入
					array[i] = array[j];
					// 避難した数字をjに代入
					array[j] = tmp;
				}
			}
		}

		// ソート後を出力
		System.out.println("\nソート後：");
		for (int i : array) {
			System.out.print(i + " ");
		}
		
		stdIn.close();

	}

}
