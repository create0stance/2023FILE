/**
 * 横棒グラフの表示
 * 
 * 実行例.txtを参考に棒グラフを表示してください。
 * 配列の要素数を入力させ、その数だけ縦棒グラフを表示してください。
 * 棒グラフは*で表し、数は1～10個でランダムとします。
 * 一番左にはインデックスの下1桁を表示してください。
 * 
 */
package section04_summary.challenge03;

import java.util.Random;
import java.util.Scanner;

public class BarGraph {

	public static void main(String[] args) {
		Random random = new Random();
		Scanner stdIn = new Scanner(System.in);

		// 要素数を入力
		System.out.print("要素数＞");
		int[] array = new int[stdIn.nextInt()];

		// 配列に数字を代入
		for (int i = 0; i < array.length; i++) {
			// 1~10をランダムに代入
			array[i] = random.nextInt(10) + 1;
		}

		// 要素ごとの数字に応じて＊を出力
		// 縦方向のfor文
		for (int i = 0; i < array.length; i++) {
			// 行番号を出力（インデックスの下1桁）
			System.out.print(i % 10 + ":");
			// 横方向のfor文
			for (int j = 0; j < array[i]; j++) {
				System.out.print("*");
			}
			// 改行
			System.out.println();
		}
		
		stdIn.close();

	}

}
