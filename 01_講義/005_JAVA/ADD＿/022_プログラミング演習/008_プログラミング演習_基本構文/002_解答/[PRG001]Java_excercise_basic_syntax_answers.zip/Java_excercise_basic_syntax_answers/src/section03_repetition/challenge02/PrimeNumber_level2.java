/**
 * 素数判定
 * 範囲内の数字の素数判定
 * 
 * 1と自分自身以外に正の約数を持たない自然数のことを素数と言います。
 * 言い換えると、2以上n未満の約数を持たない自然数nを素数といいます。
 * ※ちなみに、自然数nを割り切れる自然数xはn/2以下の数字です。
 * 
 * 2～入力した整数までの数字の中で、素数である数字を抽出する
 * プログラムを作成してください。
 * 
 * 実行例：
 * 整数を入力してください＞20
 * 20までの素数は以下の数字です。
 * 2, 3, 5, 7, 11, 13, 17, 19, 
 * 
 */

package section03_repetition.challenge02;

import java.util.Scanner;

public class PrimeNumber_level2 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		// 判定する数字を入力
		System.out.print("整数を入力してください＞");
		int target = stdIn.nextInt();

		// 数字の2
		final int NUM_2 = 2;
		// 数字の0
		final int NUM_0 = 0;
		// 判定結果の数字を格納する文字列型変数
		String resultStr = "";

		// 判定を行うループ
		// 2～入力値を繰り返す
		for (int i = NUM_2; i <= target; i++) {
			// 判定結果の真偽
			boolean isPrimeNumber = true;
			// iの値ごとに、2～i/2までの数字で割り切れるかを確認
			for (int j = NUM_2; j <= i / NUM_2; j++) {
				// iが一度でも割り切れた場合は素数ではないので次の数字へすすめる
				if (i % j == NUM_0) {
					isPrimeNumber = false;
					break;
				}
			}
			// isPrimeNumberがtrueのママであれば素数なので結果文字列に加える
			if (isPrimeNumber) {
				resultStr += i + ", ";
			}
		}
		// 最終結果を表示
		if (resultStr != "") {
			System.out.println(target + "までの素数は以下の数字です。\n" + resultStr);
		}
		
		stdIn.close();

	}

}
