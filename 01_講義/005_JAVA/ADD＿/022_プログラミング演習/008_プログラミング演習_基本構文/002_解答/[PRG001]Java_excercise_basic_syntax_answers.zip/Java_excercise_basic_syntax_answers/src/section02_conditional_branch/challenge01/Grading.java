/**
 * 3科目の成績(if)
 * 
 * 整数を3個入力させ、その平均点から成績を4段階で判定するプログラムを作成してください。
 * 条件：
 * 　if文で作成してください
 * 　入力するのは整数3個
 * 　入力値は100以下でなければいけない
 * 　入力値に101以上の数字があった場合はプログラムを終了する
 * 　平均点は浮動小数で表示すること
 * 成績の判定：
 * 　平均点に応じて成績を表示する
 * 　100点なら「満点です！」
 * 　80以上99以下なら「大変良くできました。」
 * 　60以上79以下なら「よくできました。」
 * 　59以下なら「もっと頑張りましょう」
 * 
 * 補足：
 * 　プログラムを途中で終了したい場合は下記ステートメントを使います。
 * 　なお、使わなくても実装は可能です。
 * 　System.exit(0);
 * 
 * 実行例：
 * （100点満点の場合）
 * 3科目の点数を入力してください:
 * 国語＞100
 * 数学＞100
 * 英語＞100
 * 平均点は100.0点です。
 * 満点です！
 * 
 * （100より大きい数字があった場合）
 * 3科目の点数を入力してください:
 * 国語＞101
 * 数学＞88
 * 英語＞56
 * 100以下の数字を入力してください。
 * 
 */

package section02_conditional_branch.challenge01;

import java.util.Scanner;

public class Grading {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		// 成績判定のための定数を設定
		final int NUM_100 = 100;
		final int NUM_99 = 99;
		final int NUM_80 = 80;
		final int NUM_79 = 79;
		final int NUM_60 = 60;
		// 科目の数
		int subjectCnt = 3;

		// 3科目分の点数を標準入力
		System.out.println("3科目の点数を入力してください:");
		System.out.print("国語＞");
		int scoreLang = stdIn.nextInt();
		System.out.print("数学＞");
		int scoreMath = stdIn.nextInt();
		System.out.print("英語＞");
		int scoreEng = stdIn.nextInt();

		// 入力値が100より多い場合はシステムを停止
		if (scoreLang > NUM_100 || scoreMath > NUM_100 || scoreEng > NUM_100) {
			System.out.println("100以下の数字を入力してください。");
			System.exit(0);
		}

		// 平均点の計算
		double scoreAve = (double) (scoreLang + scoreMath + scoreEng) / subjectCnt;
		System.out.println("平均点は" + scoreAve + "点です。");

		// 成績の判定
		if (scoreAve == NUM_100) {
			System.out.println("満点です！");
		} else if (scoreAve >= NUM_80 && scoreAve <= NUM_99) {
			System.out.println("大変良くできました。");
		} else if (scoreAve >= NUM_60 && scoreAve <= NUM_79) {
			System.out.println("よくできました。");
		} else {
			System.out.println("もっとがんばりましょう。");
		}
		
		stdIn.close();

	}

}
