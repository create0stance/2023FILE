/**
 * 選択ソート
 * 入力された数字10個を降順に並べ替えるプログラムを作成してください。
 * 
 * ソートアルゴリズムには様々な種類がありますが、今回は選択ソートを使用します。
 * 
 * まず、並べ替える数字の入っている箱が横一列に並んでいるとイメージします。
 * 最初は1個めの数字と他の箱を比較し、一番大きい箱（MAX値）を選択します。MAX値と一番左（1個めの箱）の値を交換します。
 * 次は2個め～最後までの箱を比較し、MAX値を調べ、MAX値を2個目の箱に移動します。
 * これをすべての箱について繰り返せば、最終的に左から順に大きな数字に並べ替えることができます。
 * このように、数値の中から一番大きい(あるいは小さい)値を選択して並べ替えていくソートアルゴリズムを、選択ソートと読んでいます。
 * 
 * 参考：https://gigazine.net/news/20140501-sorting/
 * 
 * 実行例：
 * 
 * ソート前：
 * 7 90 23 77 97 37 32 45 55 76 
 * ソート後：
 * 97 90 77 76 55 45 37 32 23 7 
 * 
 */
package section04_summary.challenge06;

import java.util.Random;
import java.util.Scanner;

public class SelectionSort {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();
		int[] array = new int[10];

		// 数字を10個用意
		for (int i = 0; i < array.length; i++) {
			array[i] = random.nextInt(100) + 1;
		}

		// ソート前を出力
		System.out.println("ソート前：");
		for (int i : array) {
			System.out.print(i + " ");
		}

		// ソートの実施
		// 0番目から順にインデックス-1までを対象にする
		for (int i = 0; i < array.length - 1; i++) {
			// 仮に今の番号の数字をmax値とする
			int max = array[i];
			// max値として選択された番号を代入する変数
			int choseIndex = i;
			// i+1番目～最後までの数字の中でmax値を調べる
			for (int j = i + 1; j < array.length; j++) {
				// 今max値としている数字よりj番目の数字のほうが大きいなら、
				// j番目の数字をmax値として保存
				// インデックス番号jも保存
				if (max < array[j]) {
					max = array[j];
					choseIndex = j;
				}
			}
			// max値だった番号に今の番号の数字を代入
			array[choseIndex] = array[i];
			// 今の番号にmax値を代入
			array[i] = max;
		}

		// ソート後の出力
		System.out.println("\nソート後：");
		for (int i : array) {
			System.out.print(i + " ");
		}
		
		stdIn.close();

	}

}
