/**
 * 配列の初期化と出力
 *
 * 実行例を参考に、プログラムを完成させてください。
 * 要素数10の配列を初期化し、順番に出力してください。
 * 初期化する数値は何でも構いません。
 * また、配列の要素数も出力してください。
 *
 * ※注意：かならず"初期化"してください。
 *
 * （実行例）
 * 1個目の数字は：1
 * 2個目の数字は：2
 * 3個目の数字は：3
 * 4個目の数字は：4
 * 5個目の数字は：5
 * 6個目の数字は：6
 * 7個目の数字は：7
 * 8個目の数字は：8
 * 9個目の数字は：9
 * 10個目の数字は：10
 * 配列の要素数は：10
 *
 */

package section01_array.challenge01;

public class Basic {

	public static void main(String[] args) {
		// 配列の準備
		int array[] = {1,2,3,4,5,6,7,8,9,10};

		// 順番に出力
		System.out.println("1個目の数字は：" + array[0]);
		System.out.println("2個目の数字は：" + array[1]);
		System.out.println("3個目の数字は：" + array[2]);
		System.out.println("4個目の数字は：" + array[3]);
		System.out.println("5個目の数字は：" + array[4]);
		System.out.println("6個目の数字は：" + array[5]);
		System.out.println("7個目の数字は：" + array[6]);
		System.out.println("8個目の数字は：" + array[7]);
		System.out.println("9個目の数字は：" + array[8]);
		System.out.println("10個目の数字は：" + array[9]);
		System.out.println("配列の要素数は：" + array.length);

	}

}
