/**
 * クラスの成績 (多次元配列）
 *
 * 実行例を参考に、クラス毎の成績を計算して一覧を出力してください
 * クラス数は2、1クラスあたりの生徒数は3人の2次元配列で定義してください。
 * クラスの各生徒に、整数の点数を入力し、クラスごとの成績を出力します。
 * 成績は、クラスごとの合計点と平均点(少数まで)を出力します。
 *
 * (実行例)
 * 1組、出席番号1番の点数＞5
 * 1組、出席番号2番の点数＞7
 * 1組、出席番号3番の点数＞9
 * 2組、出席番号1番の点数＞11
 * 2組、出席番号1番の点数＞13
 * 2組、出席番号1番の点数＞17
 * 1組の合計点は21点、平均点は7.0点です。
 * 2組の合計点は41点、平均点は13.666666666666666点です。
 *
 */

package section01_array.challenge03;

import java.util.Scanner;

public class GradeList_Array {

	public static void main(String[] args) {
		// 標準入力の準備
		Scanner stdIn = new Scanner(System.in);

		// 多次元配列の準備
		int[][] school = new int[2][3];
		// 合計と平均点用の変数を初期化
		int sum1 = 0;
		double average1 = 0.0;
		int sum2 = 0;
		double average2 = 0.0;

		// 各点数を入力する
		System.out.print("1組、出席番号1番の点数＞");
		school[0][0] = stdIn.nextInt();
		System.out.print("1組、出席番号2番の点数＞");
		school[0][1] = stdIn.nextInt();
		System.out.print("1組、出席番号3番の点数＞");
		school[0][2] = stdIn.nextInt();
		System.out.print("2組、出席番号1番の点数＞");
		school[1][0] = stdIn.nextInt();
		System.out.print("2組、出席番号1番の点数＞");
		school[1][1] = stdIn.nextInt();
		System.out.print("2組、出席番号1番の点数＞");
		school[1][2] = stdIn.nextInt();

		// 1クラス目の合計点
		sum1 += school[0][0];
		sum1 += school[0][1];
		sum1 += school[0][2];

		// 2クラス目の合計点
		sum2 += school[1][0];
		sum2 += school[1][1];
		sum2 += school[1][2];

		// 1クラス目の平均点（lengthを使っているかチェック）
		average1 = (double) sum1 / school[0].length;
		// 2クラス目の平均点（lengthを使っているかチェック）
		average2 = (double) sum2 / school[1].length;

		// 成績を出力
		System.out.println("1組の合計点は" + sum1 + "点、平均点は" + average1 + "点です。");
		System.out.println("2組の合計点は" + sum2 + "点、平均点は" + average2 + "点です。");

		stdIn.close();
	}

}
