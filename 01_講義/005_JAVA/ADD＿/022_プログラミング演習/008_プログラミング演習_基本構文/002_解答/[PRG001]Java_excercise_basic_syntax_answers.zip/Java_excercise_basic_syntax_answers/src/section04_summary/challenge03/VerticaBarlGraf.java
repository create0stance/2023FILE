/**
 * 縦棒グラフの表示
 * 
 * 実行例.txtを参考に棒グラフを表示してください。
 * 配列の要素数を入力させ、その数だけ縦棒グラフを表示してください。
 * 棒グラフは*で表し、数は1～10個でランダムとします。
 * 最下段にはインデックスの下1桁を表示してください。
 * 
 */
package section04_summary.challenge03;

import java.util.Random;
import java.util.Scanner;

public class VerticaBarlGraf {

	public static void main(String[] args) {
		Random rand = new Random();
		Scanner stdIn = new Scanner(System.in);

		// 要素数を決定する入力
		System.out.print("要素数＞");
		int length = stdIn.nextInt();
		int[] array = new int[length];

		// 各要素にランダムに1～10を代入
		for (int i = 0; i < length; i++) {
			array[i] = 1 + rand.nextInt(10);
		}

		// 最大の高さが10なので、上から順に処理するイメージでfor文を構成
		// 10段目の添字0,1,2...→9段目の添字0,1,2,...という順番で処理する
		for (int i = 10; i > 0; i--) {
			// 各要素に対する処理
			for (int j = 0; j < length; j++) {
				// 各要素の値がi以上である場合*を出力
				if (i <= array[j]) {
					System.out.print('*');
					// そうでなければスペースで埋める
				} else {
					// System.out.print('.');//わかりやすいように.を出力
					System.out.print(' ');
				}
				// 要素間のスペース
				System.out.print(' ');
			}
			// 一行すすめるための改行
			// System.out.println(i); // 縦の番号がわかるようにiを出力
			System.out.println();
		}

		// インデックス番号とグラフのセパレータを出力
		for (int i = 0; i < length * 2; i++) {
			System.out.print('-');
		}
		System.out.println();

		// インデックス番号の下1桁を出力
		for (int i = 0; i < length; i++) {
			System.out.print(i % 10);
			System.out.print(' ');
		}
		System.out.println();
		
		stdIn.close();
	}
}
