/**
 * 重複なしの配列
 * 
 * Random.nextInt(int)を使って配列にランダムな値を代入します。
 * ただし、配列中の値が重複しない（ユニーク）となるように代入してください。
 * 
 * 実行例：
 * 数字を読み上げます：
 * 10 5 2 1 9 4 7 8 6 3
 *  
 */

package section04_summary.challenge02;

import java.util.Random;

public class ArrayUnique {

	public static void main(String[] args) {
		Random rand = new Random();
		int len = 10;
		// 要素数10の配列
		int[] array = new int[len];

		// 1～10の数字を重複無しで代入するためのfor文
		for (int i = 0; i < array.length; i++) {
			// i番目にランダムな数字を代入
			array[i] = rand.nextInt(len) + 1;
			// i番目の値が今までに出てきたことがあるのかを判定
			for (int j = i - 1; j >= 0; j--) {
				// i番目の値がj番目の値と一致するなら、iを-1して代入をやり直す
				if (array[i] == array[j]) {
					i--;
					break;
				}
			}
		}
		
		// 配列要素を文字列出力する
		System.out.println("数字を読み上げます：");
		for (int i : array) {
			System.out.print(i + " ");
		}
		System.out.println();
		
	}

}
