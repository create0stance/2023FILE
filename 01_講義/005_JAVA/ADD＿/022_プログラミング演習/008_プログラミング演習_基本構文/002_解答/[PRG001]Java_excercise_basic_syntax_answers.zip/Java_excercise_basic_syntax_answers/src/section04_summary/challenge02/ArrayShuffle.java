/**
 * 配列要素のシャッフル
 *
 * 配列要素の中身がランダムな順番になるようにかき混ぜる（シャッフルする）
 * プログラムを作成してください。
 *
 * Randomクラスが数値のランダムに関する機能を持っています。
 * Random random = new Random();
 * int num = 10;
 * int i = random.nextInt(num); // 0～9までの値をランダムに1つ代入する
 *
 * 実行例：
 *
 * シャッフル前：
 * 1 2 3 4 5 6 7 8 9 10
 * シャッフル後：
 * 3 8 4 7 10 6 1 5 9 2
 *
 */

package section04_summary.challenge02;

import java.util.Random;
import java.util.Scanner;

public class ArrayShuffle {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();
		int len = 10;
		int[] array = new int[len];

		// 数字を10個用意
		for (int i = 1; i <= len; i++) {
			array[i - 1] = i;
		}

		// シャッフル前を出力
		System.out.println("シャッフル前：");
		for (int i : array) {
			System.out.print(i + " ");
		}

		// シャッフルの実施
		for (int i = 0; i < array.length; i++) {
			// 入れ替えるインデックス番号をRandomに決定
			int index = random.nextInt(len);
			// 今のインデックスの数字を避難
			int tmp = array[i];
			// 入れ替え先の数字を今のインデックスへ代入
			array[i] = array[index];
			// 避難しておいた数字を入れ替え先のインデックスへ代入
			array[index] = tmp;
		}

		// シャッフル後を出力
		System.out.println("\nシャッフル後：");
		for (int i : array) {
			System.out.print(i + " ");
		}
		
		stdIn.close();

	}

}
