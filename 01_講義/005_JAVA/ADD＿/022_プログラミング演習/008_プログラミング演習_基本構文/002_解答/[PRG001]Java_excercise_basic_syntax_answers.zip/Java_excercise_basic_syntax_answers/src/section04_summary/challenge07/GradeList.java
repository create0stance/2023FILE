/**
 * クラスの成績
 * 
 * 実行例を参考に、クラス毎の成績を計算して一覧を出力してください
 * 
 * クラス数と各クラスの人数を入力させ、人数分の点数を入力し、成績を計算します
 * 合計点は整数、平均点は有効数字1桁の実数で表示してください
 * 
 * ※標準出力の桁数を制御するにはSystem.out.printfまたはString.formatを使用します
 * 　調べてもよくわからない場合は、桁数を揃えずに出力してください
 * 
 */
package section04_summary.challenge07;

import java.util.Scanner;
a
public class GradeList {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		// クラスの数を入力
		System.out.print("クラス数＞");
		int classroom = stdIn.nextInt();
		int[][] school = new int[classroom][];
		System.out.println();

		// 全クラスの合計人数の変数
		int memberTotal = 0;

		// 各クラスの人数と、各々の点数を入力するループ
		for (int i = 0; i < school.length; i++) {
			// クラスi組目の人数を入力
			System.out.print(i + 1 + "組の人数＞");
			school[i] = new int[stdIn.nextInt()];
			// クラスの生徒j番目の点数を入力
			for (int j = 0; j < school[i].length; j++) {
				System.out.print(i + 1 + "組" + (j + 1) + "番の点数＞");
				school[i][j] = stdIn.nextInt();
			}
			// クラス内の人数を足し上げる
			memberTotal += school[i].length;
			System.out.println();
		}

		// 全クラスの合計点数
		int schoolSum = 0;
		// 全クラス合計の平均点
		double schoolAve = 0;

		// 結果配列の合計を格納するインデックス番号
		int sum = 0;
		// 結果配列の平均を格納するインデックス番号
		int ave = 1;
		// 結果を格納する配列
		double[][] result = new double[classroom][2];

		// 結果配列へ各クラスの合計点と平均点を格納していくループ
		for (int i = 0; i < school.length; i++) {
			// クラス毎に合計点を計算
			for (int array : school[i]) {
				result[i][sum] += array;
			}
			// クラス毎の平均点を計算
			result[i][ave] = (double) result[i][sum] / school[i].length;
			// 全クラスの合計点を計算
			schoolSum += result[i][sum];
		}
		// 全クラスの平均点を計算
		schoolAve = (double) schoolSum / memberTotal;

		// ここから結果の一覧を構成
		System.out.println("  組 |   合計   平均 ");
		System.out.println("---------------------");
		// クラス毎の合計点と平均点を出力する
		for (int i = 0; i < school.length; i++) {
			// クラス番号を2桁で出力
			System.out.printf("%2d組 | ", i + 1);
			// 合計点と平均点は6桁で出力
			System.out.printf("%6d %6.1f \n", (int) result[i][sum], result[i][ave]);
		}
		System.out.println("---------------------");
		// 全クラスの合計点と平均点を6桁で出力
		System.out.printf("  計 | %6d %6.1f ", schoolSum, schoolAve);
		
		stdIn.close();
	}

}
