/**
 * 一年の経過と残り
 * 入力した日付から、一年の経過日数と残り日数を計算して出力してください。
 * 2月は28日とします。
 * 
 * 不正な月や日を入力された場合はプログラムを終了してください。
 * 下記ステートメントを実行するとプログラムが終了します。
 * System.exit(0);
 * 
 * 実行例：
 * （正しい日付を入力）
 * 今は何月ですか＞5
 * 今日は何日ですか＞15
 * 一年の経過日数は135日です。
 * 一年の残り日数は230日です。
 * 
 * （不正な月を入力）
 * 今は何月ですか＞13
 * 1～12を入力してください
 * 
 * （不正な日付を入力）
 * 今は何月ですか＞2
 * 今日は何日ですか＞29
 * 正しい日付を入力してください
 * 
 * ヒント：
 * ・if文とswitch文を組み合わせて実装することを想定しています。
 * ・月や日は決まっている数字なので「定数」です。
 * ・処理をいくつかのセクションに区切って考えるとよいでしょう。
 * 　以下のようなセクション分けが考えられます。
 * 　・月の入力と、入力値の確認
 * 　・日の入力と、入力値の確認
 * 　・経過日数の計算
 * 　・残日数の計算
 * 　・結果の出力
 * 
 */

package section02_conditional_branch.challenge03;

import java.util.Scanner;

public class ElapsedAndRemainingDays {

	public static void main(String[] args) {
		// ツイタチを用意
		final int FIRST = 1;

		// 月を用意
		final int JAN = 1;
		final int FEB = 2;
		final int MAR = 3;
		final int APR = 4;
		final int MAY = 5;
		final int JUN = 6;
		final int JUL = 7;
		final int AUG = 8;
		final int SEP = 9;
		final int OCT = 10;
		final int NOV = 11;
		final int DEC = 12;

		// 各月の日数を用意
		final int JAN_DAY = 31;
		final int FEB_DAY = 28;
		final int MAR_DAY = 31;
		final int APR_DAY = 30;
		final int MAY_DAY = 31;
		final int JUN_DAY = 30;
		final int JUL_DAY = 31;
		final int AUG_DAY = 31;
		final int SEP_DAY = 30;
		final int OCT_DAY = 31;
		final int NOV_DAY = 30;
		final int DEC_DAY = 31;

		// 一年の日数=365
		final int YEAR = JAN_DAY + FEB_DAY + MAR_DAY + APR_DAY + MAY_DAY + JUN_DAY + JUL_DAY + AUG_DAY + SEP_DAY
				+ OCT_DAY + NOV_DAY + DEC_DAY;
		// System.out.println("YEAR : " + YEAR);

		Scanner stdIn = new Scanner(System.in);

		// 月を入力
		System.out.print("今は何月ですか＞");
		int inputMounth = stdIn.nextInt();

		// 月の入力確認
		if (inputMounth < JAN || inputMounth > DEC) {
			System.out.println("1～12を入力してください");
			System.exit(0);
		}

		// 日を入力
		System.out.print("今日は何日ですか＞");
		int inputDay = stdIn.nextInt();

		// 日付入力の正否判定用flag
		boolean isCorrect = true;

		// 日の入力確認
		switch (inputMounth) {
		case FEB:// 2月
			// 1～28日でないなら不正日付
			if (inputDay < FIRST || inputDay > FEB_DAY) {
				isCorrect = false;
			}
			break;
		case JAN:
		case MAR:
		case MAY:
		case JUL:
		case AUG:
		case OCT:
		case DEC: // 1,3,5,7,8,10,12月
			// 1～31日でないなら不正日付
			if (inputDay < FIRST || inputDay > JAN_DAY) {
				isCorrect = false;
			}
			break;
		default: // 4,6,9,11月
			// 1～30日出ないなら不正日付
			if (inputDay < FIRST || inputDay > APR_DAY) {
				isCorrect = false;
			}
			break;
		}

		// 入力確認結果が不正日付であるならシステム終了
		if (!isCorrect) {
			System.out.println("正しい日付を入力してください");
			System.exit(0);
		}

		// 前月までの合計日数変数
		int sumMounthDay = 0;
		// 前月までの合計日数を計算
		// ↓天才的発想のフォールスルーswitch文
		switch (inputMounth) {
		case DEC:
			sumMounthDay += NOV_DAY;
		case NOV:
			sumMounthDay += OCT_DAY;
		case OCT:
			sumMounthDay += SEP_DAY;
		case SEP:
			sumMounthDay += AUG_DAY;
		case AUG:
			sumMounthDay += JUL_DAY;
		case JUL:
			sumMounthDay += JUN_DAY;
		case JUN:
			sumMounthDay += MAY_DAY;
		case MAY:
			sumMounthDay += APR_DAY;
		case APR:
			sumMounthDay += MAR_DAY;
		case MAR:
			sumMounthDay += FEB_DAY;
		case FEB:
			sumMounthDay += JAN_DAY;
		}
		// System.out.println("elapsedMounthDay : " + elapsedMounthDay );

		// 一年の経過日数を計算（前月までの合計日数 + 今日 = 一年の経過日数）
		int elapsedYearDay = sumMounthDay + inputDay;

		// 一年の残日数を計算（一年の日数 - 一年の経過日数 = 一年の残日数）
		int remainingYearDay = YEAR - elapsedYearDay;

		System.out.println("一年の経過日数は" + elapsedYearDay + "日です。");
		System.out.println("一年の残り日数は" + remainingYearDay + "日です。");
		
		stdIn.close();
	}

}