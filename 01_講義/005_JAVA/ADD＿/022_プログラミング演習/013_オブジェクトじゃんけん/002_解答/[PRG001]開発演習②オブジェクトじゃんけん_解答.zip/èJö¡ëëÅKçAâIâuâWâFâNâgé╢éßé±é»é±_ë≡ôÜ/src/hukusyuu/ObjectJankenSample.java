package hukusyuu;

/**
 * オブジェクト指向によるジャンケンプログラム。
 *
 * @author System Shared
 */
public class ObjectJankenSample {
	/**
	 * 審判の作成、プレイヤーの作成を行い、ジャンケンを開始するメソッド。
	 */
	public static void main(String[] args) {
		// 審判（斎藤さん）のインスタンス生成
		JudgeSample saito = new JudgeSample();

		// プレイヤー1（村田さん）の生成
		PlayerSample murata = new PlayerSample("村田さん");

		// プレイヤー2（山田さん）の生成
		PlayerSample yamada = new PlayerSample("山田さん");

		// 村田さんと山田さんをプレイヤーとしてジャンケンを開始する
		saito.startJanken(murata, yamada);
	}
}
