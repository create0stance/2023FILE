package janken.excellence;

import java.util.Random;

public class SystemMain {

	public static void main(String[] args) {
		// プレイヤーの生成
		Player player = new Player();
		// コンピューターの生成
		Player computer = new Player();

		// じゃんけん開始
		System.out.println("【ジャンケン開始】\n");
		for (int i = 1; i <= 3; i++) {
			System.out.println("【" + i + "回戦目】");
			System.out.println("プレイヤーの手を決めてください");
			System.out.println("（グー：0 チョキ:1 パー:2）");
			System.out.print("＞");
			while (true) {
				// プレイヤーの手の入力
				player.inputHand();
				try {
					if (Integer.parseInt(player.getHand()) >= 0
							&& Integer.parseInt(player.getHand()) <= 2) {
						break;
					} else {
						System.out.print("入力した値が誤っています、再度入力してください \n＞");
						continue;
					}
				} catch (NumberFormatException e) {
					// TODO 自動生成された catch ブロック
					System.out.println("システムエラーが発生しました。 ");
					System.out.println("システムを終了します。 ");
					System.exit(1);
				}
			}
			// コンピュータの手をランダムに取得
			computer.setHand(String.valueOf(new Random().nextInt(3)));

			new JankenJudge().gameJudge(player, computer);;
			// 改行用
			System.out.println();

		}

		// じゃんけん終了
		System.out.println("【ジャンケン終了】\n");

		// じゃんけんの結果判定処理
		if (player.getWinCount() == computer.getWinCount()) {
			System.out.println(player.getWinCount() + " 対 "
					+ computer.getWinCount() + " で引き分けです！");
		} else if (player.getWinCount() > computer.getWinCount()) {
			System.out.println(player.getWinCount() + " 対 "
					+ computer.getWinCount() + " でプレイヤーの勝ちです！");
		} else {
			System.out.println(player.getWinCount() + " 対 "
					+ computer.getWinCount() + " でプレイヤーの負けです！");
		}

	}

}
