package janken.extra;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author m-sakai じゃんけんスタートクラス
 *
 */
public class JankenStart {

	//playerクラス
	private Player player;

	/**
     * コンストラクタ
     * mainメソッドからplayerクラスを受け取る
     */
	JankenStart(Player player) {

		this.player = player;
	}

	/**
	 * 処理開始
	 */
	public void start() {

		try {

			// インスタンス（オブジェクト）生成
			List<Player> computerList = new ArrayList<Player>();
			GameInformation gameInfo = new GameInformation();
			JankenJudge jadge = new JankenJudge();
			Util util = new Util();

			// じゃんけん回数
			System.out.println(Constant.JANKEN_NUMBER_OF_TIMES);
			System.out.print(Constant.INPUT_AUXILIARY);
			gameInfo.setBattleNumberOfTimes(util.inputNumberOfTimesFormat());

			// 対戦人数
			System.out.println(Constant.COM_NUMBER_OF_TIMES);
			System.out.print(Constant.INPUT_AUXILIARY);
			gameInfo.setComputerNumberOfTimes(util.inputNumberOfTimesFormat());

			// 対戦人数分コンピューターを生成
			for (int i = 0; i < gameInfo.getComputerNumberOfTimes(); i++) {
				Player computer = new Player();
				computerList.add(computer);
			}

			// じゃんけん開始
			System.out.println(Constant.JANKEN_START_MESSAGE + "\n");
			for (int i = 0; i < gameInfo.getBattleNumberOfTimes(); i++) {
				System.out.println("【" + (i + 1) + Constant.JANKEN_BATTLE_NUMBER_MESSAGE);
				System.out.println(Constant.JANKEN_CHOICE_MESSAGE);
				System.out.println(Constant.JANKEN_CHOICE_AUXILIARY_MESSAGE);
				System.out.print(Constant.INPUT_AUXILIARY);

				// プレイヤーの手の入力
				player.setHand(util.inputPlayerHandNumberOfTimesFormat());

				// 入力された手の表示
				player.outputHand(player.getHand());
				System.out.print(Constant.VS_MESSAGE);

				for (int j = 0; j < computerList.size(); j++) {
					// コンピューターの手をランダム生成して値を詰める
					computerList.get(j).setHand((int) (Math.random() * 3));

					// 表示する
					computerList.get(j).outputHand(computerList.get(j).getHand());

					// 最後のコンピューターの場合は vs.を表示しない
					if (j < (computerList.size() - 1)) {
						System.out.print(Constant.VS_MESSAGE);
					}

				}

				System.out.println();

				// じゃんけん判定処理
				jadge.gameJudge(player, computerList);

			}

			// じゃんけん終了
			System.out.println(Constant.JANKEN_END_MESSAGE + "\n");

			// じゃんけんの結果判定処理
			gameInfo.showResult(player, computerList, jadge);

			// 例外処理 java7から複数例外が実装可能
		} catch (IOException | NumberFormatException e) {
			System.out.println(Constant.SYSTEM_ERROR_MESSAGE);
			System.out.println(Constant.SYSTEM_END_MESSAGE);
			// e.printStackTrace();

		} catch (Exception e) {
			System.out.println(Constant.SYSTEM_ERROR_MESSAGE);
			System.out.println(Constant.SYSTEM_END_MESSAGE);
			// e.printStackTrace();
		}

	}

}
