package janken.extra;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author m-sakai
 * じゃんけん判定処理クラス
 *
 */
public class JankenJudge {

	/**
	 * コンストラクタ
	 */
	JankenJudge() {
	}

	/**
	 * 勝負判定を実施するメソッド
	 */
	void gameJudge(Player player, List<Player> computerList) {

		// リストの初期値設定0,1,2にfalseを代入
		List<Boolean> usedHand = Arrays.asList(false, false, false);

		// プレイヤーの手と一致する箇所にtrueを代入、グーなら0,チョキなら1,パーなら2
		usedHand.set(player.getHand(), true);

		// コンピューターの手と一致する箇所にtrueを代入、グーなら0,チョキなら1,パーなら2
		for (Player cpu : computerList) {
			usedHand.set(cpu.getHand(), true);
		}

		// 引き分けのパターン、上から「グーチョキパー、グーのみ、チョキのみ、パーのみ」
		if ((usedHand.get(Constant.STONE) && usedHand.get(Constant.SCISSORS) && usedHand.get(Constant.PAPER))
				|| (usedHand.get(Constant.STONE) && !usedHand.get(Constant.SCISSORS) && !usedHand.get(Constant.PAPER))
				|| (!usedHand.get(Constant.STONE) && usedHand.get(Constant.SCISSORS) && !usedHand.get(Constant.PAPER))
				|| (!usedHand.get(Constant.STONE) && !usedHand.get(Constant.SCISSORS)
						&& usedHand.get(Constant.PAPER))) {
			System.out.println(Constant.JANKEN_DRAW + "\n");

			// メソッド終了
			return;
		}

		// プレイヤーが勝利しているか判定
		gameJudgeResult(usedHand, player, Constant.PLAYER);

		// コンピューターが勝利しているか判定
		for (int i = 0; i < computerList.size(); i++) {
			gameJudgeResult(usedHand, computerList.get(i), Constant.COMPUTER + (i + 1));
		}

		System.out.println();
	}

	/**
	 * 1ゲーム毎の判定処理結果メソッド
	 */
	void gameJudgeResult(List<Boolean> drawFlag, Player player, String playerName) {

		// 他のプレイヤー（コンピューター）がチョキまたはパーのみの場合
		if (!drawFlag.get(Constant.STONE)) {

			// 該当プレイヤー（コンピューター）がチョキでの勝利処理
			if (player.getHand() == Constant.SCISSORS) {
				System.out.println(playerName + Constant.JANKEN_WIN);

				// 勝利数を1増やす
				player.setWinCount(player.getWinCount() + 1);
			}
		}
		// 他のプレイヤー（コンピューター）がグーまたはパーのみの場合
		else if (!drawFlag.get(Constant.SCISSORS)) {

			// 該当プレイヤー（コンピューター）がパーでの勝利処理
			if (player.getHand() == Constant.PAPER) {
				System.out.println(playerName + Constant.JANKEN_WIN);

				// 勝利数を1増やす
				player.setWinCount(player.getWinCount() + 1);
			}
		}

		// 他のプレイヤー（コンピューター）がグーまたはチョキのみの場合
		else {

			// 該当プレイヤー（コンピューター）がグーでの勝利処理
			if (player.getHand() == Constant.STONE) {
				System.out.println(playerName + Constant.JANKEN_WIN);

				// 勝利数を1増やす
				player.setWinCount(player.getWinCount() + 1);
			}
		}
	}

	/**
	 * 引き分け判定処理
	 */
	boolean gameJudgeDraw(int winCount, Player player, List<Player> computerList) {

		boolean drawFlag = false;

		for (Player computer : computerList) {
			// 勝ち数が最大勝ち数と異なる場合
			if (computer.getWinCount() != winCount) {

				// 勝利者がいるので、引き分けではないことを戻す
				return drawFlag;
			}
		}

		// 上記と同様
		if (player.getWinCount() != winCount) {
			return drawFlag;
		}

		// 引き分け
		drawFlag = true;
		return drawFlag;
	}

	/**
	 * 勝ち負け判定処理
	 */
	void gameResult(int winCount, Player player, String playerName) {

		// 勝利数が最大、または同数の場合
		if (player.getWinCount() >= winCount) {
			System.out.println(player.getWinCount() + Constant.GAME_MESSAGE_FIRST + playerName + Constant.WIN_MESSAGE_LAST);

			// 勝利数が最大より少ない場合
		} else {
			System.out.println(player.getWinCount() + Constant.GAME_MESSAGE_FIRST + playerName + Constant.LOSE_MESSAGE_LAST);
		}
	}

}
