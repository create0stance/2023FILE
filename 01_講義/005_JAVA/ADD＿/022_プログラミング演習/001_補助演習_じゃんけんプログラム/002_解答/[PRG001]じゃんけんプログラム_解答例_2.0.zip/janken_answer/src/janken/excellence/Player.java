package janken.excellence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author m-sakai ジャンケンを行うプレイヤークラス
 */
public class Player {

	// 勝利数
	private int winCount;

	// 選択手
	private String hand;
		
	/**
	 * コンストラクタ
	 */
	Player() {
		this.winCount = 0;
		this.hand = null;
	}

	// セッターゲッター（プロパティ）
	public int getWinCount() {
		return winCount;
	}

	public void setWinCount(int winCount) {
		this.winCount = winCount;
	}

	public String getHand() {
		return hand;
	}

	public void setHand(String hand) {
		this.hand = hand;
	}

	/**
	 * 勝利点をプラスする
	 */
	public void plusWinCount() {
		this.winCount++;
	}

	public void inputHand() {
		BufferedReader br = new BufferedReader(
				new InputStreamReader(System.in));
		try {
			// プレイヤーの手の入力
			this.hand = br.readLine();
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			System.out.println("システムエラーが発生しました。 ");
			System.out.println("システムを終了します。 ");
			System.exit(1);
		}
	}

}
