package janken.enhancement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 * ジャンケンゲーム（standard）サンプルソース 初心者向けのシンプルなアルゴリズムで作成しています。
 * 
 * @author 東京ITスクール
 * 
 */
public class JankenStandardSample {

	/**
	 * ジャンケン3回繰り返すプログラムです。 上巻までの内容で出来る必要最低限の処理となります。
	 * 
	 */
	public static void main(String[] args) {

		// 勝敗カウント用の変数を用意
		int winCount = 0;
		int loseCount = 0;

		// ランダム関数の準備
		final Random rand = new Random();

		System.out.println("【じゃんけんを開始します】");

		// じゃんけん開始
		for (int i = 1; i <= 3; i++) {
			System.out.println("【" + i + "回戦目】");
			System.out.println("プレイヤーの手を選択してください。");
			System.out.println("（グー：0  チョキ:1  パー:2） ");
			System.out.print("＞");

			BufferedReader br = new BufferedReader(
					new InputStreamReader(System.in));

			// キーボードから読み込み
			String yourHand = null;
			try {
				while (true) {
					yourHand = br.readLine();
					if(Integer.parseInt(yourHand) >= 0 && Integer.parseInt(yourHand) <= 2) {
						break;
					} else {
						System.out.print("入力した値が誤っています、再度入力してください \n＞");
						continue;
					}
				}
			} catch (IOException | NumberFormatException e) {
				// TODO 自動生成された catch ブロック
				System.out.println("システムエラーが発生しました。 ");
				System.out.println("システムを終了します。 ");
				System.exit(1);
			} 

			// コンピュータの手をランダムに取得
			final int computerHand = rand.nextInt(3);

			// 判定処理
			switch (yourHand) {

				// 自分がグーの場合
				case "0" :
					// 相手がグー
					if (computerHand == 0) {
						System.out.println("グー  vs.  グー");
						System.out.println("引き分けです！");

						// 相手がチョキ
					} else if (computerHand == 1) {
						System.out.println("グー  vs.  チョキ");
						System.out.println("プレイヤーが勝ちました！");
						winCount++;

						// 相手がパー
					} else if (computerHand == 2) {
						System.out.println("グー  vs.  パー");
						System.out.println("コンピューターが勝ちました！");
						loseCount++;
					}
					break;

				// 自分がチョキの場合
				case "1" :
					// 相手がグー
					if (computerHand == 0) {
						System.out.println("チョキ  vs.  グー");
						System.out.println("コンピューターが勝ちました！");
						loseCount++;

						// 相手がチョキ
					} else if (computerHand == 1) {
						System.out.println("チョキ  vs.  チョキ");
						System.out.println("引き分けです！");

						// 相手がパー
					} else if (computerHand == 2) {
						System.out.println("チョキ  vs.  パー");
						System.out.println("プレイヤーが勝ちました！");
						winCount++;
					}
					break;

				// 自分がパーの場合
				case "2" :
					// 相手がグー
					if (computerHand == 0) {
						System.out.println("パー  vs.  グー");
						System.out.println("プレイヤーが勝ちました！");
						winCount++;

						// 相手がチョキ
					} else if (computerHand == 1) {
						System.out.println("パー  vs.  チョキ");
						System.out.println("コンピューターが勝ちました！");
						loseCount++;

						// 相手がパー
					} else if (computerHand == 2) {
						System.out.println("パー  vs.  パー");
						System.out.println("引き分けです！");

					}
					break;
			}
			// 改行用
			System.out.println();

		}
		System.out.println("【ジャンケン終了】");

		// 結果判定
		if (loseCount < winCount) {
			System.out.println(winCount + "対" + loseCount + "でプレイヤーの勝ちです！");

		} else if (winCount < loseCount) {
			System.out.println(winCount + "対" + loseCount + "でコンピューターの勝ちです！");

		} else if (winCount == loseCount) {
			System.out.println(winCount + "対" + loseCount + "で引き分けです！");
		}
	}
}
