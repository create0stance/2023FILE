package janken.extra;

/**
 * @author m-sakai
 * メインクラス、Playerクラスを生成して、start機能の呼び出し
 */
public class SystemMain {

	/**
     * コンストラクタ
     * private付与して、newさせなくする
     */
    private SystemMain(){}

    public static void main(String[] args) {

        // プレイヤーの生成
        Player player = new Player();

        // スタートクラスの生成
        JankenStart janken = new JankenStart(player);

        // じゃんけん処理開始
        janken.start();
    }
}