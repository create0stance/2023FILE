package janken.extra;

import java.util.List;

/**
 *
 * @author m-sakai
 * 勝負情報格納クラス
 *
 */
public class GameInformation {

	// 勝負回数
	private int battleNumberOfTimes;

	// 対戦人数
	private int computerNumberOfTimes;

	/**
     * コンストラクタ
     */
	GameInformation() {

		// 勝負回数 初期値
		this.battleNumberOfTimes = 1;

		// 対戦人数 初期値
		this.computerNumberOfTimes = 1;
	}

	/**
	 * 勝負の結果表示
	 */
	void showResult(Player player, List<Player> computerList, JankenJudge judge) {

		// 勝ち数を取得
		int winCount = player.getWinCount();

		for (Player computer : computerList) {

			// コンピューターが勝利数を上回っていたら
			if (winCount <= computer.getWinCount()) {
				// 勝利数を上書き
				winCount = computer.getWinCount();
			}

		}

		// 引き分けだった場合
		if (judge.gameJudgeDraw(winCount, player, computerList)) {
			System.out.println(Constant.ALL_MESSAGE + winCount + Constant.DRAW_MESSAGE);

		} else {
			// プレイヤーの結果表示
			judge.gameResult(winCount, player, Constant.PLAYER);

			// コンピューターの結果表示
			for (int i = 0; i < computerList.size(); i++) {
				judge.gameResult(winCount, computerList.get(i), Constant.COMPUTER + (i + 1));
			}
		}
	}

	// セッターゲッター（プロパティ）
	public int getBattleNumberOfTimes() {
		return battleNumberOfTimes;
	}

	public void setBattleNumberOfTimes(int battleNumberOfTimes) {
		this.battleNumberOfTimes = battleNumberOfTimes;
	}

	public int getComputerNumberOfTimes() {
		return computerNumberOfTimes;
	}

	public void setComputerNumberOfTimes(int computerNumberOfTimes) {
		this.computerNumberOfTimes = computerNumberOfTimes;
	}
}
