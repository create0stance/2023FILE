package janken.extra;

/**
 * コンスタントクラス
 * 定数を用意する（文言や数値は定数として用意する）
 * @author m-sakai
 *
 */
public class Constant {

    public static final int STONE = 0;

    public static final String STONE_MESSAGE = "グー ";

    public static final int SCISSORS = 1;

    public static final String SCISSORS_MESSAGE ="チョキ ";

    public static final int PAPER = 2;

    public static final String PAPER_MESSAGE = "パー ";

    public static final String INPUT_FAIL_MESSAGE = "入力した値が誤っています、再度入力してください";

    public static final String JANKEN_NUMBER_OF_TIMES = "じゃんけんする回数を入力してください";

    public static final String INPUT_AUXILIARY = "＞";

    public static final String COM_NUMBER_OF_TIMES = "対戦相手の人数を入力してください";

    public static final String JANKEN_START_MESSAGE = "【ジャンケン開始】";

    public static final String JANKEN_BATTLE_NUMBER_MESSAGE = "回戦目】";

    public static final String JANKEN_CHOICE_MESSAGE = "プレイヤーの手を決めてください";

    public static final String JANKEN_CHOICE_AUXILIARY_MESSAGE = "（グー：0 チョキ:1 パー:2）";

    public static final String JANKEN_END_MESSAGE = "【ジャンケン終了】";

    public static final String SYSTEM_ERROR_MESSAGE = "システムエラーが発生しました。";

    public static final String SYSTEM_END_MESSAGE = "システムを終了します。";

    public static final String VS_MESSAGE ="vs.";

    public static final int THREE_NUM = 3;

    public static final String JANKEN_WIN = "が勝ちました！ ";

    public static final String JANKEN_DRAW = "引き分けです！";

    public static final String JANKEN_LOSE = "";

    public static final String PLAYER = "プレイヤー";

    public static final String COMPUTER = "コンピューター";

    public static final String ALL_MESSAGE = "全員";

    public static final String DRAW_MESSAGE = "勝で引き分けです！";

    public static final String GAME_MESSAGE_FIRST ="勝で";

    public static final String WIN_MESSAGE_LAST = "の勝ちです！";

    public static final String LOSE_MESSAGE_LAST = "の負けです！";

    /**
     * コンストラクタ
     * new不可のprivate付与 定数クラスはオブジェクト生成させない
     */
    private Constant() {
    }

}
