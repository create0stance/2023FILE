package janken.excellence;

/**
 *
 * @author m-sakai じゃんけん判定処理クラス
 *
 */
public class JankenJudge {

	public static final String STONE = "0";
	public static final String SCISSORS = "1";
	public static final String PAPER = "2";
	public static final String[] HAND_LIST = {"グー ", "チョキ", "パー"};
	// プレイヤーの手
	private String playerHandName;
	// コンピュータの手
	private String computerHandName;

	/**
	 * コンストラクタ
	 */
	JankenJudge() {
	}

	/**
	 * 勝負判定を実施するメソッド
	 */
	void gameJudge(Player player, Player computer) {
		// 表示用に選択手の名前を取得
		playerHandName = HAND_LIST[Integer.parseInt(player.getHand())];
		computerHandName = HAND_LIST[Integer.parseInt(computer.getHand())];
		
		// じゃんけん判定
		if (player.getHand().equals(computer.getHand())) {
			System.out.println(playerHandName + " vs. " + computerHandName);
			System.out.println("引き分けです！\n");
		} else if ((player.getHand().equals(STONE) && computer.getHand().equals(SCISSORS))
				|| (player.getHand().equals(SCISSORS) && computer.getHand().equals(PAPER))
				|| (player.getHand().equals(PAPER) && computer.getHand().equals(STONE))) {
			System.out.println(playerHandName + " vs. " + computerHandName);
			System.out.println("プレイヤーが勝ちました！\n");
			player.plusWinCount();
		} else {
			System.out.println(playerHandName + " vs. " + computerHandName);
			System.out.println("コンピューターが勝ちました！\n");
			computer.plusWinCount();
		}
	}
}