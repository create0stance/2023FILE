package janken.extra;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author m-sakai
 * 共通処理クラス
 *
 */
public class Util {

	/**
     * コンストラクタ
     */
    public Util() {

    }

    /**
     * @return 入力数値
     * @throws IOException
     *         文字列入力後、数値変換処理
     */
    public int inputNumberOfTimesFormat() throws IOException {
        do {

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            // キーボードから読み込み
            String numberOfTimes = br.readLine();

            // 数値かどうかチェック
            if (isNumberCheck(numberOfTimes)) {

                // 数値だった場合は、変換処理
                int num = Integer.parseInt(numberOfTimes);
                return num;

            } else {
                System.out.println(Constant.INPUT_FAIL_MESSAGE);
            }

            // 条件抜けるまで、無限ループ
        } while (true);
    }

    /**
     * @return 入力数値
     * @throws IOException
     *             文字列入力後、数値変換処理
     */
    public int inputPlayerHandNumberOfTimesFormat() throws IOException {

        do {
            int num = inputNumberOfTimesFormat();

            // 3より小さい数字であれば
            if (num < Constant.THREE_NUM) {

                return num;

            } else {
                System.out.println(Constant.INPUT_FAIL_MESSAGE);
            }

            // 条件抜けるまで、無限ループ
        } while (true);
    }

    /**
     * @param strValue
     * @return 数値判定 数値判定チェック処理
     */
    public boolean isNumberCheck(String strValue) {

        // 検証結果を格納する変数
        boolean result = true;

        // 一文字ずつ先頭から確認する。for文は文字数分繰り返す
        for (int i = 0; i < strValue.length(); i++) {

            // Character.isDigitメソッドで数字判定
            if (Character.isDigit(strValue.charAt(i))) {

                // 数字の場合は次の文字の判定へ
                continue;

            } else {

                // 数字でない場合は検証結果をfalseに上書きする
                result = false;
                break;
            }
        }

        return result;
    }

}
