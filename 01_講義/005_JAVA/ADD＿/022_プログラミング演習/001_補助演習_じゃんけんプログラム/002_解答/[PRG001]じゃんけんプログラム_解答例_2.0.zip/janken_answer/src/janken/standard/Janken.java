package janken.standard;

import java.util.Random;
import java.util.Scanner;

/**
 * じゃんけんクラス
 * できるだけ効率的（ステップ数を少なく）に作成したじゃんけんプログラムです。
 *
 * @author m-terada
 */
public class Janken {

    /** グー */
    public static final int STONE = 0;
    /** チョキ */
    public static final int SCISSORS = 1;
    /** パー */
    public static final int PAPER = 2;
    /** 表示用じゃんけんの手 */
    public static final String[] HAND = { "グー", "チョキ", "パー" };

    /**
     * コンピューターとじゃんけんを行う<br/>
     * ・全3回戦<br/>
     * ・引き分けはお互いポイント無し<br/>
     *
     * @param args
     */
    public static void main(String[] args) {

        // 勝ち数、負け数を初期化
        int win = 0;
        int lose = 0;

        // じゃんけん開始
        System.out.println("【じゃんけん開始】\n");

        // 対戦ループ
        for (int i = 1; i <= 3; i++) {

            // 自分の手を選択
            System.out.println("【じゃんけんの手を選択してください】");
            System.out.println("1:グー\n2:チョキ\n3:パー");
			System.out.print("＞");
            Scanner scn = new Scanner(System.in);
            int myHand = scn.nextInt() - 1;

            // エラー判定
            if (myHand != STONE && myHand != SCISSORS && myHand != PAPER) {
                System.out.println("1～3を入力してください！\n");
                i--;
                continue;
            }

            // コンピュータの手を生成
            Random rnd = new Random();
            int comHand = rnd.nextInt(3);

            // お互いの手を表示
            System.out.println("【" + i + "回戦目】");
            System.out.println(HAND[myHand] + " vs " + HAND[comHand]);

            // じゃんけん判定
            if (myHand == comHand) {
                System.out.println("引き分けです！\n");
            } else if ((myHand == STONE && comHand == SCISSORS)
                    || (myHand == SCISSORS && comHand == PAPER)
                    || (myHand == PAPER && comHand == STONE)) {
                win++;
                System.out.println("あなたが勝ちました！\n");
            } else {
                lose++;
                System.out.println("あなたが負けました！\n");
            }
        }

        // 対戦結果を表示
        System.out.println("【ジャンケン終了】");
        System.out.print(win + "対" + lose + "で");
        if (win > lose) {
            System.out.println("あなたの勝ちです！");
        } else if (win < lose) {
            System.out.println("あなたの負けです！");
        } else {
            System.out.println("引き分けです！");
        }
    }
}
