package java_exercise_ip;

import java.util.Random;
import java.util.Scanner;

/**
 * インディアンポーカープログラム
 * 
 * @author k-mori
 *
 */
public class IndianPoker {

	/** トランプが無い */
	public static final int TRUMP_EMPTY = 0;
	/** トランプの1 */
	public static final int TRUMP_1 = 1;
	/** トランプの2 */
	public static final int TRUMP_2 = 2;
	/** トランプの3 */
	public static final int TRUMP_3 = 3;
	/** トランプの4 */
	public static final int TRUMP_4 = 4;
	/** トランプの5 */
	public static final int TRUMP_5 = 5;
	/** トランプの6 */
	public static final int TRUMP_6 = 6;
	/** トランプの7 */
	public static final int TRUMP_7 = 7;
	/** トランプの8 */
	public static final int TRUMP_8 = 8;
	/** トランプの9 */
	public static final int TRUMP_9 = 9;
	/** トランプの10 */
	public static final int TRUMP_10 = 10;
	/** トランプの11 */
	public static final int TRUMP_11 = 11;
	/** トランプの12 */
	public static final int TRUMP_12 = 12;
	/** トランプの13 */
	public static final int TRUMP_13 = 13;
	/** トランプの14 */
	public static final int TRUMP_14 = 14;
	/** トランプのA */
	public static final String TRUMP_A = "A";
	/** トランプのJ */
	public static final String TRUMP_J = "J";
	/** トランプのQ */
	public static final String TRUMP_Q = "Q";
	/** トランプのK */
	public static final String TRUMP_K = "K";
	/** トランプのスペード 配列の1次元目インデックス */
	public static final int TRUMP_SPADE = 0;
	/** トランプのハート 配列の1次元目インデックス */
	public static final int TRUMP_HEART = 1;
	/** トランプのダイヤ 配列の1次元目インデックス */
	public static final int TRUMP_DIA = 2;
	/** トランプのクラブ 配列の1次元目インデックス */
	public static final int TRUMP_CLUB = 3;
	/** トランプのスート ゲーム内表示用 */
	public static final String[] TRUMP_SUIT_NAME = { "スペード", "ハート", "ダイヤ", "クラブ" };
	/** トランプのスート 結果一覧表示用 */
	public static final String[] TRUMP_SUIT_NAME_RESULT = { "スペード", "ハート　", "ダイヤ　", "クラブ　" };
	/** トランプのスート毎に数字を設定 */
	public static final int[][] TRUMP_DEFAULT_SET = { { 14, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 },
			{ 14, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 }, { 14, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 },
			{ 14, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 } };
	/** トランプ1スートあたりの枚数 */
	public static final int TRUMP_ONE_SUIT_NUM = 13;
	/** 手札配列の要素数(トランプのスートと数字) */
	public static final int HAND_ELEMENTS_NUM = 2;
	/** 手札配列のスート用インデックス */
	public static final int HAND_SUIT = 0;
	/** 手札配列の数字用インデックス */
	public static final int HAND_NUM = 1;

	/** ゲームの最大回数 */
	public static final int GAME_MAX_COUNT = 3;
	/** あなたが手札を交換できる回数変数 */
	public static final int TRADE_COUNT = 2;
	/** あなたが手札を交換する選択肢 */
	public static final int TRADE_EXE = 1;

	/** メッセージ */
	public static final String MESSAGE_DRAW = "山札から1枚引きます";
	public static final String MESSAGE_YOU_CARDS = "あなたの手札";
	public static final String MESSAGE_OPPONENT_CARDS = "相手の表示札";
	public static final String MESSAGE_YOU_TRADE = "あなたの手札を交換しますか？";
	public static final String MESSAGE_HIT_OR_STAND = "1:交換\n2:勝負\n＞";
	public static final String MESSAGE_YOU_WIN = "あなたの勝ちです！";
	public static final String MESSAGE_YOU_DEFEAT = "あなたの負けです！";
	public static final String MESSAGE_TIE = "引き分けです！";

	/**
	 * メインメソッド
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		Random random = new Random();

		// あなたの手札配列
		int[] youCards = new int[HAND_ELEMENTS_NUM];
		// 相手の手札配列
		int[] opponentCards = new int[HAND_ELEMENTS_NUM];
		// トランプの山札(デッキ)配列
		int[][] trumpDeck = new int[TRUMP_DEFAULT_SET.length][TRUMP_DEFAULT_SET[TRUMP_SPADE].length];
		// トランプの捨札を記録しておくための配列
		// 山札と同じ配列構成とし、捨札の位置にフラグ(1)を立てて記録する
		int[][] usedCards = new int[TRUMP_DEFAULT_SET.length][TRUMP_DEFAULT_SET[TRUMP_SPADE].length];

		// 勝利点カウント変数
		int youWinCount = 0;
		int opponentWinCOunt = 0;

		// トランプのデフォルトセットを山札配列にコピーする
		for (int i = 0; i < TRUMP_DEFAULT_SET.length; i++) {
			for (int j = 0; j < TRUMP_DEFAULT_SET[i].length; j++) {
				trumpDeck[i][j] = TRUMP_DEFAULT_SET[i][j];
			}
		}

		// シャッフルの実施（シャッフルは各スートごとの数字(2次元目の要素)に対して行う）
		for (int[] suit : trumpDeck) {
			for (int i = 0; i < suit.length; i++) {
				// 入れ替えるインデックス番号をRandomに決定
				int index = random.nextInt(TRUMP_ONE_SUIT_NUM);
				// 今のインデックスの数字を避難
				int tmp = suit[i];
				// 入れ替え先の数字を今のインデックスへ代入
				suit[i] = suit[index];
				// 避難しておいた数字を入れ替え先のインデックスへ代入
				suit[index] = tmp;
			}
		}

		System.out.println("【ゲームスタート】");
		// ゲーム全体のwhile文
		// 勝負回数だけループする
		int gameCount = 0;
		while (gameCount < GAME_MAX_COUNT) {
			gameCount++;
			System.out.println("★" + gameCount + "回戦");

			// あなたの手札配列を0埋めでリセット
			for (int i = 0; i < youCards.length; i++) {
				youCards[i] = TRUMP_EMPTY;
			}

			// ディーラーの手札配列を0埋めでリセット
			for (int i = 0; i < opponentCards.length; i++) {
				opponentCards[i] = TRUMP_EMPTY;
			}

			System.out.println(MESSAGE_DRAW);
			// あなたの最初のドロー
			// スートと数字(のインデックス)をランダムに決定
			int suit = 0;
			int num = 0;
			do {
				suit = random.nextInt(TRUMP_DEFAULT_SET.length);
				num = random.nextInt(TRUMP_DEFAULT_SET[TRUMP_SPADE].length);
				// 捨札配列にフラグが立っていたら使用済みのトランプなのでやり直す
			} while (usedCards[suit][num] == 1);
			// 手札配列にスートと数字をセットする
			youCards[HAND_SUIT] = suit;
			youCards[HAND_NUM] = TRUMP_DEFAULT_SET[suit][num];
			// 捨札配列にフラグを立てて記録する
			usedCards[suit][num] = 1;

			// 相手の最初のドロー
			// スートと数字(のインデックス)をランダムに決定
			do {
				suit = random.nextInt(TRUMP_DEFAULT_SET.length);
				num = random.nextInt(TRUMP_DEFAULT_SET[TRUMP_SPADE].length);
				// 捨札配列にフラグが立っていたら使用済みのトランプなのでやり直す
			} while (usedCards[suit][num] == 1);
			// 手札配列にスートと数字をセット
			opponentCards[HAND_SUIT] = suit;
			opponentCards[HAND_NUM] = TRUMP_DEFAULT_SET[suit][num];
			// 捨札配列にフラグを立てて記録する
			usedCards[suit][num] = 1;

			// 相手の手札のスートの出力を保存
			String opponentHandMsg = MESSAGE_OPPONENT_CARDS + "：" + TRUMP_SUIT_NAME[opponentCards[HAND_SUIT]] + " ";
			// 数字の出力を保存
			switch (opponentCards[HAND_NUM]) {
			case TRUMP_14: // 14ならAを出力
				opponentHandMsg += TRUMP_A;
				break;
			case TRUMP_11: // 11ならJを出力
				opponentHandMsg += TRUMP_J;
				break;
			case TRUMP_12: // 12ならQを出力
				opponentHandMsg += TRUMP_Q;
				break;
			case TRUMP_13: // 13ならKを出力
				opponentHandMsg += TRUMP_K;
				break;
			default: // 2~9ならそのまま出力
				opponentHandMsg += opponentCards[HAND_NUM];
				break;
			}
			// 相手の手札を表示
			System.out.println(opponentHandMsg);
			System.out.println();

			// あなたの手札メッセージを保存する変数
			String youHandMsg = "";
			// あなたが手札を交換するループ
			// あなたの手札出力用文字列の準備を最大3回行いたいため、for文は無限ループとする
			for (int i = TRADE_COUNT;; i--) {
				// メッセージ変数はループ先頭で初期化
				youHandMsg = "";
				// あなたの手札出力用文字列を準備
				youHandMsg += MESSAGE_YOU_CARDS + "：" + TRUMP_SUIT_NAME[youCards[HAND_SUIT]] + " ";
				// あなたの手札の数字
				switch (youCards[HAND_NUM]) {
				case TRUMP_14: // 14ならAを出力
					youHandMsg += TRUMP_A;
					break;
				case TRUMP_11: // 11ならJを出力
					youHandMsg += TRUMP_J;
					break;
				case TRUMP_12: // 12ならQを出力
					youHandMsg += TRUMP_Q;
					break;
				case TRUMP_13: // 13ならKを出力
					youHandMsg += TRUMP_K;
					break;
				default: // 2~9ならそのまま出力
					youHandMsg += youCards[HAND_NUM];
					break;
				}

				// 残回数が0以下ならループを脱出
				if (i <= 0) {
					break;
				}

				System.out.println(MESSAGE_YOU_TRADE + "(残" + i + "回)");
				System.out.print(MESSAGE_HIT_OR_STAND);
				// 手札を交換するか選ぶ
				int hitOrStand = stdIn.nextInt();
				// 1以外の入力でループを脱出
				if (hitOrStand != TRADE_EXE) {
					System.out.println();
					break;
				}
				// 捨てる手札を表示
				System.out.print(youHandMsg);
				System.out.println("でした");

				System.out.println(MESSAGE_DRAW);
				System.out.println();
				// スートと数字(のインデックス)をランダムに決定
				do {
					suit = random.nextInt(TRUMP_DEFAULT_SET.length);
					num = random.nextInt(TRUMP_DEFAULT_SET[TRUMP_SPADE].length);
					// 捨札配列にフラグが立っていたら使用済みのトランプなのでやり直す
				} while (usedCards[suit][num] == 1);
				// 手札配列にスートと数字をセットする
				youCards[HAND_SUIT] = suit;
				youCards[HAND_NUM] = TRUMP_DEFAULT_SET[suit][num];
				// 捨札配列にフラグを立てて記録する
				usedCards[suit][num] = 1;
			}

			// 勝負結果の処理
			System.out.println("【勝負！】");
			// 相手の手札表示
			System.out.println(opponentHandMsg);
			// あなたの手札表示
			System.out.println(youHandMsg);
			// 数字が大きい方の勝ち
			if (youCards[HAND_NUM] > opponentCards[HAND_NUM]) {
				System.out.println(MESSAGE_YOU_WIN);
				youWinCount++;
			} else if (youCards[HAND_NUM] < opponentCards[HAND_NUM]) {
				System.out.println(MESSAGE_YOU_DEFEAT);
				opponentWinCOunt++;
			} else {
				System.out.println(MESSAGE_TIE);
			}
			System.out.println();

			// 捨札の一覧表示
			System.out.println(" 捨札");
			System.out.println("---------------------------------------------------");
			// 捨札配列を順番に出力
			for (int i = 0; i < usedCards.length; i++) {
				// スートを表示
				System.out.print(" " + TRUMP_SUIT_NAME_RESULT[i] + " |");
				// 数字を表示
				for (int j = 0; j < usedCards[i].length; j++) {
					// 捨札配列でフラグ(1)が立っている位置について出力
					if (usedCards[i][j] != TRUMP_EMPTY) {
						// フラグの位置に対応する数字をTRUMP_DEFAULT_SETから出力する
						switch (TRUMP_DEFAULT_SET[i][j]) {
						case TRUMP_14: // 14ならAを出力
							System.out.printf("%3s", TRUMP_A);
							break;
						case TRUMP_11: // 11ならJを出力
							System.out.printf("%3s", TRUMP_J);
							break;
						case TRUMP_12: // 12ならQを出力
							System.out.printf("%3s", TRUMP_Q);
							break;
						case TRUMP_13: // 13ならKを出力
							System.out.printf("%3s", TRUMP_K);
							break;
						default: // 2~9ならそのまま出力
							System.out.printf("%3s", TRUMP_DEFAULT_SET[i][j]);
							break;
						}
					}
				}
				System.out.println();
			}
			System.out.println("---------------------------------------------------");
			System.out.println(" 勝利点 あなた" + youWinCount + "：相手" + opponentWinCOunt);
			System.out.println();

		} // ゲームループの終端

		System.out.println("【最終結果】");
		// 最終結果を出力
		if (youWinCount > opponentWinCOunt) {
			System.out.println(MESSAGE_YOU_WIN);
		} else if (youWinCount < opponentWinCOunt) {
			System.out.println(MESSAGE_YOU_DEFEAT);
		} else {
			System.out.println(MESSAGE_TIE);
		}

		System.out.println();
		System.out.println("【ゲーム終了】");
		
		stdIn.close();
	}// mainメソッドの終端
}
