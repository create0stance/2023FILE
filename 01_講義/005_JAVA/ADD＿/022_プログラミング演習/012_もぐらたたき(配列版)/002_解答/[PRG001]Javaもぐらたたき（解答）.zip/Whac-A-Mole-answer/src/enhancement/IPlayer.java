package enhancement;

/**
 * プレイヤー用インターフェイス<br />
 * プレイヤーに必要なメソッドを決める
 *
 * @author SystemShared
 *
 */
public interface IPlayer {

	/** モグラの初期設定数 */
	int INITIAL_VALUE = 3;

	/**
	 * モグラ配置機能<br/>
	 * モグラをマス上の任意の位置へ配置する
	 *
	 */
	void positioningMoles();

	/**
	 * 叩くマス決定機能<br/>
	 * 叩くマスの座標を決める
	 *
	 * @return 叩くマスの座標
	 */
	int selectStrikePoint();

	/**
	 * 名前取得機能<br/>
	 * プレイヤーの名前を返す
	 *
	 * @return プレイヤーの名前
	 */
	String getName();

	/**
	 * 名前登録機能<br/>
	 * プレイヤーの名前を登録する
	 *
	 * @param name
	 *            登録するプレイヤーの名前
	 */
	void setName(String name);

	/**
	 * モグラ取得機能<br/>
	 * プレイヤーが所持しているモグラをリストで返す
	 *
	 * @return プレイヤーが所持しているモグラ
	 */
	Mole[] getMoles();

	/**
	 * モグラ登録機能<br/>
	 * プレイヤーにモグラを所持させる
	 *
	 * @param moles
	 *            所持させるモグラ
	 */
	void setMoles(Mole[] moles);

	/**
	 * モグラ所持判定機能<br/>
	 * プレイヤーがモグラを1匹以上所持しているかを判定する
	 * 
	 * @return haveMoles
	 */
	boolean haveMoles();
}
