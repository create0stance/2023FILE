package enhancement;

import java.util.Scanner;

/**
 * ゲームの進行役クラス<br/>
 * モグラたたきゲームの中心となるクラス
 *
 * @author SystemShared
 *
 */
public class Master {

	// 入力準備
	Scanner stdIn = new Scanner(System.in);

	/** ユーザーの名前 */
	public static final String USER_NAME = "テスト太郎(あなた)";

	/** コンピューター（対戦相手）の名前 */
	public static final String COM_NAME = "テスト2-D2(コンピューター)";

	/**
	 * ゲーム進行機能<br/>
	 * ゲームの進行を行う。
	 *
	 */
	public void advance() {

		System.out.println("\n「ゲームスタート！」");

		// ユーザーの準備
		User user = new User();
		user.setName(USER_NAME);

		// コンピューターの準備
		Computer computer = new Computer();
		computer.setName(COM_NAME);

		// 第何回戦目かカウントするための変数
		int gameCount = 1;

		// どちらか一方のモグラが全滅するまで繰り返す
		do {

			System.out.println("\n\n   「第" + gameCount + "回戦！」");

			// それぞれのプレイヤーにモグラを配置させる
			user.positioningMoles();
			computer.positioningMoles();

			// 盤の表示
			Display.showHex();

			// それぞれのプレイヤーに叩くマスを決定させる
			int userStrikePoint = user.selectStrikePoint();
			int comStrikePoint = computer.selectStrikePoint();

			// ユーザーがモグラを叩けたか判定
			boolean userHitFlag = judge(user, userStrikePoint);

			// ユーザーの結果表示
			showResult(user,userHitFlag, userStrikePoint);

			goNext(); // 次へ進む(Enterキーの入力)

			// コンピューターがモグラを叩けたか判定
			boolean comHitFlag = judge(computer, comStrikePoint);

			// コンピューターの結果表示
			showResult(computer, comHitFlag, comStrikePoint);

			gameCount++; // 対戦回数を増やす

			goNext(); // 次へ進む(Enterキーの入力)

			// どちらか一方のモグラの残数が0になったらゲーム終了
		} while (user.haveMoles() && computer.haveMoles());

		// 最終勝者の判定と表示
		finalJudge(user, computer);
	}

	/**
	 * あたり判定機能<br/>
	 * プレイヤーがモグラを叩けたか判定する
	 *
	 * @param currentPlayer
	 *            対戦相手のプレイヤーオブジェクト
	 *
	 * @param strikePoint
	 *            判定対象プレイヤーが叩いた座標
	 *
	 * @return 叩けた場合はtrueが返る
	 *
	 */
	private boolean judge(IPlayer currentPlayer, int strikePoint) {

		// あたり判定フラグ
		boolean hitFlag = false;

		// 配置されたモグラの総数分繰り返す
		for (Mole mole : currentPlayer.getMoles()) {

			// Hit済みのモグラはスキップ
			if (mole.isHitFlag()) {
				continue;
			}
			// あたった場合は
			if (mole.getStayPoint() == strikePoint) {

				// 叩かれたモグラ内のフラグをあげる
				mole.setHitFlag(true);

				// あたり判定フラグをあげる
				hitFlag = true;
			}
		}
		return hitFlag;
	}

	/**
	 * 叩いた後の盤表示機能<br/>
	 * 叩いた後ゲーム盤がどのようになっているか表示する
	 *
	 * @param currentPlayer
	 *            判定対象のプレイヤーオブジェクト
	 * @param hitFlag
	 *            あたり判定
	 * @param strikePoint
	 *            判定対象プレイヤーが叩いた座標
	 */
	private void showResult(IPlayer currentPlayer, boolean hitFlag, int strikePoint) {

		System.out.println("\n「" + currentPlayer.getName() + "さんが叩いた結果を表示します。」\n");

		// 盤の情報を表示する処理
		Display.showHex(hitFlag, currentPlayer.getMoles(), strikePoint);

		// モグラの匹数分繰り返す
		for (Mole mole : currentPlayer.getMoles()) {

			// それぞれのモグラにメッセージを出力させる
			mole.speak();
		}
	}

	/**
	 * 最終勝者判定機能<br/>
	 * 最終的な勝者を判定し表示する
	 *
	 * @param user
	 *            ユーザーのオブジェクト
	 * @param computer
	 *            コンピューターのオブジェクト
	 */
	private void finalJudge(User user, Computer computer) {

		System.out.println("\n「ゲーム終了！」\n");

		// ユーザーのモグラが全滅し、かつコンピューターのモグラが存在する場合
		if (!user.haveMoles() && computer.haveMoles()) {
			System.out.println("\n「おめでとうございます。" + user.getName() + "さんの勝利です。」");

			// ユーザー、コンピューターともにモグラが存在しなかった場合
		} else if (!user.haveMoles() && !computer.haveMoles()) {
			System.out.println("\n「う～ん、おしい！今回は引き分けでした。」");

			// ユーザーのモグラが存在し、かつコンピューターのモグラが全滅した場合
		} else {
			System.out.println("\n「残念でした。。。" + computer.getName() + "が勝ちました。」");
		}
	}

	/**
	 * 次画面表示機能<br/>
	 * コンソールの出力が流れるのを防ぐため<br/>
	 * Enterキーを入力させ、次に展開に進ませる
	 *
	 */
	private void goNext() {
		System.out.print("\n【何か入力しEnterキーを押してください】＞");

		try {
			// 入力させる(Enterキーで案内しているが何が入力されても可)
			stdIn.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
