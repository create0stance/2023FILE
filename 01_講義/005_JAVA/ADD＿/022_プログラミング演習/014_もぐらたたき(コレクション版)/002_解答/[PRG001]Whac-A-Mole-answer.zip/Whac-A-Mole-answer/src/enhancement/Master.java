package enhancement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 * ゲームの進行役クラス<br/>
 * モグラたたきゲームの中心となるクラス
 *
 * @author SystemShared
 *
 */
public class Master {

    /** ユーザーの名前 */
    public static final String USER_NAME = "テスト太郎(あなた)";

    /** コンピューター（対戦相手）の名前 */
    public static final String COM_NAME = "テスト2-D2(コンピューター)";

    /**
     * ゲーム進行機能<br/>
     * ゲームの進行を行う。
     *
     */
    public void advance() {

        System.out.println("\n「ゲームスタート！」");

        // ユーザーの準備
        User user = new User();
        user.setName(USER_NAME);

        // コンピューターの準備
        Computer computer = new Computer();
        computer.setName(COM_NAME);

        // 第何回戦目かカウントするための変数
        int gameCount = 1;

        // どちらか一方のモグラが全滅するまで繰り返す
        do {

            System.out.println("\n\n   「第" + gameCount + "回戦！」");

            // それぞれのプレイヤーにモグラを配置させる
            user.positioningMoles();
            computer.positioningMoles();

            // 盤の表示
            Display.showHex();

            // それぞれのプレイヤーに叩くマスを決定させる
            int userStrikePoint = user.selectStrikePoint();
            int comStrikePoint = computer.selectStrikePoint();

            // ユーザーがモグラを叩けたか判定
            boolean userHitFlag = judge(computer, userStrikePoint);

            // ユーザーの結果表示
            showResult(user, computer, userHitFlag, userStrikePoint);

            // ユーザーがモグラを叩けた場合
            if (userHitFlag) {

                // ユーザーに叩かれたコンピューターのモグラの削除処理
                removeMole(computer);
            }

            goNext(); // 次へ進む(Enterキーの入力)

            // コンピューターがモグラを叩けたか判定
            boolean comHitFlag = judge(user, comStrikePoint);

            // コンピューターの結果表示
            showResult(computer, user, comHitFlag, comStrikePoint);

            // コンピューターがモグラを叩けた場合
            if (comHitFlag) {

                // コンピューターに叩かれたユーザーのモグラの削除処理
                removeMole(user);
            }

            gameCount++; // 対戦回数を増やす

            goNext(); // 次へ進む(Enterキーの入力)

            // どちらか一方のモグラの残数が0になったらゲーム終了
        } while (!user.getMoles().isEmpty() && !computer.getMoles().isEmpty());

        // 最終勝者の判定と表示
        finalJudge(user, computer);
    }

    /**
     * あたり判定機能<br/>
     * プレイヤーがモグラを叩けたか判定する
     *
     * @param opponent
     *            対戦相手のプレイヤーオブジェクト
     *
     * @param strikePoint
     *            判定対象プレイヤーが叩いた座標
     *
     * @return 叩けた場合はtrueが返る
     *
     */
    private boolean judge(IPlayer opponent, int strikePoint) {

        // あたり判定フラグ
        boolean hitFlag = false;

        // 配置されたモグラの総数分繰り返す
        for (Mole mole : opponent.getMoles()) {

            // あたった場合は
            if (mole.getStayPoint() == strikePoint) {

                // 叩かれたモグラ内のフラグをあげる
                mole.setHitFlag(true);

                // あたり判定フラグをあげる
                hitFlag = true;
            }
        }
        return hitFlag;
    }

    /**
     * 叩いた後の盤表示機能<br/>
     * 叩いた後ゲーム盤がどのようになっているか表示する
     *
     * @param currentPlayer
     *            判定対象のプレイヤーオブジェクト
     * @param opponent
     *            対戦相手のプレイヤーオブジェクト
     * @param hitFlag
     *            あたり判定
     * @param strikePoint
     *            判定対象プレイヤーが叩いた座標
     */
    private void showResult(IPlayer currentPlayer, IPlayer opponent,
            boolean hitFlag, int strikePoint) {

        System.out
                .println("\n「" + currentPlayer.getName() + "さんが叩いた結果を表示します。」\n");

        // 盤の情報を表示する処理
        Display.showHex(hitFlag, opponent.getMoles(), strikePoint);

        // 対戦相手のモグラの匹数分繰り返す
        for (Mole mole : opponent.getMoles()) {

            // それぞれのモグラにメッセージを出力させる
            mole.speak();
        }
    }

    /**
     * 叩かれたモグラ削除機能<br/>
     * 叩かれたモグラをリストから消去する
     *
     * @param player
     *            対戦相手のプレイヤーオブジェクト
     */
    private void removeMole(IPlayer opponent) {

        // 対戦相手のプレイヤーが持っているモグラをmolesに移す
        List<Mole> moles = opponent.getMoles();

        // 対戦相手のモグラの数分繰り返す
        for (int i = 0; i < moles.size(); i++) {

            // リストからモグラ1匹分のオブジェクトを取得する
            Mole mole = moles.get(i);

            // そのモグラのあたり判定フラグが立っていたら
            if (mole.isHitFlag()) {

                // そのモグラをリストから消去する
                moles.remove(i);
            }
        }
        // 残モグラ数の表示
        System.out.println("\n「" + opponent.getName() + "の残モグラ数："
                + moles.size() + "匹」");
    }

    /**
     * 最終勝者判定機能<br/>
     * 最終的な勝者を判定し表示する
     *
     * @param user
     *            ユーザーのオブジェクト
     * @param computer
     *            コンピューターのオブジェクト
     */
    private void finalJudge(User user, Computer computer) {

        System.out.println("\n「ゲーム終了！」\n");

        // ユーザーのモグラが存在し、かつコンピューターのモグラが存在しなかった場合
        if (!user.getMoles().isEmpty() && computer.getMoles().isEmpty()) {
            System.out.println("\n「おめでとうございます。" + user.getName() + "さんの勝利です。」");

            // ユーザー、コンピューターともにモグラが存在しなかった場合
        } else if (user.getMoles().isEmpty() && computer.getMoles().isEmpty()) {
            System.out.println("\n「う～ん、おしい！今回は引き分けでした。」");

            // コンピューターのモグラが存在し、かつユーザーのモグラが存在しなかった場合
        } else {
            System.out.println("\n「残念でした。。。" + computer.getName() + "が勝ちました。」");
        }
    }

    /**
     * 次画面表示機能<br/>
     * コンソールの出力が流れるのを防ぐため<br/>
     * Enterキーを入力させ、次に展開に進ませる
     *
     */
    private void goNext() {

        System.out.println("\n【Enterキーを押してください】");

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {
            // 入力させる(Enterキーで案内しているが何が入力されても可)
            br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
