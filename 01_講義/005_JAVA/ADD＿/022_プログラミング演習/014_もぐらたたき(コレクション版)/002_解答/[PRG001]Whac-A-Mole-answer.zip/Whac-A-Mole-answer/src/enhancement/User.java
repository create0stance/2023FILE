package enhancement;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * ユーザークラス<br/>
 * このゲームのユーザーの機能をまとめたクラス
 *
 * @author SystemShared
 *
 */
public class User implements IPlayer {

    /** プレイヤーの名前 */
    private String name;

    /** プレイヤーが所持しているモグラ */
    private List<Mole> moles = new ArrayList<Mole>();

    /** 0.0～1.0未満の乱数に対してかける数 */
    private final int INCREASE_NUM = 10;

    /** 乱数に対してわる数（0～8の剰余を求めるため） */
    private final int UPPER_LIMIT_NUM = 9;

    /**
     * コンストラクタ<br/>
     * オブジェクトが生成されるタイミングで<br/>
     * モグラをリストに詰めておく
     */
    public User() {

        // モグラの初期設定数分くり返す
        for (int i = 0; i<INITIAL_VALUE; i++) {

            // 新しいモグラオブジェクトの作成
            Mole mole = new Mole();

            // 作成したモグラをリストに詰める
            moles.add(mole);
        }
    }

    /* (非 Javadoc)
     * @see whacamole.IPlayer#positioningMoles()
     */
    @Override
    public void positioningMoles() {

        // モグラの匹数分くり返す
        for (Mole mole : moles) {

            // モグラの配置マス用変数
            int point;

            do {
                // ランダムに配置マスを取得する
                point = getRandomPoint();

                // 取得したマス番号に既にモグラがいた場合はやり直し
            } while(checkAlreadyStay(point));

            // そのモグラの配置マスとして登録する
            mole.setStayPoint(point);
        }
    }

    /* (非 Javadoc)
     * @see whacamole.IPlayer#selectStrikePoint()
     */
    @Override
    public int selectStrikePoint() {

        // 入力準備
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // 叩くマスの一次入力用変数
        String stirikePointStr = null;

        // 叩くマス用変数
        int strikePoint = 0;

        // 入力エラー時にくり返すか判定するフラグ
        boolean roopFlag = false;

        System.out.println("\n「叩くマスを選んでください 1～9(半角数字)」");

        do {
            // ループフラグを初期化
            roopFlag = false;

            System.out.print("\n>");

            try {
                // 標準入力
                stirikePointStr = br.readLine();

                // 整数に変換して格納する
                strikePoint = Integer.parseInt(stirikePointStr);

            // 整数が入力されなかった場合
            } catch (NumberFormatException e) {

                // ループフラグを立てる
                roopFlag = true;

            // それ以外の例外発生時の処理
            } catch (Exception e) {
                e.printStackTrace();
            }

            // ループフラグが立っている場合
            if (roopFlag == true) {

                // エラーメッセージを出力
                System.out.println("\n1～9(半角数字)のみ入力可能です。");

            // 入力値が1～9の範囲に収まっていない場合
            } else if (strikePoint < 1 || 9 < strikePoint) {

                // エラーメッセージを出力
                System.out.println("\n1～9(半角数字)のみ入力可能です。");

                // ループフラグを立てる
                roopFlag = true;
            }

            // ループフラグが立っている場合はくり返す
        } while (roopFlag);

        // 1～9の入力値を0～8に範囲に補正する
        strikePoint--;

        return strikePoint;
    }

    /* (非 Javadoc)
     * @see whacamole.IPlayer#getName()
     */
    @Override
    public String getName() {

        // プレイヤーの名前を返す
        return name;
    }

    /* (非 Javadoc)
     * @see whacamole.IPlayer#setName(java.lang.String)
     */
    @Override
    public void setName(String name) {

        // プレイヤーの名前を設定する
        this.name = name;
    }

    /* (非 Javadoc)
     * @see whacamole.IPlayer#getMoles()
     */
    @Override
    public List<Mole> getMoles() {

        // プレイヤーが所持しているモグラのリストを返す
        return moles;
    }

    /* (非 Javadoc)
     * @see whacamole.IPlayer#setMoles(java.util.List)
     */
    @Override
    public void setMoles(List<Mole> moles) {

        // モグラのリストを登録する
        this.moles = moles;
    }

    /**
     * マス決定機能（ランダム）<br/>
     * マスをランダムに決定する
     *
     * @return ランダムに取得されたマス
     */
    private int getRandomPoint() {

        // 乱数の格納用変数
        int point;

        // 乱数を0～8の範囲で取得
        point = (int) (Math.random() * INCREASE_NUM) % UPPER_LIMIT_NUM;

        return point;
    }

    /**
     * モグラ既設定確認機能<br/>
     * そのマスに先にモグラが設定されているか<br/>
     * 確認する機能
     *
     * @param point 確認対象となるマス
     * @return 先にモグラがいた場合はtrueを返す
     */
    private boolean checkAlreadyStay(int point){

        // 確認用フラグ
        boolean isStay = false;

        // モグラの匹数分くり返す
        for (Mole mole : moles) {

            // 既にモグラがいた場合
            if (mole.getStayPoint() == point) {

                // フラグを立てる
                isStay = true;
            }
        }

        return isStay;
    }
}
