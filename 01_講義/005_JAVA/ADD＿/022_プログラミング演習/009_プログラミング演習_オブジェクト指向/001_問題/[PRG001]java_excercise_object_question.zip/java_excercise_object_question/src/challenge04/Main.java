package challenge04;

/**
 * プログラム実行クラス
 * @author k-mori
 *
 */
public class Main {

	/**
	 * メインメソッド
	 * @param args
	 */
	public static void main(String[] args) {
		new Colosseum().duelling();
	}

}
