package challenge03;

public class Main {

	/**
	 * HumanクラスのtoStringメソッドを出力
	 * 
	 * @param human
	 */
	static void introduce(Human human) {
		System.out.println(human);
	}

	/**
	 * 両者の攻撃と防御を判定し、ダメージ計算を行う
	 * 
	 * @param p1
	 * @param p2
	 */
	static void battle(Gladiator p1, Gladiator p2) {
		// 攻撃実行判定
	}

	/**
	 * メインメソッド
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// 各種クラス、メソッドを組み合わせてプログラムを実装する
	}

}
