package challenge02;

public class Human {
	/** 社員番号のシーケンス */
	private static int empNoSeq = 0;
	/** 部署名 */
	private static final String[] DEPARTMENT = { "営業部", "総務部", "開発部"};
	/** 部署の数 */
	public static final int DEP_NUM = DEPARTMENT.length;

	/** 名前 */
	private String name;
	/** 性別 */
	private String gender;
	/** 年齢 */
	private int age;
	/** 誕生日 */
	private Day birthday;
	/** 部署番号 */
	private int depNo;
	/** 社員番号 */
	private int empNo;

	/**
	 * 引数なしのコンストラクタ
	 * 使ってほしくないのでprivateとする
	 */
	private Human() {
	}

	/**
	 * 引数がnameのみのコンストラクタ
	 * 使ってほしくないのでprivateとする
	 * 
	 * @param name
	 */
	private Human(String name) {
		this.name = name;
	}

	/**
	 * すべてのフィールドを設定するコンストラクタ
	 * 
	 * @param name
	 * @param gender
	 * @param age
	 * @param day
	 */
	public Human(String name, String gender, int age, Day day, int depNo) {
		this(name);
		this.gender = gender;
		this.age = age;
		this.birthday = new Day(day);
		this.depNo = depNo;
		this.empNo = ++empNoSeq;
	}

	/**
	 * 部署名を返すクラスメソッド
	 * 
	 * @param depNo
	 *            部署番号
	 * @return 部署名
	 */
	public static String getDepartment(int depNo) {
		return DEPARTMENT[depNo];
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @return age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @return birthday
	 */
	public Day getBirthday() {
		return birthday;
	}

	/**
	 * @param name
	 *            セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param gender
	 *            セットする gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @param age
	 *            セットする age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @param birthday
	 *            セットする birthday
	 */
	public void setBirthday(Day birthday) {
		this.birthday = birthday;
	}

	/**
	 * @return depNo
	 */
	public int getDepNo() {
		return depNo;
	}

	/**
	 * @return empNo
	 */
	public int getEmpNo() {
		return empNo;
	}

	/**
	 * @param depNo
	 *            セットする depNo
	 */
	public void setDepNo(int depNo) {
		this.depNo = depNo;
	}

	/**
	 * @param empNo
	 *            セットする empNo
	 */
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	/**
	 * 自己紹介を出力する
	 * 社員番号、部署名、名前、性別、年齢、誕生日を出力する
	 */
	public String toString() {
		String str = "社員番号" + empNo + "番、" + getDepartment() + "所属の" + name + "です。" + "性別は" + gender + "です。" + "年齢は"
				+ age + "歳です。\n" + "誕生日は" + birthday + "です。\n" + "";
		return str;
	}

	/**
	 * 自分の部署名を返すインスタンスメソッド
	 * 
	 * @return 部署名
	 */
	public String getDepartment() {
		return getDepartment(this.depNo);
	}
}
