package challenge04;

import java.util.Objects;

import challenge04.character.AbstractHuman;
import challenge04.character.ComputerGladiator;
import challenge04.character.IBattleOperation;
import challenge04.character.PlayerGladiator;

/**
 * 決闘を進行するクラス <br>
 * このクラス内に各種メソッドを組み合わせて結果までを出力する処理を記述する
 * 
 * @author k-mori
 *
 */
public class Colosseum {
	/** P1の勝ち */
	public static final int P1_ATTACK = 0;
	/** P1の負け */
	public static final int P1_DEFFENCE = 1;
	/** 引き分け */
	public static final int DRAW = -1;
	/** キャラクターの人数 */
	public static final int CHAR_NUM = 2;
	/** 攻撃を行う側のインデックス */
	public static final int ATTACKER_INDEX = 0;
	/** 攻撃を受ける側のインデックス */
	public static final int DEFFENCE_INDEX = 1;

	/**
	 * 決闘を進行するメソッド
	 */
	public void duelling() {
		System.out.println("尋常に勝負！");
		// キャラクターをインスタンス化
		// 常にインデックス１が攻撃側、インデックス２が防御側とする
		IBattleOperation[] duelist = { new PlayerGladiator("クロウ", "男", 43, 30),
				new ComputerGladiator("フェニックス", "男", 38, 40) };

		// 決闘を行うループ どちらかのHPが0になるまで繰り返す
		while (duelist[ATTACKER_INDEX].getHp() > 0 && duelist[DEFFENCE_INDEX].getHp() > 0) {
			System.out.println();
			// 攻撃を行うキャラを決定
			// インデックス１が攻撃側、インデックス２が防御側となるように配列をリターンする
			IBattleOperation[] ret = whoAttacker(duelist);
			// 攻撃を実行
			succesAttack(ret);
			// キャラのHPを表示する
			for (IBattleOperation player : duelist) {
				System.out.println("　" + ((AbstractHuman) player).getName() + ":HP " + player.getHp());
			}
		}
		System.out.println();

		System.out.println("勝負あり！！");
		System.out.println("勝者の自己紹介タイム！");
		// 最終結果を判定
		for (IBattleOperation player : duelist) {
			// HPが残っているplayerの自己紹介(toString)を出力する
			if (player.getHp() > 0) {
				// toStringはObjectクラスのメソッドであるためIBattleOperation型でも使える
				System.out.println(player);
			}
		}
	}

	/**
	 * コマンドを入力し、攻撃をどっちが行うかを判定する<br>
	 * インデックス１が攻撃側、インデックス２が防御側となるように配列をリターンする<br>
	 * あいこ(同じコマンド)だった場合はnullを返す
	 * 
	 * @param p1
	 * @param p2
	 * @return 攻撃成功者
	 */
	public IBattleOperation[] whoAttacker(IBattleOperation[] duelist) {
		// コマンドを決定
		int[] chooseCommArray = new int[CHAR_NUM];
		for (int i = 0; i < CHAR_NUM; i++) {
			chooseCommArray[i] = duelist[i].chooseCommand();
		}
		// System.out.println("P1:" +chooseCommArray[0] + "
		// P2:"+chooseCommArray[1]);

		// コマンドを比較し、結果を取得する
		int ret = commandJudge(chooseCommArray);

		// コマンドの結果からMessageを出力
		resultMessage(duelist, ret);

		// コマンドの結果から、攻撃を行うキャラを決定
		if (ret == P1_ATTACK) {
			// p1が攻撃を行うなら配列はそのまま（インデックス0番が攻撃）
		} else if (ret == P1_DEFFENCE) {
			// p2が攻撃を行うなら配列の順番を入れ替える
			IBattleOperation tmp = duelist[ATTACKER_INDEX];
			duelist[ATTACKER_INDEX] = duelist[DEFFENCE_INDEX];
			duelist[DEFFENCE_INDEX] = tmp;
		} else {
			// 引き分けの場合はnullを返す
			return null;
		}
		return duelist;
	}

	/**
	 * 入力されたコマンドから結果を決定する<br>
	 * ジャンケン形式になっており、攻撃→スペシャル→魔法→攻撃の三竦となる
	 * 
	 * @param choseP1
	 * @param choseP2
	 * @return int
	 */
	public int commandJudge(int[] chooseCommArray) {

		// コマンドが同じなら引き分け
		if (chooseCommArray[ATTACKER_INDEX] == chooseCommArray[DEFFENCE_INDEX]) {
			return DRAW;
		}

		// P1を基準に、P1が勝ちならP1_ATTACKを返却する
		switch (chooseCommArray[ATTACKER_INDEX]) {
		case IBattleOperation.COMM_ATTACK:
			if (chooseCommArray[DEFFENCE_INDEX] == IBattleOperation.COMM_SPECIAL) {
				return P1_ATTACK;
			}
			break;
		case IBattleOperation.COMM_MAGIC:
			if (chooseCommArray[DEFFENCE_INDEX] == IBattleOperation.COMM_ATTACK) {
				return P1_ATTACK;
			}
			break;
		case IBattleOperation.COMM_SPECIAL:
			if (chooseCommArray[DEFFENCE_INDEX] == IBattleOperation.COMM_MAGIC) {
				return P1_ATTACK;
			}
			break;
		default:
			break;
		}

		// P1が勝ちの判定にならないなら、P1_DEFFENCEを返却
		return P1_DEFFENCE;
	}

	/**
	 * コマンド判定の結果に応じてメッセージを出力
	 * 
	 * @param p1
	 * @param p2
	 * @param ret
	 */
	public void resultMessage(IBattleOperation[] duelist, int ret) {
		AbstractHuman p1 = (AbstractHuman) duelist[ATTACKER_INDEX];
		AbstractHuman p2 = (AbstractHuman) duelist[DEFFENCE_INDEX];

		// retの内容を確認してメッセージを出力
		if (ret == P1_ATTACK) {
			System.out.println(p1.getName() + "の攻撃がHIT！");
		} else if (ret == P1_DEFFENCE) {
			System.out.println(p2.getName() + "の攻撃がHIT！");
		} else {
			System.out.println("両者ともに動くことができない！");
		}
	}

	/**
	 * 攻撃とダメージ計算を行うメソッド
	 * 
	 * @param duelist
	 */
	public void succesAttack(IBattleOperation[] duelist) {
		// duelistがnullなら引き分けなのでダメージ計算をしない
		if (Objects.isNull(duelist)) {
			return;
		}
		// duelistのインデックス0を攻撃側、インデックス1を防御側としてダメージ計算を行う
		duelist[DEFFENCE_INDEX].damage(duelist[ATTACKER_INDEX].getOffensive());
	}
}
