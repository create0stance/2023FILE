package challenge03;

/**
 * challenge03の実行クラス
 * @author k-mori
 *
 */
public class Main {

	/**
	 * HumanクラスのtoStringメソッドを出力
	 * 
	 * @param human
	 */
	static void introduce(Human human) {
		System.out.println(human);
	}

	/**
	 * 両者の攻撃と防御を判定し、ダメージ計算を行う
	 * 
	 * @param p1
	 * @param p2
	 */
	static void battle(Gladiator p1, Gladiator p2) {
		// 攻撃実行判定
		boolean canAttackP1 = p1.canAttack();
		boolean canAttackP2 = p2.canAttack();

		if (canAttackP1 && canAttackP2) {
			// 両者が攻撃する場合は素のダメージを受ける
			p1.damage(p2.attack());
			p2.damage(p1.attack());
			System.out.println("相打ち！");
		} else if (canAttackP1 && !canAttackP2) {
			// p1の攻撃が成功した
			System.out.println(p1.getName() + "の攻撃");
			// p2が防御に成功するかを判定
			defence(p1, p2);
		} else if (!canAttackP1 && canAttackP2) {
			// p2の攻撃が成功した
			System.out.println(p2.getName() + "の攻撃");
			// p1の防御が成功するかを判定
			defence(p2, p1);
		} else {
			// どちらも攻撃しない場合
			System.out.println("両者は出方を伺っている！");
		}
		System.out.println("\t" + p1.getName() + "：HP " + p1.getHp() + "  " + p2.getName() + "：" + p2.getHp());
	}

	/**
	 * 攻撃に対する防御判定
	 * 
	 * @param attacker
	 * @param defender
	 */
	static void defence(Gladiator attacker, Gladiator defender) {
		if (defender.canDefence()) {
			defender.defence(attacker.attack());
			System.out.println(defender.getName() + "が防御！");
		} else {
			defender.damage(attacker.attack());
			System.out.println("攻撃がクリーンヒット！");
		}
	}

	/**
	 * メインメソッド
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Gladiatorクラスをインスタンス化
		Gladiator p1 = new Gladiator("クロウ", "男", 32, "師匠の剣", 30, "布の盾", 10);
		Gladiator p2 = new Gladiator("フェニックス", "男", 35, "皇帝の剣", 40, "青銅の盾", 20);

		// 試合を開始
		System.out.println("試合始め！！");
		// どちらかのHPが0以下になるまで戦う
		while (p1.getHp() > 0 && p2.getHp() > 0) {
			battle(p1, p2);
		}
		System.out.println();

		// HPが0より多いほうが勝者
		System.out.println("勝者は自己紹介しろ！");
		if (p1.getHp() > 0) {
			introduce(p1);
		} else if (p2.getHp() > 0) {
			introduce(p2);
		} else {
			System.out.println("両者絶命！");
		}
	}

}
