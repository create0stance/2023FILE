package challenge02;

import java.util.Scanner;

/**
 * 自己紹介出力プログラム
 * @author k-mori
 *
 */
public class Introduce {
	/**
	 * mainメソッド
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);

		// Humanのフィールドに代入する値を入力
		System.out.print("あなたの名前は："); String name = stdIn.nextLine();
		System.out.print("あなたの性別は："); String gender = stdIn.nextLine();
		System.out.print("あなたの年齢は："); int age = stdIn.nextInt();
		System.out.print("あなたの誕生日の年は："); int year = stdIn.nextInt();
		System.out.print("あなたの誕生日の月は："); int mounth = stdIn.nextInt();
		System.out.print("あなたの誕生日の日は："); int day = stdIn.nextInt();
		// 部署番号を入れる変数
		int depNo = -1;
		// 部署番号入力ループ
		do {
			System.out.println("あなたの所属部署を選んでください");
			// 部署の数だけループする ループ上限にはクラス変数を使っている
			for (int i = 0; i < Human.DEP_NUM; i++) {
				// 部署名をクラスメソッドを使って取得し、出力する
				System.out.print(i + 1 + ":" + Human.getDepartment(i) + " ");
			}
			System.out.print("：");
			depNo = stdIn.nextInt() - 1;
			// 入力値が0未満または部署数以上なら再入力させる
		} while (depNo < 0 || depNo >= Human.DEP_NUM);

		// Humanクラスのmeを宣言、Humanクラスをインスタンス化する
		Human me = new Human(name, gender, age, new Day(year, mounth, day), depNo);

		// 自己紹介の出力
		System.out.println("\n改めて自己紹介します。");
		System.out.println(me);
		
		stdIn.close();
		
	}

}
